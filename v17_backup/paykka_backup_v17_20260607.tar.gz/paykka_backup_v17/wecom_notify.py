#!/usr/bin/env python3
"""
企微 Webhook 通知工具
支持文本、Markdown、图文等多种消息类型
适用于 Paykka 自动化系统的清算通知场景

⚠️ 重要提醒：此为工作群，请勿随意发送测试消息。
   仅在用户明确指令或自动化流程触发时才发送通知。
"""

import json
import sys
import requests
from datetime import datetime

# 默认 Webhook URL
DEFAULT_WEBHOOK_URL = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=4c15eb09-0b7d-4ca7-b378-ae169ddc4917"


def send_text(content: str, webhook_url: str = DEFAULT_WEBHOOK_URL, mentioned_list: list = None) -> dict:
    """
    发送纯文本消息
    :param content: 消息内容（最长2048字节）
    :param webhook_url: Webhook 地址
    :param mentioned_list: @指定成员，如 ["@all"] 或 ["zhangsan"]
    """
    data = {
        "msgtype": "text",
        "text": {
            "content": content,
        }
    }
    if mentioned_list:
        data["text"]["mentioned_list"] = mentioned_list
    return _post(webhook_url, data)


def send_markdown(content: str, webhook_url: str = DEFAULT_WEBHOOK_URL) -> dict:
    """
    发送 Markdown 格式消息
    :param content: Markdown 内容
    """
    data = {
        "msgtype": "markdown",
        "markdown": {
            "content": content
        }
    }
    return _post(webhook_url, data)


def send_news(articles: list, webhook_url: str = DEFAULT_WEBHOOK_URL) -> dict:
    """
    发送图文消息（最多8条）
    :param articles: 图文列表，每条含 title, description(可选), url(可选), picurl(可选)
    """
    data = {
        "msgtype": "news",
        "news": {
            "articles": articles[:8]  # 企微限制最多8条
        }
    }
    return _post(webhook_url, data)


def send_file(media_id: str, webhook_url: str = DEFAULT_WEBHOOK_URL) -> dict:
    """
    发送文件消息（需先通过 upload_file 上传获取 media_id）
    """
    data = {
        "msgtype": "file",
        "file": {
            "media_id": media_id
        }
    }
    return _post(webhook_url, data)


def upload_file(file_path: str, webhook_url: str = DEFAULT_WEBHOOK_URL) -> dict:
    """
    上传文件获取 media_id
    :param file_path: 本地文件路径（≤20MB）
    :return: {"errcode":0, "errmsg":"ok", "media_id":"xxx"}
    """
    key = webhook_url.split("key=")[-1]
    upload_url = f"https://qyapi.weixin.qq.com/cgi-bin/webhook/upload_media?key={key}&type=file"
    with open(file_path, "rb") as f:
        resp = requests.post(upload_url, files={"media": (file_path.split("/")[-1], f)})
    return resp.json()


def notify_paykka_status(status_type: str, details: str, extra: dict = None) -> dict:
    """
    Paykka 系统状态通知（预设模板）
    :param status_type: 状态类型：success / warning / error / info
    :param details: 通知详情
    :param extra: 额外字段，如 {"平台": "YeePay", "币种": "USD"}
    """
    icons = {
        "success": "✅",
        "warning": "⚠️",
        "error": "❌",
        "info": "ℹ️",
    }
    icon = icons.get(status_type, "📌")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    content = f"{icon} **Paykka 系统通知**\n> 时间：{now}\n> 状态：{status_type.upper()}\n> 详情：{details}"

    if extra:
        for k, v in extra.items():
            content += f"\n> {k}：{v}"

    return send_markdown(content)


def notify_balance_check(platform: str, currency: str, balance: str, status: str = "正常") -> dict:
    """
    余额核对通知
    """
    return notify_paykka_status(
        "success" if status == "正常" else "warning",
        f"{platform} {currency} 账户余额核对{status}",
        {"平台": platform, "币种": currency, "余额": balance, "状态": status}
    )


def notify_route_switch(from_route: str, to_route: str, reason: str = "") -> dict:
    """
    路由切换通知
    """
    detail = f"路由从 [{from_route}] 切换至 [{to_route}]"
    if reason:
        detail += f"（原因：{reason}）"
    return notify_paykka_status("info", detail)


def _post(url: str, data: dict) -> dict:
    """发送 POST 请求"""
    try:
        resp = requests.post(url, json=data, timeout=10)
        result = resp.json()
        if result.get("errcode") == 0:
            print(f"✅ 企微消息发送成功")
        else:
            print(f"❌ 发送失败: {result}")
        return result
    except Exception as e:
        print(f"❌ 请求异常: {e}")
        return {"errcode": -1, "errmsg": str(e)}


# ==================== 命令行入口 ====================
if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法:")
        print("  python wecom_notify.py text <消息内容>")
        print("  python wecom_notify.py markdown <Markdown内容>")
        print("  python wecom_notify.py balance <平台> <币种> <余额> [状态]")
        print("  python wecom_notify.py route <原路由> <新路由> [原因]")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "text":
        content = sys.argv[2] if len(sys.argv) > 2 else "测试消息"
        send_text(content)

    elif cmd == "markdown":
        content = sys.argv[2] if len(sys.argv) > 2 else "**测试** Markdown 消息"
        send_markdown(content)

    elif cmd == "balance":
        if len(sys.argv) < 5:
            print("用法: python wecom_notify.py balance <平台> <币种> <余额> [状态]")
            sys.exit(1)
        platform, currency, balance = sys.argv[2], sys.argv[3], sys.argv[4]
        status = sys.argv[5] if len(sys.argv) > 5 else "正常"
        notify_balance_check(platform, currency, balance, status)

    elif cmd == "route":
        if len(sys.argv) < 4:
            print("用法: python wecom_notify.py route <原路由> <新路由> [原因]")
            sys.exit(1)
        from_route, to_route = sys.argv[2], sys.argv[3]
        reason = sys.argv[4] if len(sys.argv) > 4 else ""
        notify_route_switch(from_route, to_route, reason)

    else:
        print(f"未知命令: {cmd}")
        sys.exit(1)
