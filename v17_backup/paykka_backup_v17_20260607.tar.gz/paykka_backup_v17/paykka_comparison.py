# ===================== paykka_comparison.py =====================
# QuoteComparisonEngine - 渠道与友商历史报价对比引擎
# 集成到 Paykka Controller V17 命令系统中
#
# 支持:
#   - 渠道: YB, MDAQ_FX_TOM, BOC, HCE_FX_TOM（通过 PaykkaHistoryQuoteQuery）
#   - 友商: XT, WF, LL（通过 CompetitorHistoryQuery）
#   - 时间范围: 1天/3天/7天
#   - 货币对: 任意6位货币对（如 USDCNH, NGNUSD）
#
# 输出:
#   - 多源叠加对比图表 (matplotlib)
#   - Excel 导出 (pandas + openpyxl)
#   - 文本汇总

import json
import os
import sys
import logging
import traceback
from typing import List, Dict, Tuple, Any, Optional
from datetime import datetime, timedelta, timezone as tz_module

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.font_manager as fm
import pandas as pd
import numpy as np

sys.path.insert(0, '/workspace')

from paykka_competitor import CompetitorHistoryQuery
from paykka_history_quote import PaykkaHistoryQuoteQuery

logger = logging.getLogger('paykka_integrated')

# ===================== 常量定义 =====================

# 默认渠道列表
DEFAULT_CHANNEL_SOURCES = ["YB", "MDAQ_FX_TOM", "BOC", "HCE_FX_TOM"]

# 默认友商列表
DEFAULT_COMPETITOR_SOURCES = ["XT"]

# 所有支持的渠道
ALL_CHANNELS = [
    "YB", "MDAQ_FX_TOM", "BOC", "HCE_FX_TOM",
    "MDAQ", "MDAQ_FX_SPOT", "HCE_FX_SPOT", "HCE_FX_TOD",
    "PP", "OCBC", "CC",
]

# 所有支持的友商（历史数据）
ALL_COMPETITORS = ["XT", "WF", "LL"]

# 友商显示名称
COMPETITOR_NAMES = {
    "XT": "XTransfer",
    "WF": "WorldFirst",
    "LL": "LianLian",
}

# 渠道显示名称
CHANNEL_NAMES = {
    "YB": "易宝(YB)",
    "MDAQ_FX_TOM": "MDAQ(TOM)",
    "BOC": "中国银行(BOC)",
    "HCE_FX_TOM": "HCE(TOM)",
    "MDAQ": "MDAQ",
    "MDAQ_FX_SPOT": "MDAQ(Spot)",
    "HCE_FX_SPOT": "HCE(Spot)",
    "HCE_FX_TOD": "HCE(TOD)",
    "PP": "PingPong",
    "OCBC": "OCBC",
    "CC": "Currencycloud",
}

# 图表颜色
SOURCE_COLORS = {
    "YB": "#2196F3",
    "MDAQ_FX_TOM": "#4CAF50",
    "BOC": "#FF9800",
    "HCE_FX_TOM": "#9C27B0",
    "XT": "#E91E63",
    "WF": "#00BCD4",
    "LL": "#795548",
    "MDAQ": "#607D8B",
    "MDAQ_FX_SPOT": "#8BC34A",
    "HCE_FX_SPOT": "#CDDC39",
    "HCE_FX_TOD": "#FFC107",
    "PP": "#F44336",
    "OCBC": "#3F51B5",
    "CC": "#009688",
}

SOURCE_MARKERS = {
    "YB": "o",
    "MDAQ_FX_TOM": "s",
    "BOC": "^",
    "HCE_FX_TOM": "v",
    "XT": "D",
    "WF": "p",
    "LL": "*",
    "MDAQ": "h",
    "MDAQ_FX_SPOT": "P",
    "HCE_FX_SPOT": "X",
    "HCE_FX_TOD": "d",
    "PP": "<",
    "OCBC": ">",
    "CC": "H",
}

# XT 支持的货币对（XT API 只支持 CNY，不支持 CNH）
XT_CNY_ONLY = True  # XT 的 getWithSource API 只返回 CNY 数据

# 输出目录
OUTPUT_DIR = "/workspace/logs"
CHART_DIR = "/workspace/logs/charts"

# ===================== 引擎类 =====================

class QuoteComparisonEngine:
    """渠道与友商历史报价对比引擎
    
    统一查询渠道（通过 OPS API）和友商（通过各友商 API）的历史报价，
    生成对比图表、Excel 和文本汇总。
    """
    
    def __init__(self, token: str):
        """初始化对比引擎
        
        Args:
            token: OPS API 认证 token（用于查询渠道数据）
        """
        self.token = token
        self._channel_query = None
        self._competitor_query = None
        
        os.makedirs(CHART_DIR, exist_ok=True)
    
    def _get_channel_query(self) -> PaykkaHistoryQuoteQuery:
        """获取渠道查询器（延迟初始化）"""
        if self._channel_query is None:
            self._channel_query = PaykkaHistoryQuoteQuery(self.token)
        return self._channel_query
    
    def _get_competitor_query(self) -> CompetitorHistoryQuery:
        """获取友商查询器（延迟初始化）"""
        if self._competitor_query is None:
            self._competitor_query = CompetitorHistoryQuery()
        return self._competitor_query
    
    # ===================== 主入口 =====================
    
    def run_comparison(
        self,
        base_currency: str = "USD",
        quote_currency: str = "CNH",
        days: int = 3,
        channel_sources: Optional[List[str]] = None,
        competitor_sources: Optional[List[str]] = None,
    ) -> Dict:
        """执行完整的多方报价对比
        
        Args:
            base_currency: 基础货币（如 USD）
            quote_currency: 报价货币（如 CNH）
            days: 查询天数（1/3/7）
            channel_sources: 渠道列表，None 表示默认全部
            competitor_sources: 友商列表，None 表示默认 XT
        
        Returns:
            {
                "success": bool,
                "pair": str,                    # 显示的货币对
                "base_currency": str,
                "quote_currency": str,
                "days": int,
                "results": {source_name: {...}},
                "chart_path": str,
                "xlsx_path": str,
                "raw_path": str,
                "summary": str,
                "warnings": [str],
                "error": str,
            }
        """
        if channel_sources is None:
            channel_sources = DEFAULT_CHANNEL_SOURCES.copy()
        if competitor_sources is None:
            competitor_sources = DEFAULT_COMPETITOR_SOURCES.copy()
        
        pair = f"{base_currency}/{quote_currency}"
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        warnings = []
        
        result = {
            "success": False,
            "pair": pair,
            "base_currency": base_currency,
            "quote_currency": quote_currency,
            "days": days,
            "results": {},
            "chart_path": "",
            "xlsx_path": "",
            "raw_path": "",
            "summary": "",
            "warnings": warnings,
            "error": "",
        }
        
        logger.info(f"📊 启动多方报价对比: {pair}, {days}天, 渠道={channel_sources}, 友商={competitor_sources}")
        
        # ========== 阶段1：查询渠道数据 ==========
        channel_data = self._query_channels(base_currency, quote_currency, days, channel_sources)
        if channel_data.get("error"):
            warnings.append(f"⚠️ 渠道查询部分失败: {channel_data['error']}")
        
        # ========== 阶段2：查询友商数据 ==========
        competitor_data = self._query_competitors(base_currency, quote_currency, days, competitor_sources)
        if competitor_data.get("error"):
            warnings.append(f"⚠️ 友商查询部分失败: {competitor_data['error']}")
        
        # ========== 阶段3：汇总结果 ==========
        all_results = {}
        all_results.update(channel_data.get("results", {}))
        all_results.update(competitor_data.get("results", {}))
        result["results"] = all_results
        
        # 检查是否有任何成功的数据
        any_success = any(
            r.get("success") and r.get("data")
            for r in all_results.values()
        )
        if not any_success:
            result["error"] = "所有来源均查询失败，无法生成对比"
            result["summary"] = "❌ 报价对比失败：所有来源均无数据\n" + "\n".join(warnings)
            return result
        
        result["success"] = True
        
        # ========== 阶段4：生成图表 ==========
        chart_path = self._generate_chart(all_results, pair, days, warnings)
        result["chart_path"] = chart_path
        
        # ========== 阶段5：导出 Excel ==========
        xlsx_path = self._export_excel(all_results, pair, days)
        result["xlsx_path"] = xlsx_path
        
        # ========== 阶段6：保存原始数据 ==========
        raw_path = os.path.join(OUTPUT_DIR, f"compare_raw_{timestamp}.json")
        try:
            serializable = {}
            for src_name, src_data in all_results.items():
                serializable[src_name] = {
                    "source": src_data.get("source", src_name),
                    "pair": src_data.get("pair", pair),
                    "success": src_data.get("success", False),
                    "error": src_data.get("error", ""),
                    "data_count": len(src_data.get("data", [])),
                    "data": src_data.get("data", []),
                }
            serializable["metadata"] = {
                "pair": pair,
                "days": days,
                "query_time": datetime.now().isoformat(),
                "channels": channel_sources,
                "competitors": competitor_sources,
                "warnings": warnings,
            }
            with open(raw_path, "w") as f:
                json.dump(serializable, f, ensure_ascii=False, indent=2, default=str)
            result["raw_path"] = raw_path
            logger.info(f"💾 原始数据已保存: {raw_path}")
        except Exception as e:
            logger.warning(f"保存原始数据失败: {e}")
        
        # ========== 阶段7：生成文本汇总 ==========
        result["summary"] = self._format_summary(all_results, pair, days, chart_path, xlsx_path, warnings)
        
        logger.info(f"✅ 报价对比完成: {pair}, {len(all_results)} 个来源, {sum(len(r.get('data',[])) for r in all_results.values())} 条数据")
        return result
    
    # ===================== 渠道查询 =====================
    
    def _query_channels(
        self,
        base_currency: str,
        quote_currency: str,
        days: int,
        sources: List[str],
    ) -> Dict:
        """查询渠道历史报价"""
        result = {"results": {}, "error": ""}
        
        try:
            hq = self._get_channel_query()
            channel_result = hq.query_history(
                base_currency=base_currency,
                quote_currency=quote_currency,
                days=days,
                sources=sources,
            )
            
            if not channel_result.get("success"):
                result["error"] = f"渠道查询失败: {channel_result.get('error', '未知')}"
                # 即使失败也尝试为每个来源创建空结果
                for src in sources:
                    result["results"][src] = {
                        "source": src,
                        "pair": f"{base_currency}/{quote_currency}",
                        "success": False,
                        "error": result["error"],
                        "data": [],
                    }
                return result
            
            # 按来源拆分数据并标准化
            records = channel_result.get("records", [])
            by_source = {src: [] for src in sources}
            
            for rec in records:
                src = rec.get("source", "")
                if src in by_source:
                    normalized = self._normalize_channel_record(rec, src)
                    by_source[src].append(normalized)
            
            for src in sources:
                data = by_source[src]
                result["results"][src] = {
                    "source": src,
                    "pair": f"{base_currency}/{quote_currency}",
                    "success": len(data) > 0,
                    "error": "" if data else f"{src} 无有效数据",
                    "data": data,
                }
                logger.info(f"  渠道 {src}: {len(data)} 条记录")
            
        except Exception as e:
            logger.error(f"渠道查询异常: {e}")
            result["error"] = f"渠道查询异常: {str(e)[:80]}"
            for src in sources:
                if src not in result["results"]:
                    result["results"][src] = {
                        "source": src,
                        "pair": f"{base_currency}/{quote_currency}",
                        "success": False,
                        "error": str(e)[:80],
                        "data": [],
                    }
        
        return result
    
    def _normalize_channel_record(self, rec: Dict, source: str) -> Dict:
        """标准化渠道记录：字段映射 + UTC→北京时间转换
        
        PaykkaHistoryQuoteQuery 返回:
            release_time: UTC ISO 格式（如 "2026-06-04T14:29:40Z"）
            bid_rate: 报价汇率
        
        转换为统一格式:
            time: "YYYY-MM-DD HH:MM" (北京时间)
            rate: float
            source_name: 来源标识
        """
        time_str = rec.get("release_time", rec.get("time", ""))
        rate_val = float(rec.get("bid_rate", rec.get("rate", 0)))
        
        # UTC → 北京时间 (UTC+8)
        try:
            if 'T' in time_str:
                dt = datetime.fromisoformat(time_str.replace('Z', '+00:00'))
                dt = dt.astimezone(tz_module(timedelta(hours=8)))
                time_str = dt.strftime("%Y-%m-%d %H:%M")
        except Exception:
            # 保持原样
            pass
        
        return {
            "time": time_str,
            "rate": rate_val,
            "source_name": source,
        }
    
    # ===================== 友商查询 =====================
    
    def _query_competitors(
        self,
        base_currency: str,
        quote_currency: str,
        days: int,
        sources: List[str],
    ) -> Dict:
        """查询友商历史报价"""
        result = {"results": {}, "error": ""}
        errors = []
        
        for src in sources:
            src_upper = src.upper()
            try:
                cq = self._get_competitor_query()
                
                # XT 特殊处理：如果 quote_currency 是 CNH，XT 只能用 CNY
                actual_quote = quote_currency
                if src_upper == "XT" and quote_currency.upper() == "CNH":
                    actual_quote = "CNY"
                    logger.info(f"  XT 不支持 CNH，自动切换为 CNY")
                
                query_result = cq.query_history(
                    source=src_upper,
                    from_ccy=base_currency,
                    to_ccy=actual_quote,
                    days=days,
                )
                
                # 标准化字段名（XT 返回的字段可能略有不同）
                if query_result.get("success") and query_result.get("data"):
                    normalized_data = []
                    for item in query_result["data"]:
                        normalized_data.append({
                            "time": item.get("time", ""),
                            "rate": float(item.get("rate", 0)),
                            "source_name": item.get("source_name", src_upper),
                        })
                    query_result["data"] = normalized_data
                
                result["results"][src_upper] = query_result
                
                if query_result.get("success"):
                    logger.info(f"  友商 {src_upper}: {len(query_result['data'])} 条记录")
                else:
                    errors.append(f"{src_upper}: {query_result.get('error', '未知错误')}")
                    
            except Exception as e:
                logger.error(f"友商 {src_upper} 查询异常: {e}")
                errors.append(f"{src_upper}: {str(e)[:60]}")
                result["results"][src_upper] = {
                    "source": src_upper,
                    "pair": f"{base_currency}/{quote_currency}",
                    "success": False,
                    "error": str(e)[:80],
                    "data": [],
                }
        
        if errors and len(errors) == len(sources):
            result["error"] = "; ".join(errors)
        elif errors:
            result["error"] = "部分友商查询失败: " + "; ".join(errors)
        
        return result
    
    # ===================== 图表生成 =====================
    
    def _generate_chart(
        self,
        all_results: Dict,
        pair: str,
        days: int,
        warnings: List[str],
    ) -> str:
        """生成多源叠加对比图表"""
        try:
            # 设置中文字体
            cjk_font_path = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
            if os.path.exists(cjk_font_path):
                cjk_prop = fm.FontProperties(fname=cjk_font_path)
                plt.rcParams['font.family'] = cjk_prop.get_name()
            plt.rcParams['axes.unicode_minus'] = False
            
            # 收集所有成功的数据源
            active_sources = []
            for src_name in sorted(all_results.keys()):
                src = all_results[src_name]
                if src.get("success") and src.get("data"):
                    active_sources.append(src_name)
            
            if not active_sources:
                logger.warning("无有效数据可生成图表")
                return ""
            
            fig, ax = plt.subplots(figsize=(14, 8))
            
            all_rates = []
            for src_name in active_sources:
                src = all_results[src_name]
                times = []
                rates = []
                
                for d in src["data"]:
                    try:
                        t = datetime.strptime(d["time"], "%Y-%m-%d %H:%M")
                    except Exception:
                        try:
                            t = datetime.strptime(d["time"], "%Y-%m-%d %H:%M:%S")
                        except Exception:
                            continue
                    times.append(t)
                    rates.append(float(d.get("rate", 0)))
                
                if not times:
                    continue
                
                all_rates.extend(rates)
                
                color = SOURCE_COLORS.get(src_name, "#999999")
                marker = SOURCE_MARKERS.get(src_name, ".")
                display_name = CHANNEL_NAMES.get(src_name, COMPETITOR_NAMES.get(src_name, src_name))
                
                ax.plot(times, rates, color=color, linewidth=1.5, marker=marker,
                        markersize=4, alpha=0.85, label=f'{display_name} ({len(times)}条)')
            
            # 标题和标签
            title = f'{pair} 历史汇率对比 ({days}天)'
            if warnings:
                title += f' [{" ".join(warnings)}]'
            ax.set_title(title, fontsize=14, fontweight='bold')
            ax.set_xlabel('时间 (北京时间)', fontsize=11)
            ax.set_ylabel(f'汇率 ({pair})', fontsize=11)
            ax.legend(loc='best', fontsize=9)
            ax.grid(True, alpha=0.3)
            
            # X 轴格式
            if len(all_rates) > 50:
                ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
                ax.xaxis.set_major_locator(mdates.AutoDateLocator())
            else:
                ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d %H:%M'))
            plt.xticks(rotation=30, ha='right')
            
            # Y 轴范围微调
            if all_rates:
                y_min, y_max = min(all_rates), max(all_rates)
                y_range = y_max - y_min
                if y_range > 0:
                    ax.set_ylim(y_min - y_range * 0.1, y_max + y_range * 0.1)
            
            fig.tight_layout()
            
            # 保存
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe_pair = pair.replace("/", "_")
            sources_tag = "_".join(active_sources[:4])
            if len(active_sources) > 4:
                sources_tag += f"_等{len(active_sources)}家"
            chart_path = os.path.join(
                CHART_DIR,
                f"compare_{sources_tag}_{safe_pair}_{days}d_{timestamp}.png"
            )
            
            plt.savefig(chart_path, dpi=150, bbox_inches='tight')
            plt.close(fig)
            
            logger.info(f"📊 对比图表已生成: {chart_path}")
            return chart_path
            
        except Exception as e:
            logger.error(f"生成图表失败: {e}")
            logger.error(traceback.format_exc())
            return ""
    
    # ===================== Excel 导出 =====================
    
    def _export_excel(self, all_results: Dict, pair: str, days: int) -> str:
        """导出对比数据到 Excel"""
        try:
            rows = []
            for src_name in sorted(all_results.keys()):
                src = all_results[src_name]
                if src.get("success") and src.get("data"):
                    display_name = CHANNEL_NAMES.get(src_name, COMPETITOR_NAMES.get(src_name, src_name))
                    for d in src["data"]:
                        rows.append({
                            "来源": display_name,
                            "来源代码": src_name,
                            "时间": d.get("time", ""),
                            "汇率": float(d.get("rate", 0)),
                            "来源子类": d.get("source_name", src_name),
                        })
            
            if not rows:
                logger.warning("无数据可导出到 Excel")
                return ""
            
            df = pd.DataFrame(rows)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            safe_pair = pair.replace("/", "_")
            xlsx_path = os.path.join(OUTPUT_DIR, f"compare_{safe_pair}_{days}d_{timestamp}.xlsx")
            
            with pd.ExcelWriter(xlsx_path, engine='openpyxl') as writer:
                # Sheet 1: 明细数据
                df.to_excel(writer, sheet_name='明细数据', index=False)
                
                # Sheet 2: 汇总统计
                summary_rows = []
                for src_name in sorted(all_results.keys()):
                    src = all_results[src_name]
                    if src.get("success") and src.get("data"):
                        display_name = CHANNEL_NAMES.get(src_name, COMPETITOR_NAMES.get(src_name, src_name))
                        rates = [float(d.get("rate", 0)) for d in src["data"] if d.get("rate")]
                        if rates:
                            avg = sum(rates) / len(rates)
                            variance = sum((r - avg) ** 2 for r in rates) / len(rates)
                            summary_rows.append({
                                "来源": display_name,
                                "来源代码": src_name,
                                "货币对": src.get("pair", pair),
                                "数据条数": len(src["data"]),
                                "平均汇率": round(avg, 6),
                                "最高汇率": round(max(rates), 6),
                                "最低汇率": round(min(rates), 6),
                                "标准差": round(variance ** 0.5, 6),
                                "波动率(bps)": round((max(rates) - min(rates)) / avg * 10000, 1),
                            })
                
                if summary_rows:
                    pd.DataFrame(summary_rows).to_excel(writer, sheet_name='汇总统计', index=False)
                
                # Sheet 3: 参数信息
                param_rows = [
                    {"参数": "货币对", "值": pair},
                    {"参数": "查询天数", "值": f"{days}天"},
                    {"参数": "生成时间", "值": datetime.now().strftime("%Y-%m-%d %H:%M:%S")},
                    {"参数": "数据来源数", "值": len(summary_rows)},
                    {"参数": "总记录数", "值": len(rows)},
                ]
                pd.DataFrame(param_rows).to_excel(writer, sheet_name='查询参数', index=False)
            
            logger.info(f"📋 Excel 已导出: {xlsx_path}")
            return xlsx_path
            
        except Exception as e:
            logger.error(f"导出 Excel 失败: {e}")
            logger.error(traceback.format_exc())
            return ""
    
    # ===================== 文本汇总 =====================
    
    def _format_summary(
        self,
        all_results: Dict,
        pair: str,
        days: int,
        chart_path: str,
        xlsx_path: str,
        warnings: List[str],
    ) -> str:
        """生成文本格式的对比汇总"""
        lines = []
        lines.append(f"📊 报价对比结果")
        lines.append(f"货币对: {pair} | 时间范围: {days}天")
        lines.append(f"查询时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append("=" * 50)
        
        # 分类显示
        channel_sources = []
        competitor_sources = []
        
        for src_name in sorted(all_results.keys()):
            src = all_results[src_name]
            display_name = CHANNEL_NAMES.get(src_name, COMPETITOR_NAMES.get(src_name, src_name))
            
            if src_name in CHANNEL_NAMES:
                channel_sources.append((src_name, display_name, src))
            else:
                competitor_sources.append((src_name, display_name, src))
        
        # 渠道部分
        if channel_sources:
            lines.append(f"\n🏦 渠道报价 ({len(channel_sources)}家):")
            lines.append("-" * 40)
            for src_name, display_name, src in channel_sources:
                if src.get("success") and src.get("data"):
                    data = src["data"]
                    rates = [d.get("rate", 0) for d in data]
                    avg = sum(rates) / len(rates) if rates else 0
                    lines.append(
                        f"  ✅ {display_name:20s} | {len(data):4d} 条 "
                        f"| 均值 {avg:.5f} | 范围 [{min(rates):.5f} - {max(rates):.5f}]"
                    )
                else:
                    lines.append(f"  ❌ {display_name:20s} | {src.get('error', '查询失败')}")
        
        # 友商部分
        if competitor_sources:
            lines.append(f"\n🏢 友商报价 ({len(competitor_sources)}家):")
            lines.append("-" * 40)
            for src_name, display_name, src in competitor_sources:
                if src.get("success") and src.get("data"):
                    data = src["data"]
                    rates = [d.get("rate", 0) for d in data]
                    avg = sum(rates) / len(rates) if rates else 0
                    actual_pair = src.get("pair", pair)
                    pair_note = ""
                    if actual_pair != pair:
                        pair_note = f" (实际: {actual_pair})"
                    lines.append(
                        f"  ✅ {display_name:20s} | {len(data):4d} 条 "
                        f"| 均值 {avg:.5f} | 范围 [{min(rates):.5f} - {max(rates):.5f}]{pair_note}"
                    )
                else:
                    lines.append(f"  ❌ {display_name:20s} | {src.get('error', '查询失败')}")
        
        # 警告
        if warnings:
            lines.append(f"\n⚠️ 注意事项:")
            for w in warnings:
                lines.append(f"  {w}")
        
        # XT CNY/CNH 提示
        has_xt = any(s == "XT" for s, _, _ in competitor_sources)
        has_cnh_channels = any(
            s in channel_sources_dict and s in ["YB", "MDAQ_FX_TOM", "BOC", "HCE_FX_TOM"]
            for s, _, _ in channel_sources
        )
        # 简化：如果 pair 包含 CNH 且有 XT
        if "CNH" in pair.upper() and has_xt:
            lines.append(f"\n💡 说明: XT 仅支持 USD/CNY（在岸），其余渠道为 USD/CNH（离岸）")
            lines.append(f"   在岸/离岸基差约 100-200 pips，属正常市场现象")
        
        # 产出文件
        if chart_path and os.path.exists(chart_path):
            lines.append(f"\n📊 图表: 已生成")
            lines.append(f"[CHART:{chart_path}]")
        if xlsx_path and os.path.exists(xlsx_path):
            lines.append(f"📋 Excel: {os.path.basename(xlsx_path)}")
        
        # 统计所有来源
        total_records = sum(
            len(src.get("data", []))
            for src in all_results.values()
            if src.get("success")
        )
        lines.append(f"\n📈 总计: {total_records} 条数据, {len([s for s in all_results.values() if s.get('success')])} 个来源成功")
        
        return "\n".join(lines)


# ===================== 便捷函数 =====================

def run_comparison_from_args(
    token: str,
    pair_str: str = "USDCNH",
    days: int = 3,
    channels: Optional[List[str]] = None,
    competitors: Optional[List[str]] = None,
) -> Dict:
    """从参数快速执行对比
    
    Args:
        token: OPS API token
        pair_str: 6位货币对字符串（如 "USDCNH"）
        days: 天数
        channels: 渠道列表
        competitors: 友商列表
    
    Returns:
        QuoteComparisonEngine.run_comparison() 的结果
    """
    # 解析货币对
    if len(pair_str) >= 6:
        base = pair_str[:3].upper()
        quote = pair_str[3:6].upper()
    else:
        base, quote = "USD", "CNH"
    
    engine = QuoteComparisonEngine(token)
    return engine.run_comparison(
        base_currency=base,
        quote_currency=quote,
        days=days,
        channel_sources=channels,
        competitor_sources=competitors,
    )


# 方便外部获取的 source → dict 映射
channel_sources_dict = {
    "YB": True, "MDAQ_FX_TOM": True, "BOC": True, "HCE_FX_TOM": True,
    "MDAQ": True, "MDAQ_FX_SPOT": True, "HCE_FX_SPOT": True,
    "HCE_FX_TOD": True, "PP": True, "OCBC": True, "CC": True,
}
