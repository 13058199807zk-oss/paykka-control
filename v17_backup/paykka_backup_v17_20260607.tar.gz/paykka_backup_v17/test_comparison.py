#!/usr/bin/env python3
"""测试 QuoteComparisonEngine 完整流程"""
import sys, json, os, logging, time
sys.path.insert(0, '/workspace')
logging.basicConfig(level=logging.WARNING)

from paykka_comparison import QuoteComparisonEngine
from paykka_controllerV16 import PaykkaSystemManager

# 等待 Token 就绪
print('获取 Token...')
mgr = PaykkaSystemManager()
for i in range(45):
    if mgr._token:
        break
    time.sleep(2)

token = mgr._token
if not token:
    print('❌ Token 获取失败')
    sys.exit(1)

print(f'✅ Token 就绪 (长度: {len(token)})')

# ========== 测试1: 默认参数 ==========
print()
print('=' * 60)
print('测试1: 默认 (USD/CNH, 3天, YB+MDAQ+BOC+HCE + XT)')
print('=' * 60)

engine = QuoteComparisonEngine(token)
result = engine.run_comparison(
    base_currency='USD',
    quote_currency='CNH',
    days=3,
)

print(f'success: {result["success"]}')
print(f'pair: {result["pair"]}')
print(f'warnings: {result["warnings"]}')
print()

for src_name, src_data in sorted(result['results'].items()):
    status = '✅' if src_data.get('success') else '❌'
    count = len(src_data.get('data', []))
    error = src_data.get('error', '')
    if error:
        print(f'  {status} {src_name}: {count} 条 - {error[:80]}')
    else:
        rates = [d.get('rate', 0) for d in src_data.get('data', [])]
        if rates:
            print(f'  {status} {src_name}: {count} 条, 范围 [{min(rates):.5f} ~ {max(rates):.5f}]')
        else:
            print(f'  {status} {src_name}: {count} 条')

print(f'\nchart: {os.path.basename(result["chart_path"]) if result["chart_path"] else "无"}')
print(f'xlsx: {os.path.basename(result["xlsx_path"]) if result["xlsx_path"] else "无"}')
print(f'raw: {os.path.basename(result["raw_path"]) if result["raw_path"] else "无"}')
print(f'chart_exists: {os.path.exists(result["chart_path"]) if result["chart_path"] else False}')
print(f'xlsx_exists: {os.path.exists(result["xlsx_path"]) if result["xlsx_path"] else False}')

print()
print(result['summary'][:600])
