# ===================== paykka_config.py =====================
# 全局配置变量 + 日志初始化
# 从 paykka_controllerV16.py 提取，拆分后独立模块
# 敏感凭据通过 .env 文件加载，源码中不包含任何明文密码/Token

import os
import logging
from logging.handlers import RotatingFileHandler

# ===================== 加载 .env 凭据 =====================
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env'))
except ImportError:
    # fallback: 手动解析 .env
    _env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env')
    if os.path.exists(_env_path):
        with open(_env_path, 'r') as _f:
            for _line in _f:
                _line = _line.strip()
                if _line and not _line.startswith('#') and '=' in _line:
                    _key, _, _val = _line.partition('=')
                    _key = _key.strip()
                    _val = _val.strip()
                    if _key not in os.environ:
                        os.environ[_key] = _val

# ===================== 全局配置 =====================
# PAYKKA登录凭据
PAYKKA_USERNAME = os.getenv("PAYKKA_USERNAME", "")
PAYKKA_PASSWORD = os.getenv("PAYKKA_PASSWORD", "")
PAYKKA_OTP_SECRET = os.getenv("PAYKKA_OTP_SECRET", "")

# 飞书机器人配置
LARK_APP_ID = os.getenv("LARK_APP_ID", "")
LARK_APP_SECRET = os.getenv("LARK_APP_SECRET", "")
LARK_ENCRYPT_KEY = os.getenv("LARK_ENCRYPT_KEY", "")
LARK_VERIFICATION_TOKEN = os.getenv("LARK_VERIFICATION_TOKEN", "")

# 企业微信群机器人Webhook地址
WECHAT_WEBHOOK_URL = os.getenv("WECHAT_WEBHOOK_URL", "")

# GitHub配置
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")
GITHUB_REPO_NAME = "13058199807zk-oss/paykka-control"
GITHUB_FILE_PATH = "fx_rule_config.md"
GITHUB_USERNAME = os.getenv("GITHUB_USERNAME", "")
GITHUB_EMAIL = os.getenv("GITHUB_EMAIL", "")

# 余额查询相关GitHub配置
GITHUB_REPO_OWNER = "13058199807zk-oss"
GITHUB_BALANCE_REPO_NAME = "Paykka-K"
GITHUB_BALANCE_FILE_PATH = "docs/index.html"
GITHUB_THRESHOLD_FILE_PATH = "balance_threshold.md"
GITHUB_BRANCH = "main"

# 换汇交易监控相关GitHub配置
GITHUB_THRESHOLD_FILE_PATH_MD = "fx_threshold.md"

# 汇率监控GitHub配置
GITHUB_RATE_FILE_PATH = "rate_comparison.md"

# 支持的换汇策略规则
FX_STRATEGY_RULES = [
    "RULE_CC", "RULE_MDAQ_WALLEX", "RULE_FX_TOD", "RULE_FX_TOM", 
    "RULE_FX_SPOT", "RULE_PP", "RULE_YB", "RULE_HCE_TOD", "RULE_HCE_TOM", "RULE_HCE_SPOT", "RULE_BC", 
    "RULE_OCBC", "RULE_FLUTTERWAVE", "RULE_PAYKKA"
]

# 余额查询配置
BALANCE_API_ENDPOINT = "/recv-org/op/org/account-balance/query"
BALANCE_BASE_URL = "https://ops-bk.cb.paykka.com"
INSTITUTION_MAP = {
    "YB": "易宝",
    "CC": "Currencycloud",
}
INSTITUTION_CURRENCIES = {
    "YB": ["USD", "CNH", "HKD", "EUR", "GBP", "JPY", "AUD", "CAD", "SGD"],
    "CC": ["USD", "CNY", "HKD", "EUR", "GBP", "JPY", "AUD", "CAD", "SGD", "THB", "PHP", "HUF", "RON", "CZK", "PLN"],
}
EXCEL_FILENAME = "机构余额查询记录.xlsx"

# 换汇交易监控配置
FX_TRANSACTION_API = "/forex/ops/fx/page"
FX_FULL_TRANSACTION_URL = "https://ops-bk.cb.paykka.com" + FX_TRANSACTION_API

# 机构列表
ORG_LIST = [
    "YB", "MDAQ_FX_TOM", "CC", "HCE", "MDAQ", "PP", 
    "IBC", "OCBC", "NEWPAY", "PingPong", "PAYKKA"
]

# 不需要除以100的币种
NO_DIVIDE_CURRENCIES = ["VND", "JPY"]

# 默认查询条件
DEFAULT_MERCHANT_STATUS = "SUCCEEDED"
DEFAULT_ORG_STATUS = "SUCCEEDED,PROCESSING"

# 会话保持配置
SESSION_EXPIRE_HOURS = 1
SESSION_FILE = "paykka_session.json"

# 汇率监控配置
# 1. PAYKKA平台配置
PAYKKA_RATE_URL = "https://ops-bk.cb.paykka.com/forex/ops/inquiry/get-quote"
PAYKKA_COOKIE_FILE = "paykka_cookie.txt"

# 2. XT平台配置
XT_SCRIPT = "xt_rateV3.py"
XT_AUTH_FILE = "xt_auth_info.json"
XT_RESULTS_DIR = "xt_results"

# 2.1 XT 汇率查询模块配置
XT_LOGIN_PHONE = os.getenv("XT_LOGIN_PHONE", "")
XT_LOGIN_PASSWORD = os.getenv("XT_LOGIN_PASSWORD", "")
XT_LOGIN_URL = "https://www.xtransfer.cn/login"
XT_TARGET_URL = "https://www.xtransfer.cn/fund/home"
XT_RATE_API_URL = "https://api.xtransfer.cn/api/v1/spotfx/graph/present-rate/get-rate-by-ccy"
XT_AUTH_CACHE_FILE = "xt_auth_cache.json"
XT_AUTH_CACHE_DURATION = 23 * 3600

# XT 货币对列表
XT_CURRENCY_PAIRS = [
    ("USD", "CNY", "美元兑离岸人民币"),
    ("EUR", "CNY", "欧元兑离岸人民币"),
    ("HKD", "CNY", "港币兑离岸人民币"),
    ("GBP", "CNY", "英镑兑离岸人民币"),
    ("SGD", "CNY", "新加坡元兑离岸人民币"),
    ("AUD", "CNY", "澳元兑离岸人民币"),
    ("IDR", "CNY", "印尼盾兑离岸人民币"),
    ("MYR", "CNY", "马来西亚令吉兑离岸人民币"),
    ("PHP", "CNY", "菲律宾比索兑离岸人民币"),
    ("THB", "CNY", "泰铢兑离岸人民币"),
    ("RON", "CNY", "罗马尼亚列伊兑离岸人民币"),
    ("PLN", "CNY", "波兰兹罗提兑离岸人民币"),
    ("HUF", "CNY", "匈牙利福林兑离岸人民币"),
    ("NGN", "USD", "尼日利亚奈拉兑美元"),
    ("VND", "CNY", "越南盾兑离岸人民币"),
    ("VND", "USD", "越南盾兑美元"),
]

# 2.2 友商汇率查询模块配置
# WorldFirst (WF)
WF_USERNAME = os.getenv("WF_USERNAME", "")
WF_PASSWORD = os.getenv("WF_PASSWORD", "")
WF_LOGIN_URL = "https://portal.worldfirst.com/login?loginType=MOBILE&region=CN"
WF_PORTAL_URL = "https://portal.worldfirst.com"
WF_API_URL = "https://imgs.worldfirst.com/mgw.htm"
WF_AUTH_CACHE_FILE = "wf_auth_cache.json"

# LianLian (LL) - LOGIN_TOKEN 方式，需手动配置
LL_API_URL = "https://www.lianlianglobal.cn/b2b/rate/payout/queryRealExchangeRate"
LL_LOGIN_TOKEN = os.getenv("LL_LOGIN_TOKEN", "")

# Airwallex (AW) - 固定 Cookie
AW_API_URL = "https://www.airwallex.com/api/fx/fxRate/indicativeQuote"
AW_COOKIE = os.getenv("AW_COOKIE", "")

# Ksher (KS) - 固定 Headers
KS_API_URL = "https://www.ksher.cn/api/fx/reference_rates_v2"
KS_COOKIE = os.getenv("KS_COOKIE", "")
KS_MERCHANT_ID = os.getenv("KS_MERCHANT_ID", "")
KS_M_ID = os.getenv("KS_M_ID", "")

# Skyee (SK) - Authorization Token
SK_API_URL = "https://business.skyee360.com/api/v1/ExchangeRate"
SK_AUTH_TOKEN = os.getenv("SK_AUTH_TOKEN", "")

# 统一货币对列表（所有友商共用的查询货币对）
COMPETITOR_CURRENCY_PAIRS = [
    ("USD", "CNH", "美元/离岸人民币"),
    ("EUR", "CNH", "欧元/离岸人民币"),
    ("HKD", "CNH", "港币/离岸人民币"),
    ("GBP", "CNH", "英镑/离岸人民币"),
    ("SGD", "CNH", "新加坡元/离岸人民币"),
    ("AUD", "CNH", "澳元/离岸人民币"),
    ("IDR", "CNH", "印尼盾/离岸人民币"),
    ("MYR", "CNH", "马来西亚令吉/离岸人民币"),
    ("PHP", "CNH", "菲律宾比索/离岸人民币"),
    ("THB", "CNH", "泰铢/离岸人民币"),
    ("RON", "CNH", "罗马尼亚列伊/离岸人民币"),
    ("PLN", "CNH", "波兰兹罗提/离岸人民币"),
    ("HUF", "CNH", "匈牙利福林/离岸人民币"),
    ("NGN", "USD", "尼日利亚奈拉/美元"),
    ("VND", "CNH", "越南盾/离岸人民币"),
    ("VND", "USD", "越南盾/美元"),
]

# 友商代码映射
COMPETITOR_CODES = {
    "XT": "XTransfer",
    "WF": "WorldFirst",
    "LL": "LianLian",
    "AW": "Airwallex",
    "KS": "Ksher",
    "SK": "Skyee",
}

# 3. 监控配置
RATE_ALERT_THRESHOLD = 0.5
RATE_CHECK_INTERVAL_MINUTES = 5
RATE_MAX_ALERTS_PER_HOUR = 10

# 4. 统一货币对
CURRENCY_PAIRS = [
    ("NGN", "USD", "尼日利亚奈拉兑美元"),
    ("VND", "CNH", "越南盾兑离岸人民币"),
    ("VND", "USD", "越南盾兑美元"),
]

# 汇率监控Webhook
RATE_MONITOR_WEBHOOK = WECHAT_WEBHOOK_URL

# 路由价格监控配置
EXCHANGE_RATE_WEBHOOK_URL = os.getenv("EXCHANGE_RATE_WEBHOOK_URL", "")
EXCHANGE_RATE_MONITOR_INTERVAL = 10

# 目标汇率源
TARGET_RATE_SOURCES = ["OCBC", "YB", "MDAQ_FX_TOM", "HCE_FX_TOM"]

# 路由价格监控API
EXCHANGE_RATE_API_URL = "https://ops-bk.cb.paykka.com/payment-org/op/channel/exchange-rate/page"
EXCHANGE_RATE_MONITOR_LOG = "exchange_rate_monitor.log"

# 交易时段配置
TRADING_START_HOUR = 8
TRADING_END_HOUR = 15
TRADING_END_MINUTE = 30

# 历史报价查询配置
HISTORY_QUOTE_SEGMENT_DAYS = 3      # API 单次最大查询天数（OPS 硬限制为3天）
HISTORY_QUOTE_PAGE_LIMIT = 5000     # 单页最大记录数（实测支持至少5000）
HISTORY_QUOTE_SUPPORTED_PAIRS = [   # 支持的查询货币对
    ("USD", "CNH"),
    ("EUR", "CNH"),
    ("GBP", "CNH"),
    ("HKD", "CNH"),
    ("SGD", "CNH"),
    ("AUD", "CNH"),
    ("IDR", "CNH"),
    ("MYR", "CNH"),
    ("PHP", "CNH"),
    ("THB", "CNH"),
    ("RON", "CNH"),
    ("PLN", "CNH"),
    ("HUF", "CNH"),
    ("VND", "CNH"),
]

# ===================== 日志配置 =====================
def setup_logging():
    """设置日志配置"""
    log_dir = "logs"
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    logger = logging.getLogger("paykka_integrated")
    logger.setLevel(logging.INFO)
    
    file_handler = RotatingFileHandler(
        f"{log_dir}/paykka_integrated.log", 
        maxBytes=10 * 1024 * 1024,
        backupCount=5,
        encoding='utf-8'
    )
    file_handler.setLevel(logging.INFO)
    
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger

logger = setup_logging()
