#!/usr/bin/env python3
"""测试 XT Cookie 认证调用历史汇率 API"""
import json, requests

# 读取缓存
with open("/workspace/xt_auth_cache.json") as f:
    cache = json.load(f)

cookie_str = cache.get("cookie_str", "")
xsrf_token = cache.get("xsrf_token", "")
server_grant_id = cache.get("server_grant_id", "")

# 解析 cookie
cookies = {}
for item in cookie_str.split(';'):
    item = item.strip()
    if '=' in item:
        parts = item.split('=', 1)
        cookies[parts[0].strip()] = parts[1].strip()

headers = {
    'accept': 'application/json',
    'x-xsrf-token': xsrf_token,
    'origin': 'https://www.xtransfer.cn',
    'referer': 'https://www.xtransfer.cn/',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'x-language': 'CN',
}
if server_grant_id:
    headers['x-server-grant-id'] = server_grant_id
    headers['x-user-agent-context'] = f'PC_Browser;serverGrantId:{server_grant_id};'

session = requests.Session()
for name, value in cookies.items():
    session.cookies.set(name, value)

# 测试 1: get-rate-by-ccy (当前汇率)
print("=" * 60)
print("测试 1: get-rate-by-ccy (当前汇率)")
resp1 = session.get(
    "https://api.xtransfer.cn/api/v1/spotfx/graph/present-rate/get-rate-by-ccy",
    headers=headers,
    params={"fromCcy": "USD", "toCcy": "CNY", "requestFrom": "PC"},
    timeout=15
)
print(f"  Status: {resp1.status_code}")
if resp1.status_code == 200:
    print(f"  Data: {json.dumps(resp1.json(), ensure_ascii=False)[:300]}")
else:
    print(f"  Error: {resp1.text[:300]}")

# 测试 2: getWithSource (历史汇率)
print("\n" + "=" * 60)
print("测试 2: getWithSource (历史汇率 - WEEK)")
resp2 = session.get(
    "https://api.xtransfer.cn/api/v1/spotfx/graph/present-rate/v2/getWithSource",
    headers=headers,
    params={
        "fromCcy": "USD",
        "toCcy": "CNY",
        "type": "WEEK",
        "requestFrom": "PC"
    },
    timeout=15
)
print(f"  Status: {resp2.status_code}")
if resp2.status_code == 200:
    data = resp2.json()
    print(f"  Data keys: {list(data.keys())}")
    if 'data' in data and data['data']:
        print(f"  Records: {len(data['data'])}")
        if len(data['data']) > 0:
            print(f"  First: {json.dumps(data['data'][0], ensure_ascii=False)[:200]}")
            print(f"  Last: {json.dumps(data['data'][-1], ensure_ascii=False)[:200]}")
    else:
        print(f"  Response: {json.dumps(data, ensure_ascii=False)[:500]}")
else:
    print(f"  Error: {resp2.text[:500]}")

# 测试 3: getWithSource MONTH
print("\n" + "=" * 60)
print("测试 3: getWithSource (历史汇率 - MONTH)")
resp3 = session.get(
    "https://api.xtransfer.cn/api/v1/spotfx/graph/present-rate/v2/getWithSource",
    headers=headers,
    params={
        "fromCcy": "USD",
        "toCcy": "CNY",
        "type": "MONTH",
        "requestFrom": "PC"
    },
    timeout=15
)
print(f"  Status: {resp3.status_code}")
if resp3.status_code == 200:
    data = resp3.json()
    if 'data' in data and data['data']:
        print(f"  Records: {len(data['data'])}")
        if len(data['data']) > 0:
            print(f"  First: {json.dumps(data['data'][0], ensure_ascii=False)[:200]}")
            print(f"  Last: {json.dumps(data['data'][-1], ensure_ascii=False)[:200]}")
    else:
        print(f"  Response: {json.dumps(data, ensure_ascii=False)[:500]}")
else:
    print(f"  Error: {resp3.text[:500]}")
