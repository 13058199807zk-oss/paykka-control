#!/usr/bin/env python3
"""XT JWT 调试脚本 - 拦截网络请求查找 JWT token 来源"""
import asyncio, json, os, sys
from datetime import datetime
from playwright.async_api import async_playwright

XT_USER_DATA = "/workspace/xt_browser_data"
XT_API_BASE = "https://api.xtransfer.cn"

def load_env():
    env_path = "/workspace/.env"
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, _, val = line.partition('=')
                    os.environ[key.strip()] = val.strip()

load_env()

async def main():
    found_jwt = []
    api_requests = []
    
    playwright = await async_playwright().start()
    
    try:
        context = await playwright.chromium.launch_persistent_context(
            user_data_dir=XT_USER_DATA,
            headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-blink-features=AutomationControlled"],
            viewport={"width": 1280, "height": 720},
        )
        print("📂 使用已有浏览器会话...")
    except Exception as e:
        print(f"⚠️ 无法复用会话: {e}")
        browser = await playwright.chromium.launch(
            headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-blink-features=AutomationControlled"],
        )
        context = await browser.new_context(viewport={"width": 1280, "height": 720})
    
    page = context.pages[0] if context.pages else await context.new_page()
    
    async def on_request(request):
        req_url = request.url
        headers = request.headers
        if 'authorization' in headers:
            auth = headers['authorization']
            print(f"🔑 发现 Authorization header!")
            print(f"   URL: {req_url}")
            print(f"   Auth: {auth[:80]}...")
            found_jwt.append({"url": req_url, "auth": auth, "source": "request_header"})
        
        if XT_API_BASE in req_url:
            api_requests.append({
                "url": req_url,
                "method": request.method,
                "has_auth": 'authorization' in headers,
            })
    
    async def on_response(response):
        resp_url = response.url
        headers = response.headers
        if 'set-cookie' in headers:
            set_cookie = headers['set-cookie']
            if 'token' in set_cookie.lower() or 'jwt' in set_cookie.lower() or 'auth' in set_cookie.lower():
                print(f"🍪 Set-Cookie 含 token: {set_cookie[:200]}")
    
    page.on('request', on_request)
    page.on('response', on_response)
    
    print("🌐 访问 XT 首页...")
    try:
        await page.goto("https://www.xtransfer.cn/fund/home", timeout=30000, wait_until="domcontentloaded")
        await asyncio.sleep(3)
        current_url = page.url
        print(f"📍 当前 URL: {current_url}")
    except Exception as e:
        print(f"⚠️ 首页访问异常: {e}")
        current_url = page.url
        print(f"📍 当前 URL: {current_url}")
    
    if "login" in current_url.lower():
        print("🔐 需要登录...")
        try:
            tab = await page.wait_for_selector("text=Password Login", timeout=5000)
            if tab:
                await tab.click()
                await asyncio.sleep(1)
        except:
            pass
        
        phone = os.getenv("XT_LOGIN_PHONE", "")
        pwd = os.getenv("XT_LOGIN_PASSWORD", "")
        
        if phone and pwd:
            try:
                phone_input = await page.wait_for_selector("#accountLoginMobileInput", timeout=10000)
                await phone_input.fill("")
                await phone_input.type(phone, delay=80)
                
                pwd_input = await page.wait_for_selector("#accountLoginPasswordInput", timeout=10000)
                await pwd_input.fill("")
                await pwd_input.type(pwd, delay=80)
                
                btn = await page.wait_for_selector("button:has-text('Login')", timeout=10000)
                await btn.click()
                print("✅ 已点击登录按钮")
                
                for i in range(30):
                    await asyncio.sleep(1)
                    url = page.url
                    if "login" not in url.lower():
                        print(f"✅ 登录成功: {url}")
                        break
                    if i % 5 == 0:
                        print(f"   等待中... ({i}s)")
            except Exception as e:
                print(f"⚠️ 登录操作异常: {e}")
    
    await asyncio.sleep(5)
    
    # 检查 localStorage
    print("\n📦 检查 localStorage...")
    try:
        for key in ['token', 'jwt', 'access_token', 'accessToken', 'xt_token', 'xt_new_server_grant_id', 'server_grant_id']:
            val = await page.evaluate(f"() => localStorage.getItem('{key}')")
            if val:
                print(f"  localStorage.{key}: {val[:80]}...")
    except Exception as e:
        print(f"  localStorage 读取异常: {e}")
    
    # 检查 sessionStorage
    print("\n📦 检查 sessionStorage...")
    try:
        for key in ['token', 'jwt', 'access_token', 'accessToken']:
            val = await page.evaluate(f"() => sessionStorage.getItem('{key}')")
            if val:
                print(f"  sessionStorage.{key}: {val[:80]}...")
    except Exception as e:
        print(f"  sessionStorage 读取异常: {e}")
    
    # 检查 cookies
    print("\n🍪 检查 Cookies...")
    cookies = await context.cookies()
    for c in cookies:
        name = c.get('name', '')
        value = c.get('value', '')
        if any(kw in name.lower() for kw in ['token', 'jwt', 'auth', 'dx', 'server']):
            print(f"  {name}: {value[:80]}...")
    
    print(f"\n📊 汇总:")
    print(f"  找到 Authorization headers: {len(found_jwt)}")
    print(f"  API 请求总数: {len(api_requests)}")
    
    for req in api_requests:
        print(f"  [{req['method']}] {req['url'][:120]} | Auth: {req['has_auth']}")
    
    if found_jwt:
        jwt_token = found_jwt[0]['auth'].replace('Bearer ', '')
        print(f"\n✅ JWT Token: {jwt_token[:50]}...")
        
        cache = {}
        if os.path.exists("/workspace/xt_auth_cache.json"):
            with open("/workspace/xt_auth_cache.json") as f:
                cache = json.load(f)
        
        cache['jwt_token'] = jwt_token
        cache['auth_time'] = datetime.now().isoformat()
        
        with open("/workspace/xt_auth_cache.json", "w") as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
        print("💾 JWT 已保存到缓存")
    else:
        print("\n⚠️ 未找到 JWT Authorization header")
        print("尝试用 XSRF token + cookie 直接调 API...")
        
        xsrf_token = ""
        for c in cookies:
            if 'XSRF-TOKEN' in c.get('name', '').upper():
                xsrf_token = c.get('value', '')
        
        print(f"  XSRF Token: {xsrf_token[:30]}...")
        
        import requests
        headers = {
            'accept': 'application/json',
            'x-xsrf-token': xsrf_token,
            'origin': 'https://www.xtransfer.cn',
            'referer': 'https://www.xtransfer.cn/',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'x-language': 'CN',
        }
        
        cookie_dict = {c['name']: c['value'] for c in cookies}
        
        resp = requests.get(
            "https://api.xtransfer.cn/api/v1/spotfx/graph/present-rate/get-rate-by-ccy",
            headers=headers,
            params={"fromCcy": "USD", "toCcy": "CNY", "requestFrom": "PC"},
            cookies=cookie_dict,
            timeout=15
        )
        print(f"  get-rate-by-ccy: HTTP {resp.status_code}")
        if resp.status_code == 200:
            print(f"  ✅ 成功! 响应: {str(resp.json())[:200]}")
        else:
            print(f"  ❌ {resp.text[:200]}")
        
        # 也测试 getWithSource
        resp2 = requests.get(
            "https://api.xtransfer.cn/api/v1/spotfx/graph/present-rate/v2/getWithSource",
            headers=headers,
            params={"fromCcy": "USD", "toCcy": "CNY", "type": "WEEK", "siteCode": "CN"},
            cookies=cookie_dict,
            timeout=15
        )
        print(f"  getWithSource: HTTP {resp2.status_code}")
        if resp2.status_code == 200:
            print(f"  ✅ 成功! 数据点数: {len(resp2.json().get('sourceRatePointList', {}).get('SPOT', []))}")
        else:
            print(f"  ❌ {resp2.text[:200]}")
    
    await context.close()

asyncio.run(main())
