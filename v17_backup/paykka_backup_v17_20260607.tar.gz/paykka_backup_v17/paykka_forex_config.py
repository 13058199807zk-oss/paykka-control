# ===================== paykka_forex_config.py =====================
# PaykkaForexConfigurator - 汇差配置
# 从 paykka_controllerV16.py 提取

import json
import time
import urllib.parse
import requests
import re
import threading
import os
import hashlib
import asyncio
import subprocess
import base64
from typing import List, Dict, Tuple, Any, Optional, Union
from datetime import datetime, date, timedelta, timezone, time as dtime
from playwright.async_api import async_playwright
import pandas as pd
from github import Github, InputGitAuthor
import pytz

from paykka_config import *
from paykka_core import PaykkaSystemManager, send_wechat_work_message

class PaykkaForexConfigurator:
    """PAYKKA汇差配置器 - 增强版，支持自动重连"""
    
    def __init__(self, token: str):
        self.token = token
        self.base_url = "https://ops-bk.cb.paykka.com"
        self.endpoint = f"{self.base_url}/forex/ops/general-fx-transform/edit"
        self.manager = PaykkaSystemManager()  # 新增：引用管理器
    
    def _build_headers(self) -> Dict[str, str]:
        """构建HTTP请求头"""
        headers = {
            "accept": "application/json, text/plain, */*",
            "accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
            "content-type": "application/json;charset=UTF-8",
            "origin": "https://ops.cb.paykka.com",
            "referer": "https://ops.cb.paykka.com/",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "cookie": f"a_t={self.token}",
            "x-auth-token": self.token,
        }
        return headers
    
    def _construct_payload(self, sell_cur: str, buy_cur: str, 
                          cost_config: Dict, ref_configs: List[Dict]) -> Dict:
        """构建请求Payload"""
        payload = {
            "sell_cur": sell_cur,
            "items": [
                {
                    "buy_cur": buy_cur,
                    "configs": ref_configs,
                    "cost": cost_config
                }
            ]
        }
        return payload
    
    def _configure_forex_pair_internal(self, sell_cur: str, buy_cur: str, 
                                     cost_config: Dict, ref_configs: List[Dict]) -> Tuple[bool, str]:
        """内部配置方法（被safe_configure_forex_pair调用）"""
        payload = self._construct_payload(sell_cur, buy_cur, cost_config, ref_configs)
        
        headers = self._build_headers()
        response = requests.post(
            url=self.endpoint,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            resp_data = response.json()
            return True, resp_data
        else:
            return False, f"HTTP错误: {response.status_code}"
    
    def safe_configure_forex_pair(self, sell_cur: str, buy_cur: str, 
                                 cost_config: Dict, ref_configs: List[Dict]) -> Tuple[bool, str]:
        """
        安全的汇差配置（自动处理Token过期和重试）
        返回: (成功标志, 消息)
        """
        # 使用管理器的安全API调用
        success, result = self.manager.safe_api_call(
            self._configure_forex_pair_internal,
            sell_cur, buy_cur, cost_config, ref_configs,
            max_retries=2,
            retry_delay=1
        )
        
        if not success:
            return False, result
        
        # --- 修复开始：正确处理返回的元组 ---
        # result 现在是 (api_call_success, api_response) 元组
        if not isinstance(result, tuple) or len(result) != 2:
            return False, f"API返回了意外的格式: {type(result)}"
    
        api_call_success, resp_data = result
        # --- 修复结束 ---
    
        if not api_call_success:
            # resp_data 此时是错误信息字符串
            return False, resp_data

        # 现在 resp_data 应该是真正的API响应字典
        if resp_data.get('ret_code') == '000000':
            # 配置成功后发送企业微信群通知
            config_details = f"币对: {sell_cur}->{buy_cur}\n类型: 汇差配置"
            notification_message = f"ℹ️汇率配置更新，请复核ℹ️\n{config_details}"
            send_wechat_work_message(notification_message)
            
            return True, f"✅ 汇差配置成功: {sell_cur}->{buy_cur}"
        else:
            return False, f"❌ 配置失败: {resp_data.get('ret_msg', '未知错误')}"
    
    def configure_forex_pair(self, sell_cur: str, buy_cur: str, 
                            cost_config: Dict, ref_configs: List[Dict]) -> Tuple[bool, str]:
        """配置单个货币对（兼容旧版本，内部使用安全版本）"""
        logger.info("使用增强版安全配置接口")
        return self.safe_configure_forex_pair(sell_cur, buy_cur, cost_config, ref_configs)

