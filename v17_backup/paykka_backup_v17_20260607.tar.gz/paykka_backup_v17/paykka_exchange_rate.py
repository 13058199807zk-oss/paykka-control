# ===================== paykka_exchange_rate.py =====================
# PaykkaExchangeRateMonitor - 路由价格监控
# 从 paykka_controllerV16.py 提取

import json
import time
import urllib.parse
import requests
import re
import threading
import os
import hashlib
import asyncio
import subprocess
import base64
from typing import List, Dict, Tuple, Any, Optional, Union
from datetime import datetime, date, timedelta, timezone, time as dtime
from playwright.async_api import async_playwright
import pandas as pd
from github import Github, InputGitAuthor
import pytz

from paykka_config import *
from paykka_core import PaykkaSystemManager, build_auth_headers

class PaykkaExchangeRateMonitor:
    """PAYKKA路由价格监控模块 - 集成到全局框架"""
    
    def __init__(self, token: str):
        self.token = token
        self.api_url = EXCHANGE_RATE_API_URL
        self.webhook_url = EXCHANGE_RATE_WEBHOOK_URL
        self.target_sources = TARGET_RATE_SOURCES
        self.manager = PaykkaSystemManager()  # 集成到全局管理器
        
        # 时区设置
        self.beijing_tz = pytz.timezone('Asia/Shanghai')
        
        # 配置监控日志
        self.logger = logging.getLogger('ExchangeRateMonitor')
        self._setup_logging()
    
    def _build_headers(self) -> Dict[str, str]:
        """构建HTTP请求头（每次动态获取最新Token）"""
        current_token = self.token or self.manager._token
        if current_token:
            self.token = current_token  # 同步更新本地token
        return build_auth_headers(current_token)
    
    def _setup_logging(self):
        """配置监控专用日志"""
        if not self.logger.handlers:
            handler = logging.FileHandler(EXCHANGE_RATE_MONITOR_LOG)
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
    
    def _safe_exchange_rate_query(self, payload: Dict) -> Tuple[bool, Any]:
        """安全的汇率查询请求"""

        def query_func():
            response = requests.post(
                self.api_url,
                headers=self._build_headers(),  # 修复：每次请求动态获取最新headers
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                raise Exception(f"HTTP {response.status_code}")
        
        # 使用管理器的安全API调用
        return self.manager.safe_api_call(
            query_func,
            max_retries=2,
            retry_delay=1
        )
    
    def get_current_time_range(self) -> Dict[str, str]:
        """
        获取当前查询的时间范围（最近10分钟）
        """
        now_utc = datetime.now(timezone.utc)
        start_time = now_utc - timedelta(minutes=10)
        
        return {
            "start_time": start_time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "end_time": now_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        }
    
    def build_payload(self, start_time: str, end_time: str, limit: int = 50) -> Dict:
        """
        构建请求Payload
        """
        return {
            "offset": 0,
            "limit": limit,
            "start_time": start_time,
            "end_time": end_time,
            "base_currency": "USD",
            "quote_currency": "CNH"
        }
    
    def query_exchange_rates(self) -> Optional[List[Dict]]:
        """
        查询汇率数据
        返回: 汇率数据列表或None
        """
        try:

            # 获取时间范围
            time_range = self.get_current_time_range()
            
            # 构建请求数据
            payload = self.build_payload(
                start_time=time_range["start_time"],
                end_time=time_range["end_time"]
            )
            
            self.logger.info(f"查询时间范围: {time_range['start_time']} 到 {time_range['end_time']}")
            
            # 使用安全的API调用
            success, data = self._safe_exchange_rate_query(payload)
            
            if not success:
                self.logger.error(f"汇率查询失败: {data}")
                return None

            # 确保 data 是字典类型
            if not isinstance(data, dict):
                self.logger.error(f"API返回了非字典类型的响应: {type(data)} - {data}")
                return None
            
            if "data" in data:
                self.logger.info(f"成功获取 {len(data['data'])} 条汇率数据")
                return data["data"]
            else:
                self.logger.error("响应数据格式错误，缺少'data'字段")
                return None
                
        except Exception as e:
            self.logger.error(f"查询汇率数据异常: {e}")
            return None
    
    def filter_latest_rates_by_source(self, rates: List[Dict]) -> Dict[str, Dict]:
        """
        按来源过滤最新汇率数据
        """
        filtered_rates = {}
        
        for source in self.target_sources:
            # 过滤指定来源的数据
            source_rates = [rate for rate in rates if rate.get("source") == source]
            
            if source_rates:
                # 按发布时间排序，取最新的
                try:
                    latest_rate = max(
                        source_rates,
                        key=lambda x: datetime.fromisoformat(x["release_time"].replace('Z', '+00:00'))
                    )
                    filtered_rates[source] = latest_rate
                    self.logger.info(f"找到{source}最新报价: {latest_rate.get('bid_rate', 'N/A')} (发布时间: {latest_rate.get('release_time', 'N/A')})")
                except (KeyError, ValueError) as e:
                    self.logger.error(f"处理{source}数据时出错: {e}")
                    filtered_rates[source] = None
            else:
                self.logger.warning(f"未找到{source}的汇率数据")
                filtered_rates[source] = None
        
        return filtered_rates
    
    def check_rate_alert(self, rates: Dict[str, Dict]) -> Optional[Dict]:
        """
        检查是否需要发送告警
        """
        # 检查OCBC数据是否存在
        ocbc_rate = rates.get("OCBC")
        yb_rate = rates.get("YB")
        mdaq_rate = rates.get("MDAQ_FX_TOM")
        
        if not ocbc_rate:
            self.logger.error("OCBC汇率数据缺失，无法进行比较")
            return None
        
        alert_info = {
            "ocbc_rate": ocbc_rate.get("bid_rate", 0),
            "comparisons": [],
            "triggered": False
        }
        
        # 比较YB
        if yb_rate and yb_rate.get("bid_rate") is not None:
            try:
                ocbc_bid = float(ocbc_rate["bid_rate"])
                yb_bid = float(yb_rate["bid_rate"])
                
                if ocbc_bid < yb_bid:
                    alert_info["comparisons"].append({
                        "source": "YB",
                        "rate": yb_bid,
                        "difference": yb_bid - ocbc_bid
                    })
                    alert_info["triggered"] = True
            except (ValueError, TypeError) as e:
                self.logger.error(f"解析YB汇率时出错: {e}")
        
        # 比较MDAQ_FX_TOM
        if mdaq_rate and mdaq_rate.get("bid_rate") is not None:
            try:
                ocbc_bid = float(ocbc_rate["bid_rate"])
                mdaq_bid = float(mdaq_rate["bid_rate"])
                
                if ocbc_bid < mdaq_bid:
                    alert_info["comparisons"].append({
                        "source": "MDAQ_FX_TOM",
                        "rate": mdaq_bid,
                        "difference": mdaq_bid - ocbc_bid
                    })
                    alert_info["triggered"] = True
            except (ValueError, TypeError) as e:
                self.logger.error(f"解析MDAQ_FX_TOM汇率时出错: {e}")
        
        return alert_info if alert_info["triggered"] else None
    
    def send_wechat_alert(self, alert_info: Dict, rates: Dict[str, Dict]) -> bool:
        """
        发送企业微信告警
        返回: 是否发送成功
        """
        try:
            # 获取当前时间
            current_time = datetime.now(self.beijing_tz).strftime('%Y-%m-%d %H:%M:%S')
            
            # 构建消息
            message = {
                "msgtype": "markdown",
                "markdown": {
                    "content": f"""**汇率监控告警**\n
**告警时间**: {current_time}\n
**OCBC买入价异常低于其他来源**\n
---
**汇率详情**:\n
- **OCBC**: {rates['OCBC'].get('bid_rate', 'N/A')} (发布时间: {rates['OCBC'].get('release_time', 'N/A')})\n
"""
                }
            }
            
            # 添加比较信息
            for comparison in alert_info["comparisons"]:
                message["markdown"]["content"] += f"- **{comparison['source']}**: {comparison['rate']:.4f} (高出: {comparison['difference']:.6f})\n"
            
            message["markdown"]["content"] += f"""
**告警条件**: OCBC买入价 < 其他来源买入价
**监控货币对**: USD/CNH
**监控来源**: OCBC, YB, MDAQ_FX_TOM
"""
            
            self.logger.info(f"发送企微告警: {message['markdown']['content'][:200]}...")
            
            # 发送请求
            response = requests.post(
                self.webhook_url,
                json=message,
                timeout=5
            )
            
            if response.status_code == 200:
                self.logger.info("企业微信告警发送成功")
                return True
            else:
                self.logger.error(f"企业微信告警发送失败: {response.status_code}")
                return False
                
        except Exception as e:
            self.logger.error(f"发送企业微信告警失败: {e}")
            return False
    
    def is_trading_hours(self) -> bool:
        """
        检查当前是否在交易时段内
        返回: True如果在交易时段内 (08:00-15:30 UTC+8，含08:00整点)
        """
        # 获取当前北京时间
        now_beijing = datetime.now(self.beijing_tz)
        current_hour = now_beijing.hour
        current_minute = now_beijing.minute
        
        if current_hour < TRADING_START_HOUR:
            self.logger.debug(f"当前时间{current_hour:02d}:{current_minute:02d}早于08:00")
            return False
        elif current_hour > TRADING_END_HOUR:
            self.logger.debug(f"当前时间{current_hour:02d}:{current_minute:02d}晚于18:00")
            return False
        elif current_hour == TRADING_END_HOUR and current_minute > TRADING_END_MINUTE:
            self.logger.debug(f"当前时间{current_hour:02d}:{current_minute:02d}晚于{TRADING_END_HOUR}:{TRADING_END_MINUTE:02d}")
            return False
        
        self.logger.debug(f"当前时间{current_hour:02d}:{current_minute:02d}在交易时段内")
        return True
    
    def run_monitoring(self) -> Dict:
        """
        执行一次监控任务
        返回: 监控结果字典
        """
        result = {
            "success": False,
            "message": "",
            "alert_sent": False,
            "rates": {},
            "check_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        self.logger.info("开始执行汇率监控任务")

        # 检查是否在交易时段内
        if not self.is_trading_hours():
            msg = "当前不在交易时段内 (08:00-15:30 UTC+8)，跳过监控"
            result["message"] = msg
            self.logger.info(msg)
            return result
        
        # 查询汇率数据
        rates = self.query_exchange_rates()
        if not rates:
            msg = "未获取到汇率数据，跳过本次监控"
            result["message"] = msg
            self.logger.warning(msg)
            return result
        
        # 过滤最新数据
        filtered_rates = self.filter_latest_rates_by_source(rates)
        result["rates"] = filtered_rates
        
        # 检查所有目标来源是否都有数据
        missing_sources = [source for source, data in filtered_rates.items() if data is None]
        if missing_sources:
            self.logger.warning(f"以下来源数据缺失: {missing_sources}")
        
        # 检查是否需要告警
        alert_info = self.check_rate_alert(filtered_rates)
        
        if alert_info:
            alert_msg = f"检测到汇率异常: OCBC买入价({alert_info['ocbc_rate']})低于其他来源"
            result["message"] = alert_msg
            self.logger.warning(alert_msg)
            
            # 发送告警
            alert_sent = self.send_wechat_alert(alert_info, filtered_rates)
            result["alert_sent"] = alert_sent
            result["alert_info"] = alert_info
        else:
            normal_msg = "汇率正常，无需告警"
            result["message"] = normal_msg
            self.logger.info(normal_msg)
        
        result["success"] = True
        return result
    
    def print_current_rates(self, rates: Dict[str, Dict]) -> str:
        """
        打印当前汇率信息
        返回: 格式化后的汇率信息字符串
        """
        output = "\n" + "="*50 + "\n"
        output += "当前汇率监控结果:\n"
        output += "="*50 + "\n"
        
        for source, data in rates.items():
            if data:
                output += f"{source}: {data.get('bid_rate', 'N/A')} (发布时间: {data.get('release_time', 'N/A')})\n"
            else:
                output += f"{source}: 无数据\n"
        output += "="*50 + "\n"
        
        return output
    
    def start_scheduled_monitoring(self, interval_minutes: int = EXCHANGE_RATE_MONITOR_INTERVAL):
        """
        启动定时监控
        注意: 由于全局框架已有调度机制，这里提供独立启动方法
        """
        self.logger.info(f"启动汇率监控，每{interval_minutes}分钟执行一次")
        self.logger.info(f"交易时段: 08:00-15:30 (UTC+8)")
        self.logger.info(f"监控来源: {', '.join(self.target_sources)}")
        
        # 立即执行一次
        result = self.run_monitoring()
        print(self.print_current_rates(result.get("rates", {})))
        
        # 设置定时任务
        schedule.every(interval_minutes).minutes.do(self.run_monitoring)
        
        try:
            while True:
                schedule.run_pending()
                time.sleep(1)
        except KeyboardInterrupt:
            self.logger.info("汇率监控程序已停止")
        except Exception as e:
            self.logger.error(f"汇率监控程序异常终止: {e}")

# ===================== XT 汇率查询模块 =====================
