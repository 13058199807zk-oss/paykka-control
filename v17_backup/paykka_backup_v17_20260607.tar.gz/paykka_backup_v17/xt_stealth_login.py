#!/usr/bin/env python3
"""XT Stealth 登录脚本 - 修复版 v2"""
import asyncio, json, os, sys, time
from datetime import datetime
from playwright.async_api import async_playwright

XT_AUTH_CACHE = "/workspace/xt_auth_cache.json"

def load_env():
    env_path = "/workspace/.env"
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, _, val = line.partition('=')
                    os.environ[key.strip()] = val.strip()

load_env()

async def main():
    found_jwt = None
    found_xsrf = None
    found_server_grant = None
    login_success = False
    
    playwright = await async_playwright().start()
    
    browser = await playwright.chromium.launch(
        headless=False,
        args=[
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--disable-blink-features=AutomationControlled",
            "--window-size=1280,720",
        ]
    )
    
    context = await browser.new_context(
        viewport={"width": 1280, "height": 720},
        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        locale="zh-CN",
        timezone_id="Asia/Shanghai",
    )
    
    await context.add_init_script("""
        Object.defineProperty(navigator, 'webdriver', { get: () => false });
        window.chrome = { runtime: {} };
        Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
        Object.defineProperty(navigator, 'languages', { get: () => ['zh-CN', 'zh', 'en'] });
    """)
    
    page = await context.new_page()
    
    async def on_request(request):
        nonlocal found_jwt, found_xsrf, found_server_grant
        headers = request.headers
        req_url = request.url
        
        if 'authorization' in headers and 'Bearer' in headers.get('authorization', ''):
            auth = headers['authorization']
            if not found_jwt:
                found_jwt = auth.replace('Bearer ', '')
                print(f"\n🔑 JWT Token 捕获!")
                print(f"   来源: {req_url[:100]}")
                print(f"   JWT: {found_jwt[:60]}...")
        
        if 'x-xsrf-token' in headers and not found_xsrf:
            found_xsrf = headers['x-xsrf-token']
        
        if 'x-server-grant-id' in headers and not found_server_grant:
            found_server_grant = headers['x-server-grant-id']
    
    page.on('request', on_request)
    
    print("🌐 访问 XT 登录页...")
    await page.goto("https://www.xtransfer.cn/login", timeout=30000, wait_until="networkidle")
    await asyncio.sleep(3)
    
    phone = os.getenv("XT_LOGIN_PHONE", "")
    pwd = os.getenv("XT_LOGIN_PASSWORD", "")
    
    if not phone or not pwd:
        print("❌ 未配置 XT 登录凭据")
        await browser.close()
        return
    
    try:
        phone_input = await page.wait_for_selector("#accountLoginMobileInput", timeout=10000)
        await phone_input.click()
        await asyncio.sleep(0.3)
        await phone_input.fill("")
        await asyncio.sleep(0.3)
        await phone_input.type(phone, delay=80)
        print("✅ 已填充手机号")
        
        pwd_input = await page.wait_for_selector("#accountLoginPasswordInput", timeout=10000)
        await pwd_input.click()
        await asyncio.sleep(0.3)
        await pwd_input.fill("")
        await asyncio.sleep(0.3)
        await pwd_input.type(pwd, delay=80)
        print("✅ 已填充密码")
        
        await asyncio.sleep(1)
        
        btn = await page.wait_for_selector("button:has-text('登录')", timeout=10000)
        await btn.click()
        print("✅ 已点击登录按钮")
        
    except Exception as e:
        print(f"⚠️ 填充失败: {e}")
        try:
            buttons = await page.query_selector_all("button")
            for i, btn in enumerate(buttons):
                text = await btn.inner_text()
                if '登录' in text:
                    await btn.click()
                    print(f"✅ 通过 index [{i}] 点击登录按钮")
                    break
        except:
            pass
    
    # 等待登录结果
    print("\n⏳ 等待登录结果...")
    captcha_detected = False
    
    for i in range(90):
        await asyncio.sleep(1)
        url = page.url
        
        if not captcha_detected:
            try:
                captcha = await page.query_selector(".geetest_holder, [class*='captcha'], [class*='geetest']")
                if captcha:
                    captcha_detected = True
                    print("\n⚠️ 检测到 CAPTCHA!")
                    print("   尝试自动滑动...")
                    try:
                        slider = await page.query_selector(".geetest_slider_button, [class*='slider']")
                        if slider:
                            box = await slider.bounding_box()
                            if box:
                                start_x = box['x'] + box['width'] / 2
                                start_y = box['y'] + box['height'] / 2
                                await page.mouse.move(start_x, start_y)
                                await page.mouse.down()
                                for step in range(25):
                                    await page.mouse.move(start_x + (step + 1) * 12, start_y + (step % 3 - 1) * 2)
                                    await asyncio.sleep(0.04)
                                await page.mouse.up()
                                print("   ✅ 已尝试自动滑动")
                    except Exception as e:
                        print(f"   ⚠️ 滑动失败: {e}")
            except:
                pass
        
        if "login" not in url.lower():
            login_success = True
            print(f"\n✅ 登录成功! URL: {url}")
            break
        
        if i % 15 == 0 and i > 0:
            print(f"   等待中... ({i}s) URL: {url}")
    else:
        print(f"\n⚠️ 登录可能失败，URL: {page.url}")
    
    # 等待 API 请求
    print("\n⏳ 等待 API 请求...")
    await asyncio.sleep(5)
    
    if login_success:
        try:
            print("🔄 导航到 fund home...")
            await page.goto("https://www.xtransfer.cn/fund/home", timeout=30000, wait_until="networkidle")
            await asyncio.sleep(5)
        except Exception as e:
            print(f"⚠️ 导航异常: {e}")
    
    # 提取凭据
    cookies = await context.cookies()
    cookie_parts = []
    for c in cookies:
        name = c.get('name', '')
        value = c.get('value', '')
        if name and value and value != 'null':
            cookie_parts.append(f"{name}={value}")
            if 'XSRF-TOKEN' in name.upper() and not found_xsrf:
                found_xsrf = value
    
    try:
        grant = await page.evaluate("() => localStorage.getItem('xt_new_server_grant_id')")
        if grant and not found_server_grant:
            found_server_grant = grant
    except:
        pass
    
    if not found_jwt:
        for storage_type in ['localStorage', 'sessionStorage']:
            try:
                for key in ['token', 'jwt', 'access_token', 'accessToken', 'xt_token']:
                    val = await page.evaluate(f"() => {storage_type}.getItem('{key}')")
                    if val and len(val) > 20:
                        found_jwt = val
                        print(f"   ✅ 从 {storage_type}.{key} 提取: {val[:60]}...")
                        break
            except:
                pass
            if found_jwt:
                break
    
    # 测试 cookie 认证
    if not found_jwt and login_success:
        print("\n🔬 测试 cookie 认证...")
        import requests as req
        cookie_dict = {c['name']: c['value'] for c in cookies}
        test_headers = {
            'accept': 'application/json',
            'x-xsrf-token': found_xsrf or "",
            'origin': 'https://www.xtransfer.cn',
            'referer': 'https://www.xtransfer.cn/',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'x-language': 'CN',
        }
        if found_server_grant:
            test_headers['x-server-grant-id'] = found_server_grant
            test_headers['x-user-agent-context'] = f'PC_Browser;serverGrantId:{found_server_grant};'
        
        resp = req.get(
            "https://api.xtransfer.cn/api/v1/spotfx/graph/present-rate/get-rate-by-ccy",
            headers=test_headers,
            params={"fromCcy": "USD", "toCcy": "CNY", "requestFrom": "PC"},
            cookies=cookie_dict,
            timeout=15
        )
        print(f"  get-rate-by-ccy: HTTP {resp.status_code}")
        if resp.status_code == 200:
            print(f"  ✅ Cookie 认证有效!")
            print(f"  {json.dumps(resp.json())[:200]}")
        else:
            print(f"  ❌ {resp.text[:200]}")
    
    # 保存
    cache = {
        "cookie_str": "; ".join(cookie_parts),
        "xsrf_token": found_xsrf or "",
        "jwt_token": found_jwt or "",
        "server_grant_id": found_server_grant or "",
        "auth_time": datetime.now().isoformat(),
    }
    with open(XT_AUTH_CACHE, "w") as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)
    
    print(f"\n{'=' * 60}")
    print(f"📊 结果:")
    print(f"  Cookie: {len(cookie_parts)} 个")
    print(f"  XSRF: {found_xsrf[:30] if found_xsrf else '未找到'}...")
    print(f"  JWT:  {found_jwt[:50] if found_jwt else '❌ 未找到'}...")
    print(f"  server_grant_id: {found_server_grant[:30] if found_server_grant else '未找到'}...")
    print(f"  Login: {'✅ 成功' if login_success else '❌ 失败'}")
    print(f"  CAPTCHA: {'⚠️ 触发' if captcha_detected else '✅ 未触发'}")
    
    await browser.close()

asyncio.run(main())
