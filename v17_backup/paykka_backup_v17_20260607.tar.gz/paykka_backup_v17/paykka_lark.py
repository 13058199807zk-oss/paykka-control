# ===================== paykka_lark.py =====================
# LarkBotHandler + 飞书事件处理器 + 命令行交互
# 从 paykka_controllerV16.py 提取

import json
import time
import threading
import os
import asyncio
import logging

import lark_oapi as lark
from lark_oapi.api.im.v1 import *
from lark_oapi.ws import Client as LarkWSClient

from paykka_config import *
from paykka_core import PaykkaSystemManager
from paykka_commands import IntegratedCommandProcessor

class LarkBotHandler:
    """飞书机器人消息处理器"""
    
    def __init__(self, command_processor: IntegratedCommandProcessor):
        self.processor = command_processor
    
    def handle_message(self, data: lark.im.v1.P2ImMessageReceiveV1) -> None:
        """处理飞书消息事件（带去重检查 + 异常保护）"""
        message_id = "unknown"
        chat_id = "unknown"
        
        try:
            message = data.event.message
            message_id = message.message_id
            chat_id = message.chat_id
            
            # 检查消息是否已经处理过（防止重复执行）
            try:
                dedup = self.processor.manager.get_deduplicator()
                if dedup.is_processed(message_id):
                    logger.info(f"⏭️  消息 {message_id} 已处理过，跳过")
                    return
            except Exception as dedup_err:
                logger.warning(f"去重检查异常（继续处理）: {dedup_err}")
            
            content = json.loads(message.content)
            text = content.get("text", "").strip()
            
            logger.info(f"📩 收到飞书消息: {text}")
            
            # 处理指令（process 内部已有异常保护）
            reply_text = self.processor.process(text)
            
            # 检查是否包含图表路径标记（格式: [CHART:path]）
            chart_path = None
            chart_marker = "[CHART:"
            if chart_marker in reply_text:
                idx = reply_text.index(chart_marker)
                end_idx = reply_text.index("]", idx)
                chart_path = reply_text[idx + len(chart_marker):end_idx]
                reply_text = reply_text[:idx] + reply_text[end_idx + 1:]
                reply_text = reply_text.strip()
            
            # 回复消息
            try:
                self.reply_message(chat_id, message_id, reply_text)
            except Exception as reply_err:
                logger.error(f"❌ 回复消息失败: {reply_err}")
            
            # 如果有图表，发送图片
            if chart_path and os.path.exists(chart_path):
                try:
                    self.reply_image(chat_id, message_id, chart_path)
                except Exception as img_err:
                    logger.error(f"❌ 发送图片失败: {img_err}")
            
            # 标记消息为已处理
            try:
                dedup.mark_as_processed(message_id)
            except Exception as mark_err:
                logger.warning(f"标记已处理异常: {mark_err}")
            
        except Exception as e:
            logger.error(f"❌ 处理飞书消息失败: {e}")
            try:
                self.reply_message(chat_id, message_id, f"❌ 处理消息时发生错误: {str(e)}")
            except:
                pass
    
    def reply_message(self, chat_id: str, message_id: str, text: str) -> None:
        """回复飞书消息"""
        try:
            # 创建客户端
            client = lark.Client.builder() \
                .app_id(LARK_APP_ID) \
                .app_secret(LARK_APP_SECRET) \
                .log_level(lark.LogLevel.INFO) \
                .build()
            
            # 创建回复内容
            content = json.dumps({"text": text}, ensure_ascii=False)
            
            # 发送回复
            request = CreateMessageRequest.builder() \
                .receive_id_type("chat_id") \
                .request_body(CreateMessageRequestBody.builder()
                    .receive_id(chat_id)
                    .msg_type("text")
                    .content(content)
                    .uuid(message_id)
                    .build()) \
                .build()
            
            response = client.im.v1.message.create(request)
            
            if response.code == 0:
                logger.info(f"✅ 已回复飞书消息: {text[:50]}...")
            else:
                logger.error(f"❌ 回复飞书消息失败: {response.msg}")
                
        except Exception as e:
            logger.error(f"❌ 回复飞书消息异常: {e}")
    
    def reply_image(self, chat_id: str, message_id: str, image_path: str) -> None:
        """发送图片到飞书（先上传再发送）"""
        try:
            client = lark.Client.builder() \
                .app_id(LARK_APP_ID) \
                .app_secret(LARK_APP_SECRET) \
                .log_level(lark.LogLevel.INFO) \
                .build()
            
            # 上传图片获取 image_key - image 字段需要是文件句柄 (io.IOBase)
            import lark_oapi.api.im.v1 as im_v1
            
            with open(image_path, 'rb') as f:
                upload_request = im_v1.CreateImageRequest.builder() \
                    .request_body(im_v1.CreateImageRequestBody.builder()
                        .image_type("message")
                        .image(f)
                        .build()) \
                    .build()
                
                upload_response = client.im.v1.image.create(upload_request)
            
            if upload_response.code != 0:
                logger.error(f"❌ 上传图片失败: {upload_response.msg}")
                return
            
            image_key = upload_response.data.image_key
            logger.info(f"✅ 图片上传成功, image_key: {image_key}")
            
            # 发送图片消息 - 使用不同的 uuid 避免和文本消息冲突
            content = json.dumps({"image_key": image_key}, ensure_ascii=False)
            img_uuid = f"{message_id}_img"
            
            send_request = CreateMessageRequest.builder() \
                .receive_id_type("chat_id") \
                .request_body(CreateMessageRequestBody.builder()
                    .receive_id(chat_id)
                    .msg_type("image")
                    .content(content)
                    .uuid(img_uuid)
                    .build()) \
                .build()
            
            response = client.im.v1.message.create(send_request)
            
            if response.code == 0:
                logger.info(f"✅ 图片已发送到飞书")
            else:
                logger.error(f"❌ 发送图片失败: {response.msg}")
                
        except Exception as e:
            logger.error(f"❌ 发送图片异常: {e}")

# ===================== 飞书事件处理器 =====================
# 全局缓存 IntegratedCommandProcessor 实例，避免每次消息都重新创建
_global_command_processor = None
_global_command_processor_lock = threading.Lock()

def _get_command_processor(manager):
    """获取或创建全局 IntegratedCommandProcessor 实例（线程安全）"""
    global _global_command_processor
    with _global_command_processor_lock:
        if _global_command_processor is None:
            _global_command_processor = IntegratedCommandProcessor(manager)
        return _global_command_processor

def do_p2_im_message_receive_v1(data: lark.im.v1.P2ImMessageReceiveV1) -> None:
    """飞书消息接收事件处理"""
    logger.info(f'[消息接收] 事件ID: {data.header.event_id}')
    logger.info(f'[消息接收] 时间戳: {data.header.create_time}')
    
    try:
        # 使用单例管理器获取处理器
        manager = PaykkaSystemManager()
        # 修复：复用全局 IntegratedCommandProcessor 实例，避免每次消息都重新创建
        command_processor = _get_command_processor(manager)
        
        bot_handler = LarkBotHandler(command_processor)
        bot_handler.handle_message(data)
    except Exception as e:
        logger.error(f"❌ 处理飞书消息时出错: {e}")

def do_customized_event(data: lark.CustomizedEvent) -> None:
    """自定义事件处理"""
    logger.info(f'[自定义事件] 事件类型: {data.event.type}')
    logger.info(f'[自定义事件] 请求ID: {data.header.request_id}')

# ===================== 主程序入口 =====================
def start_lark_bot():
    """启动飞书机器人"""
    try:
        logger.info("🤖 启动飞书机器人...")
        
        # 创建事件处理器
        event_handler = lark.EventDispatcherHandler.builder(
            LARK_ENCRYPT_KEY,
            LARK_VERIFICATION_TOKEN
        ) \
        .register_p2_im_message_receive_v1(do_p2_im_message_receive_v1) \
        .register_p1_customized_event("message", do_customized_event) \
        .build()
        
        # 创建WebSocket客户端
        client = lark.ws.Client(
            LARK_APP_ID,
            LARK_APP_SECRET,
            event_handler=event_handler,
            log_level=lark.LogLevel.INFO
        )
        
        # 启动客户端
        client.start()
        
    except Exception as e:
        logger.error(f"❌ 飞书机器人启动失败: {e}")

def start_lark_bot_in_background():
    """在后台启动飞书机器人"""
    def run_bot():
        start_lark_bot()
    
    # 在新线程中启动机器人
    bot_thread = threading.Thread(target=run_bot, daemon=True, name="LarkBotThread")
    bot_thread.start()
    return bot_thread

# ===================== 交互式命令行 =====================
def interactive_command_line():
    """交互式命令行界面（用于测试）- 使用单例，避免重复登录"""
    print("\n" + "="*60)
    print("PAYKKA集成控制系统 - 命令行模式")
    print("="*60)
    print("注意：使用已登录的全局配置器，不会重复登录")
    print("输入'退出'或'exit'结束程序")
    print("输入'帮助'查看可用指令")
    print("="*60)
    
    try:
        # 使用单例管理器获取处理器
        manager = PaykkaSystemManager()
        command_processor = IntegratedCommandProcessor(manager)
        
        while True:
            try:
                user_input = input("\n请输入指令: ").strip()
                
                if user_input.lower() in ["退出", "exit", "quit"]:
                    print("👋 再见！")
                    break
                
                if not user_input:
                    continue
                
                # 处理指令
                response = command_processor.process(user_input)
                print(f"\n🤖 系统回复:\n{response}")
                
            except KeyboardInterrupt:
                print("\n👋 程序被用户中断")
                break
            except Exception as e:
                print(f"❌ 错误: {e}")
    except Exception as e:
        print(f"❌ 初始化失败: {e}")

