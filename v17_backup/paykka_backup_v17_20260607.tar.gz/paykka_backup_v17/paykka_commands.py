# ===================== paykka_commands.py =====================
# IntegratedCommandProcessor - 集成指令处理核心
# 从 paykka_controllerV16.py 提取

import json
import time
import urllib.parse
import requests
import re
import threading
import os
import hashlib
import asyncio
import subprocess
import base64
import sys
from typing import List, Dict, Tuple, Any, Optional, Union
from datetime import datetime, date, timedelta, timezone, time as dtime
from playwright.async_api import async_playwright
import pandas as pd
from github import Github, InputGitAuthor
import pytz

from paykka_config import *
from paykka_core import PaykkaSystemManager, send_wechat_work_message
from paykka_xt_rate import XTRateQueryManager
from paykka_competitor import CompetitorRateQuery, CompetitorHistoryQuery
from datetime import datetime, timedelta

class IntegratedCommandProcessor:
    """集成指令处理器 - 增强版，支持自动重连"""
    
    def __init__(self, manager: PaykkaSystemManager):
        self.manager = manager
        self.forex_config = None
        self.routing_config = None
        self.balance_query = None
        self.fx_monitor = None
        self.rate_monitor = None
        self.exchange_rate_monitor = None  # 新增
        self.fx_monitoring_task = None  # 新增：交易监控定时任务实例
        self.balance_monitoring_task = None

        self.commands = {
            "帮助": self.handle_help,
            "help": self.handle_help,
            "状态": self.handle_status,
            "测试": self.handle_test,
            "Token刷新状态": self.handle_token_refresh_status,
            "手动刷新Token": self.handle_manual_token_refresh,
            "配置": self.handle_configure_forex,
            "修改路由": self.handle_update_routing,
            "查询路由": self.handle_query_routing,
            "所有路由": self.handle_query_all_routing,
            "同步路由": self.handle_sync_to_github,
            "启动路由调度": self.handle_start_routing_scheduler,
            "停止路由调度": self.handle_stop_routing_scheduler,
            "路由调度状态": self.handle_routing_scheduler_status,
            "更新路由调度配置": self.handle_force_reload_routing_config,
            "余额查询": self.handle_query_balance,
            "余额预警": self.handle_check_balance_alert,
            "生成余额报告": self.handle_generate_balance_report,
            "敞口统计": self.handle_fx_statistics,
            "交易监控": self.handle_fx_monitoring,
            "机构列表": self.handle_org_list,
            "汇率监控": self.handle_rate_monitoring,
            "汇率检查": self.handle_rate_check,
            "汇率报告": self.handle_rate_report,
            "货币对列表": self.handle_currency_pairs,
            "路由价格监控": self.handle_exchange_rate_monitor,
            "定时路由价格监控": self.handle_start_exchange_rate_monitor,
            "路由汇率告警": self.handle_exchange_rate_alert,
            "路由汇率查询": self.handle_exchange_rate_status,
            "定时余额监控": self.handle_balance_monitoring,
            "余额监控状态": self.handle_balance_monitoring_status,
            "停止余额监控": self.handle_stop_balance_monitoring,
            "XT汇率查询": self.handle_xt_rate_query,
            "友商汇率查询": self.handle_competitor_rate_query,
            "友商查询": self.handle_competitor_rate_query,
            "历史报价": self.handle_history_rate_query,
            "XT报价": self.handle_history_rate_query,
            "WF报价": self.handle_history_rate_query,
            "LL报价": self.handle_history_rate_query,
            "路由历史报价": self.handle_route_history_quote,
            "路由历史": self.handle_route_history_quote,
        }
        
        # ===================== 智能指令别名表 =====================
        # 格式: (别名列表, 参数提取函数, 说明)
        self.command_aliases = [
            # --- 查询类 ---
            (["查询路由", "路由查询", "查看路由", "路由"], 
             lambda t: self._extract_pair_args(t), "查询某货币对路由"),
            (["所有路由", "全部路由", "路由列表", "路由配置"], 
             lambda t: ([], None), "查看所有路由配置"),
            (["余额查询", "查询余额", "余额", "查余额"], 
             lambda t: ([], None), "查询所有机构余额"),
            (["路由汇率查询", "路由汇率", "路由价格查询", "路由价格", "汇率查询"], 
             lambda t: ([], None), "查询路由实时汇率"),
            (["XT汇率查询", "XT查询", "查询XT汇率", "xt汇率", "XT价格", "XT报价"], 
             lambda t: self._extract_xt_pair_args(t), "查询XT平台汇率报价"),
            (["友商汇率查询", "友商查询", "友商汇率", "查询友商", "友商报价", "同行汇率"], 
             lambda t: self._extract_competitor_args(t), "查询所有友商汇率报价"),
            (["历史报价", "XT报价", "WF报价", "LL报价", "XT历史", "WF历史", "LL历史", "汇率走势", "汇率历史"], 
             lambda t: self._extract_history_args(t), "查询友商历史汇率数据并生成走势图"),
            (["汇率检查", "检查汇率", "汇率对比"], 
             lambda t: ([], None), "检查汇率差异"),
            (["汇率监控", "汇率监控查询"], 
             lambda t: ([t] if len(t.split()) > 1 else []), "执行汇率监控"),
            (["路由价格监控", "路由汇率监控"], 
             lambda t: ([], None), "执行一次路由价格监控"),
            (["路由历史报价", "路由历史", "渠道历史报价", "渠道历史"], 
             lambda t: self._extract_history_quote_args(t), "查询路由/渠道过去N天的历史报价"),
            (["路由调度状态", "调度状态", "调度器状态"], 
             lambda t: ([], None), "查看路由调度器状态"),
            (["余额监控状态", "余额监控"], 
             lambda t: ([], None), "查看余额监控状态"),
            (["机构列表", "机构", "渠道列表"], 
             lambda t: ([], None), "查看机构列表"),
            (["货币对列表", "货币对", "币种列表"], 
             lambda t: ([], None), "查看货币对列表"),
            (["Token刷新状态", "token状态", "令牌状态"], 
             lambda t: ([], None), "查看Token状态"),
            (["汇率报告", "汇率报告查询"], 
             lambda t: ([], None), "查看汇率报告"),
            # --- 操作类 ---
            (["敞口统计", "统计敞口", "敞口查询", "敞口"], 
             lambda t: self._extract_org_and_date_args(t), "换汇敞口统计"),
            (["生成余额报告", "余额报告", "生成报告"], 
             lambda t: ([], None), "生成并上传余额报告"),
            (["余额预警", "预警检查"], 
             lambda t: ([], None), "检查余额预警"),
            (["交易监控", "换汇监控", "交易统计"], 
             lambda t: self._extract_org_args(t), "换汇交易监控"),
            (["修改路由", "更新路由", "设置路由", "切换路由"], 
             lambda t: self._extract_route_update_args(t), "修改货币对路由"),
            (["同步路由", "同步配置", "同步到github"], 
             lambda t: ([], None), "同步路由配置到GitHub"),
            (["配置", "汇差配置", "设置汇差"], 
             lambda t: self._extract_pair_args(t), "配置汇差"),
            (["路由汇率告警", "汇率告警", "路由告警"], 
             lambda t: ([], None), "检查路由汇率告警"),
            # --- 定时任务类 ---
            (["启动路由调度", "开启路由调度", "路由调度启动"], 
             lambda t: ([], None), "启动路由定时切换"),
            (["停止路由调度", "关闭路由调度", "路由调度停止"], 
             lambda t: ([], None), "停止路由定时切换"),
            (["定时余额监控", "启动余额监控", "开启余额监控"], 
             lambda t: self._extract_number_arg(t, 60), "启动余额定时监控"),
            (["停止余额监控", "关闭余额监控"], 
             lambda t: ([], None), "停止余额定时监控"),
            (["定时路由价格监控", "启动路由价格监控", "开启路由价格监控"], 
             lambda t: self._extract_number_arg(t, 5), "启动路由价格定时监控"),
            (["更新路由调度配置", "重载路由配置", "刷新路由配置"], 
             lambda t: ([], None), "重新加载路由调度配置"),
            # --- 系统类 ---
            (["手动刷新Token", "刷新token", "刷新令牌"], 
             lambda t: ([], None), "手动刷新Token"),
            (["状态", "系统状态", "status"], 
             lambda t: ([], None), "查看系统状态"),
            (["帮助", "help", "命令", "?", "？"], 
             lambda t: ([], None), "查看帮助"),
            (["测试", "test", "测试连接"], 
             lambda t: ([], None), "测试系统连接"),
        ]

    # 添加处理方法：
    def handle_token_refresh_status(self, args: List[str]) -> str:
        """查看Token自动刷新状态"""
        try:
            manager = self.manager
            response = "🔐 Token自动刷新状态\n"
            response += "=" * 40 + "\n"
        
            if manager._token_refresh_thread and manager._token_refresh_thread.is_alive():
                response += "🟢 状态: 运行中\n"
            else:
                response += "🔴 状态: 已停止\n"
        
            response += f"⏰ 刷新时间点: {', '.join(manager._token_refresh_times)}\n"
        
            if manager._last_login_time:
                last_time = datetime.fromtimestamp(manager._last_login_time)
                age_hours = (datetime.now() - last_time).total_seconds() / 3600
                response += f"📅 上次刷新: {last_time.strftime('%Y-%m-%d %H:%M:%S')} ({age_hours:.1f}小时前)\n"
        
            # 计算下次刷新时间
            try:
                next_refresh_time = manager._calculate_next_refresh_time()
                hours_left = (next_refresh_time - datetime.now()).total_seconds() / 3600
                response += f"⏳ 下次刷新: {next_refresh_time.strftime('%Y-%m-%d %H:%M:%S')} ({hours_left:.1f}小时后)\n"
            except:
                response += f"⏳ 下次刷新: 计算中...\n"
        
            response += f"🔑 Token状态: {'有效' if manager._token else '无效'}\n"
            if manager._token:
                response += f"   长度: {len(manager._token)} 字符\n"
        
            response += "\n💡 提示: Token有效期为24小时，自动刷新确保不过期"
            return response
        
        except Exception as e:
            return f"❌ 获取Token刷新状态失败: {e}"

    def handle_manual_token_refresh(self, args: List[str]) -> str:
        """手动刷新Token"""
        try:
            manager = self.manager
            logger.info("🔄 手动触发Token刷新...")
        
            success = manager._refresh_token_with_retry()
        
            if success:
                return "✅ Token手动刷新成功"
            else:
                return "❌ Token手动刷新失败，请检查日志"
        
        except Exception as e:
            return f"❌ 手动刷新Token失败: {e}"
    
    # ===================== 智能指令别名系统 =====================
    # 初始化在 __init__ 末尾完成
    
    def _extract_pair_args(self, text: str) -> tuple:
        """从文本中提取货币对参数 (如 'USD CNH' 或 'USDCNH')"""
        # 去掉指令关键词，提取剩余部分
        # 尝试匹配 3字母+空格+3字母 或 6字母连写
        m = re.search(r'([A-Za-z]{3})\s*([A-Za-z]{3})', text)
        if m:
            return ([m.group(1).upper(), m.group(2).upper()], None)
        return ([], None)
    
    def _extract_org_args(self, text: str) -> tuple:
        """从文本中提取机构代码"""
        m = re.search(r'\b(YB|CC|OCBC|HCE|MDAQ)\b', text, re.IGNORECASE)
        if m:
            return ([m.group(1).upper()], None)
        # 也检查中文
        if '易宝' in text or 'yb' in text.lower():
            return (['YB'], None)
        if 'cc' in text.lower():
            return (['CC'], None)
        return ([], None)
    
    def _extract_org_and_date_args(self, text: str) -> tuple:
        """从文本中提取机构代码和日期参数"""
        args = []
        m = re.search(r'\b(YB|CC|OCBC|HCE|MDAQ)\b', text, re.IGNORECASE)
        if m:
            args.append(m.group(1).upper())
        return (args, None)
    
    def _extract_route_update_args(self, text: str) -> tuple:
        """从文本中提取修改路由的参数: 货币对 + 规则"""
        args = []
        m = re.search(r'([A-Za-z]{3})\s*([A-Za-z]{3})', text)
        if m:
            args.extend([m.group(1).upper(), m.group(2).upper()])
        # 提取规则
        m2 = re.search(r'(RULE_\w+)', text, re.IGNORECASE)
        if m2:
            args.append(m2.group(1).upper())
        return (args, None)
    
    def _extract_number_arg(self, text: str, default: int) -> tuple:
        """从文本中提取数字参数（如间隔分钟数）"""
        m = re.search(r'\b(\d+)\b', text)
        if m:
            return ([m.group(1)], None)
        return ([], None)
    
    def _extract_xt_pair_args(self, text: str) -> tuple:
        """从文本中提取 XT 货币对参数（支持单对和多对查询）
        示例: 'XT查询 USD CNY' → ['USD', 'CNY']
              'XT查询 USD CNY, EUR CNY' → ['USD', 'CNY', 'EUR', 'CNY']
        """
        args = []
        # 去掉指令关键词部分，只保留参数
        # 匹配格式: 3字母+空格+3字母（可能逗号分隔多组）
        pairs = re.findall(r'([A-Za-z]{3})\s+([A-Za-z]{3})', text)
        for m in pairs:
            args.extend([m[0].upper(), m[1].upper()])
        return (args, None)

    def _extract_competitor_args(self, text: str) -> tuple:
        """从文本中提取友商代码和货币对参数
        示例: '友商查询 XT WF' → ['XT', 'WF']
              '友商查询 USD CNY' → ['USD', 'CNY']
        """
        args = []
        # 先检查是否有友商代码
        codes_found = re.findall(r'\b(XT|WF|LL|AW|KS|SK)\b', text, re.IGNORECASE)
        for c in codes_found:
            args.append(c.upper())
        
        # 如果没有友商代码，检查是否有货币对
        if not args:
            m = re.search(r'([A-Za-z]{3})\s+([A-Za-z]{3})', text)
            if m:
                args.extend([m.group(1).upper(), m.group(2).upper()])
        
        return (args, None)

    def _fuzzy_match_command(self, text: str) -> tuple:
        """
        智能匹配指令。
        返回 (规范指令名, 参数列表, 匹配得分)
        得分: 100=精确匹配, 95=前缀匹配, 80+=高置信别名, 60+=模糊匹配, 0=不匹配
        同分情况下优先选择更长的别名（更精确匹配）
        """
        text_stripped = text.strip()
        if not text_stripped:
            return (None, [], 0)
        
        def _safe_extract_args(extractor, txt):
            """安全调用参数提取函数，兼容返回2个值或更多值的情况"""
            try:
                result = extractor(txt)
                if isinstance(result, tuple):
                    return result[0]  # 取第一个元素（args列表）
                return result
            except Exception:
                return []
        
        best_score = 0
        best_cmd = None
        best_args = []
        best_alias_len = 0
        
        for aliases, arg_extractor, _desc in self.command_aliases:
            for alias in aliases:
                alias_lower = alias.lower()
                text_lower = text_stripped.lower()
                alias_len = len(alias)
                
                # 1. 精确前缀匹配 (100分)
                if text_lower == alias_lower:
                    args = _safe_extract_args(arg_extractor, text_stripped)
                    return (aliases[0], args, 100)
                
                # 2. 以别名开头 (95分) - 如 "查询路由 USD CNH"
                if text_lower.startswith(alias_lower + ' ') or text_lower.startswith(alias_lower):
                    args = _safe_extract_args(arg_extractor, text_stripped)
                    score = 95
                    # 同分情况下优先选择更长的别名
                    if score > best_score or (score == best_score and alias_len > best_alias_len):
                        best_score = score
                        best_cmd = aliases[0]
                        best_args = args
                        best_alias_len = alias_len
                
                # 3. 别名包含在文本中 (80分) - 如 "帮我查询路由"
                if alias_lower in text_lower and len(alias_lower) >= 2:
                    score = 80
                    if score > best_score or (score == best_score and alias_len > best_alias_len):
                        best_score = score
                        best_cmd = aliases[0]
                        # 从完整文本中提取参数（而不只是截取别名后的部分）
                        best_args = _safe_extract_args(arg_extractor, text_stripped)
                        best_alias_len = alias_len
                
                # 4. 关键词匹配 (60分) - 别名的主要字符必须在文本中出现
                # 要求至少2/3的字符匹配，避免"乱七八糟"匹配到"帮助"
                if len(alias) >= 3:
                    chars = set(alias_lower.replace(' ', ''))
                    text_chars = set(text_lower.replace(' ', ''))
                    overlap = len(chars & text_chars)
                    required = max(len(chars) - 1, int(len(chars) * 0.6))
                    if overlap >= required and overlap >= 2:
                        score = 60 + overlap
                        if score > best_score or (score == best_score and alias_len > best_alias_len):
                            best_score = score
                            best_cmd = aliases[0]
                            best_args = _safe_extract_args(arg_extractor, text_stripped)
                            best_alias_len = alias_len
        
        return (best_cmd, best_args, best_score)
    
    def parse_command(self, text: str) -> Dict:
        """智能解析指令文本（支持别名、模糊匹配）"""
        parts = text.strip().split()
        if not parts:
            return {"command": "", "args": []}
        
        # 先尝试精确匹配原有 commands 字典（兼容性）
        # 按键长度降序排列，确保长命令优先匹配（如"路由历史报价"优先于"路由"）
        for cmd_key in sorted(self.commands.keys(), key=len, reverse=True):
            if text.startswith(cmd_key):
                args = text[len(cmd_key):].strip().split()
                # 对于历史报价指令，将友商代码前置到 args 中，便于 handler 识别
                if cmd_key in ["XT报价", "WF报价", "LL报价", "历史报价"]:
                    if cmd_key == "XT报价":
                        args = ["XT"] + args
                    elif cmd_key == "WF报价":
                        args = ["WF"] + args
                    elif cmd_key == "LL报价":
                        args = ["LL"] + args
                    else:
                        # 历史报价 - 尝试从 args 中识别友商，如果没有则默认 XT
                        has_source = any(a.upper() in ["XT", "WF", "LL"] for a in args)
                        if not has_source:
                            args = ["XT"] + args
                return {"command": cmd_key, "args": args}
        
        # 智能模糊匹配
        cmd, args, score = self._fuzzy_match_command(text)
        
        if cmd and score >= 60:
            return {"command": cmd, "args": args}
        
        # 完全无法匹配
        return {"command": text.split()[0], "args": text.split()[1:] if len(text.split()) > 1 else []}
    
    def safe_execute(self, func, *args, **kwargs):
        """
        安全的指令执行封装
        自动处理Token过期和网络异常，最多重试2次
        所有异常都会被捕获并返回友好的错误信息，不会导致进程崩溃
        """
        max_retries = kwargs.pop('max_retries', 2)
        last_error = None
        
        for attempt in range(max_retries + 1):
            try:
                result = func(*args, **kwargs)
                return result
                
            except Exception as e:
                last_error = e
                error_msg = str(e)
                logger.error(f"指令执行异常（第{attempt+1}次）: {error_msg}")
                
                # 检查是否是认证相关错误
                is_auth_error = any(keyword in error_msg.lower() for keyword in 
                                  ['token', 'auth', 'unauthorized', 'forbidden', '010112', '401', '403'])
                
                if is_auth_error and attempt < max_retries:
                    logger.warning("🔐 检测到认证错误，尝试刷新Token并重试...")
                    try:
                        self.manager._refresh_token_with_retry(max_retries=1, retry_delay=10)
                    except Exception as refresh_err:
                        logger.error(f"Token刷新也失败: {refresh_err}")
                    time.sleep(1)
                    continue
                elif attempt < max_retries:
                    logger.warning(f"🔁 指令执行失败，第{attempt+1}次重试...")
                    time.sleep(1)
                    continue
        
        # 所有重试都失败，返回友好错误信息而非抛出异常
        return f"❌ 指令执行失败（已重试{max_retries}次）: {str(last_error)[:200]}"
    
    def handle_configure_forex(self, args: List[str]) -> str:
        """处理汇差配置指令（增强版，支持自动重连）"""
        if len(args) < 5:
            return "❌ 参数不足，格式: 配置 [卖出币种]->[买入币种] [成本/参考] [数据源] [类型] [值]"
        
        try:
            # 使用安全执行
            return self.safe_execute(self._configure_forex_impl, args)
        except Exception as e:
            return f"❌ 汇差配置失败（自动重连后仍失败）: {str(e)}"
    
    def _configure_forex_impl(self, args: List[str]) -> str:
        """汇差配置实现（被safe_execute包装）"""
        # 解析货币对
        pair_match = re.match(r'([A-Z]{3})->([A-Z]{3})', args[0])
        if not pair_match:
            return "❌ 货币对格式错误，应为: NGN->USD"
        
        sell_cur, buy_cur = pair_match.groups()
        
        # 配置类型
        config_type = args[1]
        if config_type not in ["成本底价", "参考基准"]:
            return "❌ 配置类型错误，应为: 成本底价 或 参考基准"
        
        # 数据源
        provider = args[2].upper()
        if provider not in ["FW", "WISE", "PROC", "YB"]:
            return "❌ 数据源错误，不在渠道列表中"
        
        # 配置方式
        type_value = args[3]
        if type_value not in ["BY_RATIO", "BY_DIFF"]:
            return "❌ 配置方式错误，应为: BY_RATIO 或 BY_DIFF"
        
        # 汇差值
        value = args[4]
        
        # 获取汇差配置器
        if not self.forex_config:
            self.forex_config = self.manager.get_forex_configurator()
        
        # 构建配置
        config = {
            "provider": provider,
            "type": type_value,
            "value": value
        }
        
        # 这里简化处理
        if config_type == "成本底价":
            cost_config = config
            ref_configs = [{"provider": "BOC", "type": "BY_DIFF", "value": "0.0"}]
        else:
            # 对于参考基准，假设成本为默认值
            cost_config = {"provider": "WISE", "type": "BY_RATIO", "value": "-0.01"}
            ref_configs = [config]
        
        # 调用增强的PAYKKA配置接口（内部已包含重试）
        success, message = self.forex_config.configure_forex_pair(
            sell_cur, buy_cur, cost_config, ref_configs
        )
        
        if success:
            return f"✅ 汇差配置成功！\n币对: {sell_cur}->{buy_cur}\n类型: {config_type}\n数据源: {provider}\n方式: {type_value}\n值: {value}\n📢 已发送企业微信群通知"
        else:
            return f"❌ 汇差配置失败: {message}"
    
    def handle_update_routing(self, args: List[str]) -> str:
        """处理路由修改指令（增强版，支持自动重连）"""
        if len(args) < 4:
            return "❌ 参数不足，格式: 修改路由 [卖出币种] [买入币种] [策略规则] [启用/禁用]"
        
        try:
            # 使用安全执行
            return self.safe_execute(self._update_routing_impl, args)
        except Exception as e:
            return f"❌ 路由修改失败（自动重连后仍失败）: {str(e)}"
    
    def _update_routing_impl(self, args: List[str]) -> str:
        """路由修改实现（被safe_execute包装）"""
        sell_cur = args[0].upper()
        buy_cur = args[1].upper()
        strategy = args[2].upper()
        standalone = args[3] in ["启用", "enable", "enabled", "1", "true", "是", "yes"]
        
        # 获取路由配置器
        if not self.routing_config:
            self.routing_config = self.manager.get_routing_configurator()
        
        # 检查策略是否有效
        if strategy not in FX_STRATEGY_RULES:
            return f"❌ 策略规则 {strategy} 无效\n支持的规则: {', '.join(FX_STRATEGY_RULES)}"
        
        # 执行修改（使用增强版方法）
        success = self.routing_config.update_fx_pair_config(
            sell_cur, buy_cur, strategy, standalone
        )
        
        if success:
            # 发送企业微信群通知
            notification_message = f"✅路由配置更新✅\n币对: {sell_cur}->{buy_cur}\n策略: {strategy}\n独立换汇: {'启用' if standalone else '禁用'}"
            send_wechat_work_message(notification_message)
            
            return f"✅ 路由修改成功\n卖出: {sell_cur} -> 买入: {buy_cur}\n策略: {strategy}\n独立换汇: {'启用' if standalone else '禁用'}\n📢 已发送企业微信群通知"
        else:
            return f"❌ 路由修改失败"

    def _check_routing_scheduler_process(self) -> Optional[int]:
        """检查独立的路由调度进程是否在运行"""
        try:
            result = subprocess.run(
                ["pgrep", "-f", "python3.*routing_scheduler_daemon\\.py"],
                capture_output=True, text=True, timeout=5
            )
            pids = [p for p in result.stdout.strip().split('\n') if p]
            return int(pids[0]) if pids else None
        except:
            return None

    def handle_start_routing_scheduler(self, args: List[str]) -> str:
        """启动路由调度器（独立守护进程）"""
        existing = self._check_routing_scheduler_process()
        if existing:
            return f"⚠️ 路由调度器已在运行 (PID: {existing})"
        try:
            subprocess.Popen(
                ["python3", "/workspace/routing_scheduler_daemon.py"],
                stdout=open("/workspace/routing_scheduler_output.log", "a"),
                stderr=subprocess.STDOUT,
                cwd="/workspace",
                start_new_session=True
            )
            return "✅ 已启动路由调度器\n⏰ 将从 GitHub 读取 routing_schedule.md 配置自动执行"
        except Exception as e:
            return f"❌ 启动失败: {e}"

    def handle_stop_routing_scheduler(self, args: List[str]) -> str:
        """停止路由调度器"""
        pid = self._check_routing_scheduler_process()
        if not pid:
            return "ℹ️ 路由调度器未在运行"
        try:
            subprocess.run(["kill", str(pid)], timeout=5)
            time.sleep(1)
            if not self._check_routing_scheduler_process():
                return f"🛑 路由调度器已停止 (PID: {pid})"
            else:
                subprocess.run(["kill", "-9", str(pid)], timeout=5)
                return f"🛑 路由调度器已强制停止 (PID: {pid})"
        except Exception as e:
            return f"❌ 停止失败: {e}"

    def handle_routing_scheduler_status(self, args: List[str]) -> str:
        """获取路由调度器状态（详细信息版）"""

        pid = self._check_routing_scheduler_process()
        if not pid:
            return "🔴 路由调度器: 未启动\n💡 使用「启动路由调度」启动"

        # 尝试从日志中提取关键信息
        next_check = "未知"
        next_config_fetch = "未知"
        rule_count = "未知"
        enabled_count = "未知"
        token_refresh = "未知"

        try:
            with open("/workspace/logs/routing_scheduler.log", "r", encoding="utf-8") as f:
                lines = f.readlines()
            for line in reversed(lines):
                if "下次检查时间:" in line and next_check == "未知":
                    m = re.search(r"下次检查时间:\s*([\d\-]+\s+[\d:]+)", line)
                    if m:
                        next_check = m.group(1)
                if "下次读取配置时间:" in line and next_config_fetch == "未知":
                    m = re.search(r"下次读取配置时间:\s*([\d\-]+\s+[\d:]+)", line)
                    if m:
                        next_config_fetch = m.group(1)
                if "成功解析路由切换配置:" in line and rule_count == "未知":
                    m = re.search(r"成功解析路由切换配置:\s*(\d+)\s*条", line)
                    if m:
                        rule_count = m.group(1)
                if "下次Token刷新时间:" in line and token_refresh == "未知":
                    m = re.search(r"下次Token刷新时间:\s*([\d\-]+\s+[\d:]+)", line)
                    if m:
                        token_refresh = m.group(1)
        except Exception:
            pass

        # 从日志提取规则详情（避免触发登录导致崩溃）
        schedule_rules = []
        try:
            with open("/workspace/logs/routing_scheduler.log", "r", encoding="utf-8") as f:
                log_content = f.read()
            # 从日志中的调度器状态区域提取规则信息
            # 回退方案：直接从GitHub获取配置文件
            url = "https://api.github.com/repos/13058199807zk-oss/paykka-control/contents/routing_schedule.md"
            headers = {"Authorization": "token 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", "Accept": "application/vnd.github.v3.raw"}
            resp = requests.get(url, headers=headers, timeout=10)
            if resp.status_code == 200:
                md = resp.text
                # 解析 SCHEDULES JSON
                m = re.search(r'SCHEDULES\s*=\s*(\[[\s\S]*?\n\])', md)
                if m:
                    try:
                        schedules = _json.loads(m.group(1))
                        enabled_rules = [s for s in schedules if s.get("enabled", True)]
                        enabled_count = str(len(enabled_rules))
                        if rule_count == "未知":
                            rule_count = str(len(schedules))
                        for s in schedules:
                            status_icon = "🟢" if s.get("enabled", True) else "⚪"
                            days = ",".join(s.get("days", []))
                            pair = s.get("currency_pair", {})
                            pair_str = f"{pair.get('sell','')}/{pair.get('buy','')}"
                            target = s.get("target_rule", "")
                            time_str = s.get("time", "")
                            desc = s.get("description", "")
                            schedule_rules.append(f"{status_icon} {desc}\n   ⏰ {time_str} [{days}] | {pair_str} → {target}")
                    except _json.JSONDecodeError:
                        pass
        except Exception:
            pass

        result = f"""🟢 路由调度器: 运行中
🔢 进程 PID: {pid}
📋 规则总数: {rule_count} | 启用: {enabled_count}
⏰ 下次检查: {next_check}
📅 下次读取配置: {next_config_fetch}
🔐 下次Token刷新: {token_refresh}
📝 日志: /workspace/logs/routing_scheduler.log
───────────────────────"""
        if schedule_rules:
            result += "\n📊 路由规则:\n" + "\n".join(schedule_rules)
        return result

    def handle_force_reload_routing_config(self, args: List[str]) -> str:
        """重新加载路由调度配置"""
        try:
            scheduler = self.manager.get_routing_scheduler()
            result = scheduler.force_reload_config()
            return result
        except Exception as e:
            return f"❌ 强制重载路由配置失败: {e}"
    
    def handle_query_balance(self, args: List[str]) -> str:
        """处理余额查询指令（增强版）"""
        try:
            return self.safe_execute(self._query_balance_impl, args)
        except Exception as e:
            return f"❌ 余额查询失败（自动重连后仍失败）: {str(e)}"
    
    def _query_balance_impl(self, args: List[str]) -> str:
        """余额查询实现（支持指定渠道/币种）"""
        if not self.balance_query:
            self.balance_query = self.manager.get_balance_query()
        
        # 解析参数：余额查询 [渠道] [币种]
        # 渠道: YB/易宝, CC/Currencycloud, HCE/海云汇, 全部/ALL
        # 币种: USD, CNH, EUR 等（三字母）
        target_org = None  # None = 全部
        target_ccy = None  # None = 全部
        
        org_map = {"YB": "YB", "易宝": "YB", "CC": "CC", "CURRENCYCLOUD": "CC", 
                    "HCE": "HCE", "海云汇": "HCE", "全部": None, "ALL": None}
        
        for arg in args:
            upper = arg.upper().strip()
            # 检查是否是机构
            if upper in org_map:
                target_org = org_map[upper]
            elif upper in ["YB", "CC", "HCE"]:
                target_org = upper
            # 检查是否是币种（三字母）
            elif re.match(r'^[A-Z]{3}$', upper):
                target_ccy = upper
        
        if target_org:
            # 指定渠道查询
            org_name = {"YB": "易宝", "CC": "Currencycloud", "HCE": "海云汇"}.get(target_org, target_org)
            try:
                results = self.balance_query._query_institution_balance(target_org, org_name)
                if target_ccy:
                    results = [r for r in results if r["币种"].upper() == target_ccy]
                    if not results:
                        return f"ℹ️ {org_name} 未找到币种 {target_ccy} 的余额数据"
                
                if not results:
                    return f"ℹ️ {org_name} 未查询到余额数据"
                
                summary = self._format_balance_summary(results)
                return f"✅ {org_name} 余额查询成功！\n\n📊 查询结果:\n{summary}"
            except Exception as e:
                return f"❌ {org_name} 余额查询失败: {e}"
        else:
            # 全渠道查询
            success, message, results = self.balance_query.query_all_balances()
            
            if success:
                if target_ccy:
                    results = [r for r in results if r["币种"].upper() == target_ccy]
                
                summary = self._format_balance_summary(results)
                
                response = f"✅ 余额查询成功！\n\n"
                response += f"📊 查询结果汇总:\n{summary}\n"
                response += f"💾 数据已保存到: {EXCEL_FILENAME}"
                
                return response
            else:
                return f"❌ 余额查询失败: {message}"
    
    def handle_fx_statistics(self, args: List[str]) -> str:
        """处理'敞口统计'指令（增强版）"""
        try:
            return self.safe_execute(self._fx_statistics_impl, args)
        except Exception as e:
            return f"❌ 敞口统计失败（自动重连后仍失败）: {str(e)}"
    
    def _fx_statistics_impl(self, args: List[str]) -> str:
        """敞口统计实现
        默认统计范围：当日 + 上一个工作日（已交割交易）
        """
        if not self.fx_monitor:
            self.fx_monitor = self.manager.get_fx_transaction_monitor()
        
        # 解析参数
        org_code = None
        start_date = None
        end_date = None
        
        i = 0
        while i < len(args):
            if args[i] == "--org" and i + 1 < len(args):
                org_code = args[i + 1]
                i += 2
            elif args[i] == "--start" and i + 1 < len(args):
                start_date = args[i + 1]
                i += 2
            elif args[i] == "--end" and i + 1 < len(args):
                end_date = args[i + 1]
                i += 2
            else:
                # 位置参数：机构代码（如 YB, CC）
                if org_code is None and not args[i].startswith('--'):
                    org_code = args[i]
                i += 1
        
        # 如果未指定日期范围，默认：当日 + 上一个工作日
        if not start_date and not end_date:
            today = date.today()
            # 计算上一个工作日（跳过周末）
            prev_business_day = today
            while True:
                prev_business_day = prev_business_day - timedelta(days=1)
                if prev_business_day.weekday() < 5:  # 周一到周五
                    break
            start_date = prev_business_day.strftime("%Y-%m-%d")
            end_date = today.strftime("%Y-%m-%d")
        
        result = self.fx_monitor.query_fx_transactions(
            org_code=org_code,
            start_date=start_date,
            end_date=end_date
        )
        
        # 格式化返回结果
        response = self._format_fx_statistics_result(result)
        return response
    
    def handle_rate_monitoring(self, args: List[str]) -> str:
        """处理'汇率监控'指令（增强版）"""
        try:
            return self.safe_execute(self._rate_monitoring_impl, args)
        except Exception as e:
            return f"❌ 汇率监控失败（自动重连后仍失败）: {str(e)}"
    
    def _rate_monitoring_impl(self, args: List[str]) -> str:
        """汇率监控实现"""
        if not self.rate_monitor:
            self.rate_monitor = self.manager.get_rate_monitor()
        
        # 解析参数
        threshold = RATE_ALERT_THRESHOLD
        if args and len(args) > 0:
            try:
                threshold = float(args[0])
            except ValueError:
                pass
        
        # 更新阈值
        self.rate_monitor.alert_threshold = threshold
        
        result = self.rate_monitor.check_rates()
        
        response = f"🔍 汇率监控完成\n"
        response += f"📅 检查时间: {result['check_time']}\n"
        response += f"📊 监控结果:\n"
        response += f"  - PAYKKA汇率: {len(result['paykka_rates'])} 个\n"
        response += f"  - XT汇率: {len(result['xt_rates'])} 个\n"
        response += f"  - 异常货币对: {result['discrepancy_count']} 个\n"
        response += f"  - 发送报警: {len(result['alerts_sent'])} 个\n"
        response += f"⚙️ 使用阈值: {threshold}%\n"
        
        if result['discrepancies']:
            response += f"\n🚨 异常货币对详情:\n"
            for disc in result['discrepancies'][:5]:  # 只显示前5个
                response += f"  - {disc['pair']}: {disc['diff_percent']:.4f}% ({disc['direction']})\n"
            if len(result['discrepancies']) > 5:
                response += f"  ... 还有 {len(result['discrepancies']) - 5} 个异常\n"
        
        if result['uploaded_to_github']:
            response += f"\n💾 汇率报告已上传到GitHub: {GITHUB_RATE_FILE_PATH}\n"
        else:
            response += f"\n❌ 汇率报告上传到GitHub失败\n"
        
        return response

    def handle_exchange_rate_monitor(self, args: List[str]) -> str:
        """处理'路由价格监控'指令（执行一次监控）"""
        try:
            return self.safe_execute(self._exchange_rate_monitor_impl, args)
        except Exception as e:
            return f"❌ 路由价格监控失败（自动重连后仍失败）: {str(e)}"
    
    def _exchange_rate_monitor_impl(self, args: List[str]) -> str:
        """路由价格监控实现"""
        if not self.exchange_rate_monitor:
            self.exchange_rate_monitor = self.manager.get_exchange_rate_monitor()
        
        # 执行监控
        result = self.exchange_rate_monitor.run_monitoring()
        
        # 构建响应
        response = f"🔍 路由价格监控结果\n"
        response += f"📅 检查时间: {result['check_time']}\n"
        response += f"✅ 执行状态: {'成功' if result['success'] else '失败'}\n"
        response += f"📊 监控结果: {result['message']}\n"
        
        if result['rates']:
            response += self.exchange_rate_monitor.print_current_rates(result['rates'])
        
        if result.get('alert_sent', False):
            response += f"🚨 已发送企业微信告警\n"
        
        return response
    
    def handle_start_exchange_rate_monitor(self, args: List[str]) -> str:
        """处理'启动路由价格监控'指令（启动定时监控）"""
        try:
            return self.safe_execute(self._start_exchange_rate_monitor_impl, args)
        except Exception as e:
            return f"❌ 启动路由价格监控失败: {str(e)}"
    
    def _start_exchange_rate_monitor_impl(self, args: List[str]) -> str:
        """启动路由价格定时监控实现"""
        if not self.exchange_rate_monitor:
            self.exchange_rate_monitor = self.manager.get_exchange_rate_monitor()
        
        # 解析间隔参数
        interval_minutes = EXCHANGE_RATE_MONITOR_INTERVAL
        if args and len(args) > 0:
            try:
                interval_minutes = int(args[0])
                if interval_minutes < 1 or interval_minutes > 60:
                    return f"❌ 监控间隔必须在1-60分钟之间"
            except ValueError:
                return f"❌ 无效的监控间隔: {args[0]}"
        
        # 启动后台线程执行定时监控
        def monitor_thread():
            self.exchange_rate_monitor.start_scheduled_monitoring(interval_minutes)
        
        thread = threading.Thread(
            target=monitor_thread,
            daemon=True,
            name="ExchangeRateMonitor"
        )
        thread.start()
        
        return f"✅ 已启动路由价格定时监控\n" \
               f"⏰ 监控间隔: 每{interval_minutes}分钟一次\n" \
               f"🏦 监控来源: {', '.join(self.exchange_rate_monitor.target_sources)}\n" \
               f"⏳ 交易时段: 08:00-15:30 (UTC+8)\n" \
               f"📊 日志文件: {EXCHANGE_RATE_MONITOR_LOG}"
    
    def handle_exchange_rate_alert(self, args: List[str]) -> str:
        """处理'汇率告警'指令（手动检查并发送告警）"""
        try:
            return self.safe_execute(self._exchange_rate_alert_impl, args)
        except Exception as e:
            return f"❌ 汇率告警检查失败: {str(e)}"
    
    def _exchange_rate_alert_impl(self, args: List[str]) -> str:
        """汇率告警检查实现"""
        if not self.exchange_rate_monitor:
            self.exchange_rate_monitor = self.manager.get_exchange_rate_monitor()
        
        # 检查是否在交易时段内
        if not self.exchange_rate_monitor.is_trading_hours():
            return f"ℹ️ 当前不在交易时段内 (08:00-15:30 UTC+8)\n" \
                   f"汇率告警监控仅在交易时段内执行"
        
        # 查询汇率数据
        rates = self.exchange_rate_monitor.query_exchange_rates()
        if not rates:
            return f"❌ 未获取到汇率数据，无法进行告警检查"
        
        # 过滤最新数据
        filtered_rates = self.exchange_rate_monitor.filter_latest_rates_by_source(rates)
        
        # 检查是否需要告警
        alert_info = self.exchange_rate_monitor.check_rate_alert(filtered_rates)
        
        if alert_info:
            # 发送告警
            alert_sent = self.exchange_rate_monitor.send_wechat_alert(alert_info, filtered_rates)
            
            response = f"🚨 检测到汇率异常，已发送告警\n"
            response += f"📅 检查时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            response += f"📈 OCBC买入价: {alert_info['ocbc_rate']}\n"
            response += f"🔔 告警发送: {'成功' if alert_sent else '失败'}\n\n"
            
            response += "📊 异常来源详情:\n"
            for comparison in alert_info["comparisons"]:
                response += f"  - {comparison['source']}: {comparison['rate']:.4f} (高出: {comparison['difference']:.6f})\n"
            
            response += self.exchange_rate_monitor.print_current_rates(filtered_rates)
        else:
            response = f"✅ 汇率检查正常，无需发送告警\n"
            response += f"📅 检查时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            response += self.exchange_rate_monitor.print_current_rates(filtered_rates)
        
        return response
    
    def handle_exchange_rate_status(self, args: List[str]) -> str:
        """处理'路由汇率查询'指令（查看当前路由汇率）"""
        try:
            return self.safe_execute(self._exchange_rate_status_impl, args)
        except Exception as e:
            return f"❌ 路由汇率查询失败: {str(e)}"
    
    def _exchange_rate_status_impl(self, args: List[str]) -> str:
        """路由汇率查询实现"""
        if not self.exchange_rate_monitor:
            self.exchange_rate_monitor = self.manager.get_exchange_rate_monitor()
        
        # 查询汇率数据
        rates = self.exchange_rate_monitor.query_exchange_rates()
        if not rates:
            return f"❌ 未获取到汇率数据"
        
        # 过滤最新数据
        filtered_rates = self.exchange_rate_monitor.filter_latest_rates_by_source(rates)
        
        response = f"📊 最新路由汇率\n"
        response += f"📅 查询时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        response += f"💱 监控货币对: USD/CNH\n"
        response += f"🏦 监控来源: {', '.join(self.exchange_rate_monitor.target_sources)}\n"
        response += f"⏳ 交易时段状态: {'✅ 在交易时段内' if self.exchange_rate_monitor.is_trading_hours() else '❌ 不在交易时段内'}\n\n"
        
        response += "📈 实时汇率详情:\n"
        for source, data in filtered_rates.items():
            if data:
                release_time = data.get('release_time', 'N/A')
                # 格式化时间
                if release_time != 'N/A':
                    try:
                        dt = datetime.fromisoformat(release_time.replace('Z', '+00:00'))
                        release_time = dt.astimezone(self.exchange_rate_monitor.beijing_tz).strftime('%Y-%m-%d %H:%M:%S')
                    except:
                        pass
                
                response += f"  - {source}: {data.get('bid_rate', 'N/A')} (发布时间: {release_time})\n"
            else:
                response += f"  - {source}: 无数据\n"
        
        # 检查是否需要告警
        alert_info = self.exchange_rate_monitor.check_rate_alert(filtered_rates)
        if alert_info:
            response += f"\n🚨 告警状态: 检测到汇率异常\n"
            response += f"   OCBC买入价低于其他来源，建议发送告警\n"
        else:
            response += f"\n✅ 告警状态: 汇率正常\n"
        
        return response
    
    # ===================== XT 汇率查询指令 =====================
    def handle_xt_rate_query(self, args: List[str]) -> str:
        """处理'XT汇率查询'指令"""
        try:
            return self.safe_execute(self._xt_rate_query_impl, args)
        except Exception as e:
            return f"❌ XT 汇率查询失败: {str(e)}"
    
    def _xt_rate_query_impl(self, args: List[str]) -> str:
        """XT 汇率查询实现 - 支持全部查询和指定货币对查询"""
        xt = self.manager.get_xt_rate_query()
        
        # 检查/执行登录（在独立线程+独立事件循环中，避免与主事件循环冲突）
        login_result = {"ok": False, "error": None}
        
        def _do_login():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                login_result["ok"] = loop.run_until_complete(xt.login())
            except Exception as e:
                login_result["error"] = str(e)
            finally:
                loop.close()
        
        login_thread = threading.Thread(target=_do_login, name="XTLogin")
        login_thread.start()
        login_thread.join(timeout=60)
        
        if login_thread.is_alive():
            return "❌ XT 登录超时，请稍后重试"
        
        if not login_result["ok"]:
            err_msg = login_result.get("error", "")
            if "CAPTCHA" in err_msg or "captcha" in err_msg:
                return "❌ XT 登录触发验证码验证，无法自动完成\n💡 请手动登录 XT 后导出 Cookie 到 xt_auth_cache.json"
            return f"❌ XT 平台登录失败: {err_msg or '请检查账号或手动导入 Cookie'}"
        
        # 解析参数，决定查询范围
        target_pairs = None
        
        if args and len(args) >= 2:
            # 指定货币对查询：args 格式 ['USD', 'CNY'] 或 ['USD', 'CNY', 'EUR', 'CNY']
            target_pairs = []
            i = 0
            while i + 1 < len(args):
                from_ccy = args[i].upper()
                to_ccy = args[i + 1].upper()
                target_pairs.append((from_ccy, to_ccy, f"{from_ccy}→{to_ccy}"))
                i += 2
            
            if not target_pairs:
                target_pairs = None  # 参数不足，退回全部查询
        
        if target_pairs is None:
            pairs = xt.get_currency_pairs()
        else:
            pairs = target_pairs
        
        results = xt.query_all_rates(pairs)
        return xt.format_results(results)
    
    # ===================== 友商汇率查询指令 =====================
    def handle_competitor_rate_query(self, args: List[str]) -> str:
        """处理'友商汇率查询'指令"""
        try:
            return self.safe_execute(self._competitor_rate_query_impl, args)
        except Exception as e:
            return f"❌ 友商汇率查询失败: {str(e)}"
    
    def _competitor_rate_query_impl(self, args: List[str]) -> str:
        """友商汇率查询实现 - 支持全部友商和指定友商/货币对"""
        comp = CompetitorRateQuery()
        
        # 解析参数
        target_sources = None  # None = 全部友商
        target_pairs = None    # None = 全部货币对
        
        if args:
            # 检查是否指定了友商代码
            source_codes = [a for a in args if a.upper() in COMPETITOR_CODES]
            if source_codes:
                target_sources = [s.upper() for s in source_codes]
            
            # 检查是否有货币对参数（不在友商代码中的）
            non_source = [a for a in args if a.upper() not in COMPETITOR_CODES]
            if len(non_source) >= 2:
                target_pairs = []
                i = 0
                while i + 1 < len(non_source):
                    f = non_source[i].upper()
                    t = non_source[i + 1].upper()
                    target_pairs.append((f, t, f"{f}→{t}"))
                    i += 2
        
        if target_pairs is None:
            target_pairs = COMPETITOR_CURRENCY_PAIRS
        
        all_results = comp.query_all_competitors(pairs=target_pairs, sources=target_sources)
        return comp.format_competitor_results(all_results)
    
    # ===================== 友商历史报价查询 =====================
    def _extract_history_args(self, text: str):
        """从文本中提取历史报价参数: (source, pair, days)
        
        支持格式:
        - "XT报价 NGNUSD 7D"
        - "WF报价 USDCNH 30D"  
        - "LL报价 EURCNH 14D"
        - "XT历史 USD CNY 7D"
        - "汇率走势 WF USDCNH"
        """
        text = text.strip()
        args = text.split()
        
        source = None
        pair_str = None
        days = 7  # 默认 7 天
        
        # 尝试从指令首词中识别友商
        first_word = args[0].upper() if args else ""
        for code in ["XT", "WF", "LL"]:
            if code in first_word:
                source = code
                break
        
        # 从参数中识别
        for arg in args:
            upper = arg.upper()
            if upper in ["XT", "WF", "LL"]:
                source = upper
            elif re.match(r'^[A-Za-z]{6}$', arg):
                pair_str = arg.upper()
            elif re.match(r'^\d+[DdMmYy]$', arg) or arg.upper() in CompetitorHistoryQuery.TIME_RANGE_MAP:
                days_str = arg
                hq = CompetitorHistoryQuery()
                days = hq._parse_time_range(days_str)
        
        # 如果 pair_str 还没找到，尝试相邻的两个 3 字母
        if not pair_str:
            for i, arg in enumerate(args):
                if len(arg) == 3 and arg.isalpha() and i + 1 < len(args) and len(args[i + 1]) == 3 and args[i + 1].isalpha():
                    pair_str = arg.upper() + args[i + 1].upper()
                    break
        
        # 默认值
        if not pair_str:
            pair_str = "NGNUSD"
        
        return (source, pair_str, days)
    
    def handle_history_rate_query(self, args: List[str]) -> str:
        """处理历史报价指令"""
        try:
            return self.safe_execute(self._history_rate_query_impl, args)
        except Exception as e:
            return f"❌ 历史报价查询失败: {str(e)}"
    
    def _history_rate_query_impl(self, args: List[str]) -> str:
        """历史报价查询实现"""
        hq = CompetitorHistoryQuery()
        
        # 解析参数
        source = None
        pair_str = "NGNUSD"
        days = 7
        
        # 从原始消息文本中识别友商（args 中可能不包含指令关键字）
        text = " ".join(args) if args else ""
        full_text = text  # 保留原始文本用于友商识别
        
        # 从完整文本中识别友商（支持 "XT报价"、"XT历史" 等格式）
        for code in ["XT", "WF", "LL"]:
            if code in full_text.upper():
                source = code
                break
        
        # 从 args 中再次确认友商
        if not source:
            for arg in args:
                upper = arg.upper()
                if upper in ["XT", "WF", "LL"]:
                    source = upper
                    break
        
        if not source:
            return "❌ 请指定友商 (XT/WF/LL)，格式: XT报价 NGNUSD 7D"
        
        # 解析货币对
        for arg in args:
            arg_upper = arg.upper()
            if re.match(r'^[A-Z]{6}$', arg_upper):
                pair_str = arg_upper
                break
            elif re.match(r'^[A-Z]{3}[/\- ][A-Z]{3}$', arg_upper):
                parts = re.split(r'[/\- ]', arg_upper)
                pair_str = parts[0] + parts[1]
                break
        
        # 尝试相邻的两个 3 字母参数
        if pair_str == "NGNUSD" and len(args) >= 3:
            for i, arg in enumerate(args):
                if len(arg) == 3 and arg.isalpha() and i + 1 < len(args) and len(args[i + 1]) == 3 and args[i + 1].isalpha():
                    pair_str = arg.upper() + args[i + 1].upper()
                    break
        
        # 解析时间范围
        for arg in args:
            if re.match(r'^\d+[DdMmYy]$', arg):
                days = hq._parse_time_range(arg)
                break
            elif arg.upper() in CompetitorHistoryQuery.TIME_RANGE_MAP:
                days = hq._parse_time_range(arg.upper())
                break
        
        # 解析货币对方向
        from_ccy, to_ccy = hq._parse_currency_pair(pair_str)
        if not from_ccy or not to_ccy:
            return f"❌ 无法解析货币对: {pair_str}，请使用如 NGNUSD 格式"
        
        source_name = COMPETITOR_CODES.get(source, source)
        logger.info(f"📊 查询 {source_name} 历史汇率: {from_ccy}/{to_ccy} (最近 {days} 天)")
        
        # 执行查询
        result = hq.query_history(source, from_ccy, to_ccy, days)
        
        if not result.get("success"):
            return f"❌ {source_name} {from_ccy}/{to_ccy} 历史查询失败: {result.get('error', '未知错误')}"
        
        # 生成图表
        chart_path = hq.generate_chart(result)
        
        # 格式化文本结果
        text_result = hq.format_history_result(result, chart_path)
        
        # 如果有图表，嵌入图表路径标记，由 handle_message 检测并发送
        if chart_path and os.path.exists(chart_path):
            text_result += f"\n[CHART:{chart_path}]"
        
        return text_result
    
    # ===================== 路由历史报价指令 =====================
    def handle_route_history_quote(self, args: List[str]) -> str:
        """处理'路由历史报价'指令 - 查询OPS路由/渠道历史报价"""
        try:
            return self.safe_execute(self._route_history_quote_impl, args)
        except Exception as e:
            return f"❌ 路由历史报价查询失败: {str(e)}"
    
    def _route_history_quote_impl(self, args: List[str]) -> str:
        """路由历史报价查询实现
        
        支持格式:
        - 路由历史报价                  → 默认 USD/CNH 最近3天（采样整点/半点）
        - 路由历史报价 7                → USD/CNH 最近7天
        - 路由历史报价 USD CNH 7        → 指定货币对+天数
        - 路由历史报价 EUR CNH 5        → 欧元/离岸人民币 5天
        - 路由历史报价 YB 7             → 过滤YB来源 7天（默认USD/CNH）
        - 路由历史报价 YB USD CNH 3     → YB来源 + 指定货币对 + 天数
        """
        from paykka_history_quote import PaykkaHistoryQuoteQuery
        
        token = self.manager.get_token()
        if not token:
            return "❌ 无法获取认证Token，请检查登录状态"
        
        hq = PaykkaHistoryQuoteQuery(token)
        
        # 默认参数
        base_currency = "USD"
        quote_currency = "CNH"
        days = 3
        sources = None
        
        # 解析参数
        # 规则：先识别已知来源代码 → 剩余参数中解析货币对和天数
        # 已知来源列表（3字母的可能被误认为货币代码）
        KNOWN_SOURCES = {
            "YB", "PP", "CC", "BOC", "OCBC", "MDAQ", "HCE",
            "HCE_FX_TOD", "HCE_FX_TOM", "HCE_FX_SPOT",
            "MDAQ_FX_TOD", "MDAQ_FX_TOM", "MDAQ_FX_SPOT",
        }
        # 有效的货币代码（排除来源代码后的3字母）
        VALID_CURRENCIES = {
            "USD", "CNH", "CNY", "EUR", "GBP", "HKD", "SGD", "AUD",
            "IDR", "MYR", "PHP", "THB", "RON", "PLN", "HUF", "NGN",
            "VND", "JPY", "CAD", "CZK", "CHF", "NZD", "SEK", "NOK",
        }
        
        source_args = []
        currency_codes = []
        numeric_args = []
        
        for arg in args:
            arg_upper = arg.upper().strip()
            # 优先匹配已知来源
            if arg_upper in KNOWN_SOURCES:
                source_args.append(arg_upper)
            # 纯数字 = 天数
            elif arg_upper.isdigit():
                numeric_args.append(int(arg_upper))
            # 带D后缀 = 天数
            elif re.match(r'^\d+[Dd]$', arg_upper):
                numeric_args.append(int(arg_upper[:-1]))
            # 3字母且在有效货币列表中 = 货币代码
            elif len(arg_upper) == 3 and arg_upper.isalpha() and arg_upper in VALID_CURRENCIES:
                currency_codes.append(arg_upper)
        
        # 应用解析结果
        if len(currency_codes) >= 2:
            base_currency = currency_codes[0]
            quote_currency = currency_codes[1]
            if quote_currency == "CNY":
                quote_currency = "CNH"
        
        if numeric_args:
            days = numeric_args[0]
        
        if source_args:
            sources = source_args
        
        # 限制天数范围
        if days <= 0:
            days = 3
        elif days > 7:
            return f"❌ 查询天数不能超过7天（当前: {days}天），避免服务器压力过大"
        
        # 检查货币对是否在已知支持列表中
        pair = f"{base_currency}/{quote_currency}"
        
        logger.info(f"📊 路由历史报价查询: {pair}, {days}天, 来源过滤: {sources or '全部'}")
        
        # 执行查询（可能耗时较长，取决于天数）
        result = hq.query_history(
            base_currency=base_currency,
            quote_currency=quote_currency,
            days=days,
            sources=sources,
        )
        
        # 格式化文本
        text_result = hq.format_results(result, base_currency, quote_currency, days)
        
        # 生成图表并附加 [CHART:path] 标记（飞书会自动发送图片）
        if result.get("success") and result.get("total_count", 0) > 0:
            chart_path = hq.generate_chart(result, base_currency, quote_currency)
            if chart_path and os.path.exists(chart_path):
                text_result += f"\n[CHART:{chart_path}]"
        
        return text_result
    
    @staticmethod
    def _extract_history_quote_args(text: str) -> Tuple[List[str], Optional[str]]:
        """从文本中提取路由历史报价参数
        
        Returns:
            (args_list, matched_keyword)
        """
        # 去掉指令关键字
        keywords = ["路由历史报价", "路由历史", "渠道历史报价", "渠道历史"]
        for kw in keywords:
            if kw in text:
                text = text.replace(kw, "", 1)
                break
        
        # 提取剩余参数（空格分隔）
        args = text.strip().split()
        return (args, None)
    
    # 原有方法保持不变，为保持完整性，这里列出方法签名
    def handle_help(self, args: List[str]) -> str:
        """处理帮助指令"""
        help_text = """🤖 PAYKKA集成控制系统 - 使用说明

📋 可用指令：

🔄 汇差配置功能：
1. 配置 [卖出币种]->[买入币种] [成本/参考] [数据源] [类型] [值]
   示例: 配置 NGN->USD 成本底价 FW BY_RATIO -0.0005
   示例: 配置 NGN->USD 参考基准 FW BY_RATIO -0.005

🛣️ 路由配置功能：
1. 修改路由 [卖出币种] [买入币种] [策略规则] [启用/禁用]
   示例: 修改路由 USD CNH RULE_CC 启用
2. 查询路由 [卖出币种] [买入币种]
   示例: 查询路由 USD CNH
3. 所有路由 - 查询所有路由配置
4. 同步路由 - 同步路由配置到GitHub
5. 启动路由调度 - 启动路由定时切换任务
6. 停止路由调度 - 停止路由定时切换任务
7. 路由调度状态 - 查看路由调度器状态
8. 更新路由调度配置 - 重新加载路由调度器配置

💰 余额查询功能：
1. 余额查询 [渠道] [币种] - 查询余额（支持指定渠道/币种）
   示例: 余额查询           → 查询全部渠道
   示例: 余额查询 YB        → 查询易宝全部币种
   示例: 余额查询 CC USD    → 查询Currencycloud的USD余额
   示例: 余额查询 易宝 CNH  → 查询易宝的CNH余额
2. 余额预警 - 检查余额是否低于阈值并发送预警
3. 生成余额报告 - 生成HTML报告并发布到GitHub Pages
4. 定时余额监控 [间隔分钟数]: 启动定时余额监控任务（默认60分钟）  
5. 余额监控状态: 查看定时余额监控任务运行状态               
6. 停止余额监控: 停止正在运行的定时余额监控任务              

📊 换汇交易监控功能：
1. 敞口统计 [参数] - 查询换汇交易敞口统计
   参数: --org [机构代码] --start [开始日期] --end [结束日期]
   示例: 敞口统计 --org YB --start 2024-01-01 --end 2024-01-31
2. 交易监控 [机构] [--interval 分钟] [--stop] [--status] - 监控指定机构的换汇交易
   单次执行: 交易监控 YB
   单次执行: 交易监控 全部
   定期执行: 交易监控 YB --interval 10
   定期执行: 交易监控 全部 --interval 30
   停止任务: 交易监控 --stop
   查看状态: 交易监控 --status
3. 机构列表 - 显示支持的机构列表

💱 汇率监控功能：
1. 汇率监控 [阈值] - 检查PAYKKA与XT汇率差异
   示例: 汇率监控 0.5
2. 汇率检查 - 快速汇率检查
3. 汇率报告 - 查看最新汇率对比报告
4. 货币对列表 - 显示支持的货币对

🏦 XT汇率查询功能（新增）：
1. XT汇率查询 - 查询XT平台全部16个货币对报价
   示例: XT汇率查询
2. XT汇率查询 [货币对] - 查询指定货币对XT报价
   示例: XT汇率查询 USD CNY
   示例: XT查询 EUR CNY, GBP CNY

🌐 友商汇率查询功能（新增）：
1. 友商汇率查询 - 查询全部友商(XT/WF/LL/AW/KS/SK)全部货币对报价
   示例: 友商汇率查询
2. 友商查询 [友商代码] - 查询指定友商报价
   示例: 友商查询 XT WF
3. 友商查询 [货币对] - 查询指定货币对在所有友商的报价
   示例: 友商查询 USD CNH

📈 友商历史报价功能（新增）：
1. 历史报价 [友商] [货币对] [时间范围] - 查询友商历史汇率并生成走势图
   示例: XT报价 NGNUSD 7D
   示例: WF报价 USDCNH 30D
   示例: LL报价 EURCNH 14D
   示例: XT历史 USD CNY 7D
2. 支持友商: XT (XTransfer)、WF (WorldFirst)、LL (LianLian)
3. 时间范围: 7D(7天)、14D(14天)、30D/1M(30天)、3M(90天)、6M(180天)、1Y(365天)

🚨 路由价格监控功能（新增）：
1. 路由价格监控 - 执行一次路由价格监控
2. 定时路由价格监控 [间隔分钟] - 启动定时监控（默认10分钟）
   示例: 启动路由价格监控 5
3. 路由汇率告警 - 手动检查并发送汇率告警
4. 路由汇率查询 - 查看当前路由汇率
5. 路由历史报价 [天数] [货币对] - 查询路由/渠道历史报价（采样整点/半点）
   示例: 路由历史报价 7
   示例: 路由历史报价 USD CNH 5
   示例: 路由历史报价 YB 7
   示例: 路由历史报价 YB USD CNH 3

⚙️ 系统功能：
1. 状态 - 查看系统状态
2. 测试 - 测试连接
3. 帮助 - 显示此帮助信息
4. Token刷新状态
5. 手动刷新Token
6. 退出

🔄 自动重连功能：
- 检测到登录超时自动刷新Token
- 网络异常自动重试（最多2次）
- Token过期自动重新登录
- 指令执行失败自动恢复
"""
        return help_text
    
    def handle_query_routing(self, args: List[str]) -> str:
        """处理路由查询指令"""
        if len(args) < 2:
            return "❌ 参数不足，格式: 查询路由 [卖出币种] [买入币种]"
        
        sell_cur = args[0].upper()
        buy_cur = args[1].upper()
        
        # 获取路由配置器
        if not self.routing_config:
            self.routing_config = self.manager.get_routing_configurator()
        
        config = self.routing_config.query_fx_pair_config(sell_cur, buy_cur)
        
        if config:
            return f"""🔍 路由配置详情
卖出币种: {config['sell_cur']}
买入币种: {config['buy_cur']}
策略规则: {config['fx_strategy_rule']}
独立换汇: {config['standalone_fx']}
状态: {config['status']}
最后修改: {config['update_time']}"""
        else:
            return f"ℹ️ 未找到 {sell_cur}->{buy_cur} 的路由配置"
    
    def handle_query_all_routing(self, args: List[str]) -> str:
        """查询所有路由"""
        # 获取路由配置器
        if not self.routing_config:
            self.routing_config = self.manager.get_routing_configurator()
        
        all_configs = self.routing_config.query_all_fx_pair_configs()
        
        if not all_configs:
            return "ℹ️ 未找到任何路由配置"
        
        # 按币种分组统计
        currency_stats = {}
        for config in all_configs:
            pair = f"{config['sell_cur']}->{config['buy_cur']}"
            if pair not in currency_stats:
                currency_stats[pair] = 0
            currency_stats[pair] += 1
        
        stats_text = "📊 路由配置统计\n"
        stats_text += f"总配置数: {len(all_configs)}\n"
        stats_text += f"货币对数: {len(currency_stats)}\n\n"
        
        # 显示前10个配置
        stats_text += "最近配置示例:\n"
        for i, config in enumerate(all_configs[:10], 1):
            stats_text += f"{i}. {config['sell_cur']}->{config['buy_cur']}: {config['fx_strategy_rule']} ({config['status']})\n"
        
        if len(all_configs) > 10:
            stats_text += f"\n... 还有 {len(all_configs) - 10} 个配置未显示"
        
        return stats_text
    
    def handle_sync_to_github(self, args: List[str]) -> str:
        """同步配置到GitHub"""
        try:
            # 获取路由配置器
            if not self.routing_config:
                self.routing_config = self.manager.get_routing_configurator()
            
            all_configs = self.routing_config.query_all_fx_pair_configs()
            
            if not all_configs:
                return "ℹ️ 未找到任何路由配置，跳过同步"
            
            # 生成Markdown内容
            update_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            md_content = f"""# 换汇路由配置表
> 最后更新时间：{update_time}
> 总配置数：{len(all_configs)}

| 卖出币种 | 买入币种 | 换汇策略规则 | 独立换汇状态 | 配置状态 | 最后修改时间 |
|----------|----------|--------------|--------------|----------|--------------|
"""
            for config in all_configs:
                md_content += (
                    f"| {config['sell_cur']} | {config['buy_cur']} | {config['fx_strategy_rule']} | "
                    f"{config['standalone_fx']} | {config['status']} | {config['update_time']} |\n"
                )
            md_content += f"\n> 配置规则说明：{', '.join(FX_STRATEGY_RULES)}"
            
            # 更新到GitHub
            g = Github(GITHUB_TOKEN)
            repo = g.get_repo(GITHUB_REPO_NAME)
            author = InputGitAuthor(GITHUB_USERNAME, GITHUB_EMAIL)
            
            try:
                contents = repo.get_contents(GITHUB_FILE_PATH)
                repo.update_file(
                    path=GITHUB_FILE_PATH,
                    message=f"飞书机器人自动同步 {update_time}",
                    content=md_content,
                    sha=contents.sha,
                    author=author
                )
            except GithubException as e:
                if e.status == 404:
                    # 文件不存在，创建新文件
                    repo.create_file(
                        path=GITHUB_FILE_PATH,
                        message=f"飞书机器人初始化同步 {update_time}",
                        content=md_content,
                        author=author
                    )
                else:
                    raise
            
            return f"✅ 路由配置已同步到GitHub\n文件: {GITHUB_FILE_PATH}\n记录数: {len(all_configs)}\n时间: {update_time}"
            
        except Exception as e:
            return f"❌ 同步到GitHub时出错: {str(e)}"
    
    def handle_check_balance_alert(self, args: List[str]) -> str:
        """处理余额预警指令"""
        if not self.balance_query:
            self.balance_query = self.manager.get_balance_query()
        
        # 先查询余额
        success, query_msg, results = self.balance_query.query_all_balances()
        if not success:
            return f"❌ 无法执行预警检查，因为查询失败: {query_msg}"
        
        # 检查预警
        alert_success, alert_msg = self.balance_query.check_balance_alert(results)
        
        response = f"✅ 余额查询完成\n"
        response += f"📊 查询到 {len(results)} 条记录\n"
        response += f"🔔 预警检查结果: {alert_msg}"
        
        return response
    
    def handle_generate_balance_report(self, args: List[str]) -> str:
        """处理生成余额报告指令"""
        if not self.balance_query:
            self.balance_query = self.manager.get_balance_query()
        
        # 先查询余额
        success, query_msg, results = self.balance_query.query_all_balances()
        if not success:
            return f"❌ 无法生成报告，因为查询失败: {query_msg}"
        
        # 生成并上传报告
        report_success, report_msg = self.balance_query.generate_balance_report(results)
        
        if report_success:
            return f"✅ 余额报告生成成功！\n{report_msg}"
        else:
            return f"❌ 余额报告生成失败: {report_msg}"
    
    def _format_balance_summary(self, results: List[Dict]) -> str:
        """格式化余额查询结果为字符串"""
        if not results:
            return "无余额数据"
        
        summary = {}
        for record in results:
            channel = record["渠道名"]
            currency = record["币种"]
            balance = record["余额"]
            if channel not in summary:
                summary[channel] = {}
            summary[channel][currency] = balance
        
        formatted = ""
        for channel, currencies in summary.items():
            formatted += f"【{channel}】\n"
            for currency, balance in currencies.items():
                formatted += f"  {currency}: {balance}\n"
        
        return formatted

    def _check_balance_monitor_process(self) -> Optional[int]:
        """检查独立的余额监控进程是否在运行，返回 PID 或 None"""
        try:
            result = subprocess.run(
                ["pgrep", "-f", "python3.*balance_monitor\\.py"],
                capture_output=True, text=True, timeout=5
            )
            pids = [p for p in result.stdout.strip().split('\n') if p]
            return int(pids[0]) if pids else None
        except:
            return None
    
    def handle_balance_monitoring(self, args: list) -> str:
        """
        处理"定时余额监控"指令（管理独立守护进程）。
        格式: 定时余额监控 [间隔分钟数]
        """
        
        interval_minutes = 60
        if args:
            try:
                interval_minutes = int(args[0])
                if interval_minutes <= 0:
                    return "❌ 间隔分钟数必须为正整数。"
            except ValueError:
                return f"❌ 无法解析间隔参数: '{args[0]}'"
        
        # 检查是否已有进程在运行
        existing_pid = self._check_balance_monitor_process()
        if existing_pid:
            return f"⚠️ 余额监控已在运行 (PID: {existing_pid})。请先执行「停止余额监控」"
        
        # 启动独立进程
        try:
            subprocess.Popen(
                ["python3", "/workspace/balance_monitor.py", str(interval_minutes)],
                stdout=open("/workspace/balance_monitor_output.log", "a"),
                stderr=subprocess.STDOUT,
                cwd="/workspace",
                start_new_session=True
            )
            return f"✅ 已启动余额监控定时任务\n⏰ 执行间隔: 每 {interval_minutes} 分钟\n📊 监控内容: 机构余额查询 + 阈值预警 + 报告生成"
        except Exception as e:
            return f"❌ 启动失败: {e}"

    def handle_balance_monitoring_status(self, args: list) -> str:
        """
        处理"余额监控状态"指令（详细信息版）。
        """

        pid = self._check_balance_monitor_process()
        if not pid:
            return "🔴 余额监控定时任务: 未启动\n💡 使用「定时余额监控 60」启动"

        # 尝试从日志和进程参数中提取信息
        interval = "60"
        last_query = "未知"
        record_count = "未知"
        next_query = "未知"
        github_updated = "未知"

        # 从进程命令行获取间隔参数
        try:
            result = subprocess.run(
                ["ps", "-p", str(pid), "-o", "args="],
                capture_output=True, text=True, timeout=5
            )
            cmd = result.stdout.strip()
            parts = cmd.split()
            if len(parts) >= 2:
                interval = parts[-1] if parts[-1].isdigit() else "60"
        except Exception:
            pass

        # 从日志提取信息
        try:
            with open("/workspace/logs/balance_monitor.log", "r", encoding="utf-8") as f:
                lines = f.readlines()
            for line in reversed(lines):
                if "✅" in line and "条记录" in line and record_count == "未知":
                    m = re.search(r"✅\s*(\d+)\s*条记录", line)
                    if m:
                        record_count = m.group(1)
                        # 记录时间从日志前缀提取
                        m2 = re.match(r"(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})", line)
                        if m2:
                            last_query = m2.group(1)
                if "📤 GitHub Pages 已更新" in line and github_updated == "未知":
                    m = re.match(r"(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})", line)
                    if m:
                        github_updated = m.group(1)
                if "🟢 余额监控启动，间隔:" in line:
                    m = re.search(r"间隔:\s*(\d+)", line)
                    if m:
                        interval = m.group(1)
        except Exception:
            pass

        # 计算下次查询时间
        if last_query != "未知":
            try:
                last_dt = datetime.strptime(last_query, "%Y-%m-%d %H:%M:%S")
                next_dt = last_dt + timedelta(minutes=int(interval))
                next_query = next_dt.strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                pass

        # 获取阈值配置（从GitHub读取，避免import balance_monitor触发登录）
        threshold_info = ""
        try:
            url = "https://api.github.com/repos/13058199807zk-oss/Paykka-K/contents/balance_threshold.md"
            headers = {"Authorization": "token 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", "Accept": "application/vnd.github.v3.raw"}
            resp = _req.get(url, headers=headers, timeout=10)
            if resp.status_code == 200:
                md = resp.text
                threshold_lines = []
                for m in re.finditer(r'\(["\'](.+?)["\'],\s*["\'](.+?)["\']\)\s*:\s*([\d.]+)', md):
                    org = m.group(1)
                    ccy = m.group(2)
                    val = float(m.group(3))
                    threshold_lines.append(f"   • {org} {ccy}: {val:,.2f}")
                if threshold_lines:
                    threshold_info = "\n🚨 预警阈值:\n" + "\n".join(threshold_lines)
        except Exception:
            pass

        return f"""🟢 余额监控定时任务: 运行中
🔢 进程 PID: {pid}
⏰ 执行间隔: 每 {interval} 分钟
📅 上次查询: {last_query}
📊 记录数: {record_count}
📤 GitHub更新: {github_updated}
⏳ 下次查询: {next_query}
📝 日志: /workspace/logs/balance_monitor.log{threshold_info}"""

    def handle_stop_balance_monitoring(self, args: list) -> str:
        """
        处理"停止余额监控"指令。
        """
        pid = self._check_balance_monitor_process()
        if not pid:
            return "ℹ️ 余额监控定时任务未在运行。"
        
        try:
            subprocess.run(["kill", str(pid)], timeout=5)
            time.sleep(1)
            if not self._check_balance_monitor_process():
                return f"🛑 余额监控已停止 (PID: {pid})"
            else:
                subprocess.run(["kill", "-9", str(pid)], timeout=5)
                return f"🛑 余额监控已强制停止 (PID: {pid})"
        except Exception as e:
            return f"❌ 停止失败: {e}"
    
    def handle_fx_monitoring(self, args: List[str]) -> str:
        """处理'交易监控'指令 - 同时支持单次执行和定期执行模式"""
        try:
            return self.safe_execute(self._fx_monitoring_impl, args)
        except Exception as e:
            return f"❌ 交易监控失败: {str(e)}"
    
    def _fx_monitoring_impl(self, args: List[str]) -> str:
        """交易监控指令实现 - 支持多种执行模式"""
        # 解析参数
        org_code = None
        interval = None
        stop_task = False
        show_status = False
        
        i = 0
        while i < len(args):
            if args[i] == "--interval" and i + 1 < len(args):
                try:
                    interval = int(args[i + 1])
                    if interval < 1 or interval > 1440:
                        return "❌ 执行间隔需在 1 到 1440 分钟之间。"
                    i += 2
                except ValueError:
                    return f"❌ 无效的时间间隔参数: {args[i+1]}"
            elif args[i] == "--stop":
                stop_task = True
                i += 1
            elif args[i] == "--status":
                show_status = True
                i += 1
            else:
                # 机构参数
                if org_code is None and not stop_task and not show_status:
                    org_param = args[i].upper()
                    if org_param == "全部":
                        org_code = None
                    elif org_param in ORG_LIST:
                        org_code = org_param
                    else:
                        return f"❌ 不支持的机构代码: {org_param}\n支持的机构: {', '.join(ORG_LIST)}"
                i += 1
        
        # 处理不同的执行模式
        if stop_task:
            return self._stop_fx_monitoring_task()
        elif show_status:
            return self._get_fx_monitoring_task_status()
        elif interval is not None:
            return self._start_fx_monitoring_task(org_code, interval)
        else:
            return self._execute_single_fx_monitoring(org_code)
    
    def _execute_single_fx_monitoring(self, org_code: Optional[str]) -> str:
        """执行单次交易监控"""
        if not self.fx_monitor:
            self.fx_monitor = self.manager.get_fx_transaction_monitor()
        
        result = self.fx_monitor.query_fx_transactions(
            org_code=org_code,
            merchant_status=DEFAULT_MERCHANT_STATUS,
            org_status=DEFAULT_ORG_STATUS
        )
        
        return self._format_fx_monitoring_result(result, org_code)
    
    def _start_fx_monitoring_task(self, org_code: Optional[str], interval: int) -> str:
        """启动定期交易监控任务 - 使用全局实例"""

        # 从管理器获取全局任务实例
        fx_monitoring_task = self.manager.get_fx_monitoring_task()
        
        if not fx_monitoring_task:
            # 创建新任务
            fx_monitoring_task = FxMonitoringScheduledTask(self.manager, interval)

            self.manager.set_fx_monitoring_task(fx_monitoring_task)

        elif fx_monitoring_task.is_running:
            org_display = fx_monitoring_task.org_code or "全部"
            return f"⚠️ 交易监控定时任务已在运行中，当前监控机构: {org_display}"
        else:
            # 如果任务存在但已停止，更新配置
            fx_monitoring_task.interval_minutes = interval
        
        # 设置机构代码
        fx_monitoring_task.set_org_code(org_code)
        
        # 启动任务
        return fx_monitoring_task.start()
    
    def _stop_fx_monitoring_task(self) -> str:
        """停止定期交易监控任务 - 使用全局实例"""
        fx_monitoring_task = self.manager.get_fx_monitoring_task()
        if not fx_monitoring_task:
            return "ℹ️ 交易监控定时任务未初始化。"
        return fx_monitoring_task.stop()
    
    def _get_fx_monitoring_task_status(self) -> str:
        """获取定期交易监控任务状态 - 使用全局实例"""
        fx_monitoring_task = self.manager.get_fx_monitoring_task()
        if not fx_monitoring_task:
            return "ℹ️ 交易监控定时任务未初始化。"
        return fx_monitoring_task.status()
    
    def _format_fx_monitoring_result(self, result: Dict, org_code: Optional[str]) -> str:
        """格式化交易监控结果 - 参照敞口统计的详细格式"""
        org_display = org_code or "全部机构"
        
        # 构建详细的返回信息
        response = "🔍 交易监控结果详情\n"
        response += "=" * 50 + "\n"
        
        # 1. 基本信息
        response += f"📅 查询时间: {result.get('query_time', '未知')}\n"
        response += f"🏦 监控机构: {org_display}\n"
        response += f"📅 时间范围: {result.get('start_date', '未知')} 至 {result.get('end_date', '未知')}\n"
        response += f"📊 总交易笔数: {result.get('total_count', 0)}\n"
        response += "-" * 50 + "\n\n"
        
        settlement_stats = result.get('settlement_stats', {})
        
        if not settlement_stats:
            response += "ℹ️ 未发现未来交割的换汇交易\n"
            return response
        
        # 2. 详细统计表格
        response += "📈 详细交割敞口统计:\n\n"
        
        # 先按交割日期排序
        sorted_dates = sorted(settlement_stats.keys())
        
        for settle_date in sorted_dates:
            currency_pairs = settlement_stats[settle_date]
            
            response += f"📅 交割日: {settle_date}\n"
            response += "-" * 40 + "\n"
            
            # 表头
            response += f"{'货币对':<12} {'卖出金额':<15} {'买入金额':<15} {'交易笔数':<10}\n"
            response += f"{'-'*12:<12} {'-'*15:<15} {'-'*15:<15} {'-'*10:<10}\n"
            
            # 按货币对排序
            sorted_pairs = sorted(currency_pairs.keys())
            
            for currency_pair in sorted_pairs:
                stats = currency_pairs[currency_pair]
                total_sell = stats.get('total_sell', 0)
                total_buy = stats.get('total_buy', 0)
                count = stats.get('count', 0)
                
                response += f"{currency_pair:<12} {total_sell:>15,.2f} {total_buy:>15,.2f} {count:>10}\n"
            
            # 当日合计
            date_total_sell = sum(pair_stats.get('total_sell', 0) for pair_stats in currency_pairs.values())
            date_total_buy = sum(pair_stats.get('total_buy', 0) for pair_stats in currency_pairs.values())
            date_total_count = sum(pair_stats.get('count', 0) for pair_stats in currency_pairs.values())
            
            response += f"{'-'*12:<12} {'-'*15:<15} {'-'*15:<15} {'-'*10:<10}\n"
            response += f"{'小计':<12} {date_total_sell:>15,.2f} {date_total_buy:>15,.2f} {date_total_count:>10}\n\n"
        
        # 3. 汇总统计
        response += "📊 总体统计摘要:\n"
        response += "-" * 40 + "\n"
        
        # 计算总体统计
        all_pairs = []
        for date_pairs in settlement_stats.values():
            all_pairs.extend(date_pairs.keys())
        
        unique_currency_pairs = set(all_pairs)
        total_transactions = result.get('total_count', 0)
        date_count = len(settlement_stats)
        
        # 计算总卖出/买入金额
        total_sell_amount = 0.0
        total_buy_amount = 0.0
        for date_stats in settlement_stats.values():
            for pair_stats in date_stats.values():
                total_sell_amount += pair_stats.get('total_sell', 0)
                total_buy_amount += pair_stats.get('total_buy', 0)
        
        response += f"🔢 交割日数量: {date_count}\n"
        response += f"💱 货币对数量: {len(unique_currency_pairs)}\n"
        response += f"📄 总交易笔数: {total_transactions}\n"
        response += f"💰 总卖出金额: {total_sell_amount:,.2f}\n"
        response += f"💰 总买入金额: {total_buy_amount:,.2f}\n\n"
        
        # 4. 告警信息
        alerts_sent = result.get('alerts_sent', [])
        if alerts_sent:
            response += "🚨 告警详情:\n"
            response += "-" * 40 + "\n"
            
            for i, alert in enumerate(alerts_sent, 1):
                currency_pair = alert.get('currency_pair', 'N/A')
                settle_date = alert.get('settle_date', 'N/A')
                threshold = alert.get('threshold', 'N/A')
                actual_sell = alert.get('actual_sell', 'N/A')
                excess_amount = alert.get('excess_amount', 'N/A')
                count = alert.get('count', 0)
                
                response += f"告警 #{i}:\n"
                response += f"  • 货币对: {currency_pair}\n"
                response += f"  • 交割日: {settle_date}\n"
                response += f"  • 阈值: {threshold}\n"
                response += f"  • 实际卖出: {actual_sell}\n"
                response += f"  • 超限额: {excess_amount}\n"
                response += f"  • 交易笔数: {count}\n"
                
                if i < len(alerts_sent):
                    response += "  " + "-" * 30 + "\n"
            
            response += f"\n📢 共触发 {len(alerts_sent)} 条告警\n\n"
        
        # 5. 配置信息
        used_config = result.get('used_config', {})
        if used_config:
            response += "⚙️ 监控配置信息:\n"
            response += "-" * 40 + "\n"
            
            alert_thresholds = used_config.get('ALERT_THRESHOLDS', {})
            if alert_thresholds:
                response += "告警阈值配置:\n"
                for pair, threshold in alert_thresholds.items():
                    response += f"  • {pair}: {threshold:,.2f}\n"
                response += "\n"

            # 新增：显示处理中交易阈值
            processing_thresholds = used_config.get('PROCESSING_ALERT_THRESHOLDS', {})
            if processing_thresholds:
                response += "⏳ 处理中交易告警阈值:\n"
                for pair, threshold in processing_thresholds.items():
                    response += f"  • {pair}: {threshold:,.2f}\n"
                response += "\n"
            
            enable_alert = used_config.get('ENABLE_WECHAT_ALERT', True)
            response += f"微信告警开关: {'开启' if enable_alert else '关闭'}\n"
        
        response += "=" * 50 + "\n"
        response += "✅ 交易监控完成"
        
        return response
    
    def handle_org_list(self, args: List[str]) -> str:
        """处理'机构列表'指令"""
        if not self.fx_monitor:
            self.fx_monitor = self.manager.get_fx_transaction_monitor()
        
        response = "🏦 支持的机构列表:\n"
        for i, org in enumerate(self.fx_monitor.org_list, 1):
            response += f"{i}. {org}\n"
        response += "\n📌 使用示例:"
        response += "\n  敞口统计 --org YB --start 2024-01-01 --end 2024-01-31"
        response += "\n  交易监控 YB  (监控易宝机构的交易)"
        response += "\n  交易监控 全部  (监控所有机构)"
        
        return response
    
    def _format_fx_statistics_result(self, result: Dict) -> str:
        """格式化换汇统计结果为字符串（完整版：已交割敞口 + 处理中交易 + 配置信息）"""
        response = f"📊 换汇交易敞口统计结果\n"
        response += f"📅 统计范围: {result['start_date']} 至 {result['end_date']}\n"
        response += f"⏰ 查询时间: {result['query_time']}\n"
        response += f"📈 总交易笔数: {result['total_count']} 笔\n"

        used_config = result.get('used_config', {})
        alert_thresholds = used_config.get('ALERT_THRESHOLDS', {})
        processing_thresholds = used_config.get('PROCESSING_ALERT_THRESHOLDS', {})
        
        # 超限告警汇总（包含已交割和处理中的告警）
        alerts_sent = result.get('alerts_sent', [])
        if alerts_sent:
            response += f"\n🚨 超限告警 ({len(alerts_sent)} 条):\n"
            for alert in alerts_sent:
                settle_label = alert['settle_date'] if alert['settle_date'] != 'PROCESSING' else 'PROCESSING'
                response += f"  • {settle_label} {alert['currency_pair']}: "
                response += f"{alert['actual_sell']} > 阈值 {alert['threshold']} (超限 {alert['excess_amount']})\n"
        
        # 已交割交易统计（按交割日期）
        settlement_stats = result.get('settlement_stats', {})
        processing_stats = result.get('processing_stats', {})
        
        if settlement_stats or processing_stats:
            response += f"\n📋 交易统计 (按交割日期):\n"
        
        if settlement_stats:
            for settle_date in sorted(result['settlement_stats'].keys()):
                currency_pairs = result['settlement_stats'][settle_date]
                response += f"\n📅 交割日期: {settle_date}\n"
                
                for pair in sorted(currency_pairs.keys()):
                    stats = currency_pairs[pair]
                    sell_curr, buy_curr = pair.split('/')
                    
                    threshold = alert_thresholds.get(pair, 0)
                    alert_mark = " 🚨" if stats['total_sell'] > threshold else ""
                    
                    response += f"  {pair}{alert_mark}:\n"
                    response += f"    交易笔数: {stats['count']} 笔\n"
                    response += f"    总卖出金额: {self.fx_monitor._format_number(stats['total_sell'])} {sell_curr}\n"
                    response += f"    总买入金额: {self.fx_monitor._format_number(stats['total_buy'])} {buy_curr}\n"
                    if pair in alert_thresholds:
                        response += f"    预警阈值: {self.fx_monitor._format_number(threshold)} {sell_curr}\n"
        
        # 处理中交易统计（按货币对）
        if processing_stats:
            response += f"\n⏳ 处理中交易统计 (按货币对):\n"
            for pair in sorted(processing_stats.keys()):
                stats = processing_stats[pair]
                sell_curr, buy_curr = pair.split('/')
                
                threshold = processing_thresholds.get(pair, 0)
                alert_mark = " 🚨" if stats['total_sell'] > threshold else ""
                
                response += f"  {pair}{alert_mark}:\n"
                response += f"    交易笔数: {stats['count']} 笔\n"
                response += f"    总卖出金额: {self.fx_monitor._format_number(stats['total_sell'])} {sell_curr}\n"
                response += f"    总买入金额: {self.fx_monitor._format_number(stats['total_buy'])} {buy_curr}\n"
                if pair in processing_thresholds:
                    response += f"    预警阈值: {self.fx_monitor._format_number(threshold)} {sell_curr}\n"
        
        # 配置信息
        trading_hours = used_config.get('TRADING_HOURS', {})
        wechat_enabled = used_config.get('ENABLE_WECHAT_ALERT', False)
        response += f"\n⚙️ 使用配置:\n"
        response += f"  预警阈值: {len(alert_thresholds)} 个货币对\n"
        response += f"  处理中交易阈值: {len(processing_thresholds)} 个货币对\n"
        response += f"  交易时段配置: {len(trading_hours)} 个机构\n"
        response += f"  企业微信告警: {'开启' if wechat_enabled else '关闭'}\n"
        
        return response
    
    def handle_rate_check(self, args: List[str]) -> str:
        """处理'汇率检查'指令（简化版）"""
        if not self.rate_monitor:
            self.rate_monitor = self.manager.get_rate_monitor()
        
        result = self.rate_monitor.check_rates()
        
        # 生成简洁报告
        if result['discrepancies']:
            response = f"⚠️ 汇率检查发现 {len(result['discrepancies'])} 个异常:\n"
            for disc in result['discrepancies']:
                response += f"  {disc['pair']}: PAYKKA={disc['paykka_rate']:.6f}, XT={disc['xt_rate']:.6f}, 差{disc['diff_percent']:.4f}% ({disc['direction']})\n"
        else:
            response = f"✅ 汇率检查正常，未发现异常\n"
        
        response += f"📅 检查时间: {result['check_time']}\n"
        response += f"📊 共查询: {len(result['paykka_rates'])} 个PAYKKA汇率, {len(result['xt_rates'])} 个XT汇率"
        
        return response
    
    def handle_rate_report(self, args: List[str]) -> str:
        """处理'汇率报告'指令（支持 --force 强制重新检查）"""
        if not self.rate_monitor:
            self.rate_monitor = self.manager.get_rate_monitor()
        
        # 检查是否有 --force 参数
        force_check = "--force" in args or "-f" in args
        
        # 如果没有最近检查，或者强制重新检查，则执行一次检查
        if not self.rate_monitor.last_check_time or force_check:
            result = self.rate_monitor.check_rates()
        else:
            # 返回最近一次检查的结果摘要
            return f"ℹ️ 最近一次汇率检查: {self.rate_monitor.last_check_time.strftime('%Y-%m-%d %H:%M:%S')}\n查看完整报告: https://github.com/{GITHUB_REPO_NAME}/blob/main/{GITHUB_RATE_FILE_PATH}\n💡 使用 '汇率报告 --force' 可强制重新检查"
        
        # 返回报告摘要
        if result['uploaded_to_github']:
            return f"✅ 汇率报告已生成并上传到GitHub\n📅 检查时间: {result['check_time']}\n📊 发现异常: {result['discrepancy_count']} 个\n🌐 完整报告: https://github.com/{GITHUB_REPO_NAME}/blob/main/{GITHUB_RATE_FILE_PATH}"
        else:
            return f"❌ 汇率报告生成失败，请检查网络连接和GitHub权限"
    
    def handle_currency_pairs(self, args: List[str]) -> str:
        """处理'货币对列表'指令"""
        response = "💱 支持的货币对列表:\n"
        for i, (from_curr, to_curr, description) in enumerate(CURRENCY_PAIRS, 1):
            response += f"{i}. {from_curr}→{to_curr} ({description})\n"
        response += "\n📌 使用示例:"
        response += "\n  汇率监控 0.5  (使用0.5%的阈值检查)"
        response += "\n  汇率检查  (快速检查汇率差异)"
        
        return response
    
    def handle_status(self, args: List[str]) -> str:
        """处理状态指令"""
        manager = self.manager
        
        status = f"""
🤖 集成控制系统状态：
- 全局登录状态: {'✅ 已登录' if manager._token else '❌ 未登录'}
- Token状态: {len(manager._token) if manager._token else 0} 字符
- 最后登录时间: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(manager._last_login_time)) if manager._last_login_time else '从未登录'}
- 汇差配置器: {'✅ 已初始化' if manager._forex_configurator else '❌ 未初始化'}
- 路由配置器: {'✅ 已初始化' if manager._routing_configurator else '❌ 未初始化'}
- 余额查询器: {'✅ 已初始化' if manager._balance_query else '❌ 未初始化'}
- 交易监控器: {'✅ 已初始化' if manager._fx_transaction_monitor else '❌ 未初始化'}
- 汇率监控器: {'✅ 已初始化' if manager._rate_monitor else '❌ 未初始化'}
- 路由价格监控: {'✅ 已初始化' if manager._exchange_rate_monitor else '❌ 未初始化'}
- 路由调度器: {'✅ 已初始化' if manager._routing_scheduler else '❌ 未初始化'}
- XT汇率查询: {'✅ 已认证' if manager.get_xt_rate_query()._is_auth_valid() else '❌ 未认证'}
- 已处理消息: {len(manager.get_deduplicator().processed_messages)} 个
- 运行模式: 自动登录+混合模式
- 支持机构: {len(ORG_LIST)} 个
- 监控货币对: {len(CURRENCY_PAIRS)} 个
- 自动重连: ✅ 已启用
"""
        return status
    
    def handle_test(self, args: List[str]) -> str:
        """处理测试指令"""
        return "✅ 集成控制系统运行正常！"
    
    def process(self, text: str) -> str:
        """处理用户输入（智能匹配版，带异常保护）"""
        try:
            parsed = self.parse_command(text)
            command = parsed["command"]
            args = parsed["args"]
            
            if not command:
                return "❓ 未能识别指令，输入'帮助'查看可用指令"
            
            # 先在原有精确字典中查找
            for cmd_key, handler in self.commands.items():
                if cmd_key.lower() == command.lower():
                    try:
                        return handler(args)
                    except Exception as e:
                        logger.error(f"❌ 指令 [{command}] 执行异常: {e}", exc_info=True)
                        return f"❌ 指令执行失败: {str(e)[:200]}\n💡 系统已自动恢复，可重试或输入'帮助'查看"
            
            # 如果精确匹配失败，重新做一次模糊匹配获取得分
            _, _, score = self._fuzzy_match_command(text)
            
            if score >= 80:
                return f"⚠️ 识别到指令意图但执行失败，请用更明确的指令重试\n💡 输入'帮助'查看可用指令"
            
            return f"❌ 未识别指令: \"{text}\"\n💡 输入'帮助'查看可用指令列表"
        except Exception as e:
            logger.error(f"❌ process() 顶层异常: {e}", exc_info=True)
            return f"❌ 系统处理异常，已自动恢复: {str(e)[:200]}"

# ===================== 飞书机器人处理器 =====================
