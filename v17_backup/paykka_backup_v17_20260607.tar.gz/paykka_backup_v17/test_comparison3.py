#!/usr/bin/env python3
"""测试 V17 命令系统集成"""
import sys, json, os, logging, time
sys.path.insert(0, '/workspace')
logging.basicConfig(level=logging.WARNING)

from paykka_controllerV17 import IntegratedCommandProcessor, PaykkaSystemManager
from paykka_comparison import DEFAULT_CHANNEL_SOURCES, DEFAULT_COMPETITOR_SOURCES

# 获取 Token
mgr = PaykkaSystemManager()
for i in range(45):
    if mgr._token:
        break
    time.sleep(2)
print(f'✅ Token 就绪')

# 创建命令处理器
proc = IntegratedCommandProcessor(mgr)

# 测试 parse_command 的模糊匹配
print()
print('=' * 60)
print('测试命令解析:')
print('=' * 60)

test_texts = [
    '报价对比',
    '汇率对比 USDCNH 7D',
    '渠道对比 NGNUSD 3D YB',
    '多方对比 EURCNH BOC XT',
]

for text in test_texts:
    parsed = proc.parse_command(text)
    print(f'  "{text}" → command="{parsed["command"]}", args={parsed["args"]}')

# 测试完整的 process 流程（但需要 token）
print()
print('=' * 60)
print('测试 process("报价对比"):')
print('=' * 60)

# 确保 mgr._token 是有效的
result = proc.process('报价对比')
print(result[:800])
print('...')
if '[CHART:' in result:
    idx = result.index('[CHART:')
    chart_path = result[idx+7:result.index(']', idx)]
    print(f'\n✅ 图表标记: {chart_path}')
    print(f'   文件存在: {os.path.exists(chart_path)}')
