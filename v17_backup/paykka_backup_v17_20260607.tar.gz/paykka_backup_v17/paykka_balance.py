# ===================== paykka_balance.py =====================
# PaykkaBalanceQuery + BalanceMonitoringScheduledTask - 余额查询与监控
# 从 paykka_controllerV16.py 提取

import json
import time
import urllib.parse
import requests
import re
import threading
import os
import hashlib
import asyncio
import subprocess
import base64
from typing import List, Dict, Tuple, Any, Optional, Union
from datetime import datetime, date, timedelta, timezone, time as dtime
from playwright.async_api import async_playwright
import pandas as pd
from github import Github, InputGitAuthor
import pytz

from paykka_config import *
from paykka_core import PaykkaSystemManager, build_auth_headers

class PaykkaBalanceQuery:
    """PAYKKA渠道余额查询与预警模块 - 增强版"""
    
    def __init__(self, token: str):
        self.token = token
        self.base_url = BALANCE_BASE_URL
        self.api_endpoint = BALANCE_API_ENDPOINT
        self.full_api_url = f"{self.base_url}{self.api_endpoint}"
        self.institution_map = INSTITUTION_MAP
        self.institution_currencies = INSTITUTION_CURRENCIES
        self.excel_filename = EXCEL_FILENAME
        self.manager = PaykkaSystemManager()  # 新增
    
    def _safe_balance_query(self, payload: Dict) -> Tuple[bool, Any]:
        """安全的余额查询请求"""
        def query_func():
            headers = self._build_headers()
            response = requests.post(
                self.full_api_url, 
                headers=headers, 
                json=payload, 
                timeout=30
            )
            if response.status_code == 200:
                return response.json()
            else:
                raise Exception(f"HTTP {response.status_code}")
        
        # 使用管理器的安全API调用
        return self.manager.safe_api_call(
            query_func,
            max_retries=2,
            retry_delay=1
        )
    
    def _build_headers(self) -> Dict[str, str]:
        """构建HTTP请求头"""
        return build_auth_headers(self.token)
    
    def _format_balance(self, balance, currency):
        """格式化余额"""
        try:
            balance_float = float(balance)
            # 修复：使用全局常量 NO_DIVIDE_CURRENCIES 列表，而非仅硬编码 "JPY"
            if currency not in NO_DIVIDE_CURRENCIES:
                balance_float = balance_float / 100.0
            return "{:,.2f}".format(balance_float)
        except (ValueError, TypeError):
            return "0.00"
    
    def _backup_hce_query(self, headers, org_code, org_name, query_time):
        """备用方式查询海云汇币种"""
        currencies = self.institution_currencies.get(org_code, [])
        all_results = []
        for currency in currencies:
            try:
                payload = {
                    "offset": 0,
                    "limit": 100,
                    "account_type": "FUND_ACCOUNT",
                    "currency": currency,
                    "org_code": org_code
                }
                response = requests.post(self.full_api_url, headers=headers, json=payload, timeout=30)
                data = response.json()
                if data.get("ret_code") == "000000":
                    items = data.get("data", [])
                    for item in items:
                        if isinstance(item, dict):
                            balance_raw = item.get("balance") or item.get("currentBalance") or item.get("amount") or 0
                            if balance_raw and balance_raw != 0 and balance_raw != "0":
                                balance_formatted = self._format_balance(balance_raw, currency)
                                record = {
                                    "查询时间": query_time,
                                    "渠道名": org_name,
                                    "币种": currency,
                                    "余额": balance_formatted,
                                }
                                all_results.append(record)
                time.sleep(0.1)
            except Exception as e:
                logger.error(f"  {currency}备用查询出错: {str(e)}")
        return all_results
    
    def _query_institution_balance(self, org_code: str, org_name: str) -> List[Dict]:
        """查询单个机构余额"""
        logger.info(f"查询机构: {org_name}")
        headers = self._build_headers()
        currencies = self.institution_currencies.get(org_code, ["USD", "CNY", "HKD", "EUR", "GBP", "JPY", "AUD", "CAD", "SGD"])
        all_results = []
        query_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        found_currencies = []
        
        if org_code == "HCE":
            logger.info("  海云汇机构使用特殊查询模式（无account_type参数）...")
            try:
                payload = {
                    "offset": 0,
                    "limit": 100,
                    "org_code": org_code
                }
                response = requests.post(self.full_api_url, headers=headers, json=payload, timeout=30)
                data = response.json()
                if data.get("ret_code") == "000000":
                    items = data.get("data", [])
                    logger.info(f"  返回数据条目数: {len(items)}")
                    for item in items:
                        if isinstance(item, dict):
                            currency = item.get("currency")
                            balance_raw = item.get("balance") or item.get("currentBalance") or item.get("amount") or 0
                            if currency in currencies:
                                if balance_raw and balance_raw != 0 and balance_raw != "0":
                                    balance_formatted = self._format_balance(balance_raw, currency)
                                    record = {
                                        "查询时间": query_time,
                                        "渠道名": org_name,
                                        "币种": currency,
                                        "余额": balance_formatted,
                                    }
                                    all_results.append(record)
                                    found_currencies.append(f"{currency}: {balance_formatted}")
                else:
                    error_msg = data.get("ret_msg", "未知错误")
                    logger.error(f"  海云汇查询失败: {error_msg}")
                    logger.info("  尝试备用查询方式...")
                    all_results = self._backup_hce_query(headers, org_code, org_name, query_time)
            except Exception as e:
                logger.error(f"  海云汇查询出错: {str(e)}")
                logger.info("  尝试备用查询方式...")
                all_results = self._backup_hce_query(headers, org_code, org_name, query_time)
        else:
            for currency in currencies:
                payload = {
                    "offset": 0,
                    "limit": 100,
                    "account_type": "FUND_ACCOUNT",
                    "currency": currency,
                    "org_code": org_code
                }
                try:
                    response = requests.post(self.full_api_url, headers=headers, json=payload, timeout=30)
                    data = response.json()
                    if data.get("ret_code") == "000000":
                        items = data.get("data", [])
                        for item in items:
                            if isinstance(item, dict):
                                balance_raw = item.get("balance") or item.get("currentBalance") or item.get("amount") or 0
                                if balance_raw and balance_raw != 0 and balance_raw != "0":
                                    balance_formatted = self._format_balance(balance_raw, currency)
                                    record = {
                                        "查询时间": query_time,
                                        "渠道名": org_name,
                                        "币种": currency,
                                        "余额": balance_formatted,
                                    }
                                    all_results.append(record)
                                    found_currencies.append(f"{currency}: {balance_formatted}")
                    time.sleep(0.1)
                except Exception as e:
                    logger.error(f"  {currency}查询出错: {str(e)}")
        
        if found_currencies:
            display_count = min(5, len(found_currencies))
            display_text = ", ".join(found_currencies[:display_count])
            if len(found_currencies) > display_count:
                display_text += f" ...等共 {len(found_currencies)} 个币种"
            logger.info(f"  {org_name}余额: {display_text}")
        else:
            logger.info("  无余额数据")
            
        return all_results
    
    def _save_to_excel(self, all_results: List[Dict]) -> bool:
        """保存查询结果到Excel"""
        try:
            df = pd.DataFrame(all_results)
            if os.path.exists(self.excel_filename):
                try:
                    # 修复：显式指定 engine='openpyxl'，兼容 pandas 3.0+
                    existing_df = pd.read_excel(self.excel_filename, engine='openpyxl')
                    combined_df = pd.concat([existing_df, df], ignore_index=True)
                except Exception as read_err:
                    # 容错：如果已有文件损坏或格式不兼容，仅使用新数据覆盖
                    logger.warning(f"⚠️ 读取已有Excel文件失败({read_err})，将覆盖写入新数据")
                    combined_df = df
            else:
                combined_df = df
            with pd.ExcelWriter(self.excel_filename, engine='openpyxl', mode='w') as writer:
                combined_df.to_excel(writer, sheet_name='余额查询记录', index=False)
            logger.info(f"数据已保存到: {self.excel_filename}")
            return True
        except Exception as e:
            logger.error(f"保存Excel文件时出错: {e}")
            return False
    
    def _generate_html_report(self, results: List[Dict]) -> str:
        """生成HTML报告"""
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # 按机构组织数据
        org_balances = {}
        for record in results:
            org_name = record["渠道名"]
            currency = record["币种"]
            balance = record["余额"]
            if org_name not in org_balances:
                org_balances[org_name] = []
            org_balances[org_name].append((currency, balance))
        
        # 构建HTML
        html_content = f'''
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>PayKKa 机构余额看板</title>
        <style>
            body {{ font-family: 'Segoe UI', Arial, sans-serif; margin: 40px; background-color: #f5f5f5; color: #333; }}
            .container {{ max-width: 1200px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }}
            h1 {{ color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 15px; }}
            .update-time {{ color: #7f8c8d; font-size: 0.95em; margin-bottom: 30px; }}
            .institution {{ margin-bottom: 35px; }}
            .institution h2 {{ color: #16a085; background-color: #ecf0f1; padding: 12px 20px; border-radius: 8px; }}
            table {{ width: 100%; border-collapse: collapse; margin-top: 15px; }}
            th, td {{ padding: 15px 20px; text-align: left; border-bottom: 1px solid #ddd; }}
            th {{ background-color: #3498db; color: white; font-weight: 600; }}
            tr:hover {{ background-color: #f9f9f9; }}
            .balance {{ font-family: 'Courier New', monospace; font-weight: bold; color: #27ae60; }}
            .footer {{ margin-top: 40px; text-align: center; font-size: 0.9em; color: #95a5a6; }}
            .alert {{ background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 8px; margin-top: 20px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🏦 PayKKa 渠道机构资金余额看板</h1>
            <div class="update-time">最后更新时间: <strong>{current_time}</strong> (北京时间)</div>
            <div class="alert">
                说明：本页面数据通过自动化脚本定时更新，展示各机构资金账户的实时余额。
            </div>
    '''
        
        # 为每个机构添加表格
        for org_name, currencies in org_balances.items():
            html_content += f'''
            <div class="institution">
                <h2>📊 {org_name}</h2>
                <table>
                    <thead>
                        <tr>
                            <th>币种</th>
                            <th>余额</th>
                        </tr>
                    </thead>
                    <tbody>
            '''
            for currency, balance in currencies:
                html_content += f'''
                        <tr>
                            <td><strong>{currency}</strong></td>
                            <td class="balance">{balance}</td>
                        </tr>
                '''
            html_content += '''
                    </tbody>
                </table>
            </div>
        '''
        
        # 页脚
        html_content += f'''
            <div class="footer">
                <p>数据来源: PayKKa 运营平台 | 本页面由自动化工具生成，更新间隔可配置</p>
                <p>仓库: {GITHUB_REPO_OWNER}/{GITHUB_BALANCE_REPO_NAME} | 如有疑问，请联系相关运维人员。</p>
            </div>
        </div>
    </body>
    </html>
    '''
        return html_content
    
    def _upload_to_github(self, html_content: str, commit_message: str = "Auto update balance report") -> bool:
        """上传HTML报告到GitHub"""
        url = f"https://api.github.com/repos/{GITHUB_REPO_OWNER}/{GITHUB_BALANCE_REPO_NAME}/contents/{GITHUB_BALANCE_FILE_PATH}"
        headers = {
            "Authorization": f"token {GITHUB_TOKEN}",
            "Accept": "application/vnd.github.v3+json"
        }
        content_encoded = base64.b64encode(html_content.encode("utf-8")).decode("utf-8")
        sha = None
        try:
            response = requests.get(url, headers=headers)
            if response.status_code == 200:
                sha = response.json().get("sha")
        except:
            pass
        data = {
            "message": commit_message,
            "content": content_encoded,
            "branch": GITHUB_BRANCH
        }
        if sha:
            data["sha"] = sha
        try:
            response = requests.put(url, headers=headers, json=data, timeout=30)
            if response.status_code in [200, 201]:
                logger.info(f"✅ 余额报告已成功上传至 GitHub 仓库。")
                pages_url = f"https://{GITHUB_REPO_OWNER}.github.io/{GITHUB_BALANCE_REPO_NAME}/"
                logger.info(f"🌐 网页访问地址（需配置Pages后生效）: {pages_url}")
                return True
            else:
                logger.error(f"❌ GitHub 上传失败，状态码: {response.status_code}")
                logger.error(f"错误信息: {response.text[:200]}")
                return False
        except Exception as e:
            logger.error(f"❌ 连接GitHub API时出错: {str(e)}")
            return False
    
    def _fetch_thresholds_from_github(self) -> Dict:
        """从GitHub读取阈值配置"""
        thresholds = {}
        try:
            logger.info(f"🔍 开始从GitHub获取阈值配置...")
            url = f"https://api.github.com/repos/{GITHUB_REPO_OWNER}/{GITHUB_BALANCE_REPO_NAME}/contents/balance_threshold.md"
            headers = {
                "Authorization": f"token {GITHUB_TOKEN}",
                "Accept": "application/vnd.github.v3.raw"
            }
            response = requests.get(url, headers=headers, timeout=30)
            if response.status_code == 200:
                md_content = response.text
                # 方法1：尝试解析Python字典格式
                try:
                    import re
                    pattern = r'BALANCE_THRESHOLDS\s*=\s*({[\s\S]*?})'
                    match = re.search(pattern, md_content)
        
                    if match:
                        dict_str = match.group(1)
                        import ast
                        thresholds = ast.literal_eval(dict_str)
                        print(f"✅ 成功解析BALANCE_THRESHOLDS字典，共 {len(thresholds)} 条规则")
                        return thresholds
                except Exception as e:
                    print(f"⚠️ 解析字典格式失败: {e}")

                # 方法2：尝试解析CSV格式
                try:
                    lines = md_content.strip().split('\n')
                    for line_num, line in enumerate(lines, 1):
                        line = line.strip()
                        if not line or line.startswith('#'):
                            continue
                        parts = [p.strip() for p in line.split(',')]
                        if len(parts) >= 3:
                            try:
                                org_name = parts[0]
                                currency = parts[1]
                                threshold_value = float(parts[2])
                                thresholds[(org_name, currency)] = threshold_value
                                print(f"  第{line_num}行: {org_name}, {currency}, {threshold_value}")
                            except ValueError as e:
                                print(f"  ⚠️ 第{line_num}行解析失败: {e}")
        
                    if thresholds:
                        print(f"✅ 成功解析CSV格式，共 {len(thresholds)} 条规则")
                        return thresholds
                except Exception as e:
                    print(f"⚠️ 解析CSV格式失败: {e}")
    
                return thresholds
            else:
                logger.error(f"❌ 获取阈值配置失败，HTTP状态码: {response.status_code}")
                return thresholds
        except Exception as e:
            logger.error(f"❌ 获取预警阈值配置时出错: {e}")
            return thresholds
    
    def _send_balance_alert(self, alert_messages: List[Dict]) -> bool:
        """发送余额预警消息"""
        if not alert_messages:
            return False
        
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        markdown_content = f"## ⚠️  PayKKa渠道余额预警\n**触发时间：** {current_time}\n\n"
        markdown_content += "以下渠道币种余额已低于预设阈值，请及时关注：\n\n"
        
        for alert in alert_messages:
            markdown_content += f"**{alert['机构名']} ({alert['币种']})**\n"
            markdown_content += f"> 当前余额：`{alert['当前余额']:.2f}`\n"
            markdown_content += f"> 预警阈值：`{alert['预警阈值']:.2f}`\n\n"
        
        markdown_content += "---\n*本消息由余额监控系统自动发送*"
        
        payload = {
            "msgtype": "markdown",
            "markdown": {
                "content": markdown_content
            }
        }
        
        try:
            response = requests.post(WECHAT_WEBHOOK_URL, json=payload, timeout=10)
            if response.status_code == 200:
                logger.info(f"✅ 余额预警消息已发送至企业微信。触发警报数: {len(alert_messages)}")
                return True
            else:
                logger.error(f"❌ 发送企业微信预警失败: {response.text}")
                return False
        except Exception as e:
            logger.error(f"❌ 连接企业微信Webhook时出错: {e}")
            return False
    
    def query_all_balances(self) -> Tuple[bool, str, List[Dict]]:
        """查询所有渠道余额"""
        logger.info("开始查询所有机构余额...")
        all_results = []
        
        for org_code, org_name in self.institution_map.items():
            try:
                results = self._query_institution_balance(org_code, org_name)
                all_results.extend(results)
            except Exception as e:
                logger.error(f"查询机构 {org_name} 时出错: {e}")
        
        if not all_results:
            return False, "❌ 没有查询到任何余额数据", []
        
        # 保存到Excel
        save_success = self._save_to_excel(all_results)
        if not save_success:
            return False, "❌ 保存查询结果到Excel失败", all_results
        
        return True, "✅ 余额查询成功", all_results
    
    def check_balance_alert(self, query_results: List[Dict]) -> Tuple[bool, str]:
        """检查余额预警"""
        logger.info("开始余额阈值检查...")
        thresholds = self._fetch_thresholds_from_github()
        
        if not thresholds:
            return False, "ℹ️ 未配置任何预警阈值，跳过余额检查。"
        
        alerts = []
        for record in query_results:
            org_name = record["渠道名"]
            currency = record["币种"]
            balance_str_clean = record["余额"].replace(',', '')
            try:
                current_balance = float(balance_str_clean)
            except ValueError:
                logger.warning(f"⚠️ 无法解析余额数值: {org_name} {currency} -> {record['余额']}")
                continue
            
            threshold_key = (org_name, currency)
            if threshold_key in thresholds:
                threshold = thresholds[threshold_key]
                if current_balance < threshold:
                    alert_info = {
                        '机构名': org_name,
                        '币种': currency,
                        '当前余额': current_balance,
                        '预警阈值': threshold
                    }
                    alerts.append(alert_info)
                    logger.warning(f"⚠️ 预警: {org_name} {currency} 余额 {current_balance:.2f} < 阈值 {threshold:.2f}")
        
        if alerts:
            alert_sent = self._send_balance_alert(alerts)
            if alert_sent:
                return True, f"✅ 发现 {len(alerts)} 个预警，已成功发送到企业微信。"
            else:
                return False, f"⚠️ 发现 {len(alerts)} 个预警，但发送到企业微信失败。"
        else:
            return True, "✅ 所有渠道币种余额均正常，未触发预警。"
    
    def generate_balance_report(self, query_results: List[Dict]) -> Tuple[bool, str]:
        """生成并上传余额报告"""
        logger.info("正在生成网页报告并上传至 GitHub...")
        html_report = self._generate_html_report(query_results)
        upload_success = self._upload_to_github(html_report, f"Auto update: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        
        if upload_success:
            return True, f"✅ 余额报告生成并上传成功！\n🌐 网页访问地址: https://{GITHUB_REPO_OWNER}.github.io/{GITHUB_BALANCE_REPO_NAME}/"
        else:
            return False, "❌ 余额报告上传失败。"

# ===================== 余额预警定时任务类 =====================
class BalanceMonitoringScheduledTask:
    """余额查询与预警定时任务执行器"""
    
    def __init__(self, manager: PaykkaSystemManager, interval_minutes: int = 60):
        """
        初始化定时任务
        :param manager: 全局系统管理器
        :param interval_minutes: 监控间隔（分钟），默认60分钟
        """
        self.manager = manager
        self.interval_minutes = interval_minutes
        self.is_running = False
        self.balance_query = None
        self.task_thread = None
        self.stop_event = threading.Event()
    
    def _get_balance_query(self) -> PaykkaBalanceQuery:
        """获取或创建余额查询器实例"""
        if not self.balance_query:
            self.balance_query = self.manager.get_balance_query()
        return self.balance_query
    
    def _execute_monitoring_task(self):
        """执行一次余额监控任务的核心逻辑"""
        try:
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            logger.info(f"🔄 余额定时任务执行中 ({current_time})")
            
            # 1. 获取余额查询器
            balance_query = self._get_balance_query()
            if not balance_query:
                logger.error("❌ 无法获取余额查询器实例")
                return
            
            # 2. 执行余额查询
            success, message, query_results = balance_query.query_all_balances()
            if not success:
                logger.error(f"❌ 余额查询失败: {message}")
                return
            
            logger.info(f"✅ 余额查询成功，共获取 {len(query_results)} 条记录")
            
            # 3. 检查并发送余额预警
            alert_success, alert_message = balance_query.check_balance_alert(query_results)
            logger.info(f"⚠️ 余额预警检查: {alert_message}")
            
            # 4. 生成并上传余额报告
            report_success, report_message = balance_query.generate_balance_report(query_results)
            logger.info(f"📄 余额报告: {report_message}")
  
        except Exception as e:
            logger.error(f"❌ 余额定时任务执行异常: {e}")
            import traceback
            logger.error(f"详细错误信息: {traceback.format_exc()}")
    
    def _task_loop(self):
        """任务循环主体"""
        logger.info(f"✅ 余额监控定时任务已启动")
        logger.info(f"   执行间隔: 每 {self.interval_minutes} 分钟")
        
        while not self.stop_event.is_set():
            try:
                # 执行一次监控
                self._execute_monitoring_task()
            except Exception as e:
                logger.error(f"余额监控定时任务循环内发生异常: {e}")
            
            # 等待指定的间隔时间
            self.stop_event.wait(timeout=self.interval_minutes * 60)
    
    def start(self):
        """启动定时任务（在后台线程中）"""
        if self.is_running:
            return f"⚠️ 余额监控定时任务已在运行中。当前执行间隔: {self.interval_minutes}分钟"
        
        self.is_running = True
        self.stop_event.clear()
        
        self.task_thread = threading.Thread(
            target=self._task_loop,
            name=f"BalanceMonitoringTask_{self.interval_minutes}min",
            daemon=True
        )
        self.task_thread.start()
        
        return (f"✅ 已启动余额监控定时任务\n"
                f"⏰ 执行间隔: 每 {self.interval_minutes} 分钟\n"
                f"📊 监控内容: 机构余额查询 + 阈值预警 + 报告生成")
    
    def stop(self):
        """停止定时任务"""
        if not self.is_running:
            return f"ℹ️ 余额监控定时任务未在运行。"
        
        self.is_running = False
        self.stop_event.set()
        
        if self.task_thread and self.task_thread.is_alive():
            self.task_thread.join(timeout=5.0)
        
        return f"🛑 余额监控定时任务已停止。"
    
    def status(self):
        """获取任务状态"""
        if self.is_running and self.task_thread and self.task_thread.is_alive():
            return (f"🟢 任务状态: 运行中\n"
                    f"⏰ 执行间隔: {self.interval_minutes} 分钟")
        else:
            return f"🔴 任务状态: 已停止"

# ===================== 换汇交易监控类 =====================
