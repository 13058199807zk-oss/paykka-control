"""
xt_auto_login_query_fixed.py - 修复Cookie格式的完整自动化脚本
"""

import asyncio
import json
import random
import time
import os
from typing import Dict, List, Optional, Tuple
from playwright.async_api import async_playwright, BrowserContext
import logging
import requests
import pandas as pd
from datetime import datetime
import sys
from pathlib import Path

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('xt_auto_login_query.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class XTAutoLogin:
    """XT平台自动登录器"""
    
    def __init__(self, config_file: str = "xt_login_config.json"):
        self.config_file = config_file
        self.config = self._load_config()
        self.context: Optional[BrowserContext] = None
        self.cookies: List[Dict] = []
        self.cookie_str: str = ""  # 这是我们需要修复的关键部分
        self.xsrf_token: str = ""
        self.jwt_token: str = ""
        self.refresh_token: str = ""
        
    def _load_config(self) -> Dict:
        """加载配置"""
        default_config = {
            "phone": "13058199807",
            "password": "7639179zK@",
            "login_url": "https://www.xtransfer.cn/login",
            "target_url": "https://www.xtransfer.cn/fund/home",
            "headless": False,
            "slow_mo": 100,
            "user_data_dir": None,
            "viewport": {"width": 1920, "height": 1080},
            "timeout": 30000,
        }
        
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    user_config = json.load(f)
                    default_config.update(user_config)
                logger.info(f"从 {self.config_file} 加载配置")
        except Exception as e:
            logger.warning(f"加载配置文件失败: {e}")
            
        return default_config
    
    async def setup_browser(self):
        """设置浏览器"""
        try:
            playwright = await async_playwright().start()
            
            # 浏览器启动参数
            launch_options = {
                "headless": self.config.get("headless", True),
                "slow_mo": self.config.get("slow_mo", 100),
                "args": ["--disable-blink-features=AutomationControlled"]
            }
            
            # 如果有用户数据目录，使用持久化上下文
            user_data_dir = self.config.get("user_data_dir")
            if user_data_dir and os.path.exists(user_data_dir):
                logger.info(f"使用Chrome用户数据目录: {user_data_dir}")
                
                self.context = await playwright.chromium.launch_persistent_context(
                    user_data_dir=user_data_dir,
                    **launch_options
                )
            else:
                # 常规启动
                browser = await playwright.chromium.launch(**launch_options)
                self.context = await browser.new_context(
                    viewport=self.config.get("viewport"),
                    user_agent=self._get_random_user_agent()
                )
            
            logger.info("✅ 浏览器设置成功")
            return True
            
        except Exception as e:
            logger.error(f"❌ 设置浏览器失败: {e}")
            return False
    
    def _get_random_user_agent(self) -> str:
        """获取随机User-Agent"""
        user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        ]
        return random.choice(user_agents)
    
    async def login(self) -> bool:
        """执行登录流程"""
        try:
            logger.info("="*60)
            logger.info("开始XT平台自动登录")
            logger.info("="*60)
            
            # 1. 设置浏览器
            if not await self.setup_browser():
                return False
            
            # 2. 获取页面
            page = self.context.pages[0] if self.context.pages else await self.context.new_page()
            
            # 3. 访问登录页面
            login_url = self.config.get("login_url", "")
            logger.info(f"访问登录页面: {login_url}")
            await page.goto(login_url, timeout=self.config.get("timeout", 30000))
            await asyncio.sleep(2)
            
            # 4. 输入手机号
            phone = self.config.get("phone", "")
            logger.info(f"输入手机号: {phone}")
            
            phone_input = await page.wait_for_selector(
                "input[type='tel'], input[placeholder*='手机'], input[name*='phone']",
                timeout=10000
            )
            
            if phone_input:
                await phone_input.click()
                await asyncio.sleep(0.5)
                await phone_input.fill("")
                await asyncio.sleep(0.5)
                await phone_input.type(phone, delay=100)
            else:
                logger.error("❌ 找不到手机号输入框")
                return False
            
            await asyncio.sleep(1)
            
            # 5. 输入密码
            password = self.config.get("password", "")
            logger.info("输入密码")
            
            password_input = await page.wait_for_selector(
                "input[type='password']",
                timeout=10000
            )
            
            if password_input:
                await password_input.click()
                await asyncio.sleep(0.5)
                await password_input.fill("")
                await asyncio.sleep(0.5)
                await password_input.type(password, delay=100)
            else:
                logger.error("❌ 找不到密码输入框")
                return False
            
            await asyncio.sleep(1)
            
            # 6. 点击登录按钮
            logger.info("点击登录按钮")
            
            login_button = await page.wait_for_selector(
                "button[type='submit'], button:has-text('登录')",
                timeout=10000
            )
            
            if login_button:
                await login_button.click()
                logger.info("✅ 已点击登录按钮")
            else:
                logger.error("❌ 找不到登录按钮")
                return False
            
            # 7. 等待登录成功
            logger.info("等待登录结果...")
            await asyncio.sleep(5)
            
            # 检查当前URL
            current_url = page.url
            logger.info(f"当前URL: {current_url}")
            
            target_url = self.config.get("target_url", "")
            if target_url and target_url in current_url:
                logger.info("✅ 成功跳转到目标页面")
            elif "login" not in current_url.lower():
                logger.info("✅ 已离开登录页面，登录成功")
            else:
                logger.warning("⚠️ 可能未登录成功，但仍尝试提取Cookie")
            
            # 8. 提取Cookies
            await self.extract_cookies()
            
            if self.cookies and self.cookie_str:
                logger.info("✅ 登录成功并获取到Cookie")
                return True
            else:
                logger.error("❌ 登录失败，未获取到Cookie")
                return False
                
        except Exception as e:
            logger.error(f"❌ 登录流程异常: {e}")
            return False
    
    async def extract_cookies(self):
        """提取Cookies - 修复的版本，生成正确格式的cookie字符串"""
        try:
            if self.context:
                self.cookies = await self.context.cookies()
                logger.info(f"✅ 提取到 {len(self.cookies)} 个Cookie")
                
                # 构建正确格式的cookie字符串
                cookie_parts = []
                for cookie in self.cookies:
                    name = cookie.get('name', '')
                    value = cookie.get('value', '')
                    
                    if name and value and value != 'null':
                        # 格式: name=value
                        cookie_parts.append(f"{name}={value}")
                        
                        # 提取重要Token
                        if 'XSRF-TOKEN' in name.upper():
                            self.xsrf_token = value
                            logger.info(f"  XSRF-TOKEN: {value[:30]}...")
                        elif name.lower() == 'token' and 'eyJ' in value[:10]:
                            self.jwt_token = value
                            logger.info(f"  JWT Token: {value[:30]}...")
                        elif 'refreshtoken' in name.lower() and 'eyJ' in value[:10]:
                            self.refresh_token = value
                            logger.info(f"  Refresh Token: {value[:30]}...")
                        elif 'dx_fmrpy6' in name.lower():
                            logger.info(f"  dx_FMrPY6: {value[:30]}...")
                
                # 按照您提供的格式：用分号和空格分隔
                self.cookie_str = "; ".join(cookie_parts)
                
                # 验证格式
                logger.info("="*50)
                logger.info("生成的Cookie字符串验证:")
                logger.info(f"长度: {len(self.cookie_str)} 字符")
                logger.info(f"格式示例: {self.cookie_str[:100]}...")
                logger.info(f"包含的Cookie数量: {len(cookie_parts)}")
                logger.info("="*50)
                
            else:
                logger.error("❌ 没有可用的context")
                
        except Exception as e:
            logger.error(f"❌ 提取Cookies失败: {e}")
    
    def get_auth_info(self) -> Dict:
        """获取认证信息"""
        return {
            "cookie_str": self.cookie_str,
            "xsrf_token": self.xsrf_token,
            "jwt_token": self.jwt_token,
            "refresh_token": self.refresh_token,
            "cookies": self.cookies
        }
    
    def save_auth_info(self, filename: str = "xt_auth_info.json"):
        """保存认证信息"""
        try:
            auth_info = {
                "extracted_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "cookie_str": self.cookie_str,
                "xsrf_token": self.xsrf_token,
                "jwt_token": self.jwt_token,
                "refresh_token": self.refresh_token,
                "cookies": self.cookies
            }
            
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(auth_info, f, ensure_ascii=False, indent=2)
            logger.info(f"✅ 认证信息已保存到: {filename}")
            
            # 同时保存为纯文本格式，便于查看
            txt_filename = filename.replace('.json', '.txt')
            with open(txt_filename, 'w', encoding='utf-8') as f:
                f.write("="*60 + "\n")
                f.write("XT平台认证信息\n")
                f.write(f"提取时间: {auth_info['extracted_at']}\n")
                f.write("="*60 + "\n\n")
                f.write("Cookie字符串:\n")
                f.write(f"{self.cookie_str}\n\n")
                f.write("="*60 + "\n")
                f.write("重要Token:\n")
                f.write(f"XSRF-TOKEN: {self.xsrf_token}\n")
                f.write(f"JWT Token: {self.jwt_token[:50]}...\n")
                f.write(f"Refresh Token: {self.refresh_token[:50]}...\n")
                f.write("="*60 + "\n")
            
            logger.info(f"✅ 认证信息文本已保存到: {txt_filename}")
            return True
        except Exception as e:
            logger.error(f"❌ 保存认证信息失败: {e}")
            return False
    
    async def close(self):
        """关闭浏览器"""
        try:
            if self.context:
                await self.context.close()
            logger.info("✅ 浏览器已关闭")
        except:
            pass

class XTRateQueryFixed:
    """修复的汇率查询器，使用正确的Cookie格式"""
    
    def __init__(self, auth_info: Dict):
        """
        初始化汇率查询器
        
        Args:
            auth_info: 从登录器获取的认证信息
        """
        # API端点
        self.api_endpoint = "https://api.xtransfer.cn/api/v1/spotfx/graph/present-rate/get-rate-by-ccy"
        
        # 完整的请求头 - 与您之前成功的版本保持一致
        self.base_headers = {
            'accept': 'application/json',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'zh-CN,zh;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
            'origin': 'https://www.xtransfer.cn',
            'priority': 'u=1, i',
            'referer': 'https://www.xtransfer.cn/',
            'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',
            'x-b3-spanid': '1a1252a0119011f1',
            'x-b3-traceid': '1a1252a0119011f1a4849b0f1e2f08e7',
            'x-language': 'CN',
            'x-server-grant-id': 'NfANzrfXpAAk0dJ5ysIYQxfqKcUCBt5tLgMjxClfzII=',
            'x-user-agent-context': 'PC_Browser;serverGrantId:NfANzrfXpAAk0dJ5ysIYQxfqKcUCBt5tLgMjxClfzII=;',
        }
        
        # 从认证信息中提取数据
        self.cookie_str = auth_info.get("cookie_str", "")
        self.xsrf_token = auth_info.get("xsrf_token", "")
        self.jwt_token = auth_info.get("jwt_token", "")
        self.refresh_token = auth_info.get("refresh_token", "")
        
        # 初始化会话
        self.session = requests.Session()
        
        # 设置Cookie到会话
        self._setup_session_cookies()
        
        logger.info("✅ 汇率查询器初始化完成")
    
    def _setup_session_cookies(self):
        """设置Cookie到会话 - 修复版本"""
        if not self.cookie_str:
            logger.error("❌ 没有可用的Cookie字符串")
            return
        
        # 打印Cookie字符串验证
        logger.info("="*50)
        logger.info("汇率查询器使用的Cookie字符串:")
        logger.info(f"长度: {len(self.cookie_str)} 字符")
        logger.info(f"前100字符: {self.cookie_str[:100]}...")
        logger.info("="*50)
        
        # 将Cookie字符串解析为字典
        cookie_dict = self._parse_cookie_str(self.cookie_str)
        
        # 设置到会话
        for name, value in cookie_dict.items():
            self.session.cookies.set(name, value)
        
        logger.info(f"✅ 已设置 {len(cookie_dict)} 个Cookie到会话")
        
        # 打印重要Cookie
        important_cookies = ['token', 'XSRF-TOKEN', 'refreshToken', 'dx_FMrPY6']
        for cookie_name in important_cookies:
            cookie_value = cookie_dict.get(cookie_name) or cookie_dict.get(cookie_name.lower())
            if cookie_value:
                logger.info(f"  ✅ 设置 {cookie_name}: {cookie_value[:30]}...")
    
    def _parse_cookie_str(self, cookie_str: str) -> Dict[str, str]:
        """解析cookie字符串为字典"""
        cookies = {}
        cookie_items = cookie_str.split(';')
        
        for item in cookie_items:
            item = item.strip()
            if '=' in item:
                parts = item.split('=', 1)
                if len(parts) == 2:
                    name, value = parts
                    cookies[name.strip()] = value.strip()
        
        return cookies
    
    def get_currency_pairs(self) -> List[Tuple[str, str, str]]:
        """返回指定的货币对列表"""
        return [
            ("USD", "CNY", "美元兑离岸人民币"),
            ("EUR", "CNY", "欧元兑离岸人民币"),
            ("HKD", "CNY", "港币兑离岸人民币"),
            ("GBP", "CNY", "英镑兑离岸人民币"),
            ("SGD", "CNY", "新加坡元兑离岸人民币"),
            ("AUD", "CNY", "澳元兑离岸人民币"),
            ("IDR", "CNY", "印尼盾兑离岸人民币"),
            ("MYR", "CNY", "马来西亚令吉兑离岸人民币"),
            ("PHP", "CNY", "菲律宾比索兑离岸人民币"),
            ("THB", "CNY", "泰铢兑离岸人民币"),
            ("RON", "CNY", "罗马尼亚列伊兑离岸人民币"),
            ("PLN", "CNY", "波兰兹罗提兑离岸人民币"),
            ("HUF", "CNY", "匈牙利福林兑离岸人民币"),
            ("NGN", "USD", "尼日利亚奈拉兑美元"),
            ("VND", "CNY", "越南盾兑离岸人民币"),
            ("VND", "USD", "越南盾兑美元"),
        ]
    
    def query_exchange_rate(self, from_ccy: str, to_ccy: str) -> Optional[Dict]:
        """查询单一货币对的汇率"""
        # 构建完整的headers
        headers = self.base_headers.copy()
        
        # 添加XSRF-Token
        if self.xsrf_token:
            headers['x-xsrf-token'] = self.xsrf_token
        
        # 添加JWT Token
        if self.jwt_token:
            headers['Authorization'] = f'Bearer {self.jwt_token}'
        
        # 查询参数
        params = {
            'fromCcy': from_ccy.upper(),
            'toCcy': to_ccy.upper(),
            'requestFrom': 'PC'
        }
        
        try:
            logger.info(f"查询 {from_ccy} → {to_ccy} ...")
            
            # 添加详细调试信息
            logger.debug(f"请求URL: {self.api_endpoint}")
            logger.debug(f"请求参数: {params}")
            
            # 打印请求头（去掉敏感信息）
            safe_headers = headers.copy()
            if 'x-xsrf-token' in safe_headers:
                safe_headers['x-xsrf-token'] = safe_headers['x-xsrf-token'][:10] + "..."
            if 'Authorization' in safe_headers:
                safe_headers['Authorization'] = safe_headers['Authorization'][:20] + "..."
            logger.debug(f"请求头: {safe_headers}")
            
            # 使用会话发送请求
            response = self.session.get(
                self.api_endpoint,
                headers=headers,
                params=params,
                timeout=15,
                verify=True
            )
            
            logger.info(f"状态码: {response.status_code}")
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    logger.info(f"✅ 成功获取 {from_ccy}/{to_ccy} 汇率数据")
                    return data
                except json.JSONDecodeError as e:
                    logger.error(f"❌ JSON解析错误: {e}")
                    logger.error(f"响应内容: {response.text[:200]}")
                    return None
            elif response.status_code == 401:
                logger.error("❌ 认证失败 (401): Token可能已过期")
                logger.error(f"响应头: {dict(response.headers)}")
                return None
            elif response.status_code == 403:
                logger.error("❌ 权限拒绝 (403): Cookie或Token无效")
                return None
            else:
                logger.error(f"❌ 请求失败: {response.status_code}")
                logger.error(f"响应内容: {response.text[:200]}")
                return None
                
        except Exception as e:
            logger.error(f"❌ 查询异常: {e}")
            return None
    
    def batch_query_rates(self, currency_pairs: List[Tuple]) -> List[Dict]:
        """批量查询汇率"""
        results = []
        
        logger.info(f"\n📊 开始批量查询 {len(currency_pairs)} 个货币对")
        logger.info("="*60)
        
        for i, (from_ccy, to_ccy, description) in enumerate(currency_pairs, 1):
            logger.info(f"[{i}/{len(currency_pairs)}] 查询 {from_ccy}/{to_ccy} ({description})...")
            
            rate_data = self.query_exchange_rate(from_ccy, to_ccy)
            
            if rate_data:
                # 解析数据
                parsed_data = self.parse_rate_data(rate_data, from_ccy, to_ccy)
                
                # 构建结果
                display_pair = f"{from_ccy}→{to_ccy}".replace("CNY", "CNH")
                result = {
                    '货币对': display_pair,
                    '汇率': parsed_data.get('rate', '未找到汇率数据'),
                    '状态': '成功' if parsed_data.get('rate') else '解析失败',
                    '查询时间': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    '描述': description
                }
                
                if parsed_data.get('rate'):
                    logger.info(f"   ✅ 成功获取汇率: {parsed_data['rate']}")
                else:
                    logger.info(f"   ⚠️ 获取 {from_ccy}/{to_ccy} 但未找到汇率数据")
            else:
                display_pair = f"{from_ccy}→{to_ccy}".replace("CNY", "CNH")
                result = {
                    '货币对': display_pair,
                    '汇率': '查询失败',
                    '状态': '查询失败',
                    '查询时间': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    '描述': description
                }
                logger.info(f"   ❌ 获取 {from_ccy}/{to_ccy} 汇率失败")
            
            results.append(result)
            
            # 添加延迟避免请求过于频繁
            if i < len(currency_pairs):
                time.sleep(0.5)
        
        logger.info("="*60)
        success_count = len([r for r in results if r.get('状态') == '成功'])
        logger.info(f"✅ 批量查询完成，成功: {success_count}, 失败: {len(currency_pairs) - success_count}")
        
        return results
    
    def parse_rate_data(self, data: Dict, from_ccy: str, to_ccy: str) -> Dict:
        """解析汇率数据"""
        result = {}
        
        if not data or not isinstance(data, dict):
            return result
        
        # 处理直接返回汇率的情况
        if 'rate' in data:
            result['rate'] = data.get('rate')
        
        # 处理包含code字段的响应
        elif 'code' in data and data.get('code') == 0 and 'data' in data:
            data_field = data['data']
            if isinstance(data_field, dict) and 'rate' in data_field:
                result['rate'] = data_field.get('rate')
            elif isinstance(data_field, (int, float)):
                result['rate'] = data_field
        
        return result
    
    def save_results_to_excel(self, results: List[Dict]) -> str:
        """保存结果到Excel"""
        if not results:
            logger.error("❌ 没有查询结果可保存")
            return ""
        
        try:
            # 获取用户桌面路径
            if os.name == 'nt':  # Windows
                desktop_path = Path(os.environ['USERPROFILE']) / 'Desktop'
            else:  # macOS/Linux
                desktop_path = Path(os.environ['HOME']) / 'Desktop'
            
            # 确保桌面目录存在
            desktop_path.mkdir(exist_ok=True)
            
            # 生成文件名
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"XTransfer_汇率查询_{timestamp}.xlsx"
            file_path = desktop_path / filename
            
            # 创建DataFrame
            df = pd.DataFrame(results)
            
            # 重新排列列顺序
            column_order = ['货币对', '汇率', '状态', '查询时间', '描述']
            df = df[column_order]
            
            # 保存到Excel
            with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='汇率查询结果', index=False)
                
                # 获取工作表
                worksheet = writer.sheets['汇率查询结果']
                
                # 设置列宽
                worksheet.column_dimensions['A'].width = 15  # 货币对
                worksheet.column_dimensions['B'].width = 20  # 汇率
                worksheet.column_dimensions['C'].width = 12  # 状态
                worksheet.column_dimensions['D'].width = 20  # 查询时间
                worksheet.column_dimensions['E'].width = 25  # 描述
            
            logger.info(f"✅ Excel文件已保存到桌面: {file_path}")
            logger.info(f"📊 共保存 {len(df)} 条记录")
            
            return str(file_path)
            
        except Exception as e:
            logger.error(f"❌ 保存Excel文件失败: {e}")
            return ""
    
    def display_results(self, results: List[Dict]):
        """显示查询结果"""
        if not results:
            logger.info("没有查询结果可显示")
            return
        
        logger.info("\n" + "="*50)
        logger.info("📊 XTransfer 汇率查询结果")
        logger.info("="*50)
        
        for result in results:
            pair = result.get('货币对', '')
            rate = result.get('汇率', 'N/A')
            status = result.get('状态', '')
            logger.info(f"{pair:<12} {str(rate):<18} [{status}]")
        
        logger.info("="*50)

async def auto_login_and_query_fixed():
    """自动登录并查询汇率的主函数 - 修复版本"""
    
    # 第一步：自动登录
    logger.info("="*60)
    logger.info("第1步：XT平台自动登录 (修复Cookie格式)")
    logger.info("="*60)
    
    login_bot = XTAutoLogin()
    success = await login_bot.login()
    
    if not success:
        logger.error("❌ 登录失败，无法进行汇率查询")
        return
    
    # 获取认证信息
    auth_info = login_bot.get_auth_info()
    
    # 保存认证信息
    login_bot.save_auth_info()
    
    # 关闭浏览器
    await login_bot.close()
    
    # 第二步：自动查询汇率
    logger.info("\n" + "="*60)
    logger.info("第2步：自动查询汇率 (使用修复的Cookie格式)")
    logger.info("="*60)
    
    # 创建汇率查询器
    rate_query = XTRateQueryFixed(auth_info)
    
    # 获取货币对列表
    currency_pairs = rate_query.get_currency_pairs()
    
    # 执行批量查询
    results = rate_query.batch_query_rates(currency_pairs)
    
    if results:
        # 显示结果
        rate_query.display_results(results)
        
        # 保存结果
        excel_file = rate_query.save_results_to_excel(results)
        
        if excel_file:
            logger.info(f"\n" + "="*60)
            logger.info("✅ 完整流程完成！")
            logger.info(f"   1. ✅ 自动登录成功")
            logger.info(f"   2. ✅ 汇率查询完成")
            logger.info(f"   3. ✅ 结果已保存到: {excel_file}")
            logger.info("="*60)
            
            # 显示成功统计
            success_count = len([r for r in results if r.get('状态') == '成功'])
            logger.info(f"📈 成功查询: {success_count} 个货币对")
        else:
            logger.error("❌ 保存Excel文件失败")
    else:
        logger.error("❌ 汇率查询失败")

def main():
    """主函数"""
    try:
        # 检查依赖
        try:
            import pandas
            import openpyxl
        except ImportError:
            logger.error("❌ 缺少必要的依赖库，请安装：")
            logger.error("   pip install pandas openpyxl requests playwright")
            return
        
        # 运行异步主函数
        asyncio.run(auto_login_and_query_fixed())
        
    except KeyboardInterrupt:
        logger.info("用户中断")
    except Exception as e:
        logger.error(f"程序异常: {e}")

if __name__ == "__main__":
    main()