# 🔄 Paykka Bot 环境恢复指南

> **存储位置**：本文件及所有相关文件均保存在 `/workspace`（用户工作目录）中。
> 新对话开始时，用户只需将 `/workspace/PAYKKA_MEMORY.md` 的内容提供给 AI 即可恢复上下文。

---

## ⚠️ 安全说明

**本项目文件仅保存在 `/workspace` 本地目录，不上传任何第三方公开服务器。**
GitHub 在沙箱环境中访问不稳定，且涉及敏感凭据，故不依赖云端备份。

---

## 恢复方式

### 方式一：直接读本地文件（首选）

`/workspace` 下的文件对用户可见，新对话时把以下文件交给 AI：

| 文件 | 用途 |
|------|------|
| `PAYKKA_MEMORY.md` | 完整上下文（架构/命令/认证/待办） |
| `PAYKKA_STATE.md` | 详细状态快照 |
| `paykka_backup_v17_20260607.tar.gz` | 全部代码备份（53 文件） |

### 方式二：解压代码备份

```bash
cd /workspace
mkdir -p restore && tar -xzf paykka_backup_v17_20260607.tar.gz -C restore
cp restore/paykka_backup_v17/* /workspace/
```

---

## 环境依赖

```bash
pip3 install lark-oapi pyotp playwright pandas matplotlib openpyxl \
             requests schedule pytz PyGithub beautifulsoup4
playwright install chromium
```

---

## AI 恢复检查清单

新对话中 AI 应完成以下检查：

- [ ] 从 GitHub 拉取 `v17_backup/` 目录
- [ ] 解压 `paykka_backup_v17_20260607.tar.gz`（含 52 个文件）
- [ ] 读取 `PAYKKA_STATE.md` 了解：
  - 14 个模块的架构
  - 报价对比命令用法（`报价对比 USDCNH 7D`）
  - XT Cookie 认证机制
  - 竞品集成状态（XT✅ AW✅ WF⚠️ LL⚠️）
  - 8 项待办清单
- [ ] 确认 `/workspace` 文件完整（应为 53 个）
- [ ] 向用户汇报当前进展与下一步建议

---

## 环境依赖安装

```bash
pip3 install lark-oapi pyotp playwright pandas matplotlib openpyxl \
             requests schedule pytz PyGithub beautifulsoup4

# Playwright 浏览器（XT 登录用）
playwright install chromium
```

---

## 关键启动命令

```bash
# 启动飞书 Bot 守护进程
python3.11 lark_bot_daemon.py

# XT 重新登录（刷新 Cookie）
xvfb-run --auto-servernum python3.11 xt_stealth_login.py

# 测试报价对比
python3.11 test_comparison.py
```

---

## 记忆恢复要点

| 项目 | 位置 |
|------|------|
| 完整状态文档 | `v17_backup/PAYKKA_STATE.md` |
| 代码备份包 | `v17_backup/paykka_backup_v17_20260607.tar.gz` |
| 核心引擎 | `paykka_comparison.py`（V17新增报价对比） |
| 主控制器 | `paykka_controllerV17.py` |
| XT认证缓存 | `xt_auth_cache.json` |

---

## 项目背景速记

- **项目**：Paykka 跨境支付清算系统 Bot（V17）
- **用户**：郑凯（xgd.com 清算部，资金运营岗）
- **核心功能**：汇差配置、路由配置、余额查询、换汇监控、汇率监控、报价对比
- **V17 新增**：渠道（YB/MDAQ/BOC/HCE）与友商（XT）历史报价对比
- **特殊机制**：XT 用 Cookie 认证 + xvfb 绕过 CAPTCHA

---

*最后更新: 2026-06-07*
