# ===================== paykka_routing_sched.py =====================
# RoutingScheduler - 路由定时调度
# 从 paykka_controllerV16.py 提取

import json
import ast
import time
import urllib.parse
import requests
import re
import threading
import os
import hashlib
import asyncio
import subprocess
import base64
from typing import List, Dict, Tuple, Any, Optional, Union
from datetime import datetime, date, timedelta, timezone, time as dtime
from playwright.async_api import async_playwright
import pandas as pd
from github import Github, InputGitAuthor
import pytz

from paykka_config import *
from paykka_core import PaykkaSystemManager, send_wechat_work_message

class RoutingScheduler:
    """路由定时切换调度器"""
    
    def __init__(self, token: str):
        self.token = token
        self.routing_configurator = None
        self.is_running = False
        self.task_thread = None
        self.stop_event = threading.Event()
        self.last_switch_time = {}  # 记录上次切换时间
        self.switch_history = []  # 新增：切换历史记录（最多保留100条）
        self.check_count = 0  # 新增：检查次数统计
        self.manager = PaykkaSystemManager()
        
        # 路由配置文件的GitHub路径
        self.ROUTING_SCHEDULE_FILE = "routing_schedule.md"
        self.GITHUB_REPO_OWNER = GITHUB_REPO_OWNER
        self.GITHUB_REPO_NAME = "paykka-control"  # 纯 repo 名（不含 owner 前缀）

        # 新增：缓存配置
        self.cached_config = None
        self.last_config_fetch_time = None
        self.next_config_fetch_time = None  # 下次读取配置的时间
        self.config_lock = threading.Lock()
        
    def _get_routing_configurator(self):
        """获取路由配置器实例"""
        if not self.routing_configurator:
            self.routing_configurator = self.manager.get_routing_configurator()
        return self.routing_configurator

    def _calculate_next_switch_time(self, schedule: Dict) -> Optional[datetime]:
        """计算规则的下一次切换时间"""
        try:
            # 获取当前时间
            now = datetime.now()
            
            # 检查规则是否启用
            if not schedule.get("enabled", True):
                return None
            
            # 解析时间
            time_str = schedule.get("time", "")
            if not time_str:
                return None
            
            # 解析小时和分钟
            try:
                hour, minute = map(int, time_str.split(":"))
            except:
                return None
            
            # 解析星期几
            days = schedule.get("days", [])
            if not days:  # 如果没有指定days，表示每天都要检查
                # 构造今天的时间
                target_time = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
                if target_time <= now:  # 如果今天的时间已经过去，就是明天
                    target_time += timedelta(days=1)
                return target_time
            
            # 将星期几字符串映射为数字（0=周一，6=周日）
            day_mapping = {
                "MON": 0, "TUE": 1, "WED": 2, "THU": 3,
                "FRI": 4, "SAT": 5, "SUN": 6,
            }
            
            # 获取今天是星期几（0=周一，6=周日）
            current_weekday = now.weekday()
            
            # 将days转换为数字
            day_numbers = [day_mapping.get(day.upper(), -1) for day in days if day.upper() in day_mapping]
            day_numbers = [d for d in day_numbers if d >= 0]
            
            if not day_numbers:
                return None
            
            # 计算下一个符合条件的时间
            for day_offset in range(8):  # 最多查看8天内（包含今天）
                check_date = now.date() + timedelta(days=day_offset)
                check_weekday = check_date.weekday()
                
                if check_weekday in day_numbers:
                    # 构造这一天的时间
                    target_time = datetime.combine(check_date, dtime(hour, minute, 0))
                    
                    # 如果时间已经过去（对于今天），就跳过
                    if day_offset == 0 and target_time <= now:
                        continue
                    
                    return target_time
            
            return None
            
        except Exception as e:
            logger.error(f"计算下一次切换时间失败: {e}")
            return None

    def _calculate_next_fetch_time(self) -> Optional[datetime]:
        """计算下一次读取配置的时间（基于所有规则的下一次切换时间）"""
        if not self.cached_config or not self.cached_config.get("ENABLED", True):
            # 如果没有配置或功能禁用，默认1小时后重试
            return datetime.now() + timedelta(hours=1)
        
        schedules = self.cached_config.get("SCHEDULES", [])
        if not schedules:
            # 如果没有规则，默认1小时后重试
            return datetime.now() + timedelta(hours=1)
        
        # 找出所有规则的下一次切换时间
        next_times = []
        for schedule in schedules:
            next_time = self._calculate_next_switch_time(schedule)
            if next_time:
                next_times.append(next_time)
        
        if not next_times:
            # 如果没有找到任何有效的切换时间，默认1小时后重试
            return datetime.now() + timedelta(hours=1)
        
        # 找出最近的下一次切换时间
        nearest_time = min(next_times)
        
        # 修复：直接在切换时间点执行检查（不再延后1分钟，避免错过切换窗口）
        fetch_time = nearest_time
        
        # 确保至少是当前时间之后
        now = datetime.now()
        if fetch_time <= now:
            fetch_time = now + timedelta(minutes=5)  # 如果已经过去，5分钟后重试
        
        return fetch_time
    
    def _fetch_routing_schedule(self) -> Dict:
        """从GitHub获取路由切换时间表配置"""
        try:
            logger.info("🔍 开始从GitHub获取路由切换时间表配置...")
            url = f"https://api.github.com/repos/{self.GITHUB_REPO_OWNER}/{self.GITHUB_REPO_NAME}/contents/{self.ROUTING_SCHEDULE_FILE}"
            headers = {
                "Authorization": f"token {GITHUB_TOKEN}",
                "Accept": "application/vnd.github.v3.raw"
            }
            response = requests.get(url, headers=headers, timeout=30)
            
            if response.status_code == 200:
                md_content = response.text
                config = self._parse_routing_schedule_md(md_content)

                # 缓存配置并更新时间（修复：原代码在此处提前return，导致缓存逻辑成为死代码）
                with self.config_lock:
                    self.cached_config = config
                    self.last_config_fetch_time = datetime.now()
                    # 计算下一次读取配置的时间
                    self.next_config_fetch_time = self._calculate_next_fetch_time()
                
                logger.info(f"✅ 路由配置已缓存，共 {len(config.get('SCHEDULES', []))} 条规则")
                if self.next_config_fetch_time:
                    logger.info(f"⏰ 下次读取配置时间: {self.next_config_fetch_time.strftime('%Y-%m-%d %H:%M:%S')}")
                
                return config

            else:
                logger.error(f"❌ 获取路由切换配置失败，状态码: {response.status_code}")
                return self._get_default_schedule()
        except Exception as e:
            logger.error(f"❌ 获取路由切换配置时出错: {e}")
            return self._get_default_schedule()

    def _get_cached_config(self, force_fetch: bool = False) -> Dict:
        """获取缓存的配置，如果需要则从GitHub获取"""
        with self.config_lock:
            # 检查是否需要重新获取配置
            need_fetch = False
            
            if force_fetch:
                need_fetch = True
            elif self.cached_config is None:
                need_fetch = True
            elif self.next_config_fetch_time and datetime.now() >= self.next_config_fetch_time:
                need_fetch = True
                logger.info("⏰ 到达配置读取时间，重新获取配置")
            
            if need_fetch:
                return self._fetch_routing_schedule()
            
            return self.cached_config

    def _should_fetch_config_now(self) -> bool:
        """检查现在是否需要读取配置"""
        with self.config_lock:
            if self.cached_config is None:
                return True
            
            if self.next_config_fetch_time is None:
                return True
            
            if datetime.now() >= self.next_config_fetch_time:
                return True
            
            return False
    
    def _parse_routing_schedule_md(self, md_content: str) -> Dict:
        """解析路由切换时间表配置"""
        config = {
            "ENABLED": True,
            "SCHEDULES": [],
            "NOTIFICATION": True
        }
        
        # 1. 提取开关
        enabled_pattern = r'ENABLED\s*=\s*(True|False)'
        enabled_match = re.search(enabled_pattern, md_content)
        if enabled_match:
            config["ENABLED"] = enabled_match.group(1) == "True"
        
        # 2. 提取通知开关
        notification_pattern = r'NOTIFICATION\s*=\s*(True|False)'
        notification_match = re.search(notification_pattern, md_content)
        if notification_match:
            config["NOTIFICATION"] = notification_match.group(1) == "True"
        
        # 3. 提取时间表配置
        schedules_pattern = r'SCHEDULES\s*=\s*(\[[\s\S]*?\])(?=\s*\n\S|\s*\Z)'
        schedules_match = re.search(schedules_pattern, md_content, re.DOTALL)
        if schedules_match:
            schedules_str = schedules_match.group(1)
            try:
                config["SCHEDULES"] = ast.literal_eval(schedules_str)
            except Exception as e:
                logger.error(f"解析SCHEDULES失败: {e}")
                config["SCHEDULES"] = []
        
        logger.info(f"✅ 成功解析路由切换配置: {len(config['SCHEDULES'])} 条时间规则")
        #logger.info(f"✅ 路由切换配置详情: {config['SCHEDULES']} ")
        return config
    
    def _get_default_schedule(self) -> Dict:
        """获取默认时间表（示例）"""
        return {
            "ENABLED": True,
            "NOTIFICATION": True,
            "SCHEDULES": [
                {
                    "id": "morning_switch",
                    "description": "工作日早上切换到OCBC",
                    "currency_pair": {"sell": "USD", "buy": "CNH"},
                    "target_rule": "RULE_OCBC",
                    "time": "08:05",
                    "days": ["MON", "TUE", "WED", "THU", "FRI"],  # 工作日
                    "enabled": True
                },
                {
                    "id": "afternoon_switch",
                    "description": "工作日下午切换到HCE_TOM",
                    "currency_pair": {"sell": "USD", "buy": "CNH"},
                    "target_rule": "RULE_HCE_TOM",
                    "time": "14:50",
                    "days": ["MON", "TUE", "WED", "THU", "FRI"],  # 工作日
                    "enabled": True
                },
                {
                    "id": "saturday_switch",
                    "description": "周六早上切换到YB",
                    "currency_pair": {"sell": "USD", "buy": "CNH"},
                    "target_rule": "RULE_YB",
                    "time": "04:55",
                    "days": ["SAT"],  # 周六
                    "enabled": True
                }
            ]
        }
    
    def _check_schedule_match(self, schedule: Dict) -> bool:
        """检查当前时间是否匹配时间表（含 ±2 分钟容错窗口）"""
        now = datetime.now()
        current_time = now.strftime("%H:%M")
        current_day = now.strftime("%a").upper()  # 3个字母的星期几，如MON, TUE
        
        # 检查是否启用
        if not schedule.get("enabled", True):
            return False
        
        # 检查时间（修复：增加 ±2 分钟容错窗口，避免网络延迟/处理耗时导致错过切换）
        schedule_time_str = schedule.get("time", "")
        if not schedule_time_str:
            return False
        
        try:
            sh, sm = map(int, schedule_time_str.split(":"))
            ch, cm = map(int, current_time.split(":"))
        except (ValueError, TypeError):
            return False
        
        schedule_minutes = sh * 60 + sm
        current_minutes = ch * 60 + cm
        time_diff = abs(current_minutes - schedule_minutes)
        
        if time_diff > 2:  # 允许 ±2 分钟的误差
            return False
        
        # 检查星期几
        allowed_days = schedule.get("days", [])
        if allowed_days and current_day not in allowed_days:
            return False
        
        return True
    
    def _switch_currency_pair_route(self, schedule: Dict) -> bool:
        """执行货币对路由切换"""
        try:
            currency_pair = schedule.get("currency_pair", {})
            sell_currency = currency_pair.get("sell", "")
            buy_currency = currency_pair.get("buy", "")
            target_rule = schedule.get("target_rule", "")
            schedule_id = schedule.get("id", "")
            description = schedule.get("description", "")
            
            if not sell_currency or not buy_currency or not target_rule:
                logger.error(f"❌ 路由切换配置无效: {schedule}")
                return False
            
            # 检查目标规则是否有效
            if target_rule not in FX_STRATEGY_RULES:
                logger.error(f"❌ 无效的路由规则: {target_rule}")
                return False
            
            # 获取路由配置器
            configurator = self._get_routing_configurator()
            
            # 查询当前配置
            current_config = configurator.safe_query_fx_pair_config(sell_currency, buy_currency)
            
            if current_config:
                current_rule = current_config.get("fx_strategy_rule", "未知")
                if current_rule == target_rule:
                    logger.info(f"ℹ️ 路由无需切换: {sell_currency}->{buy_currency} 已经是 {target_rule}")
                    return True
            
            # 执行路由切换
            logger.info(f"🔄 正在切换路由: {sell_currency}->{buy_currency} 到 {target_rule}")
            success = configurator.safe_update_fx_pair_config(
                sell_currency=sell_currency,
                buy_currency=buy_currency,
                strategy_rule=target_rule,
                standalone_fx_enabled=True
            )
            
            if success:
                # 记录切换成功详情
                switch_record = {
                    "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "schedule_id": schedule_id,
                    "description": description,
                    "currency_pair": f"{sell_currency}->{buy_currency}",
                    "old_rule": current_config.get("fx_strategy_rule", "无") if current_config else "无",
                    "new_rule": target_rule,
                    "result": "✅ 成功"
                }
                self.switch_history.append(switch_record)
                if len(self.switch_history) > 100:
                    self.switch_history = self.switch_history[-100:]
                
                logger.info(f"✅ 路由切换成功: {sell_currency}->{buy_currency} | "
                           f"原规则: {switch_record['old_rule']} → 新规则: {target_rule} | "
                           f"计划: {schedule_id}({description})")
                
                # 记录切换时间
                self.last_switch_time[schedule_id] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                
                # 发送通知
                if schedule.get("send_notification", True):
                    self._send_switch_notification(schedule, current_config, target_rule)
                
                return True
            else:
                # 记录切换失败
                switch_record = {
                    "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "schedule_id": schedule_id,
                    "description": description,
                    "currency_pair": f"{sell_currency}->{buy_currency}",
                    "old_rule": current_config.get("fx_strategy_rule", "无") if current_config else "无",
                    "new_rule": target_rule,
                    "result": "❌ 失败"
                }
                self.switch_history.append(switch_record)
                if len(self.switch_history) > 100:
                    self.switch_history = self.switch_history[-100:]
                
                logger.error(f"❌ 路由切换失败: {sell_currency}->{buy_currency} 到 {target_rule}")
                return False
                
        except Exception as e:
            logger.error(f"❌ 路由切换异常: {e}")
            return False
    
    def _send_switch_notification(self, schedule: Dict, old_config: Optional[Dict], new_rule: str):
        """发送路由切换通知"""
        try:
            currency_pair = schedule.get("currency_pair", {})
            sell_currency = currency_pair.get("sell", "")
            buy_currency = currency_pair.get("buy", "")
            description = schedule.get("description", "")
            schedule_id = schedule.get("id", "")
            
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            pair_str = f"{sell_currency}->{buy_currency}"
            
            # 构建消息
            message = f"🔄 路由定时切换完成\n"
            message += f"⏰ 切换时间: {current_time}\n"
            message += f"📅 计划ID: {schedule_id}\n"
            message += f"📋 描述: {description}\n"
            message += f"💰 货币对: {pair_str}\n"
            
            if old_config:
                old_rule = old_config.get("fx_strategy_rule", "未知")
                message += f"📈 原路由: {old_rule}\n"
            
            message += f"🎯 新路由: {new_rule}\n"
            message += f"✅ 状态: 切换成功"
            
            # 发送到企业微信
            send_wechat_work_message(message)
            logger.info(f"✅ 路由切换通知已发送: {pair_str} -> {new_rule}")
            
        except Exception as e:
            logger.error(f"❌ 发送路由切换通知失败: {e}")
    
    def _execute_scheduled_checks(self):
        """执行定时检查（动态读取配置版 + 增强日志）"""
        try:
            self.check_count += 1
            
            # 检查是否需要读取配置
            config_reloaded = False
            if self._should_fetch_config_now():
                config = self._fetch_routing_schedule()
                config_reloaded = True
            else:
                config = self.cached_config
            
            if not config or not config.get("ENABLED", True):
                logger.debug("路由定时切换功能已禁用")
                self.next_config_fetch_time = datetime.now() + timedelta(hours=1)
                return
            
            schedules = config.get("SCHEDULES", [])
            if not schedules:
                logger.debug("没有配置路由切换时间表")
                self.next_config_fetch_time = datetime.now() + timedelta(hours=1)
                return
            
            # 执行规则检查
            executed_switch = False
            check_details = []
            
            for schedule in schedules:
                schedule_id = schedule.get("id", "")
                description = schedule.get("description", "")
                currency_pair = schedule.get("currency_pair", {})
                pair_str = f"{currency_pair.get('sell', '?')}->{currency_pair.get('buy', '?')}"
                target_rule = schedule.get("target_rule", "?")
                
                match_result = self._check_schedule_match(schedule)
                
                if not match_result:
                    check_details.append(f"  ⏭️ {schedule_id}({description}): 时间不匹配")
                    continue
                
                # 检查上次切换时间，避免重复切换
                last_switch = self.last_switch_time.get(schedule_id)
                if last_switch:
                    last_time = datetime.strptime(last_switch, "%Y-%m-%d %H:%M:%S")
                    time_diff = (datetime.now() - last_time).total_seconds() / 60
                    if time_diff < 5:
                        check_details.append(f"  ⏭️ {schedule_id}({description}): 5分钟内已切换")
                        continue
                
                # 执行切换
                check_details.append(f"  🔄 {schedule_id}({description}): {pair_str} → {target_rule}")
                success = self._switch_currency_pair_route(schedule)
                
                if success:
                    executed_switch = True
                    self.last_switch_time[schedule_id] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    check_details[-1] = f"  ✅ {schedule_id}({description}): {pair_str} → {target_rule}"
                else:
                    check_details[-1] = f"  ❌ {schedule_id}({description}): {pair_str} → {target_rule} 切换失败"
            
            # 汇总日志
            total = len(schedules)
            matched = sum(1 for d in check_details if '✅' in d or '❌' in d)
            success_count = sum(1 for d in check_details if '✅' in d)
            fail_count = sum(1 for d in check_details if '❌' in d)
            
            summary = (f"📊 路由检查 #{self.check_count} | "
                      f"总规则: {total} | 匹配: {matched} | "
                      f"成功: {success_count} | 失败: {fail_count} | "
                      f"配置{'已刷新' if config_reloaded else '缓存'}")
            logger.info(summary)
            if check_details:
                logger.info("检查详情:\n" + "\n".join(check_details))
            
            # 修复：无论是否执行了切换，都重新计算下一次配置读取时间
            # （避免未匹配到任何计划时 next_config_fetch_time 不更新导致循环异常）
            with self.config_lock:
                self.next_config_fetch_time = self._calculate_next_fetch_time()
                if self.next_config_fetch_time:
                    logger.info(f"⏰ 下次读取配置时间更新为: {self.next_config_fetch_time.strftime('%Y-%m-%d %H:%M:%S')}")
        
        except Exception as e:
            logger.error(f"❌ 执行路由定时检查异常: {e}")
            # 发生异常时，1小时后重试
            self.next_config_fetch_time = datetime.now() + timedelta(hours=1)
    
    def _task_loop(self):
        """任务循环主体 - 动态间隔版"""
        logger.info("✅ 路由定时切换任务已启动（动态读取配置模式）")
        
        # 首次读取配置
        config = self._fetch_routing_schedule()
        
        while not self.stop_event.is_set():
            try:
                # 计算下一次检查的时间（基于下次配置读取时间）
                now = datetime.now()
                next_check_time = self.next_config_fetch_time
                
                if next_check_time:
                    # 计算需要等待的秒数
                    wait_seconds = (next_check_time - now).total_seconds()
                    
                    if wait_seconds > 0:
                        # 记录日志
                        logger.info(f"⏰ 下次检查时间: {next_check_time.strftime('%Y-%m-%d %H:%M:%S')} (还有{wait_seconds/60:.1f}分钟)")
                        
                        # 等待到下一次检查时间
                        self.stop_event.wait(timeout=min(wait_seconds, 3600))  # 最多等待1小时
                    else:
                        # 已经到了检查时间，立即执行
                        self._execute_scheduled_checks()
                        # 执行后短暂休眠，避免CPU占用过高
                        self.stop_event.wait(timeout=60)  # 等待1分钟
                else:
                    # 没有下一次检查时间，默认等待5分钟
                    logger.debug("未计算到下次检查时间，等待5分钟")
                    self.stop_event.wait(timeout=300)
                    
            except Exception as e:
                logger.error(f"路由定时任务循环内发生异常: {e}")
                # 发生异常时，等待5分钟后重试
                self.stop_event.wait(timeout=300)

    def get_status_detail(self) -> str:
        """获取详细状态信息"""
        with self.config_lock:
            status = []
            status.append(f"🔄 任务状态: {'运行中' if self.is_running else '已停止'}")
            
            if self.last_config_fetch_time:
                status.append(f"📅 最后读取配置: {self.last_config_fetch_time.strftime('%Y-%m-%d %H:%M:%S')}")
            
            if self.next_config_fetch_time:
                now = datetime.now()
                if self.next_config_fetch_time > now:
                    minutes_left = (self.next_config_fetch_time - now).total_seconds() / 60
                    status.append(f"⏰ 下次读取配置: {self.next_config_fetch_time.strftime('%Y-%m-%d %H:%M:%S')} (还有{minutes_left:.1f}分钟)")
                else:
                    status.append(f"⏰ 下次读取配置: 即将执行")
            
            if self.cached_config:
                schedules = self.cached_config.get("SCHEDULES", [])
                enabled_schedules = [s for s in schedules if s.get("enabled", True)]
                status.append(f"📋 配置规则: {len(enabled_schedules)}/{len(schedules)} 条启用")
                
                # 显示最近的下一次切换时间
                next_times = []
                for schedule in enabled_schedules:
                    next_time = self._calculate_next_switch_time(schedule)
                    if next_time:
                        next_times.append((schedule.get("id"), next_time))
                
                if next_times:
                    next_times.sort(key=lambda x: x[1])
                    next_id, next_time = next_times[0]
                    minutes_left = (next_time - datetime.now()).total_seconds() / 60
                    status.append(f"⏳ 下一次切换: {next_id} 于 {next_time.strftime('%Y-%m-%d %H:%M')} (还有{minutes_left:.1f}分钟)")
            
            # 新增：切换历史
            status.append(f"📊 检查次数: {self.check_count}")
            if self.switch_history:
                recent = self.switch_history[-5:]  # 最近5条
                status.append("📜 最近切换记录:")
                for r in reversed(recent):
                    status.append(f"  {r['result']} {r['time']} | {r['currency_pair']} | {r['old_rule']}→{r['new_rule']} | {r['description']}")
            
            return "\n".join(status)
    
    def start(self):
        """启动定时任务（在后台线程中）"""
        if self.is_running:
            return "⚠️ 路由定时切换任务已在运行中"
        
        self.is_running = True
        self.stop_event.clear()
        
        self.task_thread = threading.Thread(
            target=self._task_loop,
            name="RoutingScheduler",
            daemon=True
        )
        self.task_thread.start()
        
        return "✅ 已启动路由定时切换任务\n⏰ 检查间隔: 每30分钟检查一次"
    
    def stop(self):
        """停止定时任务"""
        if not self.is_running:
            return "ℹ️ 路由定时切换任务未在运行"
        
        self.is_running = False
        self.stop_event.set()
        
        if self.task_thread and self.task_thread.is_alive():
            self.task_thread.join(timeout=5.0)
        
        return "🛑 路由定时切换任务已停止"
    
    def status(self):
        """获取任务状态"""
        if self.is_running and self.task_thread and self.task_thread.is_alive():
            return self.get_status_detail()
        else:
            return "🔴 任务状态: 已停止"

    def force_reload_config(self):
        """强制重新加载配置"""
        logger.info("🔄 强制重新加载路由配置...")
        config = self._fetch_routing_schedule()
        return f"✅ 配置已强制重载，共 {len(config.get('SCHEDULES', []))} 条规则"

# ===================== 余额查询配置类 =====================
