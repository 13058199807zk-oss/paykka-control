# ===================== paykka_competitor.py =====================
# CompetitorRateQuery + CompetitorHistoryQuery - 友商汇率查询
# 从 paykka_controllerV16.py 提取

import json
import time
import urllib.parse
import requests
import re
import threading
import os
import hashlib
import asyncio
import subprocess
import base64
from typing import List, Dict, Tuple, Any, Optional, Union
from datetime import datetime, date, timedelta, timezone, time as dtime
from playwright.async_api import async_playwright
import pandas as pd
from github import Github, InputGitAuthor
import pytz

from paykka_config import *
from paykka_xt_rate import XTRateQueryManager
import random
import string
import traceback

class CompetitorRateQuery:
    """友商汇率查询类 - 集成 XT、WF、LL、AW、KS、SK 六个友商"""
    
    def __init__(self):
        self.xt = None  # 延迟初始化，避免事件循环问题
        
    def _get_xt(self):
        if self.xt is None:
            self.xt = XTRateQueryManager()
        return self.xt
    
    # ===================== WF (WorldFirst) =====================
    def _query_wf(self, pairs: List[Tuple]) -> List[Dict]:
        """查询 WorldFirst 汇率（通过 API，需先登录获取 Token/Cookie）"""
        results = []
        try:
            # 尝试加载缓存
            cache = {}
            if os.path.exists(WF_AUTH_CACHE_FILE):
                with open(WF_AUTH_CACHE_FILE, 'r') as f:
                    cache = json.load(f)
            
            token = cache.get("token", "")
            cookies = cache.get("cookies", {})
            device_id = cache.get("device_id", "")
            
            if not token and not cookies.get("ALIPAYWFSESSIONID"):
                logger.warning("WF 未登录，尝试自动登录...")
                login_ok = self._wf_login()
                if not login_ok:
                    return [{"pair": f"{f}/{t}", "rate": None, "status": "登录失败", "source": "WF"} for f, t, _ in pairs]
                # 重新加载
                if os.path.exists(WF_AUTH_CACHE_FILE):
                    with open(WF_AUTH_CACHE_FILE, 'r') as f:
                        cache = json.load(f)
                    token = cache.get("token", "")
                    cookies = cache.get("cookies", {})
                    device_id = cache.get("device_id", "")
            
            if not device_id:
                chars = string.ascii_letters + string.digits + "_-="
                random_str = ''.join(random.choices(chars, k=50))
                device_id = f"T2gA{random_str}"
            
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Origin": WF_PORTAL_URL,
                "Referer": f"{WF_PORTAL_URL}/",
                "Appid": "WORLDFIRST_WEB",
                "Operation-Type": "com.worldfirst.portal.pc.dashboard.fxinfo",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Workspaceid": "default",
                "X-Cors-Worldfirst_web-Default": "1",
            }
            if token:
                headers["Token"] = token
            if cookies:
                headers["Cookie"] = "; ".join([f"{k}={v}" for k, v in cookies.items()])
            
            payload = [{
                "envInfo": {
                    "terminalType": "PC", "serviceLocation": "sea",
                    "authCode": "authCode", "deviceId": device_id,
                    "lang": "zh_CN", "operateEntrance": "portal",
                    "sourceSite": "WEB", "timeZone": "Asia/Shanghai"
                },
                "extParams": {}
            }]
            
            resp = requests.post(WF_API_URL, json=payload, headers=headers, timeout=30)
            if resp.status_code == 200:
                data = resp.json()
                if isinstance(data, list) and data:
                    data = data[0]
                if data.get("success"):
                    rates = data.get("data", {}).get("rates", [])
                    for f, t, desc in pairs:
                        pair_str = f"{f}/{t}"
                        match = [r for r in rates if r.get("currencyPair") == pair_str]
                        if match:
                            wr = match[0].get("withdrawalRate", {})
                            rate_val = wr.get("rateValue") or wr.get("accuratePrice")
                            results.append({"pair": pair_str, "rate": float(rate_val) if rate_val else None, "status": "成功", "source": "WF"})
                        else:
                            results.append({"pair": pair_str, "rate": None, "status": "未找到", "source": "WF"})
                else:
                    for f, t, desc in pairs:
                        results.append({"pair": f"{f}/{t}", "rate": None, "status": "API失败", "source": "WF"})
            else:
                for f, t, desc in pairs:
                    results.append({"pair": f"{f}/{t}", "rate": None, "status": f"HTTP {resp.status_code}", "source": "WF"})
        except Exception as e:
            logger.error(f"WF 查询异常: {e}")
            for f, t, desc in pairs:
                results.append({"pair": f"{f}/{t}", "rate": None, "status": str(e)[:30], "source": "WF"})
        return results
    
    def _wf_login(self) -> bool:
        """Playwright 自动登录 WorldFirst"""
        try:
            from playwright.sync_api import sync_playwright
            logger.info("🔐 WF 自动登录中...")
            
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-blink-features=AutomationControlled"])
                context = browser.new_context(viewport={"width": 1920, "height": 1080})
                page = context.new_page()
                
                page.goto(WF_LOGIN_URL, timeout=30000)
                page.wait_for_selector('input[placeholder*="手机号"]', timeout=15000)
                
                phone_input = page.locator('input[placeholder*="手机号"], input[placeholder*="邮箱"]').first
                phone_input.fill(WF_USERNAME)
                
                password_input = page.locator('input[type="password"]').first
                password_input.fill(WF_PASSWORD)
                
                login_btn = page.locator('button:has-text("立即登录"), button:has-text("登录"), button[type="submit"]').first
                login_btn.click()
                
                try:
                    page.wait_for_url("**/portal/**", timeout=15000)
                except:
                    pass
                
                _time.sleep(3)
                
                cookies_list = context.cookies()
                cookies = {c['name']: c['value'] for c in cookies_list}
                
                token = page.evaluate("""() => {
                    const keys = ['token', 'Token', 'access_token', 'accessToken'];
                    for (const k of keys) {
                        const v = localStorage.getItem(k) || sessionStorage.getItem(k);
                        if (v) return v;
                    }
                    return null;
                }""")
                
                device_id = page.evaluate("""() => {
                    const keys = ['deviceId', 'device_id', 'deviceTokenId'];
                    for (const k of keys) {
                        const v = localStorage.getItem(k);
                        if (v) return v;
                    }
                    return null;
                }""")
                
                browser.close()
                
                cache = {
                    "token": token or "",
                    "cookies": cookies,
                    "device_id": device_id or "",
                    "auth_time": datetime.now().isoformat(),
                }
                with open(WF_AUTH_CACHE_FILE, 'w') as f:
                    json.dump(cache, f, ensure_ascii=False, indent=2)
                
                logger.info(f"✅ WF 登录成功 (Cookie: {len(cookies)} 个)")
                return bool(cookies.get("ALIPAYWFSESSIONID") or token)
        except Exception as e:
            logger.error(f"WF 登录失败: {e}")
            return False
    
    # ===================== LL (LianLian) =====================
    def _query_ll(self, pairs: List[Tuple]) -> List[Dict]:
        """查询 LianLian 汇率"""
        results = []
        if not LL_LOGIN_TOKEN:
            for f, t, desc in pairs:
                results.append({"pair": f"{f}/{t}", "rate": None, "status": "未配置TOKEN", "source": "LL"})
            return results
        
        headers = {
            "Content-Type": "application/json",
            "Cookie": f"LOGIN_TOKEN={LL_LOGIN_TOKEN}",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        
        for f, t, desc in pairs:
            try:
                ll_from = f
                ll_to = "CNY" if t == "CNH" else t
                resp = requests.post(LL_API_URL, json={"sourceCurrency": ll_from, "targetCurrency": ll_to}, headers=headers, timeout=15)
                if resp.status_code == 200:
                    data = resp.json()
                    if data.get("code") == "000000" and "data" in data:
                        rate = float(data["data"]["rebateRate"])
                        results.append({"pair": f"{f}/{t}", "rate": rate, "status": "成功", "source": "LL"})
                    else:
                        results.append({"pair": f"{f}/{t}", "rate": None, "status": data.get("message", "失败")[:20], "source": "LL"})
                else:
                    results.append({"pair": f"{f}/{t}", "rate": None, "status": f"HTTP {resp.status_code}", "source": "LL"})
            except Exception as e:
                results.append({"pair": f"{f}/{t}", "rate": None, "status": str(e)[:30], "source": "LL"})
            time.sleep(0.3)
        return results
    
    # ===================== AW (Airwallex) =====================
    def _query_aw(self, pairs: List[Tuple]) -> List[Dict]:
        """查询 Airwallex 汇率"""
        results = []
        headers = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Cookie': AW_COOKIE,
            'Referer': 'https://www.airwallex.com/',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        }
        
        for f, t, desc in pairs:
            try:
                params = {'sellAmount': '1', 'sellCcy': f, 'buyCcy': t, 'feePercent': '0'}
                resp = requests.get(AW_API_URL, params=params, headers=headers, timeout=15)
                if resp.status_code == 200:
                    data = resp.json()
                    client_rate = data.get('clientRate', 0)
                    if client_rate and float(client_rate) > 0:
                        rate = 1.0 / float(client_rate)
                        results.append({"pair": f"{f}/{t}", "rate": rate, "status": "成功", "source": "AW"})
                    else:
                        results.append({"pair": f"{f}/{t}", "rate": None, "status": "无效汇率", "source": "AW"})
                else:
                    results.append({"pair": f"{f}/{t}", "rate": None, "status": f"HTTP {resp.status_code}", "source": "AW"})
            except Exception as e:
                results.append({"pair": f"{f}/{t}", "rate": None, "status": str(e)[:30], "source": "AW"})
            time.sleep(0.2)
        return results
    
    # ===================== KS (Ksher) =====================
    def _query_ks(self, pairs: List[Tuple]) -> List[Dict]:
        """查询 Ksher 汇率"""
        results = []
        headers = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Authorization': 'true',
            'Content-Type': 'application/json',
            'Cookie': KS_COOKIE,
            'Host': 'www.ksher.cn',
            'M_id': KS_M_ID,
            'Merchantid': KS_MERCHANT_ID,
            'Origin': 'https://www.ksher.cn',
            'Referer': 'https://www.ksher.cn/b2c/dashboard',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        }
        
        try:
            resp = requests.post(KS_API_URL, headers=headers, json={"business_scope": "B2C"}, timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("code") == 0 and "data" in data:
                    all_rates = data["data"].get("ccy_pairs", [])
                    rate_map = {}
                    for r in all_rates:
                        key = f"{r['source_currency']}/{r['target_currency']}"
                        rate_map[key] = float(r['exchange_rate'])
                    
                    for f, t, desc in pairs:
                        key = f"{f}/{t}"
                        if key in rate_map:
                            results.append({"pair": key, "rate": rate_map[key], "status": "成功", "source": "KS"})
                        else:
                            results.append({"pair": key, "rate": None, "status": "未找到", "source": "KS"})
                else:
                    for f, t, desc in pairs:
                        results.append({"pair": f"{f}/{t}", "rate": None, "status": "API失败", "source": "KS"})
            else:
                for f, t, desc in pairs:
                    results.append({"pair": f"{f}/{t}", "rate": None, "status": f"HTTP {resp.status_code}", "source": "KS"})
        except Exception as e:
            logger.error(f"KS 查询异常: {e}")
            for f, t, desc in pairs:
                results.append({"pair": f"{f}/{t}", "rate": None, "status": str(e)[:30], "source": "KS"})
        return results
    
    # ===================== SK (Skyee) =====================
    def _query_sk(self, pairs: List[Tuple]) -> List[Dict]:
        """查询 Skyee 汇率"""
        results = []
        headers = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Authorization': SK_AUTH_TOKEN,
            'X-Language': 'zh',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        }
        
        try:
            resp = requests.get(SK_API_URL, headers=headers, timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("meta", {}).get("ack") == "true":
                    all_rates = data.get("body", {}).get("content", [])
                    rate_map = {}
                    for r in all_rates:
                        pair = r.get("currencyPair", "")
                        selling = r.get("sellingRate")
                        if pair and selling:
                            rate_map[pair] = float(selling)
                    
                    for f, t, desc in pairs:
                        key = f"{f}/{t}"
                        if key in rate_map:
                            results.append({"pair": key, "rate": rate_map[key], "status": "成功", "source": "SK"})
                        else:
                            results.append({"pair": key, "rate": None, "status": "未找到", "source": "SK"})
                else:
                    for f, t, desc in pairs:
                        results.append({"pair": f"{f}/{t}", "rate": None, "status": "API失败", "source": "SK"})
            else:
                for f, t, desc in pairs:
                    results.append({"pair": f"{f}/{t}", "rate": None, "status": f"HTTP {resp.status_code}", "source": "SK"})
        except Exception as e:
            logger.error(f"SK 查询异常: {e}")
            for f, t, desc in pairs:
                results.append({"pair": f"{f}/{t}", "rate": None, "status": str(e)[:30], "source": "SK"})
        return results
    
    # ===================== 统一查询接口 =====================
    def query_all_competitors(self, pairs: List[Tuple] = None, sources: List[str] = None) -> Dict[str, List[Dict]]:
        """查询所有友商汇率
        
        Args:
            pairs: 货币对列表，默认 COMPETITOR_CURRENCY_PAIRS
            sources: 友商列表，如 ["XT", "WF", "LL", "AW", "KS", "SK"]，默认全部
        
        Returns:
            {"XT": [...], "WF": [...], ...}
        """
        if pairs is None:
            pairs = COMPETITOR_CURRENCY_PAIRS
        
        if sources is None:
            sources = ["XT", "WF", "LL", "AW", "KS", "SK"]
        
        all_results = {}
        
        for src in sources:
            logger.info(f"查询 {COMPETITOR_CODES.get(src, src)} 汇率...")
            if src == "XT":
                # XT 需要登录检查（线程隔离）
                xt_result = {"ok": False}
                def _xt_login():
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        xt = self._get_xt()
                        xt_result["ok"] = loop.run_until_complete(xt.login())
                    except:
                        pass
                    finally:
                        loop.close()
                
                t = threading.Thread(target=_xt_login)
                t.start()
                t.join(timeout=30)
                
                if xt_result["ok"]:
                    # XT 使用 CNY，需要转换
                    xt_pairs = [(f, "CNY" if t == "CNH" else t, d) for f, t, d in pairs]
                    xt = self._get_xt()
                    xt_raw = xt.query_all_rates(xt_pairs)
                    # 转换结果格式
                    xt_formatted = []
                    for r in xt_raw:
                        xt_formatted.append({
                            "pair": r['pair'],
                            "rate": r['rate'],
                            "status": r['status'],
                            "source": "XT"
                        })
                    all_results["XT"] = xt_formatted
                else:
                    all_results["XT"] = [{"pair": f"{f}/{t}", "rate": None, "status": "登录失败", "source": "XT"} for f, t, _ in pairs]
            
            elif src == "WF":
                all_results["WF"] = self._query_wf(pairs)
            elif src == "LL":
                all_results["LL"] = self._query_ll(pairs)
            elif src == "AW":
                all_results["AW"] = self._query_aw(pairs)
            elif src == "KS":
                all_results["KS"] = self._query_ks(pairs)
            elif src == "SK":
                all_results["SK"] = self._query_sk(pairs)
        
        return all_results
    
    def format_competitor_results(self, all_results: Dict[str, List[Dict]]) -> str:
        """格式化友商汇率查询结果为对比表格"""
        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        response = f"📊 友商汇率查询结果\n"
        response += f"⏰ 查询时间: {now_str}\n"
        response += f"{'─' * 70}\n"
        
        if not all_results:
            return response + "❌ 无查询结果\n"
        
        # 收集所有货币对
        all_pairs = []
        for src, results in all_results.items():
            for r in results:
                if r['pair'] not in all_pairs:
                    all_pairs.append(r['pair'])
        
        # 表头
        header = f"{'货币对':<12}"
        for src in ["XT", "WF", "LL", "AW", "KS", "SK"]:
            if src in all_results:
                header += f" {src:<14}"
        response += header + "\n"
        response += "─" * 70 + "\n"
        
        # 每行
        for pair in all_pairs:
            row = f"{pair:<12}"
            for src in ["XT", "WF", "LL", "AW", "KS", "SK"]:
                if src in all_results:
                    match = [r for r in all_results[src] if r['pair'] == pair]
                    if match and match[0]['rate'] is not None:
                        rate = match[0]['rate']
                        if rate < 0.01:
                            row += f" {rate:<14.8f}"
                        elif rate < 1:
                            row += f" {rate:<14.6f}"
                        else:
                            row += f" {rate:<14.6f}"
                    else:
                        row += f" {'--':<14}"
            response += row + "\n"
        
        response += "─" * 70 + "\n"
        
        # 统计
        total_ok = 0
        total_fail = 0
        for src, results in all_results.items():
            ok = len([r for r in results if r['rate'] is not None])
            fail = len(results) - ok
            total_ok += ok
            total_fail += fail
            name = COMPETITOR_CODES.get(src, src)
            response += f"  {src} ({name}): ✅{ok} ❌{fail}\n"
        
        response += f"  合计: ✅{total_ok} ❌{total_fail}\n"
        return response

# ===================== 友商历史汇率数据查询类 =====================
class CompetitorHistoryQuery:
    """友商历史汇率数据查询 - 支持 XT、WF、LL 的历史汇率查询和图表生成"""
    
    # 时间范围解析映射
    TIME_RANGE_MAP = {
        "7D": 7, "7d": 7,
        "14D": 14, "14d": 14,
        "30D": 30, "30d": 30,
        "1M": 30, "1m": 30,
        "3M": 90, "3m": 90,
        "6M": 180, "6m": 180,
        "1Y": 365, "1y": 365,
    }
    
    # 图表输出目录
    CHART_DIR = "/workspace/logs/charts"
    
    def __init__(self):
        self.xt = None
        self.wf = None
        os.makedirs(self.CHART_DIR, exist_ok=True)
    
    def _get_xt(self):
        if self.xt is None:
            self.xt = XTRateQueryManager()
        return self.xt
    
    def _get_wf_auth(self) -> Dict:
        """获取 WF 认证信息"""
        cache = {}
        if os.path.exists(WF_AUTH_CACHE_FILE):
            try:
                with open(WF_AUTH_CACHE_FILE, 'r') as f:
                    cache = json.load(f)
            except:
                pass
        return cache
    
    def _parse_time_range(self, range_str: str) -> int:
        """解析时间范围字符串为天数，如 7D→7, 30D→30"""
        if range_str in self.TIME_RANGE_MAP:
            return self.TIME_RANGE_MAP[range_str]
        # 尝试直接解析数字
        try:
            num = int(re.sub(r'[^0-9]', '', range_str))
            if num > 0:
                return num
        except:
            pass
        return 7  # 默认 7 天
    
    def _parse_currency_pair(self, pair_str: str) -> Tuple[str, str]:
        """解析货币对字符串，如 NGNUSD → (NGN, USD)，支持 6 位或通过分隔符"""
        pair_str = pair_str.upper().strip()
        if len(pair_str) == 6:
            return pair_str[:3], pair_str[3:]
        # 尝试通过 / 或空格分隔
        for sep in ['/', '-', ' ']:
            if sep in pair_str:
                parts = pair_str.split(sep)
                if len(parts) == 2 and len(parts[0]) == 3 and len(parts[1]) == 3:
                    return parts[0].strip(), parts[1].strip()
        return None, None
    
    # ===================== XT 历史汇率查询 =====================
    def query_xt_history(self, from_ccy: str, to_ccy: str, days: int = 7) -> Dict:
        """查询 XT 历史汇率数据
        
        XT API: spotfx/graph/present-rate/v2/getWithSource
        参数: fromCcy, toCcy, type=WEEK/MONTH, siteCode=CN
        响应: sourceRatePointList.SPOT[{rateTime, rate, taxRate, fromCcy, toCcy, source}]
        """
        result = {"source": "XT", "pair": f"{from_ccy}/{to_ccy}", "data": [], "success": False, "error": ""}
        
        try:
            xt = self._get_xt()
            if not xt._is_auth_valid():
                # 线程隔离登录
                login_ok = {"ok": False}
                def _login():
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        login_ok["ok"] = loop.run_until_complete(xt.login())
                    except:
                        pass
                    finally:
                        loop.close()
                t = threading.Thread(target=_login)
                t.start()
                t.join(timeout=30)
                if not login_ok["ok"]:
                    result["error"] = "XT 登录失败"
                    return result
            
            xt._setup_session()
            headers = xt._build_headers()
            
            # 根据天数选择 type 参数
            rate_type = "WEEK" if days <= 7 else "MONTH"
            
            params = {
                "fromCcy": from_ccy.upper(),
                "toCcy": to_ccy.upper(),
                "type": rate_type,
                "siteCode": "CN"
            }
            
            # XT 历史数据 API
            xt_history_url = "https://api.xtransfer.cn/api/v1/spotfx/graph/present-rate/v2/getWithSource"
            
            resp = xt.session.get(xt_history_url, headers=headers, params=params, timeout=30)
            if resp.status_code != 200:
                result["error"] = f"XT API HTTP {resp.status_code}"
                return result
            
            data = resp.json()
            
            # 解析 sourceRatePointList.SPOT
            spot_list = data.get("sourceRatePointList", {}).get("SPOT", [])
            if not spot_list:
                result["error"] = "XT 无历史数据 (SPOT 为空)"
                return result
            
            # 根据 days 过滤数据
            cutoff_ms = int((datetime.now() - timedelta(days=days)).timestamp() * 1000)
            
            for item in spot_list:
                rate_time_ms = item.get("rateTime")
                if rate_time_ms and rate_time_ms >= cutoff_ms:
                    result["data"].append({
                        "time": datetime.fromtimestamp(rate_time_ms / 1000).strftime("%Y-%m-%d %H:%M"),
                        "timestamp_ms": rate_time_ms,
                        "rate": float(item.get("rate", 0)),
                        "source_name": item.get("source", "XT"),
                    })
            
            if result["data"]:
                result["success"] = True
                result["data"].sort(key=lambda x: x["timestamp_ms"])
            else:
                result["error"] = f"XT {days}天内无数据"
            
        except Exception as e:
            logger.error(f"XT 历史查询异常: {e}")
            result["error"] = str(e)[:80]
        
        return result
    
    # ===================== WF 历史汇率查询 =====================
    def query_wf_history(self, from_ccy: str, to_ccy: str, days: int = 7) -> Dict:
        """查询 WorldFirst 历史汇率数据
        
        WF API: imgs.worldfirst.com/mgw.htm
        Operation-Type: com.worldfirst.portal.pc.dashboard.historicalRates
        参数: extParams.ccyPair, startTime(ms), endTime(ms), frequency, channelList=["WF"]
        响应: data.chart.timeline[{time.dateString, WF.price, WF.reversePrice}]
        """
        result = {"source": "WF", "pair": f"{from_ccy}/{to_ccy}", "data": [], "success": False, "error": ""}
        
        try:
            cache = self._get_wf_auth()
            token = cache.get("token", "")
            cookies = cache.get("cookies", {})
            device_id = cache.get("device_id", "")
            
            if not device_id:
                chars = _str.ascii_letters + _str.digits + "_-="
                device_id = f"T2gA{''.join(_rnd.choices(chars, k=50))}"
            
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Origin": WF_PORTAL_URL,
                "Referer": f"{WF_PORTAL_URL}/",
                "Appid": "WORLDFIRST_WEB",
                "Operation-Type": "com.worldfirst.portal.pc.dashboard.historicalRates",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Workspaceid": "default",
                "X-Cors-Worldfirst_web-Default": "1",
            }
            if token:
                headers["Token"] = token
            if cookies:
                headers["Cookie"] = "; ".join([f"{k}={v}" for k, v in cookies.items()])
            
            end_ms = int(time.time() * 1000)
            start_ms = end_ms - days * 24 * 60 * 60 * 1000
            
            # WF 的 currency_pair 格式：USD（表示 USD/NGN 方向取决于 reverse_price）
            # 直接用第一个货币作为 ccyPair
            wf_pair = from_ccy.upper()
            frequency = "DAY" if days > 7 else "HOUR"
            
            payload = [{
                "envInfo": {
                    "terminalType": "PC", "serviceLocation": "sea",
                    "authCode": "authCode", "deviceId": device_id,
                    "lang": "zh_CN", "operateEntrance": "portal",
                    "sourceSite": "WEB", "timeZone": "Asia/Shanghai"
                },
                "extParams": {
                    "ccyPair": wf_pair,
                    "startTime": start_ms,
                    "endTime": end_ms,
                    "frequency": frequency,
                    "channelList": ["WF"]
                }
            }]
            
            resp = requests.post(WF_API_URL, json=payload, headers=headers, timeout=30)
            if resp.status_code != 200:
                result["error"] = f"WF API HTTP {resp.status_code}"
                return result
            
            data = resp.json()
            if isinstance(data, list) and data:
                data = data[0]
            
            if not data.get("success"):
                result["error"] = f"WF API 失败: {str(data)[:100]}"
                return result
            
            chart = data.get("data", {}).get("chart", {})
            timeline = chart.get("timeline", [])
            
            for item in timeline:
                time_info = item.get("time", {})
                wf_data = item.get("WF", {})
                
                date_str = time_info.get("dateString", "")
                price = wf_data.get("price", "")
                reverse_price = wf_data.get("reversePrice", "")
                
                if price:
                    try:
                        rate_val = float(price)
                    except:
                        rate_val = None
                elif reverse_price:
                    try:
                        rate_val = 1.0 / float(reverse_price) if float(reverse_price) != 0 else None
                    except:
                        rate_val = None
                else:
                    continue
                
                if rate_val is not None:
                    result["data"].append({
                        "time": date_str,
                        "rate": rate_val,
                        "source_name": "WF",
                    })
            
            if result["data"]:
                result["success"] = True
            else:
                result["error"] = "WF 无历史数据"
            
        except Exception as e:
            logger.error(f"WF 历史查询异常: {e}")
            result["error"] = str(e)[:80]
        
        return result
    
    # ===================== LL 历史汇率查询 =====================
    def query_ll_history(self, from_ccy: str, to_ccy: str, days: int = 7) -> Dict:
        """查询 LianLian 历史汇率数据
        
        LL API: lianlianglobal.cn/b2b/rate/payout/queryHistorySingleCurrency
        参数: currencyPair(如NGNUSD), rateType(THREEHOUR), processTimeStartTime, processTimeEndTime
        响应: data[{processTime, currencyPair, quoteRate, coreRate}]
        """
        result = {"source": "LL", "pair": f"{from_ccy}/{to_ccy}", "data": [], "success": False, "error": ""}
        
        if not LL_LOGIN_TOKEN:
            result["error"] = "LL 未配置 LOGIN_TOKEN"
            return result
        
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)
            
            headers = {
                "Content-Type": "application/json",
                "Cookie": f"LOGIN_TOKEN={LL_LOGIN_TOKEN}",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Origin": "https://www.lianlianglobal.cn",
                "Referer": "https://www.lianlianglobal.cn/dashboard/home",
                "App-Name": "lli-b2b-user-web-v3",
                "Bizsource": "cn_b2b",
                "Biz-Lang": "zh-CN",
            }
            
            payload = {
                "currencyPair": f"{from_ccy.upper()}{to_ccy.upper()}",
                "rateType": "THREEHOUR",
                "processTimeStartTime": start_date.strftime("%Y-%m-%d 00:00:00"),
                "processTimeEndTime": end_date.strftime("%Y-%m-%d 23:59:59"),
            }
            
            ll_history_url = "https://www.lianlianglobal.cn/b2b/rate/payout/queryHistorySingleCurrency"
            
            resp = requests.post(ll_history_url, json=payload, headers=headers, timeout=30)
            if resp.status_code != 200:
                result["error"] = f"LL API HTTP {resp.status_code}"
                return result
            
            data = resp.json()
            if data.get("code") != "000000":
                result["error"] = f"LL API: {data.get('message', '失败')}"
                return result
            
            rate_list = data.get("data", [])
            for item in rate_list:
                quote_rate = item.get("quoteRate", "")
                process_time = item.get("processTime", "")
                if quote_rate:
                    try:
                        rate_val = float(quote_rate)
                    except:
                        continue
                    result["data"].append({
                        "time": process_time,
                        "rate": rate_val,
                        "source_name": "LL",
                    })
            
            if result["data"]:
                result["success"] = True
            else:
                result["error"] = "LL 无历史数据"
            
        except Exception as e:
            logger.error(f"LL 历史查询异常: {e}")
            result["error"] = str(e)[:80]
        
        return result
    
    # ===================== 统一查询接口 =====================
    def query_history(self, source: str, from_ccy: str, to_ccy: str, days: int = 7) -> Dict:
        """统一历史数据查询入口
        
        Args:
            source: 友商标识 (XT/WF/LL)
            from_ccy: 源货币
            to_ccy: 目标货币
            days: 查询天数
        
        Returns:
            {"source": "XT", "pair": "NGN/USD", "data": [...], "success": bool, "error": ""}
        """
        source = source.upper()
        if source == "XT":
            return self.query_xt_history(from_ccy, to_ccy, days)
        elif source == "WF":
            return self.query_wf_history(from_ccy, to_ccy, days)
        elif source == "LL":
            return self.query_ll_history(from_ccy, to_ccy, days)
        else:
            return {"source": source, "pair": f"{from_ccy}/{to_ccy}", "data": [], "success": False, "error": f"不支持的友商: {source}"}
    
    # ===================== 图表生成 =====================
    def generate_chart(self, result: Dict, save_path: str = None) -> str:
        """生成汇率走势图
        
        Args:
            result: query_history 返回的结果字典
            save_path: 保存路径，默认自动生成
        
        Returns:
            图表文件路径，失败返回空字符串
        """
        if not result.get("success") or not result.get("data"):
            logger.warning(f"无数据可生成图表: {result.get('error', '')}")
            return ""
        
        try:
            import matplotlib
            matplotlib.use('Agg')
            import matplotlib.pyplot as plt
            import matplotlib.dates as mdates
            from matplotlib.ticker import ScalarFormatter
            
            # 设置中文字体 - 使用 Noto Sans CJK JP (覆盖中日韩)
            import matplotlib.font_manager as fm
            cjk_font_path = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
            if os.path.exists(cjk_font_path):
                cjk_prop = fm.FontProperties(fname=cjk_font_path)
                plt.rcParams['font.family'] = cjk_prop.get_name()
            else:
                plt.rcParams['font.sans-serif'] = ['Noto Sans CJK JP', 'Noto Sans CJK SC', 'SimHei', 'DejaVu Sans']
            plt.rcParams['axes.unicode_minus'] = False
            
            data = result["data"]
            source_name = result.get("source", "Unknown")
            pair = result.get("pair", "Unknown")
            
            # 解析时间和汇率
            times = []
            rates = []
            for d in data:
                try:
                    t = datetime.strptime(d["time"], "%Y-%m-%d %H:%M")
                except:
                    try:
                        t = datetime.strptime(d["time"], "%Y-%m-%d %H:%M:%S")
                    except:
                        continue
                times.append(t)
                rates.append(d["rate"])
            
            if not times:
                return ""
            
            # 创建图表
            fig, ax = plt.subplots(figsize=(12, 6))
            
            # 绘制折线图
            ax.plot(times, rates, color='#2196F3', linewidth=1.5, marker='o', markersize=3, label=f'{source_name} {pair}')
            
            # 添加趋势线（简单移动平均）
            if len(rates) >= 5:
                window = max(3, len(rates) // 10)
                trend = pd.Series(rates).rolling(window=window, center=True).mean()
                ax.plot(times, trend, color='#FF5722', linewidth=2, linestyle='--', alpha=0.7, label=f'{window}点移动平均')
            
            # 标注最高/最低点
            max_idx = rates.index(max(rates))
            min_idx = rates.index(min(rates))
            ax.annotate(f'最高: {rates[max_idx]:.4f}', xy=(times[max_idx], rates[max_idx]),
                       xytext=(10, 10), textcoords='offset points', fontsize=8,
                       arrowprops=dict(arrowstyle='->', color='red'), color='red')
            ax.annotate(f'最低: {rates[min_idx]:.4f}', xy=(times[min_idx], rates[min_idx]),
                       xytext=(10, -15), textcoords='offset points', fontsize=8,
                       arrowprops=dict(arrowstyle='->', color='green'), color='green')
            
            # 格式化
            ax.set_title(f'{source_name} 历史汇率走势 - {pair}', fontsize=14, fontweight='bold')
            ax.set_xlabel('时间', fontsize=11)
            ax.set_ylabel('汇率', fontsize=11)
            ax.legend(loc='best', fontsize=9)
            ax.grid(True, alpha=0.3)
            
            # X 轴时间格式
            if len(times) > 10:
                ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
                ax.xaxis.set_major_locator(mdates.AutoDateLocator())
            else:
                ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d %H:%M'))
            plt.xticks(rotation=45, ha='right')
            
            # Y 轴格式
            avg_rate = sum(rates) / len(rates)
            if avg_rate < 0.01:
                ax.yaxis.set_major_formatter(ScalarFormatter())
                ax.ticklabel_format(axis='y', style='plain', useOffset=False)
            
            plt.tight_layout()
            
            # 保存
            if not save_path:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                safe_pair = pair.replace("/", "_")
                save_path = os.path.join(self.CHART_DIR, f"{source_name}_{safe_pair}_{timestamp}.png")
            
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            plt.close(fig)
            
            logger.info(f"📊 图表已保存: {save_path}")
            return save_path
            
        except Exception as e:
            logger.error(f"生成图表失败: {e}")
            logger.error(traceback.format_exc())
            return ""
    
    def format_history_result(self, result: Dict, chart_path: str = None) -> str:
        """格式化历史查询结果为文本消息
        
        Args:
            result: query_history 返回的结果
            chart_path: 图表文件路径（可选）
        
        Returns:
            格式化的文本消息
        """
        if not result.get("success"):
            return f"❌ {result.get('source', '')} 历史汇率查询失败: {result.get('error', '未知错误')}"
        
        data = result["data"]
        source_name = result.get("source", "")
        pair = result.get("pair", "")
        
        if not data:
            return f"⚠️ {source_name} {pair} 无历史数据"
        
        rates = [d["rate"] for d in data]
        times = [d["time"] for d in data]
        
        response = f"📊 {source_name} 历史汇率查询 - {pair}\n"
        response += f"{'─' * 50}\n"
        response += f"⏰ 数据范围: {times[0]} ~ {times[-1]}\n"
        response += f"📈 数据点数: {len(data)}\n"
        response += f"📊 最高: {max(rates):.6f}  最低: {min(rates):.6f}\n"
        response += f"📉 平均: {sum(rates)/len(rates):.6f}\n"
        response += f"📐 波动率: {(max(rates)-min(rates))/min(rates)*100:.4f}%\n"
        
        # 最近 5 条
        response += f"\n📋 最近数据:\n"
        for d in data[-5:]:
            response += f"  {d['time']}  |  {d['rate']:.6f}\n"
        
        if chart_path:
            response += f"\n📊 走势图已生成"
        
        return response

# ===================== 指令处理器 =====================
