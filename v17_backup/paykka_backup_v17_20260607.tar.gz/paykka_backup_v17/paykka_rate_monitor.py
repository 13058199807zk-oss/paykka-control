# ===================== paykka_rate_monitor.py =====================
# PaykkaRateMonitor - PAYKKA-XT汇率价差监控
# 从 paykka_controllerV16.py 提取

import json
import time
import urllib.parse
import requests
import re
import threading
import os
import hashlib
import asyncio
import subprocess
import base64
from typing import List, Dict, Tuple, Any, Optional, Union
from datetime import datetime, date, timedelta, timezone, time as dtime
from playwright.async_api import async_playwright
import pandas as pd
from github import Github, InputGitAuthor
import pytz

from paykka_config import *
from paykka_core import PaykkaSystemManager, build_auth_headers, send_wechat_work_message, upload_to_github_md

class PaykkaRateMonitor:
    """PAYKKA-XT汇率价差监控模块 - 增强版"""
    
    def __init__(self, token: str, alert_threshold: float = RATE_ALERT_THRESHOLD):
        self.token = token
        self.alert_threshold = alert_threshold
        self.last_check_time = None
        self.rate_history = []
        self.alert_history = {}
        self.alert_count = {}
        self.manager = PaykkaSystemManager()  # 新增
        
        # 确保XT结果目录存在
        os.makedirs(XT_RESULTS_DIR, exist_ok=True)
    
    def _safe_paykka_rate_query(self, from_currency: str, to_currency: str) -> Optional[float]:
        """安全的PAYKKA汇率查询"""
        def query_func():
            payload = {
                "pair_list": [{
                    "sell_currency": from_currency,
                    "buy_currency": to_currency
                }]
            }
            
            response = requests.post(
                url=PAYKKA_RATE_URL,
                headers=self._build_headers(),
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                if result.get("ret_code") == "000000":
                    quota_list = result.get("data", {}).get("quota_list", [])
                    if quota_list and len(quota_list) > 0:
                        rate = quota_list[0].get("exchange_rate")
                        if rate:
                            return float(rate)
            
            raise Exception(f"汇率查询失败: {response.status_code}")
        
        success, result = self.manager.safe_api_call(
            query_func,
            max_retries=1,  # 汇率查询快速失败，不重试太多次
            retry_delay=0.5
        )
        
        return result if success else None
    
    def _build_headers(self) -> Dict[str, str]:
        """构建HTTP请求头（用于PAYKKA汇率查询）"""
        headers = build_auth_headers(self.token)
        return headers
    
    def query_paykka_rate(self, from_currency: str, to_currency: str) -> Optional[float]:
        """查询PAYKKA单一货币对汇率"""
        try:
            payload = {
                "pair_list": [{
                    "sell_currency": from_currency,
                    "buy_currency": to_currency
                }]
            }
            
            response = requests.post(
                url=PAYKKA_RATE_URL,
                headers=self._build_headers(),
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                if result.get("ret_code") == "000000":
                    quota_list = result.get("data", {}).get("quota_list", [])
                    if quota_list and len(quota_list) > 0:
                        rate = quota_list[0].get("exchange_rate")
                        if rate:
                            return float(rate)
            else:
                logger.error(f"PAYKKA汇率查询失败 {from_currency}→{to_currency}: HTTP {response.status_code}")
            
            return None
                
        except Exception as e:
            logger.error(f"PAYKKA汇率查询异常 {from_currency}→{to_currency}: {e}")
            return None
    
    def query_all_paykka_rates(self) -> Dict[str, float]:
        """查询所有PAYKKA汇率"""
        rates = {}
        
        for from_curr, to_curr, description in CURRENCY_PAIRS:
            rate = self.query_paykka_rate(from_curr, to_curr)
            if rate is not None:
                pair_key = f"{from_curr}→{to_curr}"
                rates[pair_key] = rate
                logger.info(f"PAYKKA汇率 {pair_key}: {rate}")
            else:
                logger.warning(f"PAYKKA汇率 {from_curr}→{to_curr}: 查询失败")
            
            time.sleep(0.2)  # 避免请求过快
        
        return rates
    
    def query_xt_rates(self) -> Dict[str, float]:
        """查询XT汇率（使用集成模块，支持缓存复用）"""
        rates = {}
        
        logger.info("查询 XT 汇率（集成模块）...")
        
        try:
            xt = XTRateQueryManager()
            
            # 检查/执行登录
            loop = asyncio.new_event_loop()
            try:
                login_ok = loop.run_until_complete(xt.login())
            finally:
                loop.close()
            
            if not login_ok:
                logger.error("XT 登录失败，无法查询汇率")
                return rates
            
            # 批量查询
            results = xt.query_all_rates(xt.get_currency_pairs())
            
            # 转换为旧格式: {"USD→CNH": rate, ...}
            for r in results:
                if r.get('rate') is not None and r.get('status') == '成功':
                    pair_key = f"{r['from_ccy']}→{r['to_ccy']}"
                    # CNY → CNH 统一
                    pair_key = pair_key.replace("CNY", "CNH")
                    rates[pair_key] = r['rate']
                    logger.info(f"XT {pair_key}: {r['rate']}")
            
            logger.info(f"✅ XT 汇率查询完成: {len(rates)} 个货币对")
            
        except Exception as e:
            logger.error(f"XT 汇率查询异常: {e}")
        
        return rates
    
    def _parse_xt_results(self) -> Dict[str, float]:
        """解析XT查询结果"""
        rates = {}
        
        # 修复：提前定义 desktop_path，避免在 lambda 中引用未定义变量
        desktop_path = os.path.join(os.path.expanduser("~"), "Desktop", "query_py", "xt_query")
        
        try:
            # 查找最新的XT结果Excel文件
            xt_files = [f for f in os.listdir(XT_RESULTS_DIR) 
                       if f.startswith("XTransfer_汇率查询_") and f.endswith(".xlsx")]
            
            if not xt_files:
                # 尝试在桌面目录查找
                if os.path.exists(desktop_path):
                    xt_files = [f for f in os.listdir(desktop_path) 
                               if f.startswith("XTransfer_汇率查询") and f.endswith(".xlsx")]
            
            if xt_files:
                # 按修改时间排序，获取最新的文件
                xt_files.sort(key=lambda x: os.path.getmtime(
                    os.path.join(XT_RESULTS_DIR, x) if os.path.exists(os.path.join(XT_RESULTS_DIR, x)) 
                    else os.path.join(desktop_path, x)
                ), reverse=True)
                
                latest_file = xt_files[0]
                file_path = os.path.join(XT_RESULTS_DIR, latest_file) if os.path.exists(os.path.join(XT_RESULTS_DIR, latest_file)) else os.path.join(desktop_path, latest_file)
                
                logger.info(f"解析XT结果文件: {file_path}")
                
                # 读取Excel文件（修复：显式指定 engine='openpyxl'，兼容 pandas 3.0+）
                df = pd.read_excel(file_path, engine='openpyxl')
                
                # 解析数据
                for _, row in df.iterrows():
                    pair = row.get("货币对", "")
                    rate = row.get("汇率", "")
                    status = row.get("状态", "")
                    
                    if pair and rate and status == "成功":
                        try:
                            # 统一货币对格式：将CNY转换为CNH
                            pair = pair.replace("CNY", "CNH")
                            rates[pair] = float(rate)
                            logger.info(f"XT {pair}: {rate}")
                        except (ValueError, TypeError):
                            logger.warning(f"跳过无效的汇率数据: {pair}={rate}")
            
        except Exception as e:
            logger.error(f"解析XT结果文件失败: {e}")
        
        return rates
    
    def can_send_alert(self, pair_key: str) -> bool:
        """检查是否可以发送报警"""
        now = datetime.now()
        hour_key = now.strftime("%Y%m%d%H")  # 按小时统计
        
        # 检查每小时报警次数限制
        if hour_key not in self.alert_count:
            self.alert_count[hour_key] = 0
        
        if self.alert_count[hour_key] >= RATE_MAX_ALERTS_PER_HOUR:
            logger.warning(f"已达到每小时报警上限({RATE_MAX_ALERTS_PER_HOUR}次)")
            return False
        
        # 检查同一货币对报警间隔（10分钟内不重复报警）
        if pair_key in self.alert_history:
            last_alert_time = self.alert_history[pair_key]
            time_diff = (now - last_alert_time).total_seconds() / 60  # 分钟
            
            if time_diff < 10:  # 10分钟内不重复报警
                logger.info(f"{pair_key} 在{time_diff:.1f}分钟前已报警，跳过")
                return False
        
        # 更新记录
        self.alert_history[pair_key] = now
        self.alert_count[hour_key] += 1
        
        # 清理过期记录
        self._cleanup_old_records()
        
        return True
    
    def _cleanup_old_records(self):
        """清理过期记录"""
        now = datetime.now()
        cutoff_time = now - timedelta(hours=1)
        
        # 清理报警历史（保留1小时）
        keys_to_delete = []
        for pair_key, alert_time in self.alert_history.items():
            if alert_time < cutoff_time:
                keys_to_delete.append(pair_key)
        
        for key in keys_to_delete:
            del self.alert_history[key]
        
        # 清理报警计数（保留当天）
        hour_keys_to_delete = []
        for hour_key in self.alert_count.keys():
            hour_time = datetime.strptime(hour_key, "%Y%m%d%H")
            if hour_time < cutoff_time:
                hour_keys_to_delete.append(hour_key)
        
        for key in hour_keys_to_delete:
            del self.alert_count[key]
    
    def compare_rates(self, paykka_rates: Dict[str, float], xt_rates: Dict[str, float]) -> List[Dict]:
        """比较两个平台的汇率"""
        discrepancies = []
        
        for pair_key in paykka_rates.keys():
            if pair_key in xt_rates:
                paykka_rate = paykka_rates[pair_key]
                xt_rate = xt_rates[pair_key]
                
                # 计算差距百分比（统一使用平均值为分母，与 generate_report 保持一致）
                if paykka_rate > 0 and xt_rate > 0:
                    diff = abs(paykka_rate - xt_rate)
                    avg_rate = (paykka_rate + xt_rate) / 2
                    diff_percent = (diff / avg_rate) * 100
                    
                    # 记录到历史
                    self.rate_history.append({
                        "timestamp": datetime.now(),
                        "pair": pair_key,
                        "paykka_rate": paykka_rate,
                        "xt_rate": xt_rate,
                        "diff_percent": diff_percent
                    })
                    
                    # 只保留最近100条记录
                    if len(self.rate_history) > 100:
                        self.rate_history = self.rate_history[-100:]
                    
                    # 检查是否超过阈值
                    if diff_percent > self.alert_threshold:
                        discrepancies.append({
                            "pair": pair_key,
                            "paykka_rate": paykka_rate,
                            "xt_rate": xt_rate,
                            "diff": diff,
                            "diff_percent": diff_percent,
                            "direction": "PAYKKA更高" if paykka_rate > xt_rate else "XT更高"
                        })
        
        return discrepancies
    
    def generate_report(self, paykka_rates: Dict, xt_rates: Dict, discrepancies: List[Dict]) -> str:
        """生成对比报告"""
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        report = f"# PAYKKA vs XT 汇率对比报告\n"
        report += f"**时间**: {now}\n"
        report += f"**平台**: PAYKKA vs XT\n"
        report += f"**货币对数量**: {len(CURRENCY_PAIRS)}\n"
        report += f"**报警阈值**: {self.alert_threshold}%\n\n"
        
        # 成功查询的货币对
        common_pairs = set(paykka_rates.keys()) & set(xt_rates.keys())
        report += f"**成功查询**: {len(common_pairs)}个\n"
        report += f"**PAYKKA成功**: {len(paykka_rates)}个\n"
        report += f"**XT成功**: {len(xt_rates)}个\n\n"
        
        # 汇率对比表格
        if common_pairs:
            report += "## 汇率对比\n"
            report += "| 货币对 | PAYKKA | XT | 差价 | 差距% | 状态 |\n"
            report += "|--------|--------|----|------|-------|------|\n"
            
            for pair_key in sorted(common_pairs):
                paykka_rate = paykka_rates[pair_key]
                xt_rate = xt_rates[pair_key]
                diff = abs(paykka_rate - xt_rate)
                diff_percent = (diff / ((paykka_rate + xt_rate) / 2)) * 100
                
                status = "正常"
                if diff_percent > self.alert_threshold:
                    status = "⚠️ 异常"
                
                report += f"| {pair_key} | {paykka_rate:.6f} | {xt_rate:.6f} | {diff:.6f} | {diff_percent:.4f}% | {status} |\n"
        
        # 异常货币对
        if discrepancies:
            report += "\n## 🚨 异常汇率\n"
            for disc in discrepancies:
                report += f"- **{disc['pair']}**: PAYKKA={disc['paykka_rate']:.6f}, XT={disc['xt_rate']:.6f}, 差距={disc['diff_percent']:.4f}% ({disc['direction']})\n"
        
        # 仅一个平台有数据的货币对
        paykka_only = set(paykka_rates.keys()) - set(xt_rates.keys())
        xt_only = set(xt_rates.keys()) - set(paykka_rates.keys())
        
        if paykka_only:
            report += "\n## ⚠️ 仅PAYKKA有数据\n"
            for pair in sorted(paykka_only):
                report += f"- {pair}: {paykka_rates[pair]:.6f}\n"
        
        if xt_only:
            report += "\n## ⚠️ 仅XT有数据\n"
            for pair in sorted(xt_only):
                report += f"- {pair}: {xt_rates[pair]:.6f}\n"
        
        return report
    
    def _send_rate_alert(self, alert_data: dict) -> bool:
        """发送汇率异常报警"""
        alert_msg = f"🚨 汇率异常报警\n"
        alert_msg += f"货币对: {alert_data['pair']}\n"
        alert_msg += f"PAYKKA: {alert_data['paykka_rate']:.6f}\n"
        alert_msg += f"XT: {alert_data['xt_rate']:.6f}\n"
        alert_msg += f"差距: {alert_data['diff_percent']:.4f}%\n"
        alert_msg += f"方向: {alert_data['direction']}\n"
        alert_msg += f"时间: {datetime.now().strftime('%H:%M:%S')}\n"
        alert_msg += f"阈值: {self.alert_threshold}%"
        
        return send_wechat_work_message(alert_msg)
    
    def _upload_report_to_github(self, report: str) -> bool:
        """上传汇率报告到GitHub"""
        try:
            commit_message = f"汇率监控自动更新: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
            return upload_to_github_md(report, GITHUB_RATE_FILE_PATH, commit_message)
        except Exception as e:
            logger.error(f"上传汇率报告到GitHub失败: {e}")
            return False
    
    def check_rates(self) -> Dict:
        """执行汇率检查，返回结果字典"""
        logger.info("=" * 60)
        logger.info(f"开始汇率检查: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("=" * 60)
        
        # 查询PAYKKA汇率
        logger.info("1. 查询PAYKKA汇率...")
        paykka_rates = self.query_all_paykka_rates()
        
        # 查询XT汇率
        logger.info("2. 查询XT汇率（通过运行xt_rateV3.py）...")
        xt_rates = self.query_xt_rates()
        
        # 比较汇率
        discrepancies = self.compare_rates(paykka_rates, xt_rates)
        
        # 生成报告
        report = self.generate_report(paykka_rates, xt_rates, discrepancies)
        
        # 记录日志
        logger.info(f"PAYKKA查询成功: {len(paykka_rates)}个")
        logger.info(f"XT查询成功: {len(xt_rates)}个")
        logger.info(f"发现异常: {len(discrepancies)}个")
        
        # 上传报告到GitHub
        upload_success = self._upload_report_to_github(report)
        if upload_success:
            logger.info("✅ 汇率报告已上传到GitHub")
        else:
            logger.error("❌ 汇率报告上传到GitHub失败")
        
        # 发送报警
        alerts_sent = []
        if discrepancies:
            for disc in discrepancies:
                pair_key = disc['pair']
                
                # 检查是否可以发送报警
                if self.can_send_alert(pair_key):
                    if self._send_rate_alert(disc):
                        alerts_sent.append(pair_key)
                        logger.info(f"已发送报警: {pair_key}")
                    else:
                        logger.error(f"报警发送失败: {pair_key}")
        
        # 整理结果
        result = {
            "paykka_rates": paykka_rates,
            "xt_rates": xt_rates,
            "discrepancies": discrepancies,
            "total_count": len(paykka_rates) + len(xt_rates),
            "discrepancy_count": len(discrepancies),
            "alerts_sent": alerts_sent,
            "check_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "report": report,
            "uploaded_to_github": upload_success
        }
        
        self.last_check_time = datetime.now()
        logger.info(f"汇率检查完成: {datetime.now().strftime('%H:%M:%S')}")
        
        return result

# ===================== 路由价格监控类 =====================
