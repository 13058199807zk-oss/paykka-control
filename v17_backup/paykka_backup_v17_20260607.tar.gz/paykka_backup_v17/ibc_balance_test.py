# ibc_balance_checker.py
import asyncio
import re
import os
from datetime import datetime
from typing import Optional, Tuple
from playwright.async_api import async_playwright, Page, Browser, BrowserContext
import json

class IBCBalanceChecker:
    """IBC银行余额查询器 - 使用Playwright自动化"""
    
    def __init__(self, username: str, password: str, headless: bool = False):
        """
        初始化IBC余额查询器
        
        Args:
            username: IBC用户名
            password: IBC密码
            headless: 是否无头模式运行（False显示浏览器界面，True隐藏）
        """
        self.username = username
        self.password = password
        self.headless = headless
        self.ibc_url = "https://www.inbk.com"
        
        # 初始化Playwright对象
        self.playwright = None
        self.browser = None
        self.context = None
        self.page = None
        
    async def setup_browser(self):
        """设置浏览器"""
        try:
            print("🚀 正在启动浏览器...")
            self.playwright = await async_playwright().start()
            
            # 启动Chromium浏览器
            self.browser = await self.playwright.chromium.launch(
                headless=True,  # 使用传入的参数
                args=[
                    '--disable-blink-features=AutomationControlled',
                    '--disable-dev-shm-usage',
                    '--no-sandbox',
                    '--start-maximized'  # 最大化窗口
                ]
            )
            
            # 创建浏览器上下文
            self.context = await self.browser.new_context(
                viewport={'width': 960, 'height': 540},
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                ignore_https_errors=True
            )
            
            # 创建新页面
            self.page = await self.context.new_page()
            
            print("✅ 浏览器启动成功")
            return True
            
        except Exception as e:
            print(f"❌ 浏览器启动失败: {str(e)}")
            return False
    
    async def wait_and_click(self, selector: str, timeout: int = 10000, description: str = "元素") -> bool:
        """等待元素出现并点击"""
        try:
            print(f"🖱️  正在点击 {description}...")
            await self.page.wait_for_selector(selector, timeout=timeout, state="visible")
            await self.page.click(selector)
            print(f"✅ 已点击 {description}")
            return True
        except Exception as e:
            print(f"❌ 点击 {description} 失败: {str(e)}")
            return False
    
    async def wait_and_type(self, selector: str, text: str, timeout: int = 10000, description: str = "输入框") -> bool:
        """等待元素出现并输入文本"""
        try:
            print(f"⌨️  正在向 {description} 输入文本...")
            await self.page.wait_for_selector(selector, timeout=timeout, state="visible")
            
            # 先清空输入框
            await self.page.fill(selector, "")
            
            # 模拟真人输入（带延迟）
            await self.page.type(selector, text, delay=100)
            print(f"✅ 已向 {description} 输入文本")
            return True
        except Exception as e:
            print(f"❌ 向 {description} 输入文本失败: {str(e)}")
            return False
    
    async def find_element_by_text(self, text: str, timeout: int = 10000) -> Optional[str]:
        """通过文本查找元素"""
        try:
            print(f"🔍 正在查找包含文本 '{text}' 的元素...")
            
            # 尝试多种选择器
            selectors = [
                f"text='{text}'",
                f"text={text}",
                f":has-text('{text}')",
                f"text*='{text}'",
            ]
            
            for selector in selectors:
                try:
                    element = await self.page.wait_for_selector(selector, timeout=5000, state="visible")
                    if element:
                        print(f"✅ 找到元素: {selector}")
                        return selector
                except:
                    continue
            
            # 如果找不到精确匹配，尝试模糊匹配
            page_content = await self.page.content()
            if text.lower() in page_content.lower():
                print(f"⚠️  文本 '{text}' 在页面中但未找到可见元素")
                return f"text='{text}'"
            
            return None
            
        except Exception as e:
            print(f"❌ 查找文本失败: {str(e)}")
            return None
    
    async def login_to_ibc(self) -> bool:
        """登录IBC银行网站"""
        try:
            print("=" * 60)
            print("🔐 开始登录IBC银行")
            print("=" * 60)
        
            # 步骤1: 打开IBC网站 - 使用更宽松的等待条件
            print("\n1️⃣ 打开IBC网站...")
        
            try:
                # 尝试不同的等待策略
                await self.page.goto(
                    self.ibc_url, 
                    wait_until="domcontentloaded",  # 改为domcontentloaded，更快
                    timeout=60000  # 60秒超时
                )
            except Exception as e:
                print(f"⚠️  domcontentloaded超时，尝试load: {str(e)[:100]}")
                try:
                    await self.page.goto(
                        self.ibc_url,
                        wait_until="load",  # 只等待页面加载
                        timeout=60000
                    )
                except Exception as e2:
                    print(f"❌ 加载页面失败: {str(e2)[:100]}")
                    return False
        
            print("✅ 网站打开成功")
        
            # 检查页面是否真的加载了
            page_title = await self.page.title()
            current_url = self.page.url
            print(f"📄 页面标题: {page_title}")
            print(f"🔗 当前URL: {current_url}")
            await asyncio.sleep(2)
            
            # 步骤2: 查找并点击登录按钮
            print("\n2️⃣ 查找登录按钮...")
            
            # 尝试多种登录按钮选择器
            login_selectors = [
                "button:has-text('LOGIN')",
                "button:has-text('Log In')",
                "button:has-text('Sign In')",
            ]
            
            login_found = False
            for selector in login_selectors:
                try:
                    await self.page.wait_for_selector(selector, timeout=3000, state="visible")
                    await self.page.click(selector)
                    login_found = True
                    print(f"✅ 使用选择器点击登录按钮: {selector}")
                    break
                except:
                    continue
            
            if not login_found:
                print("❌ 未找到登录按钮，尝试其他方法...")
                # 尝试通过JavaScript点击
                await self.page.evaluate("""
                    () => {
                        const buttons = Array.from(document.querySelectorAll('button, a'));
                        const loginBtn = buttons.find(btn => 
                            btn.textContent && 
                            (btn.textContent.includes('LOGIN'))
                        );
                        if (loginBtn) loginBtn.click();
                    }
                """)

            await asyncio.sleep(2)
            
            # 步骤3: 输入用户名
            print("\n3️⃣ 输入用户名...")
            
            # 尝试多种用户名输入框选择器
            username_selectors = [
                "input[type='text']",
                "input[placeholder*='username']",
                "input[placeholder*='Username']",
                "input[placeholder*='USERNAME']",
                "input#username",
                "input.user-name",
                "input.login-input",
            ]
            
            username_entered = False
            for selector in username_selectors:
                try:
                    if await self.wait_and_type(selector, self.username, 3000, f"用户名输入框({selector})"):
                        username_entered = True
                        break
                except:
                    continue
            
            if not username_entered:
                # 尝试通过JavaScript查找并填充用户名输入框
                print("尝试通过JavaScript输入用户名...")
                result = await self.page.evaluate("""
                    (username) => {
                        const inputs = document.querySelectorAll('input[type="text"], input:not([type])');
                        for (let input of inputs) {
                            if (input.offsetWidth > 0 && input.offsetHeight > 0) {
                                input.value = username;
                                input.dispatchEvent(new Event('input', { bubbles: true }));
                                return true;
                            }
                        }
                        return false;
                    }
                """, self.username)
                
                if result:
                    print("✅ 通过JavaScript输入用户名成功")
                    username_entered = True
            
            if not username_entered:
                print("❌ 未找到用户名输入框")
                return False

            await asyncio.sleep(1)
            
            # 步骤4: 提交用户名（点击SIGN IN按钮）
            print("\n4️⃣ 提交用户名...")
            
            # 尝试多种提交按钮选择器
            submit_selectors = [
                "button:has-text('SIGN IN')",
                "button:has-text('Sign In')",
                "button:has-text('Next')",
                "button:has-text('Continue')",
                "input[type='submit']",
                "button[type='submit']",
            ]
            
            submit_clicked = False
            for selector in submit_selectors:
                try:
                    await self.page.wait_for_selector(selector, timeout=3000, state="visible")
                    await self.page.click(selector)
                    submit_clicked = True
                    print(f"✅ 点击提交按钮: {selector}")
                    break
                except:
                    continue
            
            if not submit_clicked:
                # 尝试按回车键
                print("尝试按回车键提交...")
                await self.page.keyboard.press("Enter")
                submit_clicked = True

            await asyncio.sleep(3)
            
            # 步骤5: 在NetTeller页面输入密码并提交
            print("\n5️⃣ NetTeller登录页面 - 输入密码...")
            
            # NetTeller登录页：用户名已预填，只需输密码
            # 密码框ID: ctl00_PageContent_Login1_PasswordTextBox
            # 提交按钮ID: ctl00_PageContent_Login1_PasswordSubmitButton
            
            # 先等待NetTeller页面加载完成
            await asyncio.sleep(2)
            current_url = self.page.url
            print(f"   当前页面: {current_url}")
            
            if "netteller.com" in current_url:
                # 在NetTeller登录页，用户名已预填，直接输入密码
                print("   检测到NetTeller登录页，用户名已预填")
                
                # 等待密码框出现
                try:
                    await self.page.wait_for_selector("#ctl00_PageContent_Login1_PasswordTextBox", timeout=10000, state="visible")
                    print("   ✅ 找到NetTeller密码输入框")
                    
                    # 输入密码
                    await self.page.fill("#ctl00_PageContent_Login1_PasswordTextBox", "")
                    await self.page.type("#ctl00_PageContent_Login1_PasswordTextBox", self.password, delay=80)
                    print(f"   ✅ 密码已输入")
                    
                    await asyncio.sleep(0.5)
                    
                    # 点击提交按钮
                    await self.page.click("#ctl00_PageContent_Login1_PasswordSubmitButton")
                    print("   ✅ 已点击提交按钮")
                    
                    # 等待页面跳转
                    await asyncio.sleep(8)
                    await self.page.wait_for_load_state("networkidle", timeout=15000)
                    print(f"   提交后URL: {self.page.url}")
                    
                except Exception as e:
                    print(f"   ❌ NetTeller登录失败: {e}")
                    # 回退到通用方式
                    print("   回退到通用密码输入...")
                    try:
                        await self.page.fill("input[type='password']", self.password)
                        await asyncio.sleep(0.5)
                        await self.page.click("input[type='submit']")
                        await asyncio.sleep(8)
                    except Exception as e2:
                        print(f"   ❌ 回退也失败: {e2}")
                        return False
            else:
                # 不在NetTeller页面，使用原来的通用方式
                print("   使用通用密码输入方式...")
                password_entered = False
                for selector in ["input[type='password']", "input#password"]:
                    try:
                        if await self.wait_and_type(selector, self.password, 5000, f"密码输入框({selector})"):
                            password_entered = True
                            break
                    except:
                        continue
                
                if not password_entered:
                    print("❌ 未找到密码输入框")
                    return False
                
                await asyncio.sleep(1)
                
                # 提交
                login_submitted = False
                for selector in ["input[type='submit']", "button[type='submit']"]:
                    try:
                        async with self.page.expect_navigation(timeout=30000):
                            await self.page.click(selector)
                        login_submitted = True
                        break
                    except:
                        continue
                
                if not login_submitted:
                    await self.page.keyboard.press("Enter")

            print("⏳ 登录流程完成")
            await asyncio.sleep(5)
 
            # 检查是否登录成功
            current_url = self.page.url
            page_title = await self.page.title()
            print(f"📄 当前页面标题: {page_title}")
            print(f"🔗 当前URL: {current_url}")
            print("✅ 登录流程完成") 
            return True
           
        except Exception as e:
            print(f"❌ 登录过程中发生错误: {str(e)}")
            return False
    
    async def find_balance(self) -> Tuple[bool, str, Optional[str]]:
        """查找WIRE TRANSFER ACCOUNT余额"""
        try:
            print("\n" + "=" * 60)
            print("💰 开始查找余额")
            print("=" * 60)
            
            # 等待页面稳定
            await self.page.wait_for_load_state("networkidle", timeout=15000)

            
            # 方法: 查找所有表格
            print("\n搜索所有表格...")
            balance = await self._find_balance_in_tables()
            
            if balance:
                return True, balance, None
            else:
                return False, "未在表格中找到余额", None
            
        except Exception as e:
            print(f"❌ 查找余额时发生错误: {str(e)}")
            return False, f"查找余额时出错: {str(e)}", None
    
    async def _find_balance_in_tables(self) -> Optional[str]:
        """在表格中查找余额"""
        try:
            print("🔍 在表格中查找余额...")
            
            # 查找所有表格
            tables = await self.page.query_selector_all("table")
            print(f"  找到 {len(tables)} 个表格")
            
            for i, table in enumerate(tables):
                try:
                    # 获取表格中的所有行
                    rows = await table.query_selector_all("tr")
                    
                    for row in rows:
                        # 获取行中的所有单元格
                        cells = await row.query_selector_all("td, th")
                        cell_texts = []
                        
                        for cell in cells:
                            cell_text = await cell.text_content()
                            if cell_text:
                                cell_texts.append(cell_text.strip())
                        
                        # 检查行中是否包含"WIRE TRANSFER"
                        row_text = " ".join(cell_texts)
                        
                        if "WIRE TRANSFER" in row_text.upper():
                            print(f"✅ 在表格 {i+1} 中找到WIRE TRANSFER行")
                            print(f"  行内容: {row_text[:50]}...")
                            
                            # 在行中查找金额
                            for cell_text in cell_texts:
                                balance = self._extract_balance_from_text(cell_text)
                                if balance:
                                    print(f"✅ 在行中找到余额: {balance}")
                                    return balance
          
                except Exception as e:
                    print(f"  处理表格 {i+1} 时出错: {str(e)}")
                    continue
            
            return None
            
        except Exception as e:
            print(f"在表格中查找余额时出错: {str(e)}")
            return None

    def _extract_balance_from_text(self, text: str) -> Optional[str]:
        """从文本中提取余额"""
        if not text:
            return None
        
        # 使用正则表达式查找金额格式
        # 匹配: $1,234.56 或 1,234.56 或 1234.56
        amount_patterns = [
            r'[\$\€\£]\s*[\d,]+\.\d{2}',  # 货币符号 + 数字
            r'[\d,]+\.\d{2}\s*(USD|EUR|GBP|CAD|AUD)?',  # 数字 + 可选货币
            r'[\d,]+\.\d{2}',  # 纯数字
        ]
        
        for pattern in amount_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            for match in matches:
                if isinstance(match, tuple):
                    amount = match[0]
                else:
                    amount = match
                
                # 清理金额
                clean_amount = amount.strip()
                
                # 验证是否是有效的金额
                if self._is_valid_amount(clean_amount):
                    return clean_amount
        
        return None
    
    def _is_valid_amount(self, amount: str) -> bool:
        """检查是否是有效的金额"""
        if not amount:
            return False
        
        # 清理金额：移除货币符号和空格
        clean_amount = re.sub(r'[\$\€\£\s]', '', amount)
        clean_amount = clean_amount.replace(',', '')
        
        # 检查是否匹配数字格式
        if re.match(r'^\d+(\.\d{1,2})?$', clean_amount):
            try:
                # 尝试转换为浮点数
                value = float(clean_amount)
                # 检查是否合理的金额（大于0且不是太大）
                return 0 < value < 1000000000  # 小于10亿
            except:
                return False
        
        return False
    
    async def check_balance(self) -> Tuple[bool, str, Optional[str]]:
        """检查余额的主要函数"""
        try:
            print("=" * 60)
            print("💰 IBC余额查询开始")
            print("=" * 60)
            
            # 设置浏览器
            if not await self.setup_browser():
                return False, "无法启动浏览器", None
            
            try:
                # 登录
                login_success = await self.login_to_ibc()
                
                if not login_success:
                    return False, "登录失败，请检查用户名/密码或网络连接", None
                
                # 查找余额
                balance_found, balance_result, debug_info = await self.find_balance()
                
                if balance_found:
                    print("\n" + "=" * 60)
                    print(f"✅ 余额查询成功!")
                    print(f"💰 余额: {balance_result}")
                    print("=" * 60)

                    return True, balance_result, None
                else:
                    print("\n" + "=" * 60)
                    print("⚠️  登录成功但未找到余额信息")
                    print("=" * 60)
                    
                    # 获取页面信息用于调试
                    page_title = await self.page.title()
                    current_url = self.page.url
                    
                    error_msg = f"登录成功但未找到余额信息\n页面标题: {page_title}\n当前URL: {current_url}"
                    
                    if debug_info:
                        error_msg += f"\n页面内容片段:\n{debug_info}"
                    
                    return False, error_msg, None
            
            finally:
                # 关闭浏览器
                if self.browser:
                    await self.browser.close()
                
                if self.playwright:
                    await self.playwright.stop()
        
        except Exception as e:
            print(f"\n❌ 余额查询过程中发生错误: {str(e)}")
            return False, f"查询余额时出错: {str(e)}", None
    
    async def run_interactive_mode(self):
        """交互式运行模式"""
        
        # 获取用户名和密码
        if not self.username or self.username == "YOUR_USERNAME":
            self.username = input("请输入IBC用户名: ").strip()
        
        if not self.password or self.password == "YOUR_PASSWORD":
            self.password = input("请输入IBC密码: ").strip()
        
        if not self.username or not self.password:
            print("❌ 用户名和密码不能为空")
            return

        # 运行余额查询
        success, result, debug_info = await self.check_balance()
   
async def main():
    """主函数"""
    # 创建余额查询器
    # 在这里设置你的IBC用户名和密码
    username = "622700006569"  # 替换为你的用户名
    password = "Xgd2027!"  # 替换为你的密码
    
    checker = IBCBalanceChecker(username=username, password=password, headless=False)
    
    # 运行交互式模式
    await checker.run_interactive_mode()

if __name__ == "__main__":
    # 运行异步主函数
    asyncio.run(main())