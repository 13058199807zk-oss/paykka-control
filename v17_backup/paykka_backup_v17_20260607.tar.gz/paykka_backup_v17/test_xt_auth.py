#!/usr/bin/env python3
"""测试 XT 认证和汇率查询"""
import asyncio, json, sys
sys.path.insert(0, '/workspace')

from paykka_xt_rate import XTRateQueryManager
from paykka_competitor import CompetitorHistoryQuery

async def test():
    # 测试登录
    print("=== 测试 XT 登录 ===")
    xt = XTRateQueryManager()
    login_ok = await xt.login()
    print(f"登录结果: {'✅ 成功' if login_ok else '❌ 失败'}")
    
    if login_ok:
        print(f"\nCookie 长度: {len(xt.cookie_str)}")
        print(f"XSRF: {xt.xsrf_token[:30]}...")
        print(f"JWT: {xt.jwt_token[:30] if xt.jwt_token else '无'}...")
        print(f"server_grant_id: {xt.server_grant_id[:30]}...")
        
        # 测试实时汇率
        print("\n=== 测试实时汇率 ===")
        rate = xt.query_single_rate("USD", "CNY")
        print(f"USD/CNY: {json.dumps(rate, indent=2)}")
        
        # 测试历史数据
        print("\n=== 测试历史数据 ===")
        hist = CompetitorHistoryQuery()
        result = hist.query_xt_history("USD", "CNY", days=3)
        print(f"历史查询结果:")
        print(f"  success: {result['success']}")
        print(f"  pair: {result['pair']}")
        print(f"  error: {result.get('error', '无')}")
        print(f"  数据点数: {len(result.get('data', []))}")
        if result.get('data'):
            print(f"  第一条: {result['data'][0]}")
            print(f"  最后一条: {result['data'][-1]}")
    else:
        print("❌ 登录失败，无法测试 API")

asyncio.run(test())
