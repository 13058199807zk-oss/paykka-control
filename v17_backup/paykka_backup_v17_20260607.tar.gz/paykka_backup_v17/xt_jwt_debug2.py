#!/usr/bin/env python3
"""XT 认证机制深度分析 - 分析登录后 API 请求的认证方式"""
import asyncio, json, os, sys
from datetime import datetime
from playwright.async_api import async_playwright

XT_USER_DATA = "/workspace/xt_browser_data"

async def main():
    playwright = await async_playwright().start()
    
    try:
        context = await playwright.chromium.launch_persistent_context(
            user_data_dir=XT_USER_DATA,
            headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-blink-features=AutomationControlled"],
            viewport={"width": 1280, "height": 720},
        )
        print("📂 使用已有浏览器会话...")
    except Exception as e:
        print(f"⚠️ 无法复用会话: {e}")
        return
    
    page = context.pages[0] if context.pages else await context.new_page()
    
    # 收集所有 API 请求的详细 headers
    all_api_requests = []
    
    async def on_request(request):
        req_url = request.url
        if "api.xtransfer.cn" in req_url:
            req_headers = dict(request.headers)
            all_api_requests.append({
                "url": req_url,
                "method": request.method,
                "headers": {k: v for k, v in req_headers.items() if k.lower() in [
                    'authorization', 'cookie', 'x-xsrf-token', 'x-server-grant-id',
                    'x-user-agent-context', 'x-language', 'content-type'
                ]},
            })
    
    page.on('request', on_request)
    
    print("🌐 访问 XT 首页...")
    try:
        await page.goto("https://www.xtransfer.cn/fund/home", timeout=30000, wait_until="domcontentloaded")
        await asyncio.sleep(5)
        current_url = page.url
        print(f"📍 当前 URL: {current_url}")
    except Exception as e:
        print(f"⚠️ 首页访问异常: {e}")
    
    # 导航到汇率页面以触发 API 调用
    if "login" not in current_url.lower():
        print("🔄 导航到汇率页面...")
        try:
            # 点击汇率相关页面触发 API
            await page.goto("https://www.xtransfer.cn/fund/home", timeout=30000, wait_until="networkidle")
            await asyncio.sleep(5)
        except Exception as e:
            print(f"⚠️ 导航异常: {e}")
        
        # 尝试通过 evaluate 执行 API 调用
        print("\n🔬 尝试通过页面上下文调用 API...")
        result = await page.evaluate("""
            async () => {
                try {
                    const resp = await fetch('https://api.xtransfer.cn/api/v1/spotfx/graph/present-rate/get-rate-by-ccy?fromCcy=USD&toCcy=CNY&requestFrom=PC', {
                        credentials: 'include'
                    });
                    const text = await resp.text();
                    return {status: resp.status, body: text.substring(0, 200)};
                } catch(e) {
                    return {error: e.message};
                }
            }
        """)
        print(f"  get-rate-by-ccy (fetch): {json.dumps(result)}")
        
        result2 = await page.evaluate("""
            async () => {
                try {
                    const resp = await fetch('https://api.xtransfer.cn/api/v1/spotfx/graph/present-rate/v2/getWithSource?fromCcy=USD&toCcy=CNY&type=WEEK&siteCode=CN', {
                        credentials: 'include'
                    });
                    const text = await resp.text();
                    return {status: resp.status, body: text.substring(0, 200)};
                } catch(e) {
                    return {error: e.message};
                }
            }
        """)
        print(f"  getWithSource (fetch): {json.dumps(result2)}")
    
    await asyncio.sleep(2)
    
    # 分析所有 API 请求
    print(f"\n📊 共拦截 {len(all_api_requests)} 个 API 请求")
    
    has_auth = [r for r in all_api_requests if 'authorization' in r.get('headers', {})]
    print(f"  带 Authorization 的请求: {len(has_auth)}")
    
    # 列出所有不同的 header keys
    all_keys = set()
    for r in all_api_requests:
        all_keys.update(r['headers'].keys())
    print(f"  所有 header keys: {sorted(all_keys)}")
    
    # 展示几个请求样例
    print("\n📋 请求样例:")
    for r in all_api_requests[-5:]:
        print(f"  [{r['method']}] {r['url'][:100]}")
        for k, v in r['headers'].items():
            print(f"    {k}: {v[:80]}")
        print()
    
    await context.close()

asyncio.run(main())
