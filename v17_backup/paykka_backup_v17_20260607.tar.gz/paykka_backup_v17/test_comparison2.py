#!/usr/bin/env python3
"""测试自定义参数"""
import sys, json, os, logging, time
sys.path.insert(0, '/workspace')
logging.basicConfig(level=logging.WARNING)

from paykka_comparison import QuoteComparisonEngine
from paykka_controllerV16 import PaykkaSystemManager

mgr = PaykkaSystemManager()
for i in range(45):
    if mgr._token:
        break
    time.sleep(2)
token = mgr._token

# ========== 测试2: 自定义 (USD/CNH, 1天, 仅 YB + BOC + XT) ==========
print('=' * 60)
print('测试2: 自定义 (USD/CNH, 1天, YB + BOC + XT)')
print('=' * 60)

engine = QuoteComparisonEngine(token)
result = engine.run_comparison(
    base_currency='USD',
    quote_currency='CNH',
    days=1,
    channel_sources=['YB', 'BOC'],
    competitor_sources=['XT'],
)

print(f'success: {result["success"]}')
for src_name, src_data in sorted(result['results'].items()):
    status = '✅' if src_data.get('success') else '❌'
    count = len(src_data.get('data', []))
    rates = [d.get('rate', 0) for d in src_data.get('data', [])]
    if rates:
        print(f'  {status} {src_name}: {count} 条, 范围 [{min(rates):.5f} ~ {max(rates):.5f}]')
    else:
        print(f'  {status} {src_name}: {count} 条 - {src_data.get("error", "")[:60]}')

print(f'chart: {os.path.basename(result["chart_path"])}')
print(f'chart_exists: {os.path.exists(result["chart_path"])}')
print()
print(result['summary'][:500])
