#!/usr/bin/env python3
"""余额监控定时任务 - 每N分钟自动查询机构余额并更新GitHub Pages（V17模块化版本）"""

import asyncio, json, time, requests, pyotp, threading, base64, os, sys
from playwright.async_api import async_playwright
from datetime import datetime
import pandas as pd
import logging
from logging.handlers import RotatingFileHandler

# 确保可以导入 paykka 模块
sys.path.insert(0, '/workspace')

# ============ 从 V17 模块读取配置（统一凭据源） ============
from paykka_config import (
    PAYKKA_USERNAME, PAYKKA_PASSWORD, PAYKKA_OTP_SECRET,
    BALANCE_BASE_URL, INSTITUTION_MAP, INSTITUTION_CURRENCIES,
    NO_DIVIDE_CURRENCIES, EXCEL_FILENAME,
    GITHUB_TOKEN, GITHUB_REPO_OWNER, GITHUB_BALANCE_REPO_NAME,
    GITHUB_BALANCE_FILE_PATH, GITHUB_BRANCH,
)

BALANCE_URL = BALANCE_BASE_URL + "/recv-org/op/org/account-balance/query"
NO_DIVIDE = NO_DIVIDE_CURRENCIES

# ============ 日志 ============
os.makedirs("logs", exist_ok=True)
logger = logging.getLogger("balance_monitor")
logger.setLevel(logging.INFO)
fh = RotatingFileHandler("logs/balance_monitor.log", maxBytes=5*1024*1024, backupCount=3, encoding='utf-8')
ch = logging.StreamHandler()
fmt = logging.Formatter('%(asctime)s [%(levelname)s] %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
fh.setFormatter(fmt); ch.setFormatter(fmt)
logger.addHandler(fh); logger.addHandler(ch)

# ============ 登录 ============
def get_otp(secret):
    return pyotp.TOTP(secret.replace(" ", ""), interval=30, digits=6).now()

async def paykka_login():
    token = None
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True, channel="chrome", slow_mo=100,
            args=["--no-sandbox", "--disable-blink-features=AutomationControlled"])
        ctx = await browser.new_context(viewport=None, ignore_https_errors=True)
        page = await ctx.new_page()
        try:
            await page.goto("https://ops.cb.paykka.com/login")
            time.sleep(2)
            await page.locator("//input[@placeholder='请输入账号/邮箱地址/手机号']").fill(PAYKKA_USERNAME)
            time.sleep(0.5)
            await page.locator("//input[@placeholder='请输入密码']").fill(PAYKKA_PASSWORD)
            time.sleep(0.5)
            await page.locator("button:has-text('登录'), button[type='submit']").first.click(force=True)
            time.sleep(2)
            otp_code = get_otp(PAYKKA_OTP_SECRET)
            oi = page.locator("//input[@maxlength='1']")
            await oi.first.wait_for(timeout=20000)
            for i in range(6):
                await oi.nth(i).fill(str(otp_code)[i])
                time.sleep(0.2)
            time.sleep(5)
            for c in (await ctx.cookies()):
                if c['name'] == 'a_t':
                    token = c['value']
        finally:
            await browser.close()
    return token

def build_headers(token):
    return {
        "accept": "application/json, text/plain, */*",
        "content-type": "application/json;charset=UTF-8",
        "cookie": f"a_t={token}",
        "origin": "https://ops.cb.paykka.com",
        "referer": "https://ops.cb.paykka.com/",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "x-auth-token": token,
        "x-requested-with": "XMLHttpRequest"
    }

def fmt_bal(b, cur):
    try:
        b = float(b)
        if cur not in NO_DIVIDE: b = b / 100.0
        return f"{b:,.2f}"
    except: return "0.00"

# ============ 监控器 ============
class BalanceMonitor:
    def __init__(self):
        self.token = None
        self.last_login = None
        self.is_running = False
        self.stop_event = threading.Event()
        self.interval_minutes = 60

    def login(self):
        self.token = asyncio.run(paykka_login())
        self.last_login = time.time()
        return self.token is not None

    def refresh_token(self):
        if not self.token or (self.last_login and time.time() - self.last_login > 20 * 3600):
            logger.info("🔄 Token 过期，重新登录...")
            return self.login()
        return True

    def query_balances(self):
        headers = build_headers(self.token)
        results = []
        qt = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        for org_code, org_name in INSTITUTION_MAP.items():
            for currency in INSTITUTION_CURRENCIES.get(org_code, []):
                payload = {"offset": 0, "limit": 100, "account_type": "FUND_ACCOUNT", "currency": currency, "org_code": org_code}
                try:
                    resp = requests.post(BALANCE_URL, headers=headers, json=payload, timeout=30)
                    data = resp.json()
                    if data.get("ret_code") == "000000":
                        for item in data.get("data", []):
                            if isinstance(item, dict) and item.get("balance") is not None:
                                results.append({"查询时间": qt, "渠道名": org_name, "币种": currency, "余额": fmt_bal(item["balance"], currency)})
                    time.sleep(0.1)
                except Exception as e:
                    logger.error(f"{org_name}/{currency} 查询失败: {e}")
        return results

    def generate_html(self, results):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        org_data = {}
        for r in results:
            org_data.setdefault(r["渠道名"], []).append((r["币种"], r["余额"]))
        html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PayKKa 机构余额看板</title>
    <style>
        body {{ font-family: 'Segoe UI', Arial, sans-serif; margin: 40px; background-color: #f5f5f5; color: #333; }}
        .container {{ max-width: 1200px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }}
        h1 {{ color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 15px; }}
        .update-time {{ color: #7f8c8d; font-size: 0.95em; margin-bottom: 30px; }}
        .institution {{ margin-bottom: 35px; }}
        .institution h2 {{ color: #16a085; background-color: #ecf0f1; padding: 12px 20px; border-radius: 8px; }}
        table {{ width: 100%; border-collapse: collapse; margin-top: 15px; }}
        th, td {{ padding: 15px 20px; text-align: left; border-bottom: 1px solid #ddd; }}
        th {{ background-color: #3498db; color: white; font-weight: 600; }}
        tr:hover {{ background-color: #f9f9f9; }}
        .balance {{ font-family: 'Courier New', monospace; font-weight: bold; color: #27ae60; }}
        .footer {{ margin-top: 40px; text-align: center; font-size: 0.9em; color: #95a5a6; }}
        .alert {{ background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 8px; margin-top: 20px; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🏦 PayKKa 渠道机构资金余额看板</h1>
        <div class="update-time">最后更新时间: <strong>{now}</strong> (北京时间)</div>
        <div class="alert">说明：本页面数据通过自动化脚本定时更新，展示各机构资金账户的实时余额。</div>
'''
        for org_name, currencies in org_data.items():
            html += f'\n        <div class="institution">\n            <h2>📊 {org_name}</h2>\n            <table>\n                <thead>\n                    <tr><th>币种</th><th>余额</th></tr>\n                </thead>\n                <tbody>\n'
            for cur, bal in currencies:
                html += f'                    <tr><td><strong>{cur}</strong></td><td class="balance">{bal}</td></tr>\n'
            html += '                </tbody>\n            </table>\n        </div>\n'
        html += f'''        <div class="footer">
            <p>数据来源: PayKKa 运营平台 | 定时监控间隔: {self.interval_minutes}分钟</p>
            <p>仓库: {GITHUB_REPO_OWNER}/{GITHUB_BALANCE_REPO_NAME}</p>
        </div>
    </div>
</body>
</html>'''
        return html

    def save_excel(self, results):
        df = pd.DataFrame(results)
        if os.path.exists(EXCEL_FILENAME):
            existing = pd.read_excel(EXCEL_FILENAME, engine='openpyxl')
            df = pd.concat([existing, df], ignore_index=True)
        df.to_excel(EXCEL_FILENAME, index=False, engine='openpyxl')

    def upload_github(self, html):
        url = f"https://api.github.com/repos/{GITHUB_REPO_OWNER}/{GITHUB_BALANCE_REPO_NAME}/contents/{GITHUB_BALANCE_FILE_PATH}"
        gh_h = {"Authorization": f"token {GITHUB_TOKEN}", "Accept": "application/vnd.github.v3+json"}
        enc = base64.b64encode(html.encode("utf-8")).decode("utf-8")
        sha = None
        try:
            r = requests.get(url, headers=gh_h)
            if r.status_code == 200: sha = r.json().get("sha")
        except: pass
        body = {"message": f"定时余额监控 {datetime.now().strftime('%Y-%m-%d %H:%M')}", "content": enc, "branch": GITHUB_BRANCH}
        if sha: body["sha"] = sha
        r = requests.put(url, headers=gh_h, json=body, timeout=30)
        return r.status_code in [200, 201]

    def execute_once(self):
        try:
            if not self.refresh_token():
                logger.error("❌ Token 刷新失败")
                return False
            logger.info("📡 查询余额...")
            results = self.query_balances()
            logger.info(f"✅ {len(results)} 条记录")
            if results:
                self.save_excel(results)
                html = self.generate_html(results)
                if self.upload_github(html):
                    logger.info("📤 GitHub Pages 已更新")
                else:
                    logger.error("❌ GitHub 上传失败")
                return True
            else:
                logger.warning("⚠️ 无余额数据")
                return False
        except Exception as e:
            logger.error(f"❌ 执行异常: {e}")
            return False

    def start(self, interval_minutes=60):
        if self.is_running:
            return "⚠️ 余额监控已在运行中"
        self.interval_minutes = interval_minutes
        self.is_running = True
        self.stop_event.clear()
        if not self.login():
            return "❌ 登录失败"
        logger.info(f"🟢 余额监控启动，间隔: {interval_minutes}分钟")
        # 首次立即执行
        self.execute_once()
        self.task_thread = threading.Thread(target=self._loop, daemon=True)
        self.task_thread.start()
        return f"✅ 余额监控已启动 | 间隔: {interval_minutes}分钟 | 首次执行完成"

    def _loop(self):
        while not self.stop_event.is_set():
            logger.info(f"⏳ 等待 {self.interval_minutes} 分钟...")
            self.stop_event.wait(timeout=self.interval_minutes * 60)
            if not self.stop_event.is_set():
                self.execute_once()
        logger.info("🔴 监控已停止")

    def stop(self):
        if not self.is_running: return "ℹ️ 未运行"
        self.is_running = False
        self.stop_event.set()
        return "🛑 已停止"

    def status(self):
        return f"🟢 运行中 | 间隔: {self.interval_minutes}分钟" if self.is_running else "🔴 已停止"


# ============ 入口 ============
if __name__ == "__main__":
    interval = int(sys.argv[1]) if len(sys.argv) > 1 else 60
    monitor = BalanceMonitor()
    print(monitor.start(interval))
    try:
        while monitor.is_running:
            time.sleep(30)
    except KeyboardInterrupt:
        monitor.stop()
        print("手动停止")
