#!/usr/bin/env python3
"""
XT 登录 + JWT 提取脚本
策略：使用非 headless 模式 + VNC，人工完成 CAPTCHA，
登录成功后自动拦截 API 请求提取 JWT token
"""
import asyncio, json, os, sys, signal
from datetime import datetime
from playwright.async_api import async_playwright

XT_USER_DATA = "/workspace/xt_browser_data"
XT_AUTH_CACHE = "/workspace/xt_auth_cache.json"

def load_env():
    env_path = "/workspace/.env"
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, _, val = line.partition('=')
                    os.environ[key.strip()] = val.strip()

load_env()

# 全局状态
found_jwt = None
found_xsrf = None
found_server_grant = None
login_success = False

async def main():
    global found_jwt, found_xsrf, found_server_grant, login_success
    
    playwright = await async_playwright().start()
    
    # 使用持久化上下文，headless=False 以便 VNC 操作
    context = await playwright.chromium.launch_persistent_context(
        user_data_dir=XT_USER_DATA,
        headless=False,  # 关键：非 headless，通过 VNC 手动操作
        args=[
            "--no-sandbox", 
            "--disable-dev-shm-usage", 
            "--disable-blink-features=AutomationControlled",
            "--disable-features=TranslateUI",
        ],
        viewport={"width": 1280, "height": 720},
        slow_mo=50,
    )
    
    page = context.pages[0] if context.pages else await context.new_page()
    
    # 拦截所有 API 请求
    async def on_request(request):
        global found_jwt, found_xsrf, found_server_grant
        req_url = request.url
        headers = request.headers
        
        # 提取 JWT
        if 'authorization' in headers and 'Bearer' in headers.get('authorization', ''):
            auth = headers['authorization']
            if not found_jwt:
                found_jwt = auth.replace('Bearer ', '')
                print(f"\n🔑 捕获 JWT Token!")
                print(f"   来源 URL: {req_url}")
                print(f"   JWT: {found_jwt[:60]}...")
        
        # 提取 XSRF
        if 'x-xsrf-token' in headers and not found_xsrf:
            found_xsrf = headers['x-xsrf-token']
        
        # 提取 server_grant_id
        if 'x-server-grant-id' in headers and not found_server_grant:
            found_server_grant = headers['x-server-grant-id']
    
    page.on('request', on_request)
    
    # 导航到首页
    print("🌐 访问 XT 首页...")
    await page.goto("https://www.xtransfer.cn/fund/home", timeout=30000)
    await asyncio.sleep(3)
    
    current_url = page.url
    print(f"📍 当前 URL: {current_url}")
    
    if "login" in current_url.lower():
        print("\n🔐 检测到需要登录...")
        
        # 尝试自动填充（CAPTCHA 需要人工）
        try:
            tab = await page.wait_for_selector("text=Password Login", timeout=5000)
            if tab:
                await tab.click()
                print("✅ 切换到 Password Login")
                await asyncio.sleep(1)
        except:
            pass
        
        phone = os.getenv("XT_LOGIN_PHONE", "")
        pwd = os.getenv("XT_LOGIN_PASSWORD", "")
        
        if phone and pwd:
            try:
                phone_input = await page.wait_for_selector("#accountLoginMobileInput", timeout=10000)
                await phone_input.fill("")
                await phone_input.type(phone, delay=80)
                print("✅ 已填充手机号")
                
                pwd_input = await page.wait_for_selector("#accountLoginPasswordInput", timeout=10000)
                await pwd_input.fill("")
                await pwd_input.type(pwd, delay=80)
                print("✅ 已填充密码")
                
                btn = await page.wait_for_selector("button:has-text('Login')", timeout=10000)
                await btn.click()
                print("✅ 已点击登录按钮")
                print("\n" + "=" * 60)
                print("⚠️ 如果出现 CAPTCHA，请在 VNC 中手动完成验证")
                print("   等待登录成功（最多 5 分钟）...")
                print("=" * 60)
            except Exception as e:
                print(f"⚠️ 自动填充失败: {e}")
        else:
            print("⚠️ 未配置 XT 登录凭据，请手动登录")
        
        # 等待登录成功
        for i in range(300):  # 最多等 5 分钟
            await asyncio.sleep(1)
            url = page.url
            if "login" not in url.lower() and "fund" in url.lower():
                login_success = True
                print(f"\n✅ 登录成功! URL: {url}")
                break
            if i % 30 == 0 and i > 0:
                print(f"   等待中... ({i}s) 当前 URL: {url}")
        else:
            print("\n⚠️ 等待超时，但继续尝试提取凭据...")
            if "login" not in page.url.lower():
                login_success = True
    else:
        login_success = True
        print("✅ 已登录状态")
    
    # 登录后等待 API 调用
    print("\n⏳ 等待 API 请求发出...")
    await asyncio.sleep(5)
    
    # 导航到汇率页面触发汇率 API
    try:
        print("🔄 访问汇率页面以触发 API...")
        await page.goto("https://www.xtransfer.cn/fund/home", timeout=30000, wait_until="networkidle")
        await asyncio.sleep(3)
    except:
        pass
    
    # 提取所有凭据
    cookies = await context.cookies()
    cookie_parts = []
    for c in cookies:
        name = c.get('name', '')
        value = c.get('value', '')
        if name and value and value != 'null':
            cookie_parts.append(f"{name}={value}")
            if 'XSRF-TOKEN' in name.upper() and not found_xsrf:
                found_xsrf = value
    
    # 从 localStorage 提取
    try:
        if not found_server_grant:
            grant = await page.evaluate("() => localStorage.getItem('xt_new_server_grant_id')")
            if grant:
                found_server_grant = grant
                print(f"  server_grant_id: {grant[:30]}...")
    except:
        pass
    
    # 从 localStorage 提取 token
    try:
        for key in ['token', 'jwt', 'access_token', 'accessToken', 'xt_token']:
            val = await page.evaluate(f"() => localStorage.getItem('{key}')")
            if val and len(val) > 20:
                print(f"  localStorage.{key}: {val[:60]}...")
                if not found_jwt:
                    found_jwt = val
    except:
        pass
    
    # 从 sessionStorage 提取
    try:
        for key in ['token', 'jwt', 'access_token', 'accessToken']:
            val = await page.evaluate(f"() => sessionStorage.getItem('{key}')")
            if val and len(val) > 20:
                print(f"  sessionStorage.{key}: {val[:60]}...")
                if not found_jwt:
                    found_jwt = val
    except:
        pass
    
    # 保存缓存
    cache = {
        "cookie_str": "; ".join(cookie_parts),
        "xsrf_token": found_xsrf or "",
        "jwt_token": found_jwt or "",
        "server_grant_id": found_server_grant or "",
        "auth_time": datetime.now().isoformat(),
    }
    
    with open(XT_AUTH_CACHE, "w") as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)
    
    print(f"\n{'=' * 60}")
    print(f"📊 提取结果:")
    print(f"  Cookie 数量: {len(cookie_parts)}")
    print(f"  XSRF Token: {found_xsrf[:30] if found_xsrf else '未找到'}...")
    print(f"  JWT Token:  {found_jwt[:50] if found_jwt else '❌ 未找到'}...")
    print(f"  server_grant_id: {found_server_grant[:30] if found_server_grant else '未找到'}...")
    print(f"  Login success: {login_success}")
    print(f"\n💾 缓存已保存到: {XT_AUTH_CACHE}")
    print(f"{'=' * 60}")
    
    if not found_jwt:
        print("\n⚠️ 未捕获到 JWT token。可能原因:")
        print("   1. 登录未完全成功（可能卡在 CAPTCHA）")
        print("   2. XT 不使用 JWT Bearer token（可能用其他认证方式）")
        print("   3. 需要导航到特定页面才会触发 API 调用")
    
    print("\n📌 浏览器保持打开 30 秒，如需手动操作请通过 VNC...")
    await asyncio.sleep(30)
    
    await context.close()

asyncio.run(main())
