# ===================== paykka_dedup.py =====================
# 消息去重管理器
# 从 paykka_controllerV16.py 原文提取

import time
import threading
from paykka_config import logger


class MessageDeduplicator:
    """消息去重管理器，防止重复处理"""
    
    def __init__(self, max_size=1000, timeout=86400):  # 24小时超时
        self.processed_messages = {}
        self.max_size = max_size
        self.timeout = timeout
        
    def is_processed(self, message_id: str) -> bool:
        """检查消息是否已处理"""
        if message_id in self.processed_messages:
            timestamp = self.processed_messages[message_id]
            if time.time() - timestamp < self.timeout:
                return True
            else:
                del self.processed_messages[message_id]
        
        self._cleanup()
        return False
    
    def mark_as_processed(self, message_id: str):
        """标记消息为已处理"""
        self.processed_messages[message_id] = time.time()
        
        if len(self.processed_messages) > self.max_size:
            oldest_key = min(self.processed_messages.items(), key=lambda x: x[1])[0]
            del self.processed_messages[oldest_key]
    
    def _cleanup(self):
        """清理过期条目"""
        current_time = time.time()
        expired_keys = [
            key for key, timestamp in self.processed_messages.items()
            if current_time - timestamp > self.timeout
        ]
        for key in expired_keys:
            del self.processed_messages[key]
