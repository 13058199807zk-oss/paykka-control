# ===================== paykka_xt_rate.py =====================
# XTRateQueryManager - XT汇率查询（独立）
# 从 paykka_controllerV16.py 提取

import json
import time
import urllib.parse
import requests
import re
import threading
import os
import hashlib
import asyncio
import subprocess
import base64
from typing import List, Dict, Tuple, Any, Optional, Union
from datetime import datetime, date, timedelta, timezone, time as dtime
from playwright.async_api import async_playwright
import pandas as pd
from github import Github, InputGitAuthor
import pytz

from paykka_config import *

class XTRateQueryManager:
    """XT 汇率查询模块 - 支持登录态持久化和批量/按需查询"""
    
    def __init__(self):
        self.cookie_str = ""
        self.xsrf_token = ""
        self.jwt_token = ""
        self.server_grant_id = ""  # XT API 必需 header
        self.auth_time = None
        self.session = None
        self._load_auth_cache()
    
    # ===================== 认证缓存 =====================
    def _load_auth_cache(self):
        """从缓存文件加载 XT 认证信息"""
        try:
            if os.path.exists(XT_AUTH_CACHE_FILE):
                with open(XT_AUTH_CACHE_FILE, 'r', encoding='utf-8') as f:
                    cache = json.load(f)
                self.cookie_str = cache.get("cookie_str", "")
                self.xsrf_token = cache.get("xsrf_token", "")
                self.jwt_token = cache.get("jwt_token", "")
                self.server_grant_id = cache.get("server_grant_id", "")
                auth_time_str = cache.get("auth_time", "")
                if auth_time_str:
                    self.auth_time = datetime.fromisoformat(auth_time_str)
                logger.info(f"📦 已加载 XT 认证缓存 (时间: {auth_time_str})")
        except Exception as e:
            logger.warning(f"加载 XT 认证缓存失败: {e}")
    
    def _save_auth_cache(self):
        """保存 XT 认证信息到缓存文件"""
        try:
            cache = {
                "cookie_str": self.cookie_str,
                "xsrf_token": self.xsrf_token,
                "jwt_token": self.jwt_token,
                "server_grant_id": self.server_grant_id,
                "auth_time": datetime.now().isoformat(),
            }
            with open(XT_AUTH_CACHE_FILE, 'w', encoding='utf-8') as f:
                json.dump(cache, f, ensure_ascii=False, indent=2)
            self.auth_time = datetime.now()
            logger.info(f"💾 XT 认证缓存已保存")
        except Exception as e:
            logger.error(f"保存 XT 认证缓存失败: {e}")
    
    def _is_auth_valid(self) -> bool:
        """检查认证是否在有效期内"""
        if not self.cookie_str or not self.xsrf_token:
            return False
        if not self.auth_time:
            return False
        elapsed = (datetime.now() - self.auth_time).total_seconds()
        return elapsed < XT_AUTH_CACHE_DURATION
    
    # ===================== Cookie 解析 =====================
    def _parse_cookie_str(self, cookie_str: str) -> Dict[str, str]:
        """解析 cookie 字符串为字典"""
        cookies = {}
        for item in cookie_str.split(';'):
            item = item.strip()
            if '=' in item:
                parts = item.split('=', 1)
                if len(parts) == 2:
                    name, value = parts
                    cookies[name.strip()] = value.strip()
        return cookies
    
    def _setup_session(self):
        """设置 requests 会话的 Cookie"""
        if not self.session:
            self.session = requests.Session()
        cookie_dict = self._parse_cookie_str(self.cookie_str)
        for name, value in cookie_dict.items():
            self.session.cookies.set(name, value)
    
    # ===================== 构建请求头 =====================
    def _build_headers(self) -> Dict[str, str]:
        """构建 XT API 请求头"""
        headers = {
            'accept': 'application/json',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'zh-CN,zh;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
            'origin': 'https://www.xtransfer.cn',
            'referer': 'https://www.xtransfer.cn/',
            'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',
            'x-language': 'CN',
        }
        if self.xsrf_token:
            headers['x-xsrf-token'] = self.xsrf_token
        if self.jwt_token:
            headers['Authorization'] = f'Bearer {self.jwt_token}'
        if self.server_grant_id:
            headers['x-server-grant-id'] = self.server_grant_id
            headers['x-user-agent-context'] = f'PC_Browser;serverGrantId:{self.server_grant_id};'
        return headers
    
    # ===================== 登录 =====================
    async def login(self) -> bool:
        """Playwright 自动登录 XT 平台，使用 xvfb + 有头浏览器绕过 CAPTCHA"""
        if self._is_auth_valid():
            logger.info("✅ XT 认证缓存有效，跳过登录")
            self._setup_session()
            return True
        
        logger.info("🔐 开始 XT 平台自动登录 (xvfb + 有头浏览器)...")
        
        try:
            from playwright.async_api import async_playwright
            
            playwright = await async_playwright().start()
            browser = await playwright.chromium.launch(
                headless=False,  # 非 headless 绕过 CAPTCHA 检测
                slow_mo=50,
                args=[
                    "--disable-blink-features=AutomationControlled",
                    "--no-sandbox",
                    "--disable-dev-shm-usage",
                    "--window-size=1280,720",
                ]
            )
            context = await browser.new_context(
                viewport={"width": 1280, "height": 720},
                locale="zh-CN",
                timezone_id="Asia/Shanghai",
            )
            
            # Stealth: 隐藏 webdriver 特征
            await context.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', { get: () => false });
                window.chrome = { runtime: {} };
                Object.defineProperty(navigator, 'plugins', { get: () => [1, 2, 3, 4, 5] });
                Object.defineProperty(navigator, 'languages', { get: () => ['zh-CN', 'zh', 'en'] });
            """)
            
            page = await context.new_page()
            
            # 访问登录页
            logger.info(f"访问 XT 登录页: {XT_LOGIN_URL}")
            await page.goto(XT_LOGIN_URL, timeout=30000, wait_until="networkidle")
            await asyncio.sleep(3)
            
            # 输入手机号
            phone_input = await page.wait_for_selector(
                "#accountLoginMobileInput", timeout=10000
            )
            await phone_input.click()
            await asyncio.sleep(0.3)
            await phone_input.fill("")
            await asyncio.sleep(0.3)
            await phone_input.type(XT_LOGIN_PHONE, delay=80)
            logger.info("✅ 已填充手机号")
            
            # 输入密码
            password_input = await page.wait_for_selector(
                "#accountLoginPasswordInput", timeout=10000
            )
            await password_input.click()
            await asyncio.sleep(0.3)
            await password_input.fill("")
            await asyncio.sleep(0.3)
            await password_input.type(XT_LOGIN_PASSWORD, delay=80)
            logger.info("✅ 已填充密码")
            
            await asyncio.sleep(1)
            
            # 点击登录按钮
            try:
                login_button = await page.wait_for_selector(
                    "button:has-text('登录')", timeout=10000
                )
                await login_button.click()
            except:
                # 回退到 index 点击
                buttons = await page.query_selector_all("button")
                for btn in buttons:
                    text = await btn.inner_text()
                    if '登录' in text:
                        await btn.click()
                        break
            logger.info("✅ 已点击 XT 登录按钮")
            
            # 等待登录结果，处理 CAPTCHA
            captcha_detected = False
            for i in range(90):
                await asyncio.sleep(1)
                current_url = page.url
                
                # 检测并自动处理滑块 CAPTCHA
                if not captcha_detected:
                    try:
                        captcha = await page.query_selector(
                            ".geetest_holder, [class*='captcha'], [class*='geetest']"
                        )
                        if captcha:
                            captcha_detected = True
                            logger.warning("⚠️ 检测到 CAPTCHA，尝试自动滑动...")
                            try:
                                slider = await page.query_selector(
                                    ".geetest_slider_button, [class*='slider']"
                                )
                                if slider:
                                    box = await slider.bounding_box()
                                    if box:
                                        start_x = box['x'] + box['width'] / 2
                                        start_y = box['y'] + box['height'] / 2
                                        await page.mouse.move(start_x, start_y)
                                        await page.mouse.down()
                                        for step in range(25):
                                            await page.mouse.move(
                                                start_x + (step + 1) * 12,
                                                start_y + (step % 3 - 1) * 2
                                            )
                                            await asyncio.sleep(0.04)
                                        await page.mouse.up()
                                        logger.info("   ✅ 已尝试自动滑动")
                            except Exception as e:
                                logger.warning(f"   ⚠️ 自动滑动失败: {e}")
                    except:
                        pass
                
                if "login" not in current_url.lower():
                    logger.info(f"✅ XT 登录成功，已跳转到: {current_url}")
                    break
                
                if i % 15 == 0 and i > 0:
                    logger.info(f"   等待中... ({i}s)")
            else:
                if "login" in page.url.lower():
                    logger.warning("⚠️ XT 登录超时，可能 CAPTCHA 验证失败")
                    await browser.close()
                    return False
            
            # 等待 API 请求触发
            await asyncio.sleep(5)
            
            # 导航到 fund home 以触发 API 调用
            try:
                await page.goto("https://www.xtransfer.cn/fund/home",
                                timeout=30000, wait_until="networkidle")
                await asyncio.sleep(3)
            except:
                pass
            
            # 提取 Cookies
            cookies = await context.cookies()
            logger.info(f"✅ 提取到 {len(cookies)} 个 XT Cookie")
            
            cookie_parts = []
            for cookie in cookies:
                name = cookie.get('name', '')
                value = cookie.get('value', '')
                if name and value and value != 'null':
                    cookie_parts.append(f"{name}={value}")
                    if 'XSRF-TOKEN' in name.upper():
                        self.xsrf_token = value
                        logger.info(f"  XSRF-TOKEN: {value[:30]}...")
            
            self.cookie_str = "; ".join(cookie_parts)
            
            # 从 localStorage 提取 server_grant_id
            try:
                grant_id = await page.evaluate(
                    "() => localStorage.getItem('xt_new_server_grant_id')"
                )
                if grant_id:
                    self.server_grant_id = grant_id
                    logger.info(f"  server_grant_id: {grant_id[:30]}...")
            except Exception as e:
                logger.warning(f"  无法提取 server_grant_id: {e}")
            
            # 尝试从 storage 提取 JWT（XT 通常不用 JWT）
            for storage_type in ['localStorage', 'sessionStorage']:
                try:
                    for key in ['token', 'jwt', 'access_token', 'accessToken']:
                        val = await page.evaluate(
                            f"() => {storage_type}.getItem('{key}')"
                        )
                        if val and len(val) > 20:
                            self.jwt_token = val
                            logger.info(f"  JWT from {storage_type}.{key}: {val[:30]}...")
                            break
                except:
                    pass
                if self.jwt_token:
                    break
            
            # 保存缓存
            self._save_auth_cache()
            self._setup_session()
            
            await browser.close()
            
            # 验证认证
            has_auth = '_dx_FMrPY6' in self.cookie_str
            if has_auth:
                logger.info(f"✅ XT 登录完成，Cookie 长度: {len(self.cookie_str)}")
                return True
            else:
                logger.warning("⚠️ XT Cookie 中未检测到有效认证信息")
                return False
            
        except Exception as e:
            logger.error(f"❌ XT 登录失败: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False
    
    # ===================== 汇率查询 =====================
    def query_single_rate(self, from_ccy: str, to_ccy: str) -> Optional[Dict]:
        """查询单一货币对的 XT 汇率"""
        if not self.session:
            self._setup_session()
        
        params = {
            'fromCcy': from_ccy.upper(),
            'toCcy': to_ccy.upper(),
            'requestFrom': 'PC'
        }
        
        try:
            response = self.session.get(
                XT_RATE_API_URL,
                headers=self._build_headers(),
                params=params,
                timeout=15,
            )
            
            if response.status_code == 200:
                data = response.json()
                # 解析汇率数据
                rate_value = None
                if 'rate' in data:
                    rate_value = data.get('rate')
                elif 'code' in data and data.get('code') == 0 and 'data' in data:
                    data_field = data['data']
                    if isinstance(data_field, dict) and 'rate' in data_field:
                        rate_value = data_field.get('rate')
                    elif isinstance(data_field, (int, float)):
                        rate_value = data_field
                
                if rate_value is not None:
                    return {
                        "from_ccy": from_ccy.upper(),
                        "to_ccy": to_ccy.upper(),
                        "rate": float(rate_value),
                        "status": "成功",
                    }
                else:
                    return {
                        "from_ccy": from_ccy.upper(),
                        "to_ccy": to_ccy.upper(),
                        "rate": None,
                        "status": "未找到汇率",
                    }
            elif response.status_code == 401:
                logger.error(f"XT 认证失败 (401)，Cookie 已过期或无效")
                # 清除缓存，下次会尝试重新登录
                self.cookie_str = ""
                self.xsrf_token = ""
                self.jwt_token = ""
                self.auth_time = None
                try:
                    if os.path.exists(XT_AUTH_CACHE_FILE):
                        os.remove(XT_AUTH_CACHE_FILE)
                except:
                    pass
                return None
            else:
                logger.error(f"XT 查询 {from_ccy}/{to_ccy} 失败: HTTP {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"XT 查询 {from_ccy}/{to_ccy} 异常: {e}")
            return None
    
    def query_all_rates(self, pairs: List[Tuple[str, str, str]] = None) -> List[Dict]:
        """批量查询 XT 汇率
        
        Args:
            pairs: 货币对列表，格式 [(from_ccy, to_ccy, description), ...]
                   如果为 None，默认查询全部 XT_CURRENCY_PAIRS
        """
        if pairs is None:
            pairs = XT_CURRENCY_PAIRS
        
        results = []
        total = len(pairs)
        
        for i, (from_ccy, to_ccy, description) in enumerate(pairs, 1):
            logger.info(f"[{i}/{total}] XT 查询 {from_ccy}/{to_ccy} ({description})...")
            
            rate_data = self.query_single_rate(from_ccy, to_ccy)
            
            # 展示时 CNY → CNH
            display_from = from_ccy
            display_to = to_ccy if to_ccy != "CNY" else "CNH"
            display_pair = f"{display_from}/{display_to}"
            
            if rate_data:
                result = {
                    'pair': display_pair,
                    'from_ccy': from_ccy,
                    'to_ccy': to_ccy,
                    'rate': rate_data.get('rate'),
                    'status': rate_data.get('status', '未知'),
                    'description': description,
                }
                if rate_data.get('rate'):
                    logger.info(f"   ✅ {display_pair}: {rate_data['rate']}")
                else:
                    logger.info(f"   ⚠️ {display_pair}: 未获取到汇率")
            else:
                result = {
                    'pair': display_pair,
                    'from_ccy': from_ccy,
                    'to_ccy': to_ccy,
                    'rate': None,
                    'status': '查询失败',
                    'description': description,
                }
            
            results.append(result)
            
            # 请求间隔
            if i < total:
                time.sleep(0.5)
        
        return results
    
    def get_currency_pairs(self) -> List[Tuple[str, str, str]]:
        """返回 XT 货币对列表"""
        return list(XT_CURRENCY_PAIRS)
    
    # ===================== 结果格式化 =====================
    def format_results(self, results: List[Dict]) -> str:
        """格式化 XT 汇率查询结果为可读文本"""
        if not results:
            return "❌ XT 汇率查询无结果"
        
        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        success_count = len([r for r in results if r.get('status') == '成功'])
        fail_count = len(results) - success_count
        
        response = f"📊 XT 汇率查询结果\n"
        response += f"⏰ 查询时间: {now_str}\n"
        response += f"📈 成功: {success_count} 个 | 失败: {fail_count} 个\n"
        
        if fail_count > 0 and success_count == 0:
            response += f"⚠️ 所有查询均失败，可能原因：\n"
            response += f"   1. XT Cookie 已过期，需要重新登录\n"
            response += f"   2. XT 平台触发 CAPTCHA，无法自动登录\n"
            response += f"   💡 建议：在本地浏览器登录 XT 后导出 Cookie 到 {XT_AUTH_CACHE_FILE}\n"
        
        response += f"{'─' * 40}\n"
        
        # 按货币对分组展示
        for r in results:
            pair = r['pair']
            rate = r['rate']
            status = r['status']
            desc = r.get('description', '')
            
            if rate is not None:
                # 根据货币对类型决定小数位数
                if 'IDR' in pair or 'VND' in pair:
                    rate_str = f"{rate:.2f}"
                elif 'NGN' in pair:
                    rate_str = f"{rate:.6f}"
                elif 'RON' in pair or 'PLN' in pair or 'HUF' in pair:
                    rate_str = f"{rate:.6f}"
                else:
                    rate_str = f"{rate:.6f}"
                response += f"  {pair:<12} {rate_str:<16} [{status}] {desc}\n"
            else:
                response += f"  {pair:<12} {'N/A':<16} [{status}] {desc}\n"
        
        response += f"{'─' * 40}\n"
        
        # 汇总
        if success_count > 0:
            # 列出主要货币对汇率便于快速查看
            major_pairs = ['USD/CNH', 'EUR/CNH', 'GBP/CNH', 'HKD/CNH']
            quick_view = []
            for r in results:
                if r['pair'] in major_pairs and r['rate'] is not None:
                    quick_view.append(f"{r['pair']}={r['rate']:.6f}")
            if quick_view:
                response += f"📌 主要货币: {', '.join(quick_view)}\n"
        
        return response

# ===================== 友商汇率查询模块 =====================
