#!/usr/bin/env python3
# ===================== 飞书机器人独立守护进程 V4 =====================
# 
# 根因：PaykkaSystemManager.__new__() 自动调用 _start_token_auto_refresh()
# 该后台线程会在任意时刻触发 Playwright 登录，与飞书 lark.ws.Client 
# 共用的模块级 asyncio 事件循环冲突，导致 WS 静默崩溃。
#
# 修复策略：
# 1. Monkey-patch _start_token_auto_refresh 为空操作
# 2. 在独立线程+独立事件循环中完成首次登录
# 3. 关闭登录的事件循环后再启动飞书 WS
# 4. Token 过期时由飞书消息处理逻辑按需重新登录

import sys
import os
import time
import signal
import threading
import asyncio
import subprocess
import logging
import traceback
from datetime import datetime
from logging.handlers import RotatingFileHandler

sys.path.insert(0, '/workspace')

# ===================== 日志配置 =====================
LOG_DIR = '/workspace/logs'
os.makedirs(LOG_DIR, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[
        RotatingFileHandler(
            os.path.join(LOG_DIR, 'lark_bot.log'),
            maxBytes=10*1024*1024,
            backupCount=5,
            encoding='utf-8'
        ),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('LarkBotDaemon')

# ===================== 关键：Monkey-patch 禁止自动 Token 刷新 =====================
# 必须在导入 paykka_core 之前 patch（V17 模块化版本）
import paykka_core as _pkv16
_original_start_refresh = _pkv16.PaykkaSystemManager._start_token_auto_refresh

def _noop_start_refresh(self):
    """禁用自动 Token 刷新（避免后台 Playwright 污染事件循环）"""
    logger.info("🚫 Token 自动刷新已禁用（飞书机器人模式）")

_pkv16.PaykkaSystemManager._start_token_auto_refresh = _noop_start_refresh
logger.info("✅ 已 Monkey-patch: 禁用 Token 自动刷新")

# 现在安全导入其余模块（V17 模块化版本）
from paykka_config import (
    LARK_APP_ID,
    LARK_APP_SECRET,
    LARK_ENCRYPT_KEY,
    LARK_VERIFICATION_TOKEN,
)
from paykka_core import PaykkaSystemManager
from paykka_commands import IntegratedCommandProcessor
from paykka_lark import LarkBotHandler

# ===================== 全局状态 =====================
_global_manager = None
_global_processor = None
_running = True
_reconnect_count = 0
_last_reconnect_time = None
_start_time = None
_lock = threading.Lock()

def get_manager():
    global _global_manager
    if _global_manager is None:
        _global_manager = PaykkaSystemManager()
    return _global_manager

def get_processor():
    global _global_processor
    if _global_processor is None:
        manager = get_manager()
        _global_processor = IntegratedCommandProcessor(manager)
    return _global_processor

# ===================== 独立线程登录 =====================
def do_login_isolated():
    """在独立线程+独立事件循环中登录，完成后彻底关闭循环"""
    result = {"token": None, "error": None}
    
    def _login():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            manager = get_manager()
            token = manager.get_token()
            result["token"] = token
            if token:
                logger.info(f"✅ 登录成功 (Token: {len(token)}字符)")
            else:
                result["error"] = "get_token() 返回 None"
                logger.error("❌ 登录失败: Token为空")
        except Exception as e:
            result["error"] = str(e)
            logger.error(f"❌ 登录异常: {e}")
        finally:
            try:
                # 彻底关闭事件循环
                pending = asyncio.all_tasks(loop)
                for task in pending:
                    task.cancel()
                loop.run_until_complete(asyncio.sleep(0.1))
            except:
                pass
            try:
                loop.close()
            except:
                pass
            logger.info("🔒 登录事件循环已关闭")
    
    t = threading.Thread(target=_login, name="PaykkaLogin", daemon=True)
    t.start()
    t.join(timeout=90)
    
    if t.is_alive():
        logger.warning("⚠️ 登录超时(90秒)")
    
    return result["token"]


# ===================== 飞书 WS 客户端 =====================
def build_and_run_lark_ws():
    """构建并启动飞书 WebSocket 客户端（阻塞式）"""
    import lark_oapi as lark
    
    def do_p2_im_message_receive_v1(data: lark.im.v1.P2ImMessageReceiveV1):
        try:
            event_id = data.header.event_id if data.header else "unknown"
            logger.info(f'[消息接收] event_id={event_id}')
            
            processor = get_processor()
            bot_handler = LarkBotHandler(processor)
            bot_handler.handle_message(data)
        except Exception as e:
            logger.error(f"❌ 处理消息失败: {e}")
            logger.error(traceback.format_exc())
    
    def do_customized_event(data: lark.CustomizedEvent):
        logger.info(f'[自定义事件] type={data.event.type if data.event else "?"}')
    
    event_handler = lark.EventDispatcherHandler.builder(
        LARK_ENCRYPT_KEY,
        LARK_VERIFICATION_TOKEN
    ) \
    .register_p2_im_message_receive_v1(do_p2_im_message_receive_v1) \
    .register_p1_customized_event("message", do_customized_event) \
    .build()
    
    ws_client = lark.ws.Client(
        LARK_APP_ID,
        LARK_APP_SECRET,
        event_handler=event_handler,
        log_level=lark.LogLevel.INFO
    )
    
    logger.info("🔗 飞书 WebSocket 连接中...")
    ws_client.start()  # 阻塞


# ===================== 主循环 =====================
def run_bot():
    global _running, _start_time, _reconnect_count, _last_reconnect_time
    
    _start_time = datetime.now()
    logger.info("=" * 60)
    logger.info("🤖 飞书机器人守护进程 V4 启动")
    logger.info(f"⏰ {_start_time.strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"📱 App ID: {LARK_APP_ID}")
    logger.info("=" * 60)
    
    # 步骤1：隔离登录
    logger.info("🔐 步骤1: Paykka 登录（独立事件循环）...")
    token = do_login_isolated()
    if not token:
        logger.warning("⚠️ 登录失败，将在收到指令时自动重试")
    
    # 步骤2：初始化处理器 + 预加载配置器（此时不会触发 Playwright）
    logger.info("🔧 步骤2: 初始化指令处理器...")
    try:
        processor = get_processor()
        logger.info("✅ 处理器就绪")
        
        # 预加载配置器（懒加载方式，首次指令时无需等待初始化）
        try:
            manager = get_manager()
            manager.get_forex_configurator()
            manager.get_routing_configurator()
            manager.get_balance_query()
            manager.get_fx_transaction_monitor()
            manager.get_rate_monitor()
            manager.get_exchange_rate_monitor()
            manager.get_routing_scheduler()
            logger.info("✅ 配置器预加载完成")
        except Exception as e:
            logger.warning(f"⚠️ 配置器预加载部分失败（不影响使用）: {e}")
    except Exception as e:
        logger.error(f"❌ 处理器初始化失败: {e}")
    
    # 步骤2.5：自动启动后台守护任务
    logger.info("🔧 步骤2.5: 自动启动后台守护任务...")
    try:
        processor = get_processor()
        # 启动余额监控（60分钟间隔）
        proc_balance = subprocess.Popen(
            ["python3", "/workspace/balance_monitor.py", "60"],
            stdout=open("/workspace/balance_monitor_output.log", "a"),
            stderr=subprocess.STDOUT,
            cwd="/workspace",
            start_new_session=True
        )
        logger.info(f"✅ 余额监控已启动 (PID: {proc_balance.pid}, 间隔: 60分钟)")
        
        # 启动路由调度
        proc_routing = subprocess.Popen(
            ["python3", "/workspace/routing_scheduler_daemon.py"],
            stdout=open("/workspace/routing_scheduler_output.log", "a"),
            stderr=subprocess.STDOUT,
            cwd="/workspace",
            start_new_session=True
        )
        logger.info(f"✅ 路由调度已启动 (PID: {proc_routing.pid})")
    except Exception as e:
        logger.error(f"❌ 自动启动后台任务失败: {e}")
    
    # 步骤3：飞书 WS
    logger.info("🔗 步骤3: 启动飞书 WebSocket...")
    
    consecutive_failures = 0
    max_backoff = 300
    
    while _running:
        try:
            _reconnect_count += 1
            _last_reconnect_time = datetime.now()
            logger.info(f"🔗 WS 连接尝试 #{_reconnect_count}")
            
            build_and_run_lark_ws()
            
            consecutive_failures = 0
            if _running:
                logger.warning("⚠️ WS 断开，3秒后重连...")
                time.sleep(3)
                
        except Exception as e:
            consecutive_failures += 1
            logger.error(f"❌ WS 异常 (连续{consecutive_failures}次): {e}")
            logger.error(traceback.format_exc())
            
            if not _running:
                break
            
            backoff = min(5 * (2 ** min(consecutive_failures - 1, 6)), max_backoff)
            logger.info(f"⏳ {backoff}秒后重连...")
            for _ in range(backoff):
                if not _running:
                    break
                time.sleep(1)


# ===================== 状态 =====================
def get_bot_status():
    now = datetime.now()
    lines = ["🤖 飞书机器人 V4", "=" * 40]
    lines.append("🟢 运行中" if _running else "🔴 已停止")
    if _start_time:
        s = int((now - _start_time).total_seconds())
        lines.append(f"⏱️  运行: {s//3600}h{(s%3600)//60}m")
    lines.append(f"🔗 连接次数: {_reconnect_count}")
    if _last_reconnect_time:
        lines.append(f"📅 最近连接: {_last_reconnect_time.strftime('%H:%M:%S')}")
    manager = get_manager()
    lines.append(f"🔑 Token: {'有效' if manager._token else '无效'}")
    return "\n".join(lines)

# ===================== 信号 =====================
def handle_shutdown(signum, frame):
    global _running
    logger.info(f"🛑 信号 {signal.Signals(signum).name}，关闭中...")
    _running = False

signal.signal(signal.SIGTERM, handle_shutdown)
signal.signal(signal.SIGINT, handle_shutdown)

# ===================== CLI =====================
def find_running_pid():
    try:
        import subprocess
        # 用更精确的正则，避免匹配到 shell 快照命令行
        r = subprocess.run(
            ["pgrep", "-f", "python3.*lark_bot_daemon\\.py"],
            capture_output=True, text=True
        )
        pids = r.stdout.strip().split('\n')
        current_pid = str(os.getpid())
        valid = []
        for p in pids:
            if not p or p == current_pid:
                continue
            try:
                with open(f"/proc/{p}/cmdline", "r") as f:
                    cmdline = f.read().replace('\x00', ' ')
                if 'lark_bot_daemon.py' in cmdline and 'snapshot' not in cmdline:
                    valid.append(p)
            except:
                pass
        return valid
    except:
        return []

if __name__ == '__main__':
    if len(sys.argv) > 1:
        cmd = sys.argv[1].lower()
        if cmd == 'status':
            pids = find_running_pid()
            if pids:
                print(f"🟢 运行中 PID={pids[0]}")
                print(get_bot_status())
            else:
                print("🔴 未运行")
            sys.exit(0)
        elif cmd == 'stop':
            pids = find_running_pid()
            if pids:
                import subprocess
                for p in pids:
                    subprocess.run(["kill", p])
                time.sleep(2)
                remaining = find_running_pid()
                if remaining:
                    for p in remaining:
                        subprocess.run(["kill", "-9", p])
                print("✅ 已停止")
            else:
                print("ℹ️ 未运行")
            sys.exit(0)
        elif cmd in ('help', '--help', '-h'):
            print("用法: python3 lark_bot_daemon.py [status|stop]")
            sys.exit(0)
        else:
            print(f"未知: {cmd}")
            sys.exit(1)
    
    pids = find_running_pid()
    if pids:
        print(f"⚠️ 已运行 PID={pids[0]}")
        sys.exit(1)
    
    print("🚀 飞书机器人 V4 启动中...")
    run_bot()
    logger.info("👋 已关闭")
