# ===================== paykka_history_quote.py =====================
# PaykkaHistoryQuoteQuery - 路由历史报价查询模块
# 基于 OPS exchange-rate/page API，采样整点/半点数据
# OPS API 限制：单次查询最大 3 天范围，通过分段拼接实现最长7天查询
# 采样策略：只取整点(HH:00)和半点(HH:30)的报价，就近匹配

import json
import time
import requests
import logging
import os
import pandas as pd
from typing import List, Dict, Tuple, Any, Optional
from datetime import datetime, timedelta, timezone
from collections import defaultdict

from paykka_config import *
from paykka_core import build_auth_headers

# 历史查询模块配置
HISTORY_QUOTE_SEGMENT_DAYS = 3      # API 单次最大查询天数（OPS 硬限制）
HISTORY_QUOTE_PAGE_LIMIT = 5000     # 单页最大记录数
HISTORY_QUOTE_MAX_DAYS = 7          # 最大支持查询天数（避免服务器压力）
HISTORY_QUOTE_SAMPLE_MINUTES = 30   # 采样间隔（分钟）：整点和半点

logger = logging.getLogger('paykka_integrated')


class PaykkaHistoryQuoteQuery:
    """路由历史报价查询器 - 采样版
    
    核心策略：
    - OPS API 限制单次查询最大 3 天 → 自动分段
    - 只查询最多 7 天内数据 → 避免服务器压力
    - 全量拉取原始数据后采样 → 只保留整点(HH:00)和半点(HH:30)
    - 就近匹配：如果精确时间点无数据，取最近的一条
    """
    
    def __init__(self, token: str):
        self.token = token
        self.api_url = EXCHANGE_RATE_API_URL
        
        self.segment_days = HISTORY_QUOTE_SEGMENT_DAYS
        self.page_limit = HISTORY_QUOTE_PAGE_LIMIT
        self.max_days = HISTORY_QUOTE_MAX_DAYS
        self.sample_minutes = HISTORY_QUOTE_SAMPLE_MINUTES
        self.max_retries = 2
        self.retry_delay = 1
        
        # 已知来源映射
        self.source_names = {
            "PP": "PingPong",
            "HCE_FX_SPOT": "HCE(Spot)",
            "HCE_FX_TOM": "HCE(TOM)",
            "HCE_FX_TOD": "HCE(TOD)",
            "MDAQ": "MDAQ",
            "MDAQ_FX_SPOT": "MDAQ(Spot)",
            "MDAQ_FX_TOM": "MDAQ(TOM)",
            "YB": "易宝",
            "OCBC": "OCBC",
        }
    
    def _build_headers(self) -> Dict[str, str]:
        return build_auth_headers(self.token)
    
    def _safe_query_page(self, payload: Dict) -> Tuple[bool, Any]:
        """安全的单页查询（带重试）"""
        for attempt in range(self.max_retries + 1):
            try:
                resp = requests.post(
                    self.api_url,
                    headers=self._build_headers(),
                    json=payload,
                    timeout=30
                )
                if resp.status_code == 200:
                    data = resp.json()
                    if isinstance(data, dict):
                        return True, data
                    else:
                        logger.warning(f"API 响应格式异常: {type(data)}")
                        return False, f"响应格式异常"
                elif resp.status_code == 401:
                    logger.error("Token 失效 (401)")
                    return False, "Token 失效"
                else:
                    logger.warning(f"API HTTP {resp.status_code}")
                    if attempt < self.max_retries:
                        time.sleep(self.retry_delay * (attempt + 1))
                        continue
                    return False, f"HTTP {resp.status_code}"
            except requests.exceptions.Timeout:
                logger.warning(f"请求超时 (尝试 {attempt+1})")
                if attempt < self.max_retries:
                    time.sleep(self.retry_delay * (attempt + 1))
                    continue
                return False, "请求超时"
            except Exception as e:
                logger.error(f"查询异常: {e}")
                if attempt < self.max_retries:
                    time.sleep(self.retry_delay * (attempt + 1))
                    continue
                return False, str(e)
        
        return False, "达到最大重试次数"
    
    def _query_segment_all(
        self,
        start_time: str,
        end_time: str,
        base_currency: str = "USD",
        quote_currency: str = "CNH",
    ) -> List[Dict]:
        """查询单个时间段的全量原始数据（自动分页取完）"""
        all_records = []
        offset = 0
        
        while True:
            payload = {
                "offset": offset,
                "limit": self.page_limit,
                "start_time": start_time,
                "end_time": end_time,
                "base_currency": base_currency,
                "quote_currency": quote_currency,
            }
            
            success, data = self._safe_query_page(payload)
            if not success:
                logger.error(f"分页查询失败 offset={offset}")
                break
            
            records = data.get("data", [])
            if not records or not isinstance(records, list) or len(records) == 0:
                break
            
            all_records.extend(records)
            
            total = data.get("total", 0)
            if isinstance(total, (int, float)) and offset + len(records) >= total:
                break
            if len(records) < self.page_limit:
                break
            
            offset += len(records)
            if offset > 100000:
                logger.warning("记录数超过 100000，停止分页")
                break
        
        return all_records
    
    def _generate_sample_slots(
        self,
        start_dt: datetime,
        end_dt: datetime,
    ) -> List[datetime]:
        """生成采样时间槽（整点和半点）
        
        Args:
            start_dt: 开始时间 (timezone-aware)
            end_dt: 结束时间 (timezone-aware)
        
        Returns:
            按时间升序排列的采样时间点列表
        """
        slots = []
        # 从 start 的下一个整点/半点开始
        current = start_dt.replace(second=0, microsecond=0)
        
        # 对齐到最近的采样点
        minute = current.minute
        if minute == 0:
            pass  # 正好整点，从当前开始
        elif minute < 30:
            current = current.replace(minute=30)
        else:
            current = current.replace(minute=0) + timedelta(hours=1)
        
        while current <= end_dt:
            slots.append(current)
            # 下一个采样点：整点 → 半点，半点 → 下一个整点
            if current.minute == 0:
                current = current.replace(minute=30)
            else:
                current = current.replace(minute=0) + timedelta(hours=1)
        
        return slots
    
    def _parse_time(self, time_str: str) -> Optional[datetime]:
        """解析 ISO 时间字符串"""
        if not time_str:
            return None
        try:
            # 处理各种格式
            s = time_str.replace('Z', '+00:00')
            return datetime.fromisoformat(s)
        except (ValueError, TypeError):
            return None
    
    def _sample_records(
        self,
        all_records: List[Dict],
        start_dt: datetime,
        end_dt: datetime,
    ) -> List[Dict]:
        """从全量数据中采样整点/半点数据（就近匹配）
        
        策略：
        1. 生成所有采样时间槽（整点和半点）
        2. 对每个时间槽，在所有来源中找到最接近该时间点的记录
        3. 每个时间槽 × 每个来源最多保留1条记录
        
        Args:
            all_records: 全量原始记录（已按时间排序）
            start_dt: 查询开始时间
            end_dt: 查询结束时间
        
        Returns:
            采样后的记录列表
        """
        if not all_records:
            return []
        
        # 生成采样槽
        slots = self._generate_sample_slots(start_dt, end_dt)
        if not slots:
            return []
        
        # 按来源分组原始数据: {source: [(dt, record), ...]}
        source_data = defaultdict(list)
        for r in all_records:
            dt = self._parse_time(r.get("release_time", ""))
            source = r.get("source", "未知")
            if dt:
                source_data[source].append((dt, r))
        
        # 对每个来源，按时间排序
        for src in source_data:
            source_data[src].sort(key=lambda x: x[0])
        
        # 对每个采样槽，在每个来源中找最接近的记录
        sampled = []
        for slot in slots:
            for source, records in source_data.items():
                closest = self._find_closest(records, slot)
                if closest:
                    sampled.append(closest)
        
        # 去重（同一个记录可能被多个槽匹配）
        seen = set()
        unique = []
        for r in sampled:
            key = (r.get("source", ""), r.get("release_time", ""), r.get("bid_rate", ""))
            if key not in seen:
                seen.add(key)
                unique.append(r)
        
        # 按时间排序
        unique.sort(key=lambda x: x.get("release_time", ""))
        
        logger.info(
            f"采样: {len(all_records)} 条原始数据 → {len(unique)} 条采样点 "
            f"({len(slots)} 个时间槽 × {len(source_data)} 个来源)"
        )
        
        return unique
    
    def _find_closest(
        self,
        records: List[Tuple[datetime, Dict]],
        target: datetime,
    ) -> Optional[Dict]:
        """在记录列表中找到最接近目标时间的记录
        
        Args:
            records: [(datetime, record), ...] 按时间排序的列表
            target: 目标时间
        
        Returns:
            最接近的记录，如果时间差超过采样间隔的1.5倍则返回 None
        """
        if not records:
            return None
        
        # 二分查找最近
        import bisect
        times = [r[0] for r in records]
        idx = bisect.bisect_left(times, target)
        
        candidates = []
        if idx < len(times):
            candidates.append((abs((times[idx] - target).total_seconds()), records[idx][1]))
        if idx > 0:
            candidates.append((abs((times[idx - 1] - target).total_seconds()), records[idx - 1][1]))
        
        if not candidates:
            return None
        
        candidates.sort(key=lambda x: x[0])
        best_diff, best_record = candidates[0]
        
        # 容忍范围：采样间隔的 1.5 倍（即 45 分钟）
        max_diff = self.sample_minutes * 60 * 1.5
        if best_diff > max_diff:
            return None
        
        return best_record
    
    def query_history(
        self,
        base_currency: str = "USD",
        quote_currency: str = "CNH",
        days: int = 3,
        sources: Optional[List[str]] = None,
    ) -> Dict:
        """查询过去 N 天的历史报价（采样版）
        
        Args:
            base_currency: 基础货币（默认 USD）
            quote_currency: 报价货币（默认 CNH）
            days: 查询天数（1-7天）
            sources: 可选，过滤特定来源
        
        Returns:
            {
                "success": bool,
                "records": List[Dict],        # 采样后的记录
                "raw_count": int,              # 原始拉取条数
                "total_count": int,            # 采样后条数
                "segments": int,
                "time_range": str,
                "sources_summary": Dict,
                "sample_slots": int,           # 采样槽数量
                "error": str or None,
            }
        """
        # 限制天数
        days = max(1, min(days, self.max_days))
        
        now = datetime.now(timezone.utc)
        end_dt = now
        start_dt = end_dt - timedelta(days=days)
        
        result = {
            "success": False,
            "records": [],
            "raw_count": 0,
            "total_count": 0,
            "segments": 0,
            "time_range": "",
            "sources_summary": {},
            "sample_slots": 0,
            "error": None,
        }
        
        # 构建时间分段
        segments = []
        remaining = timedelta(days=days)
        seg_end = end_dt
        
        while remaining > timedelta(0):
            seg_delta = min(timedelta(days=self.segment_days), remaining)
            seg_start = seg_end - seg_delta
            segments.append((
                seg_start.strftime("%Y-%m-%dT%H:%M:%SZ"),
                seg_end.strftime("%Y-%m-%dT%H:%M:%SZ"),
            ))
            seg_end = seg_start
            remaining -= seg_delta
        
        logger.info(
            f"📊 历史报价查询: {base_currency}/{quote_currency}, "
            f"{days}天, {len(segments)}段, 采样间隔{self.sample_minutes}分钟"
        )
        
        # 阶段1：拉取全量原始数据
        all_raw = []
        for i, (seg_start, seg_end) in enumerate(segments, 1):
            logger.info(f"  拉取第 {i}/{len(segments)} 段: {seg_start[:10]} → {seg_end[:10]}")
            seg_records = self._query_segment_all(
                start_time=seg_start,
                end_time=seg_end,
                base_currency=base_currency,
                quote_currency=quote_currency,
            )
            logger.info(f"  第 {i} 段: {len(seg_records)} 条原始记录")
            all_raw.extend(seg_records)
            
            if i < len(segments):
                time.sleep(0.3)
        
        result["raw_count"] = len(all_raw)
        logger.info(f"  全量拉取完成: {len(all_raw)} 条")
        
        # 阶段2：采样
        sampled = self._sample_records(all_raw, start_dt, end_dt)
        
        # 按来源过滤
        if sources:
            sources_upper = [s.upper() for s in sources]
            sampled = [r for r in sampled if r.get("source", "").upper() in sources_upper]
        
        # 统计
        source_counts = defaultdict(int)
        for r in sampled:
            source_counts[r.get("source", "未知")] += 1
        
        result["success"] = True
        result["records"] = sampled
        result["total_count"] = len(sampled)
        result["segments"] = len(segments)
        result["time_range"] = f"{start_dt.strftime('%Y-%m-%d %H:%M')} → {end_dt.strftime('%Y-%m-%d %H:%M')}"
        result["sources_summary"] = dict(source_counts)
        
        # 计算采样槽数量
        slots = self._generate_sample_slots(start_dt, end_dt)
        result["sample_slots"] = len(slots)
        
        logger.info(
            f"✅ 历史报价完成: 原始{len(all_raw)}条 → 采样{len(sampled)}条 "
            f"({len(slots)}个时间槽 × {len(source_counts)}个来源)"
        )
        
        return result
    
    def _aggregate_by_day(self, records: List[Dict]) -> Dict[str, Dict]:
        """按天聚合采样数据"""
        daily = defaultdict(lambda: {"sources": defaultdict(list), "day_avg": None})
        
        for r in records:
            release_time = r.get("release_time", "")
            if not release_time:
                continue
            day = release_time[:10]
            source = r.get("source", "未知")
            bid_rate = r.get("bid_rate")
            if bid_rate is not None:
                try:
                    daily[day]["sources"][source].append(float(bid_rate))
                except (ValueError, TypeError):
                    pass
        
        for day, data in daily.items():
            all_rates = []
            for rates in data["sources"].values():
                all_rates.extend(rates)
            if all_rates:
                data["day_avg"] = sum(all_rates) / len(all_rates)
        
        return dict(daily)
    
    # ===================== 图表生成 =====================
    CHART_DIR = "/workspace/logs/charts"
    
    def generate_chart(
        self,
        result: Dict,
        base_currency: str = "USD",
        quote_currency: str = "CNH",
        save_path: str = None,
    ) -> str:
        """生成多渠道历史报价对比走势图
        
        Args:
            result: query_history 的返回结果
            base_currency: 基础货币
            quote_currency: 报价货币
            save_path: 保存路径，默认自动生成
        
        Returns:
            图表文件路径，失败返回空字符串
        """
        records = result.get("records", [])
        if not records:
            logger.warning("无数据可生成图表")
            return ""
        
        try:
            import matplotlib
            matplotlib.use('Agg')
            import matplotlib.pyplot as plt
            import matplotlib.dates as mdates
            from matplotlib.ticker import ScalarFormatter
            import matplotlib.font_manager as fm
            
            # 中文字体
            cjk_font_path = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
            if os.path.exists(cjk_font_path):
                cjk_prop = fm.FontProperties(fname=cjk_font_path)
                plt.rcParams['font.family'] = cjk_prop.get_name()
            else:
                plt.rcParams['font.sans-serif'] = ['Noto Sans CJK JP', 'Noto Sans CJK SC', 'SimHei', 'DejaVu Sans']
            plt.rcParams['axes.unicode_minus'] = False
            
            # 按来源分组：{source: [(dt, rate), ...]}
            source_series = defaultdict(list)
            for r in records:
                dt = self._parse_time(r.get("release_time", ""))
                bid = r.get("bid_rate")
                source = r.get("source", "未知")
                if dt and bid is not None:
                    try:
                        source_series[source].append((dt, float(bid)))
                    except (ValueError, TypeError):
                        pass
            
            if not source_series:
                return ""
            
            # 对每个来源按时间排序
            for src in source_series:
                source_series[src].sort(key=lambda x: x[0])
            
            # 颜色方案（最多支持12个渠道）
            colors = [
                '#2196F3', '#FF5722', '#4CAF50', '#FF9800', '#9C27B0',
                '#00BCD4', '#E91E63', '#3F51B5', '#8BC34A', '#FFC107',
                '#795548', '#607D8B',
            ]
            
            fig, ax = plt.subplots(figsize=(14, 7))
            
            # 按数据量排序，数据多的先画（作为底色）
            sorted_sources = sorted(source_series.items(), key=lambda x: -len(x[1]))
            
            for i, (source, points) in enumerate(sorted_sources):
                times = [p[0] for p in points]
                rates = [p[1] for p in points]
                
                color = colors[i % len(colors)]
                src_label = self.source_names.get(source, source)
                
                if len(points) >= 20:
                    # 数据点多时：细线+小点
                    ax.plot(times, rates, color=color, linewidth=1.2, marker='.', 
                           markersize=2, alpha=0.85, label=f'{src_label} ({source})')
                else:
                    # 数据点少时：突出显示
                    ax.plot(times, rates, color=color, linewidth=1.5, marker='o',
                           markersize=4, alpha=0.9, label=f'{src_label} ({source})')
            
            # 格式化
            pair = f"{base_currency}/{quote_currency}"
            days = result.get("segments", 0) * self.segment_days
            time_range = result.get("time_range", "")
            
            ax.set_title(f'路由渠道历史报价对比 - {pair}\n{time_range} ({days}天 · 整点/半点采样)', 
                        fontsize=13, fontweight='bold')
            ax.set_xlabel('时间', fontsize=10)
            ax.set_ylabel('汇率', fontsize=10)
            
            # 图例放外面，避免遮挡
            ax.legend(loc='upper left', bbox_to_anchor=(1.01, 1), fontsize=8, 
                     framealpha=0.9, ncol=1 if len(sorted_sources) <= 6 else 2)
            ax.grid(True, alpha=0.25, linestyle='--')
            
            # X 轴时间格式
            total_hours = (times[-1] - times[0]).total_seconds() / 3600 if times else 0
            if total_hours > 72:
                ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
                ax.xaxis.set_major_locator(mdates.DayLocator())
            elif total_hours > 24:
                ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d %H:%M'))
                ax.xaxis.set_major_locator(mdates.HourLocator(interval=6))
            else:
                ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d %H:%M'))
                ax.xaxis.set_major_locator(mdates.HourLocator(interval=3))
            plt.xticks(rotation=45, ha='right')
            
            # Y 轴精度
            all_rates = [p[1] for src, points in sorted_sources for p in points]
            if all_rates:
                avg_rate = sum(all_rates) / len(all_rates)
                if avg_rate < 0.01:
                    ax.ticklabel_format(axis='y', style='plain', useOffset=False)
            
            plt.tight_layout()
            
            # 确保目录存在
            os.makedirs(self.CHART_DIR, exist_ok=True)
            
            if not save_path:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                safe_pair = pair.replace("/", "_")
                save_path = os.path.join(self.CHART_DIR, f"route_history_{safe_pair}_{timestamp}.png")
            
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            plt.close(fig)
            
            logger.info(f"📊 路由历史图表已保存: {save_path} ({len(sorted_sources)} 渠道)")
            return save_path
            
        except Exception as e:
            logger.error(f"生成路由历史图表失败: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return ""
    
    def format_results(
        self,
        result: Dict,
        base_currency: str = "USD",
        quote_currency: str = "CNH",
        days: int = 3,
    ) -> str:
        """格式化查询结果为飞书消息文本"""
        if not result.get("success"):
            return f"❌ 历史报价查询失败: {result.get('error', '未知错误')}"
        
        records = result.get("records", [])
        total = result.get("total_count", 0)
        raw_count = result.get("raw_count", 0)
        time_range = result.get("time_range", "")
        sources_summary = result.get("sources_summary", {})
        sample_slots = result.get("sample_slots", 0)
        
        if total == 0:
            return (
                f"📊 {base_currency}/{quote_currency} 历史报价查询\n"
                f"⏰ 时间范围: {time_range}\n"
                f"⚠️ 未获取到采样数据（可能非交易时段或数据缺失）\n"
                f"   原始拉取: {raw_count} 条"
            )
        
        pair = f"{base_currency}/{quote_currency}"
        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        response = f"📊 **路由历史报价查询（采样版）**\n"
        response += f"💱 货币对: {pair}\n"
        response += f"📅 时间范围: {time_range} ({days}天)\n"
        response += f"⏱️ 采样策略: 整点(HH:00) + 半点(HH:30)，就近匹配\n"
        response += f"📈 采样结果: {total} 个数据点 ({sample_slots} 个时间槽)\n"
        response += f"📦 原始拉取: {raw_count} 条 → 采样压缩 {total} 条\n"
        response += f"⏰ 查询时间: {now_str}\n"
        response += f"\n"
        
        # 来源分布
        response += f"🏦 **各渠道采样点数:**\n"
        for src, count in sorted(sources_summary.items(), key=lambda x: -x[1]):
            src_name = self.source_names.get(src, src)
            response += f"  • {src_name} ({src}): {count} 点\n"
        
        response += f"\n"
        
        # 按天汇总
        daily = self._aggregate_by_day(records)
        response += f"📅 **每日均价汇总:**\n"
        
        days_sorted = sorted(daily.keys(), reverse=True)
        for day in days_sorted:
            data = daily[day]
            avg = data.get("day_avg")
            if avg is not None:
                if quote_currency in ("IDR", "VND"):
                    avg_str = f"{avg:.2f}"
                else:
                    avg_str = f"{avg:.6f}"
                
                all_rates = []
                for rates in data["sources"].values():
                    all_rates.extend(rates)
                
                if all_rates:
                    high = max(all_rates)
                    low = min(all_rates)
                    # 当天来源数
                    src_count = len(data["sources"])
                    response += f"  • {day}: 均价 {avg_str} | 高 {high:.6f} | 低 {low:.6f} | {src_count}渠道\n"
        
        response += f"\n"
        
        # 最新采样点
        if records:
            latest = records[-1]
            response += f"📌 **最新采样点:** {latest.get('source', '?')} "
            response += f"bid={latest.get('bid_rate', 'N/A')} "
            response += f"({latest.get('release_time', 'N/A')[:19]})\n"
        
        return response
    
    def export_to_excel(self, result: Dict, filepath: str = None) -> str:
        """导出采样结果为 Excel"""
        records = result.get("records", [])
        if not records:
            raise ValueError("无数据可导出")
        
        if filepath is None:
            pair = f"{result.get('base_currency', 'USD')}_{result.get('quote_currency', 'CNH')}"
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filepath = f"history_quote_{pair}_{timestamp}.xlsx"
        
        rows = []
        for r in records:
            rows.append({
                "来源(source)": r.get("source", ""),
                "买入价(bid_rate)": r.get("bid_rate", ""),
                "卖出价(ask_rate)": r.get("ask_rate", ""),
                "发布时间(release_time)": r.get("release_time", ""),
                "基础货币(base_currency)": r.get("base_currency", ""),
                "报价货币(quote_currency)": r.get("quote_currency", ""),
            })
        
        df = pd.DataFrame(rows)
        df.to_excel(filepath, index=False, engine='openpyxl')
        logger.info(f"📁 历史报价已导出: {filepath} ({len(rows)} 条)")
        return filepath


# ===================== 便捷函数 =====================

def quick_history_query(
    token: str,
    base: str = "USD",
    quote: str = "CNH",
    days: int = 3,
    sources: Optional[List[str]] = None,
) -> str:
    """便捷函数：查询历史报价并返回格式化文本"""
    query = PaykkaHistoryQuoteQuery(token)
    result = query.query_history(
        base_currency=base,
        quote_currency=quote,
        days=days,
        sources=sources,
    )
    return query.format_results(result, base, quote, days)
