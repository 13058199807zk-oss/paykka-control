#!/usr/bin/env python3
"""快速验证 XT 登录页元素选择器"""
import asyncio, os
from playwright.async_api import async_playwright

async def main():
    os.environ['DISPLAY'] = ':99'
    
    playwright = await async_playwright().start()
    browser = await playwright.chromium.launch(
        headless=False,
        args=["--no-sandbox", "--disable-dev-shm-usage", "--window-size=1280,720"]
    )
    context = await browser.new_context(viewport={"width": 1280, "height": 720})
    page = await context.new_page()
    
    print("🌐 访问登录页...")
    await page.goto("https://www.xtransfer.cn/login", timeout=30000, wait_until="domcontentloaded")
    await asyncio.sleep(3)
    
    # 检查各种选择器
    selectors = [
        ("#accountLoginMobileInput", "手机号输入框"),
        ("#accountLoginPasswordInput", "密码输入框"),
        ("button:has-text('登录')", "登录按钮(中文)"),
        ("button:has-text('Login')", "登录按钮(英文)"),
        ("text=手机号码", "手机号码标签"),
        ("text=邮箱/账号", "邮箱标签"),
        ("text=密码登录", "密码登录标题"),
        (".geetest_holder", "geetest验证码"),
        ("[class*='captcha']", "captcha类元素"),
    ]
    
    for sel, name in selectors:
        try:
            el = await page.query_selector(sel)
            if el:
                visible = await el.is_visible()
                text = await el.text_content()
                print(f"  ✅ {name}: 找到, visible={visible}, text='{text[:30] if text else ''}'")
            else:
                print(f"  ❌ {name}: 未找到")
        except Exception as e:
            print(f"  ⚠️ {name}: 错误 {e}")
    
    # 检查所有按钮
    print("\n📋 所有按钮:")
    buttons = await page.query_selector_all("button")
    for i, btn in enumerate(buttons):
        try:
            text = await btn.text_content()
            visible = await btn.is_visible()
            print(f"  [{i}] text='{text.strip() if text else ''}', visible={visible}")
        except:
            pass
    
    # 截图
    await page.screenshot(path="/workspace/xt_selector_test.png", full_page=True)
    print("\n📸 截图已保存")
    
    await browser.close()

asyncio.run(main())
