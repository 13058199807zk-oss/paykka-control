# ===================== paykka_core.py =====================
# PAYKKA 系统核心管理器（全局单例）
# 从 paykka_controllerV16.py 提取

import json
import pyotp
import time
import urllib.parse
import requests
import re
import threading
import os
import hashlib
from typing import List, Dict, Tuple, Any, Optional, Union
from playwright.async_api import async_playwright
import asyncio
from datetime import datetime, date, timedelta, timezone, time as dtime
from github import Github, InputGitAuthor
import pandas as pd
import base64
import pytz
import schedule

from paykka_config import *
from paykka_dedup import MessageDeduplicator
import traceback

class PaykkaSystemManager:
    """PAYKKA系统管理器（全局单例） - 增强版，支持自动重连和定时Token刷新"""
    _instance = None
    _forex_configurator = None
    _routing_configurator = None
    _balance_query = None
    _fx_transaction_monitor = None
    _rate_monitor = None
    _token = None
    _last_login_time = None
    _deduplicator = None
    _login_lock = threading.Lock()  # 新增：登录锁，防止并发登录
    _is_refreshing = False  # 新增：刷新状态标志
    _exchange_rate_monitor = None  # 新增：路由价格监控器
    _xt_rate_query = None  # 新增：XT 汇率查询器
    _fx_monitoring_task = None  # 新增：全局定时任务实例
    _balance_monitoring_task = None
    _routing_scheduler = None  # 新增：路由调度器
    # 新增：Token自动刷新相关
    _token_refresh_thread = None
    _token_refresh_stop_event = None
    _token_refresh_times = ["13:00", "01:00"]  # 每天两次刷新时间
    _token_refresh_interval = 12 * 3600  # 12小时（秒），作为备用的固定间隔

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._deduplicator = MessageDeduplicator()
            # 启动Token自动刷新任务（原第一个__new__中的逻辑，合并到此处）
            cls._instance._start_token_auto_refresh()
        return cls._instance

    def _start_token_auto_refresh(self):
        """启动Token自动刷新任务"""
        if self._token_refresh_thread and self._token_refresh_thread.is_alive():
            logger.warning("Token自动刷新任务已在运行中")
            return

        self._token_refresh_stop_event = threading.Event()
        self._token_refresh_thread = threading.Thread(
            target=self._token_refresh_loop,
            name="TokenAutoRefresh",
            daemon=True
        )
        self._token_refresh_thread.start()
        logger.info("✅ Token自动刷新任务已启动")

    def _stop_token_auto_refresh(self):
        """停止Token自动刷新任务"""
        if self._token_refresh_stop_event:
            self._token_refresh_stop_event.set()
        
        if self._token_refresh_thread and self._token_refresh_thread.is_alive():
            self._token_refresh_thread.join(timeout=5.0)
            logger.info("🛑 Token自动刷新任务已停止")
    
    def _calculate_next_refresh_time(self) -> datetime:
        """计算下一次刷新Token的时间"""
        now = datetime.now()
        
        # 将刷新时间转换为datetime对象
        refresh_times = []
        for time_str in self._token_refresh_times:
            hour, minute = map(int, time_str.split(":"))
            # 创建今天的刷新时间
            refresh_time = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            
            # 如果今天的刷新时间已过，就是明天
            if refresh_time <= now:
                refresh_time += timedelta(days=1)
            
            refresh_times.append(refresh_time)
        
        # 返回最近的下一次刷新时间
        return min(refresh_times)
    
    def _refresh_token_with_retry(self, max_retries=3, retry_delay=60):
        """刷新Token（带重试机制）- 修复事件循环冲突"""
    
        for attempt in range(max_retries):
            try:
                logger.info(f"🔄 第{attempt+1}次尝试刷新Token...")
            
                # 方法1：检查是否已经有运行的事件循环
                try:
                    # 尝试获取当前线程的事件循环
                    loop = asyncio.get_event_loop()
                
                    # 检查事件循环是否已经在运行
                    if loop.is_running():
                        # 事件循环已经在运行，使用run_coroutine_threadsafe在新线程中运行
                        logger.info("检测到已有运行的事件循环，使用新线程运行异步登录")
                    
                        # 创建新的事件循环并在新线程中运行
                    
                        # 使用线程池运行异步函数
                        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                            future = executor.submit(self._run_async_login_in_thread, force=True)
                            token = future.result(timeout=120)  # 120秒超时
                    else:
                        # 事件循环存在但没有运行，可以直接使用
                        logger.info("事件循环存在但未运行，使用run_until_complete")
                        token = loop.run_until_complete(self.login(force=True))
                except RuntimeError:
                    # 没有事件循环，创建新的
                    logger.info("没有事件循环，创建新的")
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        token = loop.run_until_complete(self.login(force=True))
                    finally:
                        loop.close()
            
                if token:
                    logger.info(f"✅ Token刷新成功，新Token长度: {len(token)}")
                
                    # 更新所有已初始化的模块的Token
                    self._update_all_modules_token(token)
                
                    # 记录刷新时间
                    self._last_login_time = time.time()
                    logger.info(f"📅 Token已更新到所有模块，有效期重新开始计算")
                    return True
                else:
                    logger.error("❌ Token刷新失败，返回为空")
        
            except Exception as e:
                logger.error(f"❌ Token刷新异常（第{attempt+1}次）: {e}")
                logger.error(traceback.format_exc())
        
            # 如果不是最后一次重试，等待后继续
            if attempt < max_retries - 1:
                logger.info(f"⏸️ 等待{retry_delay}秒后重试...")
                time.sleep(retry_delay)
    
        logger.error(f"❌ Token刷新失败，已达最大重试次数{max_retries}")
        return False

    def _run_async_login_in_thread(self, force=False):
        """在新线程中运行异步登录函数"""
    
        result = None
    
        def run_in_thread():
            """在新线程中运行的事件循环"""
            nonlocal result
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                result = loop.run_until_complete(self.login(force))
            except Exception as e:
                logger.error(f"新线程中登录失败: {e}")
            finally:
                loop.close()
    
        # 创建并启动线程
        thread = threading.Thread(target=run_in_thread, daemon=True)
        thread.start()
        thread.join(timeout=120)  # 等待120秒
    
        return result
    
    def _update_all_modules_token(self, new_token: str):
        """更新所有已初始化模块的Token"""
        modules_updated = 0
        
        if self._forex_configurator:
            self._forex_configurator.token = new_token
            modules_updated += 1
        
        if self._routing_configurator:
            self._routing_configurator.token = new_token
            modules_updated += 1
        
        if self._balance_query:
            self._balance_query.token = new_token
            modules_updated += 1
        
        if self._fx_transaction_monitor:
            self._fx_transaction_monitor.token = new_token
            modules_updated += 1
        
        if self._rate_monitor:
            self._rate_monitor.token = new_token
            modules_updated += 1
        
        if self._exchange_rate_monitor:
            self._exchange_rate_monitor.token = new_token
            modules_updated += 1
        
        if self._routing_scheduler:
            self._routing_scheduler.token = new_token
            modules_updated += 1
        
        # 更新全局Token
        self._token = new_token
        logger.info(f"✅ Token已更新到 {modules_updated} 个模块")
    
    def _token_refresh_loop(self):
        """Token自动刷新循环"""
        logger.info(f"⏰ Token自动刷新任务启动，刷新时间: {', '.join(self._token_refresh_times)}")
        
        # 首次启动时，立即刷新一次（确保Token是最新的）
        logger.info("🔄 程序启动，立即刷新Token...")
        self._refresh_token_with_retry()
        
        while not self._token_refresh_stop_event.is_set():
            try:
                # 计算下一次刷新时间
                next_refresh_time = self._calculate_next_refresh_time()
                wait_seconds = (next_refresh_time - datetime.now()).total_seconds()
                
                if wait_seconds > 0:
                    logger.info(f"⏰ 下次Token刷新时间: {next_refresh_time.strftime('%Y-%m-%d %H:%M:%S')} (还有{wait_seconds/3600:.1f}小时)")
                    
                    # 等待到刷新时间
                    self._token_refresh_stop_event.wait(timeout=min(wait_seconds, 3600))  # 最长等待1小时
                else:
                    # 已经到了刷新时间，立即执行
                    self._refresh_token_with_retry()
                    
                    # 执行后短暂休眠，避免CPU占用过高
                    self._token_refresh_stop_event.wait(timeout=60)
                    
            except Exception as e:
                logger.error(f"❌ Token自动刷新循环异常: {e}")
                # 发生异常时，等待1小时后重试
                self._token_refresh_stop_event.wait(timeout=600)

    def get_routing_scheduler(self):
        """获取路由调度器"""
        if not self._routing_scheduler:
            from paykka_routing_sched import RoutingScheduler
            token = self.get_token()
            if not token:
                raise Exception("无法获取Token，请检查登录凭据")
            self._routing_scheduler = RoutingScheduler(token)
        return self._routing_scheduler
    
    def get_fx_monitoring_task(self):
        """获取全局交易监控定时任务实例"""
        return self._fx_monitoring_task
    
    def set_fx_monitoring_task(self, task):
        """设置全局交易监控定时任务实例"""
        self._fx_monitoring_task = task
    
    def clear_fx_monitoring_task(self):
        """清除全局交易监控定时任务实例"""
        if self._fx_monitoring_task:
            # 停止任务
            if self._fx_monitoring_task.is_running:
                self._fx_monitoring_task.stop()
            self._fx_monitoring_task = None

    def get_balance_monitoring_task(self):
        """获取全局余额监控定时任务实例"""
        return self._balance_monitoring_task
    
    def set_balance_monitoring_task(self, task):
        """设置全局余额监控定时任务实例"""
        self._balance_monitoring_task = task
    
    def clear_balance_monitoring_task(self):
        """清除全局余额监控定时任务实例"""
        if self._balance_monitoring_task:
            # 停止任务
            if self._balance_monitoring_task.is_running:
                self._balance_monitoring_task.stop()
            self._balance_monitoring_task = None
    
    # __new__ 已在类上方定义（含 _start_token_auto_refresh 调用），此处不再重复定义
    
    async def login(self, force=False):
        """登录获取Token（带锁的线程安全版本）"""
        with self._login_lock:
            if self._token and not force:
                # 检查Token是否过期（超过24小时）
                if self._last_login_time and (time.time() - self._last_login_time) < 86400:
                    return self._token
            
            logger.info("🔐 开始全局自动登录...")
            token = await paykka_auto_login_with_otp(
                PAYKKA_USERNAME, 
                PAYKKA_PASSWORD, 
                PAYKKA_OTP_SECRET
            )
            
            if token:
                self._token = token
                self._last_login_time = time.time()
                logger.info(f"✅ 全局登录成功，Token长度: {len(token)}")
                self._is_refreshing = False
            else:
                logger.error("❌ 全局登录失败")
                
            return self._token
    
    def refresh_token_if_needed(self, api_response=None):
        """
        智能Token刷新：根据API响应判断是否需要刷新Token
        返回：(是否需要重试, 新的Token或None)
        """
        # 情况1：API返回明确的认证错误
        if api_response and isinstance(api_response, dict):
            ret_code = api_response.get('ret_code')
            if ret_code in ['010112', '401', '403']:  # 认证相关错误码
                logger.warning(f"⚠️ 检测到认证错误 {ret_code}，触发自动Token刷新")
                new_token = self.refresh_token()
                return True, new_token
        
        # 情况2：Token为空或明显无效
        if not self._token or len(self._token) < 10:
            logger.warning("⚠️ Token无效或过短，触发自动刷新")
            new_token = self.refresh_token()
            return True, new_token
        
        # 情况3：Token过期（超过24小时）
        if self._last_login_time and (time.time() - self._last_login_time) > 86400:
            logger.warning("⚠️ Token已过期（>24小时），触发自动刷新")
            new_token = self.refresh_token()
            return True, new_token
        
        return False, self._token
    
    def refresh_token(self):
        """刷新Token（强制重新登录）并更新所有依赖模块 - 使用线程安全的异步调用"""
        logger.info("🔄 强制刷新Token...")
        self._is_refreshing = True
        
        # 使用已有的 _refresh_token_with_retry 方法，内部已正确处理异步调用
        success = self._refresh_token_with_retry(max_retries=2, retry_delay=30)
        
        self._is_refreshing = False
        return self._token if success else None
    
    def safe_api_call(self, api_func, *args, **kwargs):
        """
        安全的API调用封装，自动处理Token过期和重试
        参数:
            api_func: 要执行的API函数
            max_retries: 最大重试次数（默认2）
            retry_delay: 重试延迟秒数（默认1）
        返回: (成功标志, 结果或错误信息)
        """
        max_retries = kwargs.pop('max_retries', 2)
        retry_delay = kwargs.pop('retry_delay', 1)
        
        for attempt in range(max_retries + 1):
            try:
                result = api_func(*args, **kwargs)
                
                # 检查API响应是否需要刷新Token
                if isinstance(result, dict) and 'ret_code' in result:
                    need_retry, new_token = self.refresh_token_if_needed(result)
                    if need_retry and attempt < max_retries:
                        logger.info(f"🔄 认证失败，第{attempt+1}次重试...")
                        time.sleep(retry_delay)
                        continue
                
                return True, result
                
            except requests.exceptions.ConnectionError as e:
                if attempt < max_retries:
                    logger.warning(f"🔌 网络连接失败，第{attempt+1}次重试: {e}")
                    time.sleep(retry_delay * 2)  # 网络错误等待更久
                else:
                    return False, f"网络连接失败: {e}"
                    
            except requests.exceptions.Timeout as e:
                if attempt < max_retries:
                    logger.warning(f"⏰ 请求超时，第{attempt+1}次重试")
                    time.sleep(retry_delay)
                else:
                    return False, f"请求超时: {e}"
                    
            except Exception as e:
                # 其他异常，检查是否是认证相关
                error_str = str(e).lower()
                if any(auth_keyword in error_str for auth_keyword in ['auth', 'token', 'unauthorized', 'forbidden']):
                    if attempt < max_retries:
                        logger.warning(f"🔐 认证异常，第{attempt+1}次重试: {e}")
                        self.refresh_token()
                        time.sleep(retry_delay)
                        continue
                
                return False, f"API调用异常: {e}"
        
        return False, "达到最大重试次数"
    
    def get_token(self):
        """获取Token（如果不存在或已过期则自动刷新）"""
        if not self._token:
            # Token不存在，使用线程安全的方式刷新
            success = self._refresh_token_with_retry(max_retries=1, retry_delay=10)
            if not success:
                logger.error("❌ 无法获取Token，自动登录失败")
            return self._token
        
        # 检查Token是否接近过期（超过20小时视为即将过期）
        if self._last_login_time and (time.time() - self._last_login_time) > 20 * 3600:
            logger.warning("⚠️ Token已使用超过20小时，主动刷新")
            self._refresh_token_with_retry(max_retries=1, retry_delay=10)
        
        return self._token
    
    def get_forex_configurator(self):
        """获取汇差配置器"""
        if not self._forex_configurator:
            from paykka_forex_config import PaykkaForexConfigurator
            token = self.get_token()
            if not token:
                raise Exception("无法获取Token，请检查登录凭据")
            self._forex_configurator = PaykkaForexConfigurator(token)
        return self._forex_configurator
    
    def get_routing_configurator(self):
        """获取路由配置器"""
        if not self._routing_configurator:
            from paykka_routing_config import PaykkaRoutingConfigurator
            token = self.get_token()
            if not token:
                raise Exception("无法获取Token，请检查登录凭据")
            self._routing_configurator = PaykkaRoutingConfigurator(token)
        return self._routing_configurator
    
    def get_balance_query(self):
        """获取余额查询器"""
        if not self._balance_query:
            from paykka_balance import PaykkaBalanceQuery
            token = self.get_token()
            if not token:
                raise Exception("无法获取Token，请检查登录凭据")
            self._balance_query = PaykkaBalanceQuery(token)
        return self._balance_query
    
    def get_fx_transaction_monitor(self):
        """获取换汇交易监控器"""
        if not self._fx_transaction_monitor:
            from paykka_fx_monitor import PaykkaFxTransactionMonitor
            token = self.get_token()
            if not token:
                raise Exception("无法获取Token，请检查登录凭据")
            self._fx_transaction_monitor = PaykkaFxTransactionMonitor(token)
        return self._fx_transaction_monitor
    
    def get_rate_monitor(self):
        """获取汇率监控器"""
        if not self._rate_monitor:
            from paykka_rate_monitor import PaykkaRateMonitor
            token = self.get_token()
            if not token:
                raise Exception("无法获取Token，请检查登录凭据")
            self._rate_monitor = PaykkaRateMonitor(token)
        return self._rate_monitor
    
    def get_deduplicator(self):
        """获取消息去重器"""
        return self._deduplicator

    def get_exchange_rate_monitor(self):
        """获取路由价格监控器"""
        if not self._exchange_rate_monitor:
            from paykka_exchange_rate import PaykkaExchangeRateMonitor
            token = self.get_token()
            if not token:
                raise Exception("无法获取Token，请检查登录凭据")
            self._exchange_rate_monitor = PaykkaExchangeRateMonitor(token)
        return self._exchange_rate_monitor
    
    def get_xt_rate_query(self):
        """获取 XT 汇率查询器"""
        if not self._xt_rate_query:
            from paykka_xt_rate import XTRateQueryManager
            self._xt_rate_query = XTRateQueryManager()
        return self._xt_rate_query
    
    # ===================== 历史报价查询器 =====================
    _history_quote_query = None
    
    def get_history_quote_query(self):
        """获取历史报价查询器"""
        if not self._history_quote_query:
            from paykka_history_quote import PaykkaHistoryQuoteQuery
            token = self.get_token()
            if not token:
                raise Exception("无法获取Token，请检查登录凭据")
            self._history_quote_query = PaykkaHistoryQuoteQuery(token)
        return self._history_quote_query

# ===================== 消息去重管理器 =====================

# ===================== 企业微信群机器人通知 =====================
def send_wechat_work_message(message: str) -> bool:
    """向企业微信群机器人发送消息"""
    try:
        payload = {
            "msgtype": "text",
            "text": {
                "content": message
            }
        }
        
        response = requests.post(
            WECHAT_WEBHOOK_URL,
            json=payload,
            headers={'Content-Type': 'application/json'},
            timeout=10
        )
        
        result = response.json()
        if result.get("errcode") == 0:
            logger.info(f"✅ 企业微信群消息发送成功: {message}")
            return True
        else:
            logger.error(f"❌ 企业微信群消息发送失败: {result.get('errmsg')}")
            return False
            
    except Exception as e:
        logger.error(f"❌ 发送企业微信群消息异常: {e}")
        return False

# ===================== GitHub文件上传工具函数 =====================
def upload_to_github_md(content: str, file_path: str, commit_message: str = "Auto update") -> bool:
    """上传Markdown内容到GitHub"""
    try:
        g = Github(GITHUB_TOKEN)
        repo = g.get_repo(GITHUB_REPO_NAME)
        author = InputGitAuthor(GITHUB_USERNAME, GITHUB_EMAIL)
        
        try:
            # 尝试获取文件（如果存在）
            contents = repo.get_contents(file_path)
            repo.update_file(
                path=file_path,
                message=commit_message,
                content=content,
                sha=contents.sha,
                author=author
            )
        except Exception:
            # 文件不存在，创建新文件
            repo.create_file(
                path=file_path,
                message=commit_message,
                content=content,
                author=author
            )
        
        logger.info(f"✅ 文件已上传到GitHub: {file_path}")
        return True
            
    except Exception as e:
        logger.error(f"❌ 上传到GitHub时出错: {str(e)}")
        return False

# ===================== 通用工具函数 =====================
def get_microsoft_otp(secret_key):
    """从Microsoft Authenticator的base32密钥自动计算6位OTP"""
    cleaned_secret = secret_key.replace(" ", "")
    totp = pyotp.TOTP(cleaned_secret, interval=30, digits=6)
    current_otp = totp.now()
    remaining_seconds = 30 - (int(time.time()) % 30)
    return current_otp, remaining_seconds

async def paykka_auto_login_with_otp(username, password, otp_secret):
    """自动登录并提取Token"""
    valid_token = None
    async with async_playwright() as p:
        args = [
            "--start-maximized",
            "--force-device-scale-factor=1",
            "--window-position=0,0",
            "--disable-infobars",
            "--disable-notifications",
            "--disable-blink-features=AutomationControlled",
            "--ignore-https-errors",
            "--no-sandbox"
        ]

        browser = await p.chromium.launch(
            headless=True,
            channel="chrome",
            slow_mo=100,
            args=args
        )

        context = await browser.new_context(viewport=None, ignore_https_errors=True)
        page = await context.new_page()

        try:
            logger.info("开始访问PayKKa登录页面...")
            await page.goto("https://ops.cb.paykka.com/login")
            time.sleep(2)

            username_locator = page.locator("//input[@placeholder='请输入账号/邮箱地址/手机号']")
            await username_locator.wait_for(timeout=10000)
            await username_locator.fill(username)
            time.sleep(0.5)

            password_locator = page.locator("//input[@placeholder='请输入密码']")
            await password_locator.wait_for(timeout=10000)
            await password_locator.fill(password)
            time.sleep(0.5)

            login_button = page.locator("button:has-text('登录'), button[type='submit']").first
            await login_button.wait_for(timeout=10000)
            await login_button.click(force=True)
            logger.info("已点击登录，等待OTP验证页面加载...")
            time.sleep(2)

            otp_inputs = page.locator("//input[@maxlength='1']")
            await otp_inputs.first.wait_for(timeout=20000)
            otp_count = await otp_inputs.count()
            if otp_count < 6:
                raise Exception(f"OTP输入框数量异常，检测到{otp_count}个，需6个")
            logger.info("OTP验证页面已加载完成")

            otp_code, remaining = get_microsoft_otp(otp_secret)
            logger.info(f"自动计算出OTP码：{otp_code}（剩余有效时间：{remaining}秒）")
            if remaining < 8:
                time.sleep(5)
                otp_code, remaining = get_microsoft_otp(otp_secret)
                logger.info(f"OTP即将过期，重新计算：{otp_code}")

            for i in range(6):
                await otp_inputs.nth(i).wait_for(timeout=5000)
                await otp_inputs.nth(i).fill(str(otp_code)[i])
                time.sleep(0.2)
            logger.info("已自动填充OTP验证码，等待登录验证...")
            
            time.sleep(5)

            logger.info("开始提取Local Storage中的TOKEN...")
            possible_keys = ['TOKEN', 'token', 'accessToken', 'access_token', 'Authorization']
            
            for key in possible_keys:
                try:
                    raw_token = await page.evaluate(f"() => localStorage.getItem('{key}')")
                    
                    if raw_token:
                        logger.info(f"从 localStorage['{key}'] 获取到Token")
                        
                        try:
                            token_data = json.loads(raw_token)
                            if isinstance(token_data, dict):
                                for token_key in ['token', 'access_token', 'accessToken', 'value']:
                                    if token_key in token_data:
                                        valid_token = token_data[token_key]
                                        break
                                if not valid_token and len(token_data) == 1:
                                    valid_token = list(token_data.values())[0]
                            elif isinstance(token_data, str):
                                valid_token = token_data
                        except json.JSONDecodeError:
                            valid_token = raw_token
                        
                        if valid_token:
                            try:
                                decoded_token = urllib.parse.unquote(valid_token)
                                valid_token = decoded_token
                            except:
                                pass
                            
                            valid_token = valid_token.strip().strip('"').strip("'")
                            
                            if '%22' in valid_token:
                                valid_token = valid_token.replace('%22', '')
                            
                            logger.info(f"成功从 {key} 提取Token")
                            break
                except Exception as e:
                    continue
            
            if not valid_token:
                try:
                    all_items = await page.evaluate("""() => {
                        const items = {};
                        for (let i = 0; i < localStorage.length; i++) {
                            const key = localStorage.key(i);
                            items[key] = localStorage.getItem(key);
                        }
                        return items;
                    }""")
                    
                    for key, value in all_items.items():
                        if value and len(value) > 20:
                            if 'token' in key.lower() or 'auth' in key.lower():
                                valid_token = value.strip().strip('"').strip("'")
                                logger.info(f"从 {key} 找到Token")
                                break
                except Exception as e:
                    logger.error(f"获取全部localStorage失败: {e}")
            
            if valid_token:
                logger.info(f"✅ Token提取成功!")
                    
        except Exception as e:
            logger.error(f"\n❌ 登录流程出错：{str(e)}")
        finally:
            try:
                await browser.close()
                logger.info("🔒 浏览器已关闭")
            except:
                pass
                
    return valid_token

def build_auth_headers(token: str) -> Dict[str, str]:
    """根据Token构建认证头"""
    if not token:
        return {}
    
    cookie = f"a_t={token}"
    
    return {
        "accept": "application/json, text/plain, */*",
        "accept-encoding": "gzip, deflate, br, zstd",
        "accept-language": "zh-CN",
        "content-type": "application/json;charset=UTF-8",
        "cookie": cookie,
        "origin": "https://ops.cb.paykka.com",
        "priority": "u=1, i",
        "referer": "https://ops.cb.paykka.com/",
        "sec-ch-ua": '"Not(A:Brand";v="8", "Chromium";v="144", "Google Chrome";v="144"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
        "x-auth-token": token,
        "x-requested-with": "XMLHttpRequest"
    }

