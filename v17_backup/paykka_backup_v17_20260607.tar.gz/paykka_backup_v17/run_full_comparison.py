#!/usr/bin/env python3
"""完整渠道 vs 友商历史汇率对比: YB + MDAQ_FX_TOM + BOC + XT (USD/CNH, 3天)"""
import sys, json, os
from datetime import datetime, timedelta
sys.path.insert(0, '/workspace')

from paykka_competitor import CompetitorHistoryQuery
from paykka_history_quote import PaykkaHistoryQuoteQuery
from paykka_controllerV16 import PaykkaSystemManager

def main():
    print("=" * 70)
    print("四路历史汇率对比: YB | MDAQ_FX_TOM | BOC | XT")
    print(f"货币对: USD/CNH | 时间范围: 3天 | 时间: {datetime.now()}")
    print("=" * 70)
    
    # ========== 1. XT 数据 ==========
    print("\n📡 [1/4] 查询 XT 历史汇率...")
    hist = CompetitorHistoryQuery()
    xt_result = hist.query_xt_history("USD", "CNY", days=3)
    if xt_result.get("success"):
        print(f"  ✅ XT: {len(xt_result['data'])} 条数据")
        if xt_result['data']:
            print(f"     First: {xt_result['data'][0]}")
            print(f"     Last:  {xt_result['data'][-1]}")
    else:
        print(f"  ❌ XT: {xt_result.get('error', '未知错误')}")
    
    # ========== 2. 渠道数据 (YB/MDAQ_FX_TOM/BOC) ==========
    print("\n📡 [2/4] 查询渠道历史报价 (YB, MDAQ_FX_TOM, BOC)...")
    token = PaykkaSystemManager._token
    if not token:
        print("  ⚠️ OPS Token 未就绪，尝试刷新...")
        mgr = PaykkaSystemManager()
        token = mgr.get_token()
    if not token:
        print("  ❌ 无法获取 OPS Token，跳过渠道查询")
    else:
        hq = PaykkaHistoryQuoteQuery(token)
        channel_result = hq.query_history(
            base_currency="USD",
            quote_currency="CNH",
            days=3,
            sources=["YB", "MDAQ_FX_TOM", "BOC"],
        )
    
    # 按来源拆分渠道数据（转换 UTC 时间到北京时间）
    channel_by_source = {"YB": [], "MDAQ_FX_TOM": [], "BOC": []}
    if channel_result.get("success") and channel_result.get("records"):
        for rec in channel_result["records"]:
            src = rec.get("source", "")
            if src in channel_by_source:
                time_str = rec.get("release_time", rec.get("time", ""))
                rate_val = float(rec.get("bid_rate", rec.get("rate", 0)))
                # 转换 UTC ISO 时间到北京时间 "YYYY-MM-DD HH:MM"
                try:
                    if 'T' in time_str:
                        from datetime import timezone as tz
                        dt = datetime.fromisoformat(time_str.replace('Z', '+00:00'))
                        dt = dt.astimezone(tz(timedelta(hours=8)))
                        time_str = dt.strftime("%Y-%m-%d %H:%M")
                except:
                    pass
                channel_by_source[src].append({
                    "time": time_str,
                    "rate": rate_val,
                    "source_name": src,
                })
    
    for src_name in ["YB", "MDAQ_FX_TOM", "BOC"]:
        data = channel_by_source[src_name]
        print(f"  ✅ {src_name}: {len(data)} 条 (采样后)")
        if data:
            print(f"     First: {data[0]}")
            print(f"     Last:  {data[-1]}")
    
    # ========== 3. 汇总 ==========
    all_results = {
        "YB": {
            "success": len(channel_by_source["YB"]) > 0,
            "pair": "USD/CNH",
            "source": "YB",
            "data": channel_by_source["YB"],
        },
        "MDAQ_FX_TOM": {
            "success": len(channel_by_source["MDAQ_FX_TOM"]) > 0,
            "pair": "USD/CNH",
            "source": "MDAQ_FX_TOM",
            "data": channel_by_source["MDAQ_FX_TOM"],
        },
        "BOC": {
            "success": len(channel_by_source["BOC"]) > 0,
            "pair": "USD/CNH",
            "source": "BOC",
            "data": channel_by_source["BOC"],
        },
        "XT": xt_result,
        "metadata": {
            "pair": "USD/CNH",
            "days": 3,
            "query_time": datetime.now().isoformat(),
            "raw_count": channel_result.get("raw_count", 0),
            "sample_slots": channel_result.get("sample_slots", 0),
        },
    }
    
    # 保存
    raw_path = "/workspace/logs/compare_full_raw.json"
    with open(raw_path, "w") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2, default=str)
    print(f"\n💾 原始数据已保存: {raw_path}")
    
    # ========== 4. 图表 ==========
    print("\n📊 生成对比图表...")
    chart_path = generate_comparison_chart(all_results)
    if chart_path:
        print(f"  ✅ 图表: {chart_path}")
    
    # ========== 5. Excel ==========
    print("\n📋 导出 Excel...")
    xlsx_path = export_excel(all_results)
    if xlsx_path:
        print(f"  ✅ Excel: {xlsx_path}")
    
    # ========== 6. 汇总 ==========
    print("\n" + "=" * 70)
    print("📊 对比汇总")
    print("=" * 70)
    
    for src_name in ["YB", "MDAQ_FX_TOM", "BOC", "XT"]:
        src = all_results.get(src_name, {})
        if src.get("success"):
            data = src.get("data", [])
            rates = [d.get("rate", 0) for d in data if d.get("rate")]
            if rates:
                avg = sum(rates) / len(rates)
                print(f"  {src_name:15s}: {len(data):4d} 条 | 均值 {avg:.4f} | 范围 [{min(rates):.4f} - {max(rates):.4f}]")
            else:
                print(f"  {src_name:15s}: {len(data):4d} 条 | 无有效汇率")
        else:
            print(f"  {src_name:15s}: ❌ {src.get('error', '查询失败')}")
    
    print(f"\n✅ 完成!")


def generate_comparison_chart(all_results):
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        import matplotlib.dates as mdates
        import matplotlib.font_manager as fm
        
        cjk_path = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
        if os.path.exists(cjk_path):
            cjk_prop = fm.FontProperties(fname=cjk_path)
            plt.rcParams['font.family'] = cjk_prop.get_name()
        plt.rcParams['axes.unicode_minus'] = False
        
        colors = {"YB": "#2196F3", "MDAQ_FX_TOM": "#4CAF50", "BOC": "#FF9800", "XT": "#E91E63"}
        markers = {"YB": "o", "MDAQ_FX_TOM": "s", "BOC": "^", "XT": "D"}
        
        fig, ax = plt.subplots(figsize=(14, 8))
        
        for src_name in ["YB", "MDAQ_FX_TOM", "BOC", "XT"]:
            src = all_results.get(src_name, {})
            if not src.get("success") or not src.get("data"):
                continue
            
            times = []
            rates = []
            for d in src["data"]:
                try:
                    t = datetime.strptime(d["time"], "%Y-%m-%d %H:%M")
                except:
                    try:
                        t = datetime.strptime(d["time"], "%Y-%m-%d %H:%M:%S")
                    except:
                        continue
                times.append(t)
                rates.append(float(d.get("rate", 0)))
            
            if not times:
                continue
            
            color = colors.get(src_name, "#999")
            marker = markers.get(src_name, ".")
            ax.plot(times, rates, color=color, linewidth=1.5, marker=marker,
                    markersize=4, alpha=0.85, label=f'{src_name} ({len(times)}条)')
        
        ax.set_title('USD/CNH 历史汇率对比 (3天) - YB vs MDAQ vs BOC vs XT',
                     fontsize=14, fontweight='bold')
        ax.set_xlabel('时间', fontsize=11)
        ax.set_ylabel('汇率 (USD/CNH)', fontsize=11)
        ax.legend(loc='best', fontsize=9)
        ax.grid(True, alpha=0.3)
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d %H:%M'))
        plt.xticks(rotation=30, ha='right')
        fig.tight_layout()
        
        chart_path = "/workspace/logs/charts/compare_YB_MDAQ_BOC_XT_USDCNH_3d.png"
        fig.savefig(chart_path, dpi=150, bbox_inches='tight')
        plt.close()
        return chart_path
    except Exception as e:
        print(f"  ⚠️ 图表失败: {e}")
        import traceback; traceback.print_exc()
        return ""


def export_excel(all_results):
    try:
        import pandas as pd
        rows = []
        for src_name in ["YB", "MDAQ_FX_TOM", "BOC", "XT"]:
            src = all_results.get(src_name, {})
            if src.get("success") and src.get("data"):
                for d in src["data"]:
                    rows.append({
                        "来源": src_name,
                        "时间": d.get("time", ""),
                        "汇率": float(d.get("rate", 0)),
                        "来源子类": d.get("source_name", src_name),
                    })
        
        if not rows:
            print("  ⚠️ 无数据可导出")
            return ""
        
        df = pd.DataFrame(rows)
        xlsx_path = "/workspace/logs/compare_YB_MDAQ_BOC_XT_USDCNH_3d.xlsx"
        
        with pd.ExcelWriter(xlsx_path, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='明细数据', index=False)
            
            summary_rows = []
            for src_name in ["YB", "MDAQ_FX_TOM", "BOC", "XT"]:
                src = all_results.get(src_name, {})
                if src.get("success") and src.get("data"):
                    rates = [float(d.get("rate", 0)) for d in src["data"] if d.get("rate")]
                    if rates:
                        summary_rows.append({
                            "来源": src_name,
                            "数据条数": len(src["data"]),
                            "平均汇率": round(sum(rates) / len(rates), 5),
                            "最高汇率": round(max(rates), 5),
                            "最低汇率": round(min(rates), 5),
                            "标准差": round((sum((r - sum(rates)/len(rates))**2 for r in rates) / len(rates)) ** 0.5, 5),
                        })
            
            if summary_rows:
                pd.DataFrame(summary_rows).to_excel(writer, sheet_name='汇总统计', index=False)
        
        return xlsx_path
    except Exception as e:
        print(f"  ⚠️ Excel 失败: {e}")
        return ""


if __name__ == "__main__":
    main()
