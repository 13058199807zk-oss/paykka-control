#!/usr/bin/env python3
"""XT 手动登录脚本 - 打开有头浏览器，用户通过 VNC 完成 CAPTCHA 后自动保存 Cookie"""
import asyncio, json, os, sys
from datetime import datetime
from playwright.async_api import async_playwright

XT_USER_DATA = "/workspace/xt_browser_data"
XT_LOGIN_URL = "https://www.xtransfer.cn/login"

async def main():
    playwright = await async_playwright().start()
    
    context = await playwright.chromium.launch_persistent_context(
        user_data_dir=XT_USER_DATA,
        headless=False,
        args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-blink-features=AutomationControlled"],
        viewport={"width": 1280, "height": 720},
        slow_mo=50,
    )
    
    page = context.pages[0] if context.pages else await context.new_page()
    
    print(f"🌐 打开 XT 登录页面...")
    await page.goto(XT_LOGIN_URL, timeout=30000)
    await asyncio.sleep(2)
    
    # 自动填充
    try:
        try:
            tab = await page.wait_for_selector("text=Password Login", timeout=5000)
            if tab:
                await tab.click()
                print("✅ 切换到 Password Login")
                await asyncio.sleep(1)
        except:
            pass
        
        phone = await page.wait_for_selector("#accountLoginMobileInput", timeout=10000)
        await phone.fill("")
        await phone.type("13058199807", delay=80)
        print("✅ 已填充手机号")
        
        pwd = await page.wait_for_selector("#accountLoginPasswordInput", timeout=10000)
        await pwd.fill("")
        await pwd.type("7639179zK@", delay=80)
        print("✅ 已填充密码")
        
        btn = await page.wait_for_selector("button:has-text('Login')", timeout=10000)
        await btn.click()
        print("✅ 已点击登录")
    except Exception as e:
        print(f"⚠️ 自动填充失败: {e}")
    
    print("\n" + "=" * 60)
    print("📌 请通过 VNC 连接服务器完成 CAPTCHA 验证")
    print("   等待登录完成后自动保存 Cookie...")
    print("=" * 60)
    
    # 等待登录成功（最多 5 分钟）
    for i in range(300):
        await asyncio.sleep(1)
        url = page.url
        if "fund" in url.lower():
            print(f"\n✅ 登录成功！URL: {url}")
            break
        if i % 15 == 0 and i > 0:
            print(f"   等待中... ({i}s)")
    
    await asyncio.sleep(3)
    
    # 保存 Cookie
    cookies = await context.cookies()
    cookie_parts = []
    xsrf_token = ""
    for c in cookies:
        name = c.get('name', '')
        value = c.get('value', '')
        if name and value and value != 'null':
            cookie_parts.append(f"{name}={value}")
            if 'XSRF-TOKEN' in name.upper():
                xsrf_token = value
    
    cache = {
        "cookie_str": "; ".join(cookie_parts),
        "xsrf_token": xsrf_token,
        "jwt_token": "",
        "auth_time": datetime.now().isoformat(),
    }
    
    with open("/workspace/xt_auth_cache.json", "w") as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)
    
    print(f"\n💾 Cookie 已保存 ({len(cookie_parts)} 个)")
    print(f"📁 浏览器数据: {XT_USER_DATA}")
    print("✅ 完成！可以关闭 VNC 了")
    
    await context.close()

asyncio.run(main())
