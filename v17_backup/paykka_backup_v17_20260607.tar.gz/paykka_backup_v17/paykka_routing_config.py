# ===================== paykka_routing_config.py =====================
# PaykkaRoutingConfigurator - 路由配置
# 从 paykka_controllerV16.py 提取

import json
import time
import urllib.parse
import requests
import re
import threading
import os
import hashlib
import asyncio
import subprocess
import base64
from typing import List, Dict, Tuple, Any, Optional, Union
from datetime import datetime, date, timedelta, timezone, time as dtime
from playwright.async_api import async_playwright
import pandas as pd
from github import Github, InputGitAuthor
import pytz

from paykka_config import *
from paykka_core import PaykkaSystemManager, build_auth_headers

class PaykkaRoutingConfigurator:
    """PAYKKA路由配置器 - 增强版，支持自动重连"""
    
    def __init__(self, token: str):
        self.token = token
        self.base_url = "https://ops-bk.cb.paykka.com"
        self.fx_update_api = "/forex/ops/fx/pair-config/update"
        self.fx_detail_api = "/forex/ops/fx/pair-config/detail"
        self.fx_list_api = "/forex/ops/fx/pair-config/page"
        self.manager = PaykkaSystemManager()  # 新增：引用管理器
    
    def _build_headers(self) -> Dict[str, str]:
        """构建HTTP请求头"""
        return build_auth_headers(self.token)
    
    def _safe_api_request(self, method: str, api_path: str, payload: Dict = None) -> Tuple[bool, Any]:
        """安全的API请求封装"""
        url = f"{self.base_url}{api_path}"
        headers = self._build_headers()
        
        def request_func():
            if method.upper() == "POST":
                response = requests.post(url, headers=headers, json=payload, timeout=30)
            else:
                response = requests.get(url, headers=headers, params=payload, timeout=30)
            
            if response.status_code == 200:
                return response.json()
            else:
                raise Exception(f"HTTP {response.status_code}: {response.text[:100]}")
        
        # 使用管理器的安全API调用
        success, result = self.manager.safe_api_call(
            request_func,
            max_retries=2,
            retry_delay=1
        )
        
        return success, result
    
    def safe_query_fx_pair_config(self, sell_currency: str, buy_currency: str) -> Optional[Dict]:
        """安全的查询单个货币对配置"""
        payload = {"sell_cur": sell_currency.upper(), "buy_cur": buy_currency.upper()}
        
        success, data = self._safe_api_request("POST", self.fx_detail_api, payload)
        
        if success and data.get("ret_code") == "000000":
            current_config = data.get("data", {})
            if current_config:
                return {
                    "fx_strategy_rule": current_config.get("fx_strategy_rule", "未知"),
                    "standalone_fx": current_config.get("standalone_fx", "未知"),
                    "buy_cur": current_config.get("buy_cur", buy_currency),
                    "sell_cur": current_config.get("sell_cur", sell_currency),
                    "status": current_config.get("status", "未知"),
                    "update_time": current_config.get("update_time", "未知")
                }
        
        return None
    
    def safe_update_fx_pair_config(
        self, 
        sell_currency: str, 
        buy_currency: str, 
        strategy_rule: str, 
        standalone_fx_enabled: bool
    ) -> bool:
        """安全的修改货币对配置"""
        if strategy_rule not in FX_STRATEGY_RULES:
            logger.error(f"策略规则 {strategy_rule} 不在支持的列表中")
            return False

        payload = {
            "buy_cur": buy_currency.upper(),
            "sell_cur": sell_currency.upper(),
            "fx_strategy_rule": strategy_rule,
            "standalone_fx": "ENABLED" if standalone_fx_enabled else "DISABLED"
        }
        
        success, data = self._safe_api_request("POST", self.fx_update_api, payload)
        
        if success and data.get("ret_code") == "000000":
            logger.info(f"路由修改成功: {sell_currency}->{buy_currency} 策略:{strategy_rule}")
            return True
        else:
            error_msg = data.get('ret_msg', '未知错误') if success else str(data)
            logger.error(f"路由修改失败: {error_msg}")
            return False
    
    def query_fx_pair_config(self, sell_currency: str, buy_currency: str) -> Optional[Dict]:
        """查询单个货币对配置（兼容旧版本）"""
        return self.safe_query_fx_pair_config(sell_currency, buy_currency)
    
    def update_fx_pair_config(
        self, 
        sell_currency: str, 
        buy_currency: str, 
        strategy_rule: str, 
        standalone_fx_enabled: bool
    ) -> bool:
        """修改货币对配置（兼容旧版本）"""
        return self.safe_update_fx_pair_config(sell_currency, buy_currency, strategy_rule, standalone_fx_enabled)
    
    def safe_query_all_fx_pair_configs(self) -> List[Dict]:
        """安全的分页查询所有货币对配置"""
        all_configs = []
        offset = 0
        limit = 100
        page = 1
        
        while True:
            payload = {"offset": offset, "limit": limit}
            
            success, data = self._safe_api_request("POST", self.fx_list_api, payload)
            
            if not success:
                logger.error(f"第{page}页查询异常: {data}")
                break
            
            if data.get("ret_code") != "000000":
                logger.error(f"第{page}页查询失败: {data.get('ret_msg', '未知错误')}")
                break
            
            page_data = data.get("data", [])
            if isinstance(page_data, dict):
                page_data = page_data.get("list", page_data.get("records", []))
            if not isinstance(page_data, list):
                page_data = []
            
            if not page_data:
                logger.info(f"分页查询完成，共获取 {len(all_configs)} 条配置")
                break
            
            for item in page_data:
                if not isinstance(item, dict):
                    continue
                config = {
                    "fx_strategy_rule": item.get("fx_strategy_rule", "未知"),
                    "standalone_fx": item.get("standalone_fx", "未知"),
                    "buy_cur": item.get("buy_cur", "未知"),
                    "sell_cur": item.get("sell_cur", "未知"),
                    "status": item.get("status", "未知"),
                    "update_time": item.get("update_time", "未知")
                }
                all_configs.append(config)
            
            if len(page_data) < limit:
                break
            
            offset += limit
            page += 1
            time.sleep(0.2)
        
        return all_configs
    
    def query_all_fx_pair_configs(self) -> List[Dict]:
        """分页查询所有货币对配置（兼容旧版本）"""
        return self.safe_query_all_fx_pair_configs()

