# ===================== paykka_fx_monitor.py =====================
# PaykkaFxTransactionMonitor + FxMonitoringScheduledTask - 换汇交易监控
# 从 paykka_controllerV16.py 提取

import json
import time
import urllib.parse
import requests
import re
import threading
import os
import hashlib
import asyncio
import subprocess
import base64
from typing import List, Dict, Tuple, Any, Optional, Union
from datetime import datetime, date, timedelta, timezone, time as dtime
from playwright.async_api import async_playwright
import pandas as pd
from github import Github, InputGitAuthor
import pytz

from paykka_config import *
from paykka_core import PaykkaSystemManager, build_auth_headers, send_wechat_work_message

class PaykkaFxTransactionMonitor:
    """PAYKKA换汇交易量统计与监控模块"""
    
    def __init__(self, token: str):
        self.token = token
        self.base_url = "https://ops-bk.cb.paykka.com"
        self.fx_api_endpoint = FX_TRANSACTION_API
        self.full_api_url = FX_FULL_TRANSACTION_URL
        self.org_list = ORG_LIST
        self.no_divide_currencies = NO_DIVIDE_CURRENCIES
        self.manager = PaykkaSystemManager()
    
    def _build_headers(self) -> Dict[str, str]:
        """构建HTTP请求头"""
        return build_auth_headers(self.token)
    
    def _convert_amount(self, raw_amt: any, currency: str) -> float:
        """转换金额"""
        try:
            amt = float(raw_amt)
            if currency not in self.no_divide_currencies:
                amt = amt / 100
            return amt
        except (ValueError, TypeError):
            return 0.0
    
    def _format_number(self, num: float) -> str:
        """格式化数字"""
        return f"{num:,.2f}"
    
    def _convert_org_settlement_time(self, iso_time_str: str) -> Optional[datetime]:
        """转换交割时间为北京时间"""
        if not iso_time_str:
            return None
        try:
            utc_time = datetime.strptime(iso_time_str, "%Y-%m-%dT%H:%M:%SZ")
            return utc_time + timedelta(hours=8)
        except (ValueError, TypeError):
            return None
    
    def fetch_fx_threshold_config(self) -> Dict:
        """从GitHub拉取并解析最新的fx_threshold.md（公有方法）"""
        try:
            #logger.info(f"🔍 开始从GitHub获取换汇阈值配置...")
            url = f"https://api.github.com/repos/{GITHUB_REPO_OWNER}/paykka-control/contents/{GITHUB_THRESHOLD_FILE_PATH_MD}"
            headers = {
                "Authorization": f"token {GITHUB_TOKEN}",
                "Accept": "application/vnd.github.v3.raw"
            }
            response = requests.get(url, headers=headers, timeout=30)
            
            if response.status_code == 200:
                md_content = response.text
                return self._parse_fx_threshold_md(md_content)
            else:
                logger.error(f"❌ 获取阈值配置失败，状态码: {response.status_code}")
                return self._get_default_config()
        except Exception as e:
            logger.error(f"❌ 获取预警阈值配置时出错: {e}")
            return self._get_default_config()
    
    def _parse_fx_threshold_md(self, md_content: str) -> Dict:
        """解析fx_threshold.md内容"""
        config = {
            "WECHAT_WEBHOOK_URL": "",
            "ALERT_THRESHOLDS": {},
            "PROCESSING_ALERT_THRESHOLDS": {},  # 新增：处理中交易阈值
            "ENABLE_WECHAT_ALERT": True,
            "TRADING_HOURS": {}
        }

        # 1. 提取 Webhook URL
        webhook_pattern = r'WECHAT_WEBHOOK_URL\s*=\s*"([^"]+)"'
        webhook_match = re.search(webhook_pattern, md_content)
        if webhook_match:
            config["WECHAT_WEBHOOK_URL"] = webhook_match.group(1)

        # 2. 提取 ALERT_THRESHOLDS 字典
        threshold_pattern = r'ALERT_THRESHOLDS\s*=\s*({[^}]+})'
        threshold_match = re.search(threshold_pattern, md_content, re.DOTALL)
        if threshold_match:
            threshold_dict_str = threshold_match.group(1)
            try:
                config["ALERT_THRESHOLDS"] = ast.literal_eval(threshold_dict_str)
            except:
                logger.warning("⚠️ 解析ALERT_THRESHOLDS失败，使用默认阈值")

        # 3. 新增：提取 PROCESSING_ALERT_THRESHOLDS 字典
        processing_threshold_pattern = r'PROCESSING_ALERT_THRESHOLDS\s*=\s*({[^}]+})'
        processing_threshold_match = re.search(processing_threshold_pattern, md_content, re.DOTALL)
        if processing_threshold_match:
            processing_threshold_dict_str = processing_threshold_match.group(1)
            try:
                config["PROCESSING_ALERT_THRESHOLDS"] = ast.literal_eval(processing_threshold_dict_str)
            except:
                logger.warning("⚠️ 解析PROCESSING_ALERT_THRESHOLDS失败，使用ALERT_THRESHOLDS作为默认")
                config["PROCESSING_ALERT_THRESHOLDS"] = config.get("ALERT_THRESHOLDS", {})
        else:
            # 如果没有配置，默认使用ALERT_THRESHOLDS
            config["PROCESSING_ALERT_THRESHOLDS"] = config.get("ALERT_THRESHOLDS", {})
            logger.warning("⚠️ 未配置PROCESSING_ALERT_THRESHOLDS，使用ALERT_THRESHOLDS")


        # 4. 提取提醒开关
        alert_switch_pattern = r'ENABLE_WECHAT_ALERT\s*=\s*(True|False)'
        alert_switch_match = re.search(alert_switch_pattern, md_content)
        if alert_switch_match:
            config["ENABLE_WECHAT_ALERT"] = alert_switch_match.group(1) == "True"

        # 5. 提取 TRADING_HOURS 字典
        trading_hours_pattern = r'TRADING_HOURS\s*=\s*(\{(?:[^{}]|\{[^{}]*\})*\})'
        trading_hours_match = re.search(trading_hours_pattern, md_content, re.DOTALL)
        if trading_hours_match:
            trading_hours_str = trading_hours_match.group(1)
            try:
                config["TRADING_HOURS"] = ast.literal_eval(trading_hours_str)
            except:
                logger.warning("⚠️ 解析TRADING_HOURS失败，使用默认配置")
        
        #logger.info(f"✅ 成功解析换汇阈值配置: {len(config['ALERT_THRESHOLDS'])} 个阈值规则")
        logger.info(f"   已完成交易阈值: {len(config['ALERT_THRESHOLDS'])} 个货币对")
        logger.info(f"   处理中交易阈值: {len(config['PROCESSING_ALERT_THRESHOLDS'])} 个货币对")

        return config
    
    def _get_default_config(self) -> Dict:
        """获取默认配置"""
        return {
            "WECHAT_WEBHOOK_URL": WECHAT_WEBHOOK_URL,
            "ALERT_THRESHOLDS": {"USD/CNH": 100000.0, "EUR/CNH": 50000.0, "GBP/CNH": 30000.0},
            "ENABLE_WECHAT_ALERT": True,
            "TRADING_HOURS": {}
        }
    
    def query_fx_transactions(
        self, 
        org_code: Optional[str] = None,
        merchant_status: str = DEFAULT_MERCHANT_STATUS,
        org_status: str = DEFAULT_ORG_STATUS,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> Dict:
        """
        查询换汇交易并统计敞口
        返回包含统计结果的字典
        """
        # 拉取GitHub最新配置
        config = self.fetch_fx_threshold_config()

        ALERT_THRESHOLDS = config["ALERT_THRESHOLDS"]  # 已完成交易阈值
        PROCESSING_THRESHOLDS = config["PROCESSING_ALERT_THRESHOLDS"]  # 处理中交易阈值
        
        # 默认查询当日+上一个工作日
        today = date.today()
        if not start_date:
            # 上一个工作日
            prev = today
            while True:
                prev = prev - timedelta(days=1)
                if prev.weekday() < 5:
                    break
            start_date = prev.strftime("%Y-%m-%d")
        if not end_date:
            end_date = today.strftime("%Y-%m-%d")
        
        all_transactions = []
        page_num = 1
        page_size = 100
        
        #logger.info(f"📡 正在查询 {start_date} 至 {end_date} 期间所有货币对的交割敞口...")
        #logger.info(f"   机构: {org_code or '全部'} | 状态: 企业为成功/机构为成功/处理中")
        
        # 查询所有货币对数据
        while True:
            payload = {
                "offset": (page_num - 1) * page_size,
                "limit": page_size,
                "sell_currency": "",
                "buy_currency": "",
                "org_code": org_code,
                "status": merchant_status,
                "org_fx_order_status": org_status,
                #"start_time": start_date,
                #"end_time": end_date
            }
            
            try:
                response = requests.post(
                    self.full_api_url,
                    headers=self._build_headers(),
                    json=payload,
                    timeout=30
                )
                data = response.json()
                
                if data.get("ret_code") == "000000":
                    response_data = data.get("data", {})
                    
                    if isinstance(response_data, dict):
                        transactions = response_data.get("list", [])
                        total = response_data.get("total", 0)
                    elif isinstance(response_data, list):
                        transactions = response_data
                        total = len(response_data)
                    else:
                        transactions = []
                        total = 0
                    
                    if not transactions:
                        break
                    
                    all_transactions.extend(transactions)
                    
                    logger.info(f"   已获取_所有明细，累计 {len(all_transactions)}/{total} 条")
                    
                    if len(all_transactions) >= total or total == 0:
                        break
                    
                    page_num += 1
                    time.sleep(0.5)
                else:
                    logger.error(f"❌ 查询失败: {data.get('ret_msg', '未知错误')}")
                    break
            except Exception as e:
                logger.error(f"❌ 查询异常: {str(e)}")
                break
        
        # 按交割日期+货币对统计
        settlement_stats: Dict[str, Dict[str, Dict[str, float]]] = {}
        processing_stats: Dict[str, Dict[str, float]] = {}  # 新增：用于PROCESSING状态，按货币对统计
        filtered_transactions = []

        for tx in all_transactions:
            # 获取交易状态（假设状态字段为 org_fx_order_status）
            tx_status = tx.get("org_fx_order_status", "").upper()
    
            # 转换金额
            sell_currency = tx.get("sell_currency", "")
            buy_currency = tx.get("buy_currency", "")
            sell_amt = self._convert_amount(tx.get("sell_amt", 0), sell_currency)
            buy_amt = self._convert_amount(tx.get("buy_amt", 0), buy_currency)
    
            currency_pair = f"{sell_currency}/{buy_currency}"
    
            if tx_status == "PROCESSING":
                # 对于PROCESSING状态，只按货币对统计，不分日期
                if currency_pair not in processing_stats:
                    processing_stats[currency_pair] = {
                        "total_sell": 0.0,
                        "total_buy": 0.0,
                        "count": 0
                    }
                processing_stats[currency_pair]["total_sell"] += sell_amt
                processing_stats[currency_pair]["total_buy"] += buy_amt
                processing_stats[currency_pair]["count"] += 1
                filtered_transactions.append(tx)  # 可选：保留交易记录
            else:
                # 对于SUCCEEDED状态，按交割日期统计
                settlement_date_str = tx.get("settlement_date", "")
                if not settlement_date_str:
                    # 回退：尝试从 org_settlement_date 解析
                    org_settlement_time = self._convert_org_settlement_time(tx.get("org_settlement_date", ""))
                    if not org_settlement_time:
                        continue
                    settlement_date_str = org_settlement_time.strftime("%Y-%m-%d")
        
                # 按日期范围过滤（start_date ~ end_date）
                if start_date and settlement_date_str < start_date:
                    continue
                if end_date and settlement_date_str > end_date:
                    continue
        
                if settlement_date_str not in settlement_stats:
                    settlement_stats[settlement_date_str] = {}
                if currency_pair not in settlement_stats[settlement_date_str]:
                    settlement_stats[settlement_date_str][currency_pair] = {
                        "total_sell": 0.0,
                        "total_buy": 0.0,
                        "count": 0
                    }
        
                settlement_stats[settlement_date_str][currency_pair]["total_sell"] += sell_amt
                settlement_stats[settlement_date_str][currency_pair]["total_buy"] += buy_amt
                settlement_stats[settlement_date_str][currency_pair]["count"] += 1
                filtered_transactions.append(tx)
        
        # 超限判断+发送提醒
        query_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        alerts_sent = []

        # 1. 检查SUCCEEDED状态的交易（使用ALERT_THRESHOLDS）        
        for settle_date, currency_pairs in settlement_stats.items():
            for currency_pair, stats in currency_pairs.items():
                if currency_pair in ALERT_THRESHOLDS:
                    threshold = ALERT_THRESHOLDS[currency_pair]
                    actual_sell = stats["total_sell"]
                    
                    if actual_sell > threshold:
                        alert_data = {
                            "query_time": query_time,
                            "org_code": org_code,
                            "settle_date": settle_date,
                            "currency_pair": currency_pair,
                            "threshold": self._format_number(threshold),
                            "actual_sell": self._format_number(actual_sell),
                            "excess_amount": self._format_number(actual_sell - threshold),
                            "count": stats["count"],
                            "status": "SUCCEEDED",  # 状态标识
                            "threshold_type": "ALERT_THRESHOLDS"  # 阈值类型
                        }
                        # 简化处理，这里不发送实际告警
                        alerts_sent.append(alert_data)

        # 2. 检查PROCESSING状态的交易（使用PROCESSING_THRESHOLDS）
        for currency_pair, stats in processing_stats.items():
            if currency_pair in PROCESSING_THRESHOLDS:
                threshold = PROCESSING_THRESHOLDS[currency_pair]
                actual_sell = stats["total_sell"]
        
                if actual_sell > threshold:
                    alert_data = {
                        "query_time": query_time,
                        "org_code": org_code,
                        "settle_date": "PROCESSING",  # 没有交割日期
                        "currency_pair": currency_pair,
                        "threshold": self._format_number(threshold),
                        "actual_sell": self._format_number(actual_sell),
                        "excess_amount": self._format_number(actual_sell - threshold),
                        "count": stats["count"],
                        "status": "PROCESSING",  # 状态标识
                        "threshold_type": "PROCESSING_THRESHOLDS"  # 阈值类型
                    }
                    alerts_sent.append(alert_data)
        
        # 整理结果
        result = {
            "settlement_stats": settlement_stats,
            "processing_stats": processing_stats,  # 新增：PROCESSING状态统计结果
            "transactions": filtered_transactions,
            "total_count": len(filtered_transactions),
            "start_date": start_date,
            "end_date": end_date,
            "query_time": query_time,
            "alerts_sent": alerts_sent,
            "used_config": {
                "ALERT_THRESHOLDS": ALERT_THRESHOLDS,
                "PROCESSING_ALERT_THRESHOLDS": PROCESSING_THRESHOLDS,  # 新增
                "TRADING_HOURS": config.get("TRADING_HOURS", {}),
                "ENABLE_WECHAT_ALERT": config["ENABLE_WECHAT_ALERT"]
            }
        }
        
        return result

# ===================== 交易监控定时任务类 =====================
class FxMonitoringScheduledTask:
    """换汇交易监控定时任务执行器 - 针对'交易监控'指令"""
    
    def __init__(self, manager: PaykkaSystemManager, interval_minutes: int = 5):
        """
        初始化定时任务
        :param manager: 全局系统管理器
        :param interval_minutes: 监控间隔（分钟），默认5分钟
        """
        self.manager = manager
        self.interval_minutes = interval_minutes
        self.is_running = False
        self.monitor = None
        self.org_code = None
        self.task_thread = None
        self.stop_event = threading.Event()
    
    def set_org_code(self, org_code: Optional[str]):
        """设置要监控的机构代码"""
        self.org_code = org_code
    
    def _get_monitor(self) -> PaykkaFxTransactionMonitor:
        """获取或创建监控器实例"""
        if not self.monitor:
            self.monitor = self.manager.get_fx_transaction_monitor()
        return self.monitor
    
    def _execute_monitoring_task(self):
        """执行一次交易监控任务的核心逻辑"""
        try:
            org_display = self.org_code or "全部"
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            logger.info("=" * 60)            
            logger.info(f"🚀 定期任务执行中 ({current_time})")
            logger.info("=" * 60)
            
            # 获取监控器
            monitor = self._get_monitor()
            if not monitor:
                logger.error("❌ 无法获取交易监控器实例")
                return
            
            # 从监控器中获取配置
            try:
                config = monitor.fetch_fx_threshold_config()
                logger.info(f"✅ GitHub连接成功，已绑定paykka-control仓库")
                logger.info(f"✅ 从fx_threshold.md解析到配置：{len(config['ALERT_THRESHOLDS'])} 个阈值规则")
            except AttributeError as e:
                logger.error(f"❌ 获取GitHub配置失败: {e}")
                # 使用默认配置
                config = {
                    "WECHAT_WEBHOOK_URL": None,
                    "ALERT_THRESHOLDS": {},
                    "ENABLE_WECHAT_ALERT": True,
                    "TRADING_HOURS": {}
                }
                logger.info(f"ℹ️ 使用默认配置")
            
            # 显示Webhook信息
            webhook_url = config.get("WECHAT_WEBHOOK_URL", "使用全局默认")
            if webhook_url and len(webhook_url) > 20:
                webhook_display = webhook_url[:20] + "..."
            else:
                webhook_display = webhook_url
            
            #logger.info(f"  - Webhook: {webhook_display}")
            #logger.info(f"  - 阈值: {config.get('ALERT_THRESHOLDS', {})}")
            #logger.info(f"  - 提醒开关: {'开启' if config.get('ENABLE_WECHAT_ALERT', True) else '关闭'}")
            
            trading_hours = config.get("TRADING_HOURS", {})
            #if trading_hours:
                #logger.info(f"  - 交易时段: {trading_hours}")
            
            # 检查交易时段
            if org_display != "全部" and trading_hours and org_display in trading_hours:
                time_range = trading_hours[org_display]
                start_time = time_range.get('start', '00:00')
                end_time = time_range.get('end', '23:59')
                current_hour_min = datetime.now().strftime("%H:%M")
                
                # 简单检查是否在交易时段内
                if start_time <= current_hour_min <= end_time:
                    logger.info(f"✅ 当前时间 {current_hour_min} 在 {org_display} 的交易时段内 ({start_time}-{end_time})")
                else:
                    logger.info(f"⚠️ 当前时间 {current_hour_min} 不在 {org_display} 的交易时段内 ({start_time}-{end_time})")
            
            # 计算查询时间范围
            today = date.today()
            start_date = today.strftime("%Y-%m-%d")
            end_date = (today + timedelta(days=10)).strftime("%Y-%m-%d")
            
            #logger.info(f"📡 正在查询 {start_date} 至 {end_date} 期间所有货币对的交割敞口...")
            #logger.info(f"   机构: {org_display} | 状态: 企业为成功/机构为成功/处理中")
            
            #logger.info(f"   本次使用配置（来自GitHub fx_threshold.md）:")
            #logger.info(f"    - 阈值: {config.get('ALERT_THRESHOLDS', {})}")
            #logger.info(f"    - 交易时段: {config.get('TRADING_HOURS', {})}")
            #logger.info(f"    - 提醒开关: {'开启' if config.get('ENABLE_WECHAT_ALERT', True) else '关闭'}")
            #logger.info(f"    - Webhook: {webhook_display}")
            
            # 执行查询
            result = monitor.query_fx_transactions(
                org_code=self.org_code,
                merchant_status=DEFAULT_MERCHANT_STATUS,
                org_status=DEFAULT_ORG_STATUS
            )
            
            # 如果有分页信息，记录分页进度
            if 'total_count' in result:
                logger.info(f"   已获取_符合条件明细，累计 {result.get('total_count', 0)}/{result.get('total_count', 0)} 条")
            
            # 生成详细统计报告
            self._generate_detailed_report(result, config, org_display, start_date, end_date)
            
            # 记录结果摘要
            settlement_stats = result.get('settlement_stats', {})
            processing_stats = result.get('processing_stats', {})

            if settlement_stats or processing_stats:
                # SUCCEEDED状态统计
                if settlement_stats:
                    date_count = len(settlement_stats)
                    total_sell_succeeded = 0.0
                    for date_stats in settlement_stats.values():
                        for pair_stats in date_stats.values():
                            total_sell_succeeded += pair_stats.get('total_sell', 0.0)
    
                # PROCESSING状态统计
                if processing_stats:
                    pair_count_processing = len(processing_stats)
                    total_sell_processing = 0.0
                    for pair_stats in processing_stats.values():
                        total_sell_processing += pair_stats.get('total_sell', 0.0)
    
                logger.info(f"✅ 交易监控完成。")
                logger.info(f"   监控机构: {org_display}")
    
                if settlement_stats:
                    logger.info(f"   ✅ 已完成交易: {date_count}个交割日，总卖出: {total_sell_succeeded:,.2f}")
                if processing_stats:
                    logger.info(f"   ⏳ 处理中交易: {pair_count_processing}个货币对，总卖出: {total_sell_processing:,.2f}")
    
                # 如果有告警发送，在日志中体现
                if result.get('alerts_sent'):
                    alert_count = len(result['alerts_sent'])
                    logger.warning(f"🚨 触发 {alert_count} 条敞口超限告警")
        
                    # 统计两种状态的告警数量
                    succeeded_alerts = len([a for a in result['alerts_sent'] if a.get('status') == 'SUCCEEDED'])
                    processing_alerts = len([a for a in result['alerts_sent'] if a.get('status') == 'PROCESSING'])
        
                    if succeeded_alerts > 0:
                        logger.warning(f"   ✅ 已完成交易告警: {succeeded_alerts} 条")
                    if processing_alerts > 0:
                        logger.warning(f"   ⏳ 处理中交易告警: {processing_alerts} 条")
        
                    # 发送汇总告警到企业微信
                    if alert_count > 0:
                        self._send_monitoring_summary_alert(result, config, org_display, start_date, end_date)
            else:
                logger.info(f"ℹ️ 交易监控完成，{org_display}机构未发现未来交割或处理中交易。")
        
        except Exception as e:
            logger.error(f"❌ 交易监控定时任务执行异常: {e}")
            import traceback
            logger.error(f"详细错误信息: {traceback.format_exc()}")
    
    def _generate_detailed_report(self, result: Dict, config: Dict, org_display: str, start_date: str, end_date: str):
        """生成详细的统计报告"""

        settlement_stats = result.get('settlement_stats', {})
        processing_stats = result.get('processing_stats', {})
    
        if not settlement_stats and not processing_stats:
            return
        
        total_transactions = result.get('total_count', {})
        alert_thresholds = config.get('ALERT_THRESHOLDS', {})
        processing_thresholds = config.get('PROCESSING_ALERT_THRESHOLDS', {})
        trading_hours = config.get('TRADING_HOURS', {})
        enable_alert = config.get('ENABLE_WECHAT_ALERT', True)
        
        # 生成详细报告
        report_lines = []
        report_lines.append("=" * 80)
        report_lines.append("📊 换汇交易敞口统计结果（按交割日期）")
        report_lines.append("=" * 80)
        report_lines.append(f"统计范围: {start_date} 至 {end_date} 期间的未来交割敞口（含当日）")
        report_lines.append(f"机构: {org_display}")
        report_lines.append(f"状态: 企业-{DEFAULT_MERCHANT_STATUS} | 机构-{DEFAULT_ORG_STATUS}")
        report_lines.append(f"本次使用配置（GitHub fx_threshold.md）:")
        report_lines.append(f"  - 阈值: {alert_thresholds}")
        report_lines.append(f"  - 处理中交易阈值: {processing_thresholds}")
        report_lines.append(f"  - 交易时段: {trading_hours}")
        report_lines.append(f"  - 提醒开关: {'开启' if enable_alert else '关闭'}")
        report_lines.append(f"总交易笔数: {total_transactions} 笔")
        report_lines.append("=" * 80)
        
        # 1. 显示SUCCEEDED状态统计
        if settlement_stats:
           report_lines.append("📅 已完成交易统计 (按交割日期):")
           report_lines.append("=" * 60)
        
           # 按交割日期排序
           sorted_dates = sorted(settlement_stats.keys())
        
           for settle_date in sorted_dates[:5]:  # 只显示前5个交割日
               currency_pairs = settlement_stats[settle_date]
               report_lines.append(f"交割日期: {settle_date}")
               report_lines.append("-" * 40)
            
               sorted_pairs = sorted(currency_pairs.keys())[:3]  # 只显示前3个货币对
               for currency_pair in sorted_pairs:
                   stats = currency_pairs[currency_pair]
                   total_sell = stats.get('total_sell', 0)
                   total_buy = stats.get('total_buy', 0)
                   count = stats.get('count', 0)
                
                   if '/' in currency_pair:
                       sell_cur, buy_cur = currency_pair.split('/')
                   else:
                       sell_cur, buy_cur = currency_pair[:3], currency_pair[3:]
                
                   report_lines.append(f"货币对 {currency_pair}:")
                   report_lines.append(f"  交易笔数: {count} 笔")
                   report_lines.append(f"  总卖出金额: {total_sell:,.2f} {sell_cur}")
                   report_lines.append(f"  总买入金额: {total_buy:,.2f} {buy_cur}")
                
                   # 检查是否超过阈值
                   if currency_pair in config.get('ALERT_THRESHOLDS', {}):
                       threshold = config['ALERT_THRESHOLDS'][currency_pair]
                       if total_sell > threshold:
                           excess = total_sell - threshold
                           report_lines.append(f"  ⚠️ 超限告警: 卖出 {total_sell:,.2f} > 阈值 {threshold:,.2f} (超出 {excess:,.2f})")
                
                   report_lines.append("")
    
        # 2. 显示PROCESSING状态统计
        if processing_stats:
            report_lines.append("⏳ 处理中交易统计 (按货币对):")
            report_lines.append("=" * 60)
        
            sorted_pairs = sorted(processing_stats.keys())[:3]  # 只显示前3个货币对
            for currency_pair in sorted_pairs:
                stats = processing_stats[currency_pair]
                total_sell = stats.get('total_sell', 0)
                total_buy = stats.get('total_buy', 0)
                count = stats.get('count', 0)
            
                if '/' in currency_pair:
                    sell_cur, buy_cur = currency_pair.split('/')
                else:
                    sell_cur, buy_cur = currency_pair[:3], currency_pair[3:]
            
                report_lines.append(f"货币对 {currency_pair}:")
                report_lines.append(f"  交易笔数: {count} 笔")
                report_lines.append(f"  总卖出金额: {total_sell:,.2f} {sell_cur}")
                report_lines.append(f"  总买入金额: {total_buy:,.2f} {buy_cur}")
            
                # 检查是否超过阈值
                if currency_pair in config.get('ALERT_THRESHOLDS', {}):
                    threshold = config['ALERT_THRESHOLDS'][currency_pair]
                    if total_sell > threshold:
                        excess = total_sell - threshold
                        report_lines.append(f"  ⚠️ 超限告警: 卖出 {total_sell:,.2f} > 阈值 {threshold:,.2f} (超出 {excess:,.2f})")
            
                report_lines.append("")
    
        # 将报告写入日志
        for line in report_lines:
            logger.info(line)
    
    def _send_monitoring_summary_alert(self, result: Dict, config: Dict, org_display: str, start_date: str, end_date: str):
        """发送交易监控汇总告警"""
        try:
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            alerts_sent = result.get('alerts_sent', [])
            alert_count = len(alerts_sent)
        
            if alert_count == 0:
                return  # 没有告警，不发送消息
        
            # 初始化告警消息
            alert_msg = ""
        
            # 按状态分组告警
            succeeded_alerts = [a for a in alerts_sent if a.get('status') == 'SUCCEEDED']
            processing_alerts = [a for a in alerts_sent if a.get('status') == 'PROCESSING']
        
            # 构建告警标题
            alert_msg += f"🚨 换汇交易量监控告警\n"
            alert_msg += f"⏰ 触发时间: {current_time}\n"
            alert_msg += f"🏦 监控机构: {org_display}\n"
            alert_msg += f"📅 查询范围: {start_date} 至 {end_date}\n"
            alert_msg += f"📊 告警总数: {alert_count} 条\n\n"
        
            # 如果有SUCCEEDED状态的告警
            if succeeded_alerts:
                alert_msg += f"✅ 已完成交易告警 ({len(succeeded_alerts)}条):\n"
                alert_msg += "-" * 40 + "\n"
            
                for i, alert in enumerate(succeeded_alerts[:5], 1):  # 最多显示3条
                    currency_pair = alert.get('currency_pair', 'N/A')
                    settle_date = alert.get('settle_date', 'N/A')
                    threshold = alert.get('threshold', 'N/A')
                    actual_sell = alert.get('actual_sell', 'N/A')
                    excess_amount = alert.get('excess_amount', 'N/A')
                    threshold_type = alert.get('threshold_type', '已完成交易阈值')
                
                    alert_msg += f"{i}. {currency_pair} (交割日: {settle_date})\n"
                    alert_msg += f"   阈值类型: {threshold_type}\n"
                    alert_msg += f"   阈值: {threshold} | 实际: {actual_sell} | 超出: {excess_amount}\n"
            
                if len(succeeded_alerts) > 5:
                    alert_msg += f"   还有 {len(succeeded_alerts) - 5} 条已折叠...\n"
                alert_msg += "\n"
        
            # 如果有PROCESSING状态的告警
            if processing_alerts:
                alert_msg += f"⏳ 处理中交易告警 ({len(processing_alerts)}条):\n"
                alert_msg += "-" * 40 + "\n"
            
                for i, alert in enumerate(processing_alerts[:5], 1):  # 最多显示3条
                    currency_pair = alert.get('currency_pair', 'N/A')
                    threshold = alert.get('threshold', 'N/A')
                    actual_sell = alert.get('actual_sell', 'N/A')
                    excess_amount = alert.get('excess_amount', 'N/A')
                    threshold_type = alert.get('threshold_type', '处理中交易阈值')
                    count = alert.get('count', 0)
                
                    alert_msg += f"{i}. {currency_pair} (处理中)\n"
                    alert_msg += f"   阈值类型: {threshold_type}\n"
                    alert_msg += f"   阈值: {threshold} | 实际: {actual_sell} | 超出: {excess_amount}\n"
                    alert_msg += f"   交易笔数: {count} 笔\n"
            
                if len(processing_alerts) > 5:
                    alert_msg += f"   还有 {len(processing_alerts) - 5} 条已折叠...\n"
                alert_msg += "\n"
        
            # 添加统计摘要
            settlement_stats = result.get('settlement_stats', {})
            processing_stats = result.get('processing_stats', {})
        
            if settlement_stats or processing_stats:
                alert_msg += f"📈 统计摘要:\n"
                alert_msg += "-" * 40 + "\n"
            
                # SUCCEEDED状态统计
                if settlement_stats:
                    total_sell_succeeded = 0.0
                    for date_stats in settlement_stats.values():
                        for pair_stats in date_stats.values():
                            total_sell_succeeded += pair_stats.get('total_sell', 0.0)
                    alert_msg += f"✅ 已完成交易: {len(settlement_stats)}个交割日\n"
                    alert_msg += f"   总卖出金额: {total_sell_succeeded:,.2f}\n"
            
                # PROCESSING状态统计
                if processing_stats:
                    total_sell_processing = 0.0
                    for pair_stats in processing_stats.values():
                        total_sell_processing += pair_stats.get('total_sell', 0.0)
                    alert_msg += f"⏳ 处理中交易: {len(processing_stats)}个货币对\n"
                    alert_msg += f"   总卖出金额: {total_sell_processing:,.2f}\n"
            
                alert_msg += "\n"

            alert_msg += f"⚠️ 提醒: 两种状态使用不同的阈值配置\n"        
            alert_msg += f"⚠️ 提醒: 当某货币对的总卖出金额超过阈值时触发告警\n"
            alert_msg += f"📅 下次监控: {self.interval_minutes}分钟后"
        
            # 发送到企业微信
            send_wechat_work_message(alert_msg)
        
        except Exception as e:
            logger.error(f"发送交易监控汇总告警失败: {e}")
    
    def _task_loop(self):
        """任务循环主体"""
        org_display = self.org_code or "全部"
        logger.info(f"✅ 交易监控定时任务已启动")
        logger.info(f"   监控机构: {org_display}")
        logger.info(f"   执行间隔: {self.interval_minutes} 分钟")
        
        while not self.stop_event.is_set():
            try:
                # 执行一次监控
                self._execute_monitoring_task()
            except Exception as e:
                logger.error(f"交易监控定时任务循环内发生异常: {e}")
            
            # 等待指定的间隔时间
            self.stop_event.wait(timeout=self.interval_minutes * 60)
    
    def start(self):
        """启动定时任务（在后台线程中）"""
        if self.is_running:
            org_display = self.org_code or "全部"
            return f"⚠️ 交易监控定时任务已在运行中。当前监控机构: {org_display}"
        
        self.is_running = True
        self.stop_event.clear()
        
        self.task_thread = threading.Thread(
            target=self._task_loop,
            name=f"FxMonitoringTask_{self.org_code or 'ALL'}",
            daemon=True
        )
        self.task_thread.start()
        
        org_display = self.org_code or "全部"
        return (f"✅ 已启动交易监控定时任务\n"
                f"🏦 监控机构: {org_display}\n"
                f"⏰ 执行间隔: 每 {self.interval_minutes} 分钟\n"
                f"📊 监控内容: 未来交割交易敞口与阈值告警")
    
    def stop(self):
        """停止定时任务"""
        if not self.is_running:
            org_display = self.org_code or "全部"
            return f"ℹ️ 交易监控定时任务未在运行。"
        
        self.is_running = False
        self.stop_event.set()
        
        if self.task_thread and self.task_thread.is_alive():
            self.task_thread.join(timeout=5.0)
        
        org_display = self.org_code or "全部"
        return f"🛑 交易监控定时任务已停止。原监控机构: {org_display}"
    
    def status(self):
        """获取任务状态"""
        if self.is_running and self.task_thread and self.task_thread.is_alive():
            org_display = self.org_code or "全部"
            return (f"🟢 任务状态: 运行中\n"
                    f"🏦 监控机构: {org_display}\n"
                    f"⏰ 执行间隔: {self.interval_minutes} 分钟")
        else:
            return f"🔴 任务状态: 已停止"

# ===================== 汇率监控类 =====================
