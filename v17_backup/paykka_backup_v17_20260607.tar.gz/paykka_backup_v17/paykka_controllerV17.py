# ===================== 文件: paykka_controllerV17.py =====================
# 完整集成版本：汇差配置 + 路由配置 + 余额查询 + 换汇交易监控 + PAYKKA-XT汇率监控
# + 渠道与友商报价对比（V17 新增）
# 第一部分：导入与全局配置
import lark_oapi as lark
from lark_oapi.api.im.v1 import *
import json
import pyotp
import time
import urllib.parse
import requests
import re
import threading
import os
import hashlib
import sys
import ast
from typing import List, Dict, Tuple, Any, Optional, Union
from playwright.async_api import async_playwright
import asyncio
from datetime import datetime, date, timedelta, timezone, time as dtime
from github import Github, InputGitAuthor
import logging
from logging.handlers import RotatingFileHandler
import pandas as pd
import base64
import subprocess
import pytz
import schedule

# V17 新增：报价对比引擎
from paykka_comparison import QuoteComparisonEngine, DEFAULT_CHANNEL_SOURCES, DEFAULT_COMPETITOR_SOURCES

# ===================== 全局配置 =====================
# PAYKKA登录凭据
PAYKKA_USERNAME = "zhengkai"
PAYKKA_PASSWORD = "7639179zK@"
PAYKKA_OTP_SECRET = "MQHAFQJXNK4LK4NN24JSSS2KZLNB4E2P"

# 飞书机器人配置
LARK_APP_ID = "cli_a92121fea1f85bc9"
LARK_APP_SECRET = "BR43BDpJ5wLg7IVTcJ213dOFKxus6s2K"
LARK_ENCRYPT_KEY = ""
LARK_VERIFICATION_TOKEN = ""

# 企业微信群机器人Webhook地址
WECHAT_WEBHOOK_URL = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=85c09e71-c20c-433e-b663-58f3b392c2d0"

# GitHub配置
GITHUB_TOKEN = "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"
GITHUB_REPO_NAME = "13058199807zk-oss/paykka-control"
GITHUB_FILE_PATH = "fx_rule_config.md"
GITHUB_USERNAME = "13058199807zk-oss"
GITHUB_EMAIL = "13058199807zk@gmail.com"

# 余额查询相关GitHub配置
GITHUB_REPO_OWNER = "13058199807zk-oss"
GITHUB_BALANCE_REPO_NAME = "Paykka-K"
GITHUB_BALANCE_FILE_PATH = "docs/index.html"
GITHUB_THRESHOLD_FILE_PATH = "balance_threshold.md"
GITHUB_BRANCH = "main"

# 换汇交易监控相关GitHub配置
GITHUB_THRESHOLD_FILE_PATH_MD = "fx_threshold.md"

# 汇率监控GitHub配置
GITHUB_RATE_FILE_PATH = "rate_comparison.md"  # 新添加：汇率报告文件路径

# 支持的换汇策略规则
FX_STRATEGY_RULES = [
    "RULE_CC", "RULE_MDAQ_WALLEX", "RULE_FX_TOD", "RULE_FX_TOM", 
    "RULE_FX_SPOT", "RULE_PP", "RULE_YB", "RULE_HCE_TOD", "RULE_HCE_TOM", "RULE_HCE_SPOT", "RULE_BC", 
    "RULE_OCBC", "RULE_FLUTTERWAVE", "RULE_PAYKKA"
]

# 余额查询配置
BALANCE_API_ENDPOINT = "/recv-org/op/org/account-balance/query"
BALANCE_BASE_URL = "https://ops-bk.cb.paykka.com"
INSTITUTION_MAP = {
    "YB": "易宝",
    "CC": "Currencycloud",
}
INSTITUTION_CURRENCIES = {
    "YB": ["USD", "CNH", "HKD", "EUR", "GBP", "JPY", "AUD", "CAD", "SGD"],
    "CC": ["USD", "CNY", "HKD", "EUR", "GBP", "JPY", "AUD", "CAD", "SGD", "THB", "PHP", "HUF", "RON", "CZK", "PLN"],
}
EXCEL_FILENAME = "机构余额查询记录.xlsx"

# 换汇交易监控配置
FX_TRANSACTION_API = "/forex/ops/fx/page"
FX_FULL_TRANSACTION_URL = "https://ops-bk.cb.paykka.com" + FX_TRANSACTION_API

# 机构列表
ORG_LIST = [
    "YB", "MDAQ_FX_TOM", "CC", "HCE", "MDAQ", "PP", 
    "IBC", "OCBC", "NEWPAY", "PingPong", "PAYKKA"
]

# 不需要除以100的币种
NO_DIVIDE_CURRENCIES = ["VND", "JPY"]

# 默认查询条件
DEFAULT_MERCHANT_STATUS = "SUCCEEDED"
DEFAULT_ORG_STATUS = "SUCCEEDED,PROCESSING" #["SUCCEEDED","PROCESSING"]

# 会话保持配置
SESSION_EXPIRE_HOURS = 1
SESSION_FILE = "paykka_session.json"

# 汇率监控配置
# 1. PAYKKA平台配置
PAYKKA_RATE_URL = "https://ops-bk.cb.paykka.com/forex/ops/inquiry/get-quote"
PAYKKA_COOKIE_FILE = "paykka_cookie.txt"

# 2. XT平台配置
XT_SCRIPT = "xt_rateV3.py"  # 确保此文件在同一目录
XT_AUTH_FILE = "xt_auth_info.json"
XT_RESULTS_DIR = "xt_results"  # XT查询结果保存目录

# 2.1 XT 汇率查询模块配置
XT_LOGIN_PHONE = "13058199807"
XT_LOGIN_PASSWORD = "7639179zK@"
XT_LOGIN_URL = "https://www.xtransfer.cn/login"
XT_TARGET_URL = "https://www.xtransfer.cn/fund/home"
XT_RATE_API_URL = "https://api.xtransfer.cn/api/v1/spotfx/graph/present-rate/get-rate-by-ccy"
XT_AUTH_CACHE_FILE = "xt_auth_cache.json"        # XT 认证缓存（Cookie/Token）
XT_AUTH_CACHE_DURATION = 23 * 3600               # 缓存有效期 23 小时

# XT 货币对列表（友商 XT 平台支持的完整货币对，与 xt_rateV3 一致）
XT_CURRENCY_PAIRS = [
    ("USD", "CNY", "美元兑离岸人民币"),
    ("EUR", "CNY", "欧元兑离岸人民币"),
    ("HKD", "CNY", "港币兑离岸人民币"),
    ("GBP", "CNY", "英镑兑离岸人民币"),
    ("SGD", "CNY", "新加坡元兑离岸人民币"),
    ("AUD", "CNY", "澳元兑离岸人民币"),
    ("IDR", "CNY", "印尼盾兑离岸人民币"),
    ("MYR", "CNY", "马来西亚令吉兑离岸人民币"),
    ("PHP", "CNY", "菲律宾比索兑离岸人民币"),
    ("THB", "CNY", "泰铢兑离岸人民币"),
    ("RON", "CNY", "罗马尼亚列伊兑离岸人民币"),
    ("PLN", "CNY", "波兰兹罗提兑离岸人民币"),
    ("HUF", "CNY", "匈牙利福林兑离岸人民币"),
    ("NGN", "USD", "尼日利亚奈拉兑美元"),
    ("VND", "CNY", "越南盾兑离岸人民币"),
    ("VND", "USD", "越南盾兑美元"),
]

# 2.2 友商汇率查询模块配置
# WorldFirst (WF)
WF_USERNAME = "18664585320"
WF_PASSWORD = "Ifast@123"
WF_LOGIN_URL = "https://portal.worldfirst.com/login?loginType=MOBILE&region=CN"
WF_PORTAL_URL = "https://portal.worldfirst.com"
WF_API_URL = "https://imgs.worldfirst.com/mgw.htm"
WF_AUTH_CACHE_FILE = "wf_auth_cache.json"

# LianLian (LL) - LOGIN_TOKEN 方式，需手动配置
LL_API_URL = "https://www.lianlianglobal.cn/b2b/rate/payout/queryRealExchangeRate"
LL_LOGIN_TOKEN = ""  # 手动从浏览器获取后填入

# Airwallex (AW) - 固定 Cookie
AW_API_URL = "https://www.airwallex.com/api/fx/fxRate/indicativeQuote"
AW_COOKIE = "0a84cfe602e500cbedb599de12f8a234c4097a92_260316"

# Ksher (KS) - 固定 Headers
KS_API_URL = "https://www.ksher.cn/api/fx/reference_rates_v2"
KS_COOKIE = "i_r_code=0438; Hm_lvt_a28dcc9a9305a2ffaa8d1a49c690585f=1773812836; HMACCOUNT=FE5BF9431421BFBF; _fbp=fb.1.1773812836491.194955317918274466; _ga=GA1.1.1429049773.1773812837; _blmsdk_did=05e04071cc383c-19cff7bf05dc8-26061c51-1fa400-19cff7bf05ec8; kgp=eaf69ea7-aa8a-4547-abc9-4c474b8fd54d; _gcl_au=1.1.514858404.1773815640; _blmsdk_as_uid=149279; USessionId=da2609d8138e4e7f812cf10855102ec5; version=new; Hm_lpkt_a28dcc9a9305a2ffaa8d1a49c690585f=1774431186; _ga_LEM48MXE6G=GS2.1.s1774429710$o4$g0$t1774431185$j60$l0$h0; _blmsdk_s=19d24408390-f77-a19-d67%7C25"
KS_MERCHANT_ID = "M25072300128809120"
KS_M_ID = "211bc6ae9d3891460edaae3cd7455a67"

# Skyee (SK) - Authorization Token
SK_API_URL = "https://business.skyee360.com/api/v1/ExchangeRate"
SK_AUTH_TOKEN = "Business-a6feda05271efc292581338f18ee96e8"

# 统一货币对列表（所有友商共用的查询货币对）
COMPETITOR_CURRENCY_PAIRS = [
    ("USD", "CNH", "美元/离岸人民币"),
    ("EUR", "CNH", "欧元/离岸人民币"),
    ("HKD", "CNH", "港币/离岸人民币"),
    ("GBP", "CNH", "英镑/离岸人民币"),
    ("SGD", "CNH", "新加坡元/离岸人民币"),
    ("AUD", "CNH", "澳元/离岸人民币"),
    ("IDR", "CNH", "印尼盾/离岸人民币"),
    ("MYR", "CNH", "马来西亚令吉/离岸人民币"),
    ("PHP", "CNH", "菲律宾比索/离岸人民币"),
    ("THB", "CNH", "泰铢/离岸人民币"),
    ("RON", "CNH", "罗马尼亚列伊/离岸人民币"),
    ("PLN", "CNH", "波兰兹罗提/离岸人民币"),
    ("HUF", "CNH", "匈牙利福林/离岸人民币"),
    ("NGN", "USD", "尼日利亚奈拉/美元"),
    ("VND", "CNH", "越南盾/离岸人民币"),
    ("VND", "USD", "越南盾/美元"),
]

# 友商代码映射
COMPETITOR_CODES = {
    "XT": "XTransfer",
    "WF": "WorldFirst",
    "LL": "LianLian",
    "AW": "Airwallex",
    "KS": "Ksher",
    "SK": "Skyee",
}

# 3. 监控配置
RATE_ALERT_THRESHOLD = 0.5  # 汇率差距百分比阈值（默认0.5%）
RATE_CHECK_INTERVAL_MINUTES = 5  # 检查间隔（分钟）
RATE_MAX_ALERTS_PER_HOUR = 10  # 每小时最大报警次数

# 4. 统一货币对（显示为CNH，XT查询时内部处理CNY/CNH映射）
CURRENCY_PAIRS = [
    #("USD", "CNH", "美元兑离岸人民币"),
    #("EUR", "CNH", "欧元兑离岸人民币"),
    #("HKD", "CNH", "港币兑离岸人民币"),
    #("GBP", "CNH", "英镑兑离岸人民币"),
    #("SGD", "CNH", "新加坡元兑离岸人民币"),
    #("AUD", "CNH", "澳元兑离岸人民币"),
    ("NGN", "USD", "尼日利亚奈拉兑美元"),
    ("VND", "CNH", "越南盾兑离岸人民币"),
    ("VND", "USD", "越南盾兑美元"),
]

# 汇率监控Webhook（可使用余额预警相同的Webhook）
RATE_MONITOR_WEBHOOK = WECHAT_WEBHOOK_URL

# 路由价格监控配置
EXCHANGE_RATE_WEBHOOK_URL = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=4c15eb09-0b7d-4ca7-b378-ae169ddc4917"
EXCHANGE_RATE_MONITOR_INTERVAL = 10  # 监控间隔（分钟）

# 目标汇率源
TARGET_RATE_SOURCES = ["OCBC", "YB", "MDAQ_FX_TOM", "HCE_FX_TOM"]

# 路由价格监控API
EXCHANGE_RATE_API_URL = "https://ops-bk.cb.paykka.com/payment-org/op/channel/exchange-rate/page"
EXCHANGE_RATE_MONITOR_LOG = "exchange_rate_monitor.log"

# 交易时段配置
TRADING_START_HOUR = 8
TRADING_END_HOUR = 15
TRADING_END_MINUTE = 30

# ===================== 日志配置 =====================
def setup_logging():
    """设置日志配置"""
    log_dir = "logs"
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    logger = logging.getLogger("paykka_integrated")
    logger.setLevel(logging.INFO)
    
    # 文件处理器
    file_handler = RotatingFileHandler(
        f"{log_dir}/paykka_integrated.log", 
        maxBytes=10 * 1024 * 1024,  # 10MB
        backupCount=5,
        encoding='utf-8'
    )
    file_handler.setLevel(logging.INFO)
    
    # 控制台处理器
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    
    # 格式化
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger

logger = setup_logging()

# ===================== 全局单例管理器 =====================
class PaykkaSystemManager:
    """PAYKKA系统管理器（全局单例） - 增强版，支持自动重连和定时Token刷新"""
    _instance = None
    _forex_configurator = None
    _routing_configurator = None
    _balance_query = None
    _fx_transaction_monitor = None
    _rate_monitor = None
    _token = None
    _last_login_time = None
    _deduplicator = None
    _login_lock = threading.Lock()  # 新增：登录锁，防止并发登录
    _is_refreshing = False  # 新增：刷新状态标志
    _exchange_rate_monitor = None  # 新增：路由价格监控器
    _xt_rate_query = None  # 新增：XT 汇率查询器
    _fx_monitoring_task = None  # 新增：全局定时任务实例
    _balance_monitoring_task = None
    _routing_scheduler = None  # 新增：路由调度器
    # 新增：Token自动刷新相关
    _token_refresh_thread = None
    _token_refresh_stop_event = None
    _token_refresh_times = ["13:00", "01:00"]  # 每天两次刷新时间
    _token_refresh_interval = 12 * 3600  # 12小时（秒），作为备用的固定间隔

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._deduplicator = MessageDeduplicator()
            # 启动Token自动刷新任务（原第一个__new__中的逻辑，合并到此处）
            cls._instance._start_token_auto_refresh()
        return cls._instance

    def _start_token_auto_refresh(self):
        """启动Token自动刷新任务"""
        if self._token_refresh_thread and self._token_refresh_thread.is_alive():
            logger.warning("Token自动刷新任务已在运行中")
            return

        self._token_refresh_stop_event = threading.Event()
        self._token_refresh_thread = threading.Thread(
            target=self._token_refresh_loop,
            name="TokenAutoRefresh",
            daemon=True
        )
        self._token_refresh_thread.start()
        logger.info("✅ Token自动刷新任务已启动")

    def _stop_token_auto_refresh(self):
        """停止Token自动刷新任务"""
        if self._token_refresh_stop_event:
            self._token_refresh_stop_event.set()
        
        if self._token_refresh_thread and self._token_refresh_thread.is_alive():
            self._token_refresh_thread.join(timeout=5.0)
            logger.info("🛑 Token自动刷新任务已停止")
    
    def _calculate_next_refresh_time(self) -> datetime:
        """计算下一次刷新Token的时间"""
        now = datetime.now()
        
        # 将刷新时间转换为datetime对象
        refresh_times = []
        for time_str in self._token_refresh_times:
            hour, minute = map(int, time_str.split(":"))
            # 创建今天的刷新时间
            refresh_time = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            
            # 如果今天的刷新时间已过，就是明天
            if refresh_time <= now:
                refresh_time += timedelta(days=1)
            
            refresh_times.append(refresh_time)
        
        # 返回最近的下一次刷新时间
        return min(refresh_times)
    
    def _refresh_token_with_retry(self, max_retries=3, retry_delay=60):
        """刷新Token（带重试机制）- 修复事件循环冲突"""
        import asyncio
    
        for attempt in range(max_retries):
            try:
                logger.info(f"🔄 第{attempt+1}次尝试刷新Token...")
            
                # 方法1：检查是否已经有运行的事件循环
                try:
                    # 尝试获取当前线程的事件循环
                    loop = asyncio.get_event_loop()
                
                    # 检查事件循环是否已经在运行
                    if loop.is_running():
                        # 事件循环已经在运行，使用run_coroutine_threadsafe在新线程中运行
                        logger.info("检测到已有运行的事件循环，使用新线程运行异步登录")
                    
                        # 创建新的事件循环并在新线程中运行
                        import concurrent.futures
                        import threading
                    
                        # 使用线程池运行异步函数
                        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                            future = executor.submit(self._run_async_login_in_thread, force=True)
                            token = future.result(timeout=120)  # 120秒超时
                    else:
                        # 事件循环存在但没有运行，可以直接使用
                        logger.info("事件循环存在但未运行，使用run_until_complete")
                        token = loop.run_until_complete(self.login(force=True))
                except RuntimeError:
                    # 没有事件循环，创建新的
                    logger.info("没有事件循环，创建新的")
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        token = loop.run_until_complete(self.login(force=True))
                    finally:
                        loop.close()
            
                if token:
                    logger.info(f"✅ Token刷新成功，新Token长度: {len(token)}")
                
                    # 更新所有已初始化的模块的Token
                    self._update_all_modules_token(token)
                
                    # 记录刷新时间
                    self._last_login_time = time.time()
                    logger.info(f"📅 Token已更新到所有模块，有效期重新开始计算")
                    return True
                else:
                    logger.error("❌ Token刷新失败，返回为空")
        
            except Exception as e:
                logger.error(f"❌ Token刷新异常（第{attempt+1}次）: {e}")
                import traceback
                logger.error(traceback.format_exc())
        
            # 如果不是最后一次重试，等待后继续
            if attempt < max_retries - 1:
                logger.info(f"⏸️ 等待{retry_delay}秒后重试...")
                time.sleep(retry_delay)
    
        logger.error(f"❌ Token刷新失败，已达最大重试次数{max_retries}")
        return False

    def _run_async_login_in_thread(self, force=False):
        """在新线程中运行异步登录函数"""
        import asyncio
        import threading
    
        result = None
    
        def run_in_thread():
            """在新线程中运行的事件循环"""
            nonlocal result
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                result = loop.run_until_complete(self.login(force))
            except Exception as e:
                logger.error(f"新线程中登录失败: {e}")
            finally:
                loop.close()
    
        # 创建并启动线程
        thread = threading.Thread(target=run_in_thread, daemon=True)
        thread.start()
        thread.join(timeout=120)  # 等待120秒
    
        return result
    
    def _update_all_modules_token(self, new_token: str):
        """更新所有已初始化模块的Token"""
        modules_updated = 0
        
        if self._forex_configurator:
            self._forex_configurator.token = new_token
            modules_updated += 1
        
        if self._routing_configurator:
            self._routing_configurator.token = new_token
            modules_updated += 1
        
        if self._balance_query:
            self._balance_query.token = new_token
            modules_updated += 1
        
        if self._fx_transaction_monitor:
            self._fx_transaction_monitor.token = new_token
            modules_updated += 1
        
        if self._rate_monitor:
            self._rate_monitor.token = new_token
            modules_updated += 1
        
        if self._exchange_rate_monitor:
            self._exchange_rate_monitor.token = new_token
            modules_updated += 1
        
        if self._routing_scheduler:
            self._routing_scheduler.token = new_token
            modules_updated += 1
        
        # 更新全局Token
        self._token = new_token
        logger.info(f"✅ Token已更新到 {modules_updated} 个模块")
    
    def _token_refresh_loop(self):
        """Token自动刷新循环"""
        logger.info(f"⏰ Token自动刷新任务启动，刷新时间: {', '.join(self._token_refresh_times)}")
        
        # 首次启动时，立即刷新一次（确保Token是最新的）
        logger.info("🔄 程序启动，立即刷新Token...")
        self._refresh_token_with_retry()
        
        while not self._token_refresh_stop_event.is_set():
            try:
                # 计算下一次刷新时间
                next_refresh_time = self._calculate_next_refresh_time()
                wait_seconds = (next_refresh_time - datetime.now()).total_seconds()
                
                if wait_seconds > 0:
                    logger.info(f"⏰ 下次Token刷新时间: {next_refresh_time.strftime('%Y-%m-%d %H:%M:%S')} (还有{wait_seconds/3600:.1f}小时)")
                    
                    # 等待到刷新时间
                    self._token_refresh_stop_event.wait(timeout=min(wait_seconds, 3600))  # 最长等待1小时
                else:
                    # 已经到了刷新时间，立即执行
                    self._refresh_token_with_retry()
                    
                    # 执行后短暂休眠，避免CPU占用过高
                    self._token_refresh_stop_event.wait(timeout=60)
                    
            except Exception as e:
                logger.error(f"❌ Token自动刷新循环异常: {e}")
                # 发生异常时，等待1小时后重试
                self._token_refresh_stop_event.wait(timeout=600)

    def get_routing_scheduler(self):
        """获取路由调度器"""
        if not self._routing_scheduler:
            token = self.get_token()
            if not token:
                raise Exception("无法获取Token，请检查登录凭据")
            self._routing_scheduler = RoutingScheduler(token)
        return self._routing_scheduler
    
    def get_fx_monitoring_task(self):
        """获取全局交易监控定时任务实例"""
        return self._fx_monitoring_task
    
    def set_fx_monitoring_task(self, task):
        """设置全局交易监控定时任务实例"""
        self._fx_monitoring_task = task
    
    def clear_fx_monitoring_task(self):
        """清除全局交易监控定时任务实例"""
        if self._fx_monitoring_task:
            # 停止任务
            if self._fx_monitoring_task.is_running:
                self._fx_monitoring_task.stop()
            self._fx_monitoring_task = None

    def get_balance_monitoring_task(self):
        """获取全局余额监控定时任务实例"""
        return self._balance_monitoring_task
    
    def set_balance_monitoring_task(self, task):
        """设置全局余额监控定时任务实例"""
        self._balance_monitoring_task = task
    
    def clear_balance_monitoring_task(self):
        """清除全局余额监控定时任务实例"""
        if self._balance_monitoring_task:
            # 停止任务
            if self._balance_monitoring_task.is_running:
                self._balance_monitoring_task.stop()
            self._balance_monitoring_task = None
    
    # __new__ 已在类上方定义（含 _start_token_auto_refresh 调用），此处不再重复定义
    
    async def login(self, force=False):
        """登录获取Token（带锁的线程安全版本）"""
        with self._login_lock:
            if self._token and not force:
                # 检查Token是否过期（超过24小时）
                if self._last_login_time and (time.time() - self._last_login_time) < 86400:
                    return self._token
            
            logger.info("🔐 开始全局自动登录...")
            token = await paykka_auto_login_with_otp(
                PAYKKA_USERNAME, 
                PAYKKA_PASSWORD, 
                PAYKKA_OTP_SECRET
            )
            
            if token:
                self._token = token
                self._last_login_time = time.time()
                logger.info(f"✅ 全局登录成功，Token长度: {len(token)}")
                self._is_refreshing = False
            else:
                logger.error("❌ 全局登录失败")
                
            return self._token
    
    def refresh_token_if_needed(self, api_response=None):
        """
        智能Token刷新：根据API响应判断是否需要刷新Token
        返回：(是否需要重试, 新的Token或None)
        """
        # 情况1：API返回明确的认证错误
        if api_response and isinstance(api_response, dict):
            ret_code = api_response.get('ret_code')
            if ret_code in ['010112', '401', '403']:  # 认证相关错误码
                logger.warning(f"⚠️ 检测到认证错误 {ret_code}，触发自动Token刷新")
                new_token = self.refresh_token()
                return True, new_token
        
        # 情况2：Token为空或明显无效
        if not self._token or len(self._token) < 10:
            logger.warning("⚠️ Token无效或过短，触发自动刷新")
            new_token = self.refresh_token()
            return True, new_token
        
        # 情况3：Token过期（超过24小时）
        if self._last_login_time and (time.time() - self._last_login_time) > 86400:
            logger.warning("⚠️ Token已过期（>24小时），触发自动刷新")
            new_token = self.refresh_token()
            return True, new_token
        
        return False, self._token
    
    def refresh_token(self):
        """刷新Token（强制重新登录）并更新所有依赖模块 - 使用线程安全的异步调用"""
        logger.info("🔄 强制刷新Token...")
        self._is_refreshing = True
        
        # 使用已有的 _refresh_token_with_retry 方法，内部已正确处理异步调用
        success = self._refresh_token_with_retry(max_retries=2, retry_delay=30)
        
        self._is_refreshing = False
        return self._token if success else None
    
    def safe_api_call(self, api_func, *args, **kwargs):
        """
        安全的API调用封装，自动处理Token过期和重试
        参数:
            api_func: 要执行的API函数
            max_retries: 最大重试次数（默认2）
            retry_delay: 重试延迟秒数（默认1）
        返回: (成功标志, 结果或错误信息)
        """
        max_retries = kwargs.pop('max_retries', 2)
        retry_delay = kwargs.pop('retry_delay', 1)
        
        for attempt in range(max_retries + 1):
            try:
                result = api_func(*args, **kwargs)
                
                # 检查API响应是否需要刷新Token
                if isinstance(result, dict) and 'ret_code' in result:
                    need_retry, new_token = self.refresh_token_if_needed(result)
                    if need_retry and attempt < max_retries:
                        logger.info(f"🔄 认证失败，第{attempt+1}次重试...")
                        time.sleep(retry_delay)
                        continue
                
                return True, result
                
            except requests.exceptions.ConnectionError as e:
                if attempt < max_retries:
                    logger.warning(f"🔌 网络连接失败，第{attempt+1}次重试: {e}")
                    time.sleep(retry_delay * 2)  # 网络错误等待更久
                else:
                    return False, f"网络连接失败: {e}"
                    
            except requests.exceptions.Timeout as e:
                if attempt < max_retries:
                    logger.warning(f"⏰ 请求超时，第{attempt+1}次重试")
                    time.sleep(retry_delay)
                else:
                    return False, f"请求超时: {e}"
                    
            except Exception as e:
                # 其他异常，检查是否是认证相关
                error_str = str(e).lower()
                if any(auth_keyword in error_str for auth_keyword in ['auth', 'token', 'unauthorized', 'forbidden']):
                    if attempt < max_retries:
                        logger.warning(f"🔐 认证异常，第{attempt+1}次重试: {e}")
                        self.refresh_token()
                        time.sleep(retry_delay)
                        continue
                
                return False, f"API调用异常: {e}"
        
        return False, "达到最大重试次数"
    
    def get_token(self):
        """获取Token（如果不存在或已过期则自动刷新）"""
        if not self._token:
            # Token不存在，使用线程安全的方式刷新
            success = self._refresh_token_with_retry(max_retries=1, retry_delay=10)
            if not success:
                logger.error("❌ 无法获取Token，自动登录失败")
            return self._token
        
        # 检查Token是否接近过期（超过20小时视为即将过期）
        if self._last_login_time and (time.time() - self._last_login_time) > 20 * 3600:
            logger.warning("⚠️ Token已使用超过20小时，主动刷新")
            self._refresh_token_with_retry(max_retries=1, retry_delay=10)
        
        return self._token
    
    def get_forex_configurator(self):
        """获取汇差配置器"""
        if not self._forex_configurator:
            token = self.get_token()
            if not token:
                raise Exception("无法获取Token，请检查登录凭据")
            self._forex_configurator = PaykkaForexConfigurator(token)
        return self._forex_configurator
    
    def get_routing_configurator(self):
        """获取路由配置器"""
        if not self._routing_configurator:
            token = self.get_token()
            if not token:
                raise Exception("无法获取Token，请检查登录凭据")
            self._routing_configurator = PaykkaRoutingConfigurator(token)
        return self._routing_configurator
    
    def get_balance_query(self):
        """获取余额查询器"""
        if not self._balance_query:
            token = self.get_token()
            if not token:
                raise Exception("无法获取Token，请检查登录凭据")
            self._balance_query = PaykkaBalanceQuery(token)
        return self._balance_query
    
    def get_fx_transaction_monitor(self):
        """获取换汇交易监控器"""
        if not self._fx_transaction_monitor:
            token = self.get_token()
            if not token:
                raise Exception("无法获取Token，请检查登录凭据")
            self._fx_transaction_monitor = PaykkaFxTransactionMonitor(token)
        return self._fx_transaction_monitor
    
    def get_rate_monitor(self):
        """获取汇率监控器"""
        if not self._rate_monitor:
            token = self.get_token()
            if not token:
                raise Exception("无法获取Token，请检查登录凭据")
            self._rate_monitor = PaykkaRateMonitor(token)
        return self._rate_monitor
    
    def get_deduplicator(self):
        """获取消息去重器"""
        return self._deduplicator

    def get_exchange_rate_monitor(self):
        """获取路由价格监控器"""
        if not self._exchange_rate_monitor:
            token = self.get_token()
            if not token:
                raise Exception("无法获取Token，请检查登录凭据")
            self._exchange_rate_monitor = PaykkaExchangeRateMonitor(token)
        return self._exchange_rate_monitor
    
    def get_xt_rate_query(self):
        """获取 XT 汇率查询器"""
        if not self._xt_rate_query:
            self._xt_rate_query = XTRateQueryManager()
        return self._xt_rate_query

# ===================== 消息去重管理器 =====================
class MessageDeduplicator:
    """消息去重管理器，防止重复处理"""
    
    def __init__(self, max_size=1000, timeout=86400):  # 24小时超时
        self.processed_messages = {}
        self.max_size = max_size
        self.timeout = timeout
        
    def is_processed(self, message_id: str) -> bool:
        """检查消息是否已处理"""
        if message_id in self.processed_messages:
            timestamp = self.processed_messages[message_id]
            if time.time() - timestamp < self.timeout:
                return True
            else:
                del self.processed_messages[message_id]
        
        self._cleanup()
        return False
    
    def mark_as_processed(self, message_id: str):
        """标记消息为已处理"""
        self.processed_messages[message_id] = time.time()
        
        if len(self.processed_messages) > self.max_size:
            oldest_key = min(self.processed_messages.items(), key=lambda x: x[1])[0]
            del self.processed_messages[oldest_key]
    
    def _cleanup(self):
        """清理过期条目"""
        current_time = time.time()
        expired_keys = [
            key for key, timestamp in self.processed_messages.items()
            if current_time - timestamp > self.timeout
        ]
        for key in expired_keys:
            del self.processed_messages[key]

# ===================== 企业微信群机器人通知 =====================
def send_wechat_work_message(message: str) -> bool:
    """向企业微信群机器人发送消息"""
    try:
        payload = {
            "msgtype": "text",
            "text": {
                "content": message
            }
        }
        
        response = requests.post(
            WECHAT_WEBHOOK_URL,
            json=payload,
            headers={'Content-Type': 'application/json'},
            timeout=10
        )
        
        result = response.json()
        if result.get("errcode") == 0:
            logger.info(f"✅ 企业微信群消息发送成功: {message}")
            return True
        else:
            logger.error(f"❌ 企业微信群消息发送失败: {result.get('errmsg')}")
            return False
            
    except Exception as e:
        logger.error(f"❌ 发送企业微信群消息异常: {e}")
        return False

# ===================== GitHub文件上传工具函数 =====================
def upload_to_github_md(content: str, file_path: str, commit_message: str = "Auto update") -> bool:
    """上传Markdown内容到GitHub"""
    try:
        g = Github(GITHUB_TOKEN)
        repo = g.get_repo(GITHUB_REPO_NAME)
        author = InputGitAuthor(GITHUB_USERNAME, GITHUB_EMAIL)
        
        try:
            # 尝试获取文件（如果存在）
            contents = repo.get_contents(file_path)
            repo.update_file(
                path=file_path,
                message=commit_message,
                content=content,
                sha=contents.sha,
                author=author
            )
        except Exception:
            # 文件不存在，创建新文件
            repo.create_file(
                path=file_path,
                message=commit_message,
                content=content,
                author=author
            )
        
        logger.info(f"✅ 文件已上传到GitHub: {file_path}")
        return True
            
    except Exception as e:
        logger.error(f"❌ 上传到GitHub时出错: {str(e)}")
        return False

# ===================== 通用工具函数 =====================
def get_microsoft_otp(secret_key):
    """从Microsoft Authenticator的base32密钥自动计算6位OTP"""
    cleaned_secret = secret_key.replace(" ", "")
    totp = pyotp.TOTP(cleaned_secret, interval=30, digits=6)
    current_otp = totp.now()
    remaining_seconds = 30 - (int(time.time()) % 30)
    return current_otp, remaining_seconds

async def paykka_auto_login_with_otp(username, password, otp_secret):
    """自动登录并提取Token"""
    valid_token = None
    async with async_playwright() as p:
        args = [
            "--start-maximized",
            "--force-device-scale-factor=1",
            "--window-position=0,0",
            "--disable-infobars",
            "--disable-notifications",
            "--disable-blink-features=AutomationControlled",
            "--ignore-https-errors",
            "--no-sandbox"
        ]

        browser = await p.chromium.launch(
            headless=True,
            channel="chrome",
            slow_mo=100,
            args=args
        )

        context = await browser.new_context(viewport=None, ignore_https_errors=True)
        page = await context.new_page()

        try:
            logger.info("开始访问PayKKa登录页面...")
            await page.goto("https://ops.cb.paykka.com/login")
            time.sleep(2)

            username_locator = page.locator("//input[@placeholder='请输入账号/邮箱地址/手机号']")
            await username_locator.wait_for(timeout=10000)
            await username_locator.fill(username)
            time.sleep(0.5)

            password_locator = page.locator("//input[@placeholder='请输入密码']")
            await password_locator.wait_for(timeout=10000)
            await password_locator.fill(password)
            time.sleep(0.5)

            login_button = page.locator("button:has-text('登录'), button[type='submit']").first
            await login_button.wait_for(timeout=10000)
            await login_button.click(force=True)
            logger.info("已点击登录，等待OTP验证页面加载...")
            time.sleep(2)

            otp_inputs = page.locator("//input[@maxlength='1']")
            await otp_inputs.first.wait_for(timeout=20000)
            otp_count = await otp_inputs.count()
            if otp_count < 6:
                raise Exception(f"OTP输入框数量异常，检测到{otp_count}个，需6个")
            logger.info("OTP验证页面已加载完成")

            otp_code, remaining = get_microsoft_otp(otp_secret)
            logger.info(f"自动计算出OTP码：{otp_code}（剩余有效时间：{remaining}秒）")
            if remaining < 8:
                time.sleep(5)
                otp_code, remaining = get_microsoft_otp(otp_secret)
                logger.info(f"OTP即将过期，重新计算：{otp_code}")

            for i in range(6):
                await otp_inputs.nth(i).wait_for(timeout=5000)
                await otp_inputs.nth(i).fill(str(otp_code)[i])
                time.sleep(0.2)
            logger.info("已自动填充OTP验证码，等待登录验证...")
            
            time.sleep(5)

            logger.info("开始提取Local Storage中的TOKEN...")
            possible_keys = ['TOKEN', 'token', 'accessToken', 'access_token', 'Authorization']
            
            for key in possible_keys:
                try:
                    raw_token = await page.evaluate(f"() => localStorage.getItem('{key}')")
                    
                    if raw_token:
                        logger.info(f"从 localStorage['{key}'] 获取到Token")
                        
                        try:
                            token_data = json.loads(raw_token)
                            if isinstance(token_data, dict):
                                for token_key in ['token', 'access_token', 'accessToken', 'value']:
                                    if token_key in token_data:
                                        valid_token = token_data[token_key]
                                        break
                                if not valid_token and len(token_data) == 1:
                                    valid_token = list(token_data.values())[0]
                            elif isinstance(token_data, str):
                                valid_token = token_data
                        except json.JSONDecodeError:
                            valid_token = raw_token
                        
                        if valid_token:
                            try:
                                decoded_token = urllib.parse.unquote(valid_token)
                                valid_token = decoded_token
                            except:
                                pass
                            
                            valid_token = valid_token.strip().strip('"').strip("'")
                            
                            if '%22' in valid_token:
                                valid_token = valid_token.replace('%22', '')
                            
                            logger.info(f"成功从 {key} 提取Token")
                            break
                except Exception as e:
                    continue
            
            if not valid_token:
                try:
                    all_items = await page.evaluate("""() => {
                        const items = {};
                        for (let i = 0; i < localStorage.length; i++) {
                            const key = localStorage.key(i);
                            items[key] = localStorage.getItem(key);
                        }
                        return items;
                    }""")
                    
                    for key, value in all_items.items():
                        if value and len(value) > 20:
                            if 'token' in key.lower() or 'auth' in key.lower():
                                valid_token = value.strip().strip('"').strip("'")
                                logger.info(f"从 {key} 找到Token")
                                break
                except Exception as e:
                    logger.error(f"获取全部localStorage失败: {e}")
            
            if valid_token:
                logger.info(f"✅ Token提取成功!")
                    
        except Exception as e:
            logger.error(f"\n❌ 登录流程出错：{str(e)}")
        finally:
            try:
                await browser.close()
                logger.info("🔒 浏览器已关闭")
            except:
                pass
                
    return valid_token

def build_auth_headers(token: str) -> Dict[str, str]:
    """根据Token构建认证头"""
    if not token:
        return {}
    
    cookie = f"a_t={token}"
    
    return {
        "accept": "application/json, text/plain, */*",
        "accept-encoding": "gzip, deflate, br, zstd",
        "accept-language": "zh-CN",
        "content-type": "application/json;charset=UTF-8",
        "cookie": cookie,
        "origin": "https://ops.cb.paykka.com",
        "priority": "u=1, i",
        "referer": "https://ops.cb.paykka.com/",
        "sec-ch-ua": '"Not(A:Brand";v="8", "Chromium";v="144", "Google Chrome";v="144"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
        "x-auth-token": token,
        "x-requested-with": "XMLHttpRequest"
    }

# ===================== 汇差配置类 =====================
class PaykkaForexConfigurator:
    """PAYKKA汇差配置器 - 增强版，支持自动重连"""
    
    def __init__(self, token: str):
        self.token = token
        self.base_url = "https://ops-bk.cb.paykka.com"
        self.endpoint = f"{self.base_url}/forex/ops/general-fx-transform/edit"
        self.manager = PaykkaSystemManager()  # 新增：引用管理器
    
    def _build_headers(self) -> Dict[str, str]:
        """构建HTTP请求头"""
        headers = {
            "accept": "application/json, text/plain, */*",
            "accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
            "content-type": "application/json;charset=UTF-8",
            "origin": "https://ops.cb.paykka.com",
            "referer": "https://ops.cb.paykka.com/",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "cookie": f"a_t={self.token}",
            "x-auth-token": self.token,
        }
        return headers
    
    def _construct_payload(self, sell_cur: str, buy_cur: str, 
                          cost_config: Dict, ref_configs: List[Dict]) -> Dict:
        """构建请求Payload"""
        payload = {
            "sell_cur": sell_cur,
            "items": [
                {
                    "buy_cur": buy_cur,
                    "configs": ref_configs,
                    "cost": cost_config
                }
            ]
        }
        return payload
    
    def _configure_forex_pair_internal(self, sell_cur: str, buy_cur: str, 
                                     cost_config: Dict, ref_configs: List[Dict]) -> Tuple[bool, str]:
        """内部配置方法（被safe_configure_forex_pair调用）"""
        payload = self._construct_payload(sell_cur, buy_cur, cost_config, ref_configs)
        
        headers = self._build_headers()
        response = requests.post(
            url=self.endpoint,
            headers=headers,
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            resp_data = response.json()
            return True, resp_data
        else:
            return False, f"HTTP错误: {response.status_code}"
    
    def safe_configure_forex_pair(self, sell_cur: str, buy_cur: str, 
                                 cost_config: Dict, ref_configs: List[Dict]) -> Tuple[bool, str]:
        """
        安全的汇差配置（自动处理Token过期和重试）
        返回: (成功标志, 消息)
        """
        # 使用管理器的安全API调用
        success, result = self.manager.safe_api_call(
            self._configure_forex_pair_internal,
            sell_cur, buy_cur, cost_config, ref_configs,
            max_retries=2,
            retry_delay=1
        )
        
        if not success:
            return False, result
        
        # --- 修复开始：正确处理返回的元组 ---
        # result 现在是 (api_call_success, api_response) 元组
        if not isinstance(result, tuple) or len(result) != 2:
            return False, f"API返回了意外的格式: {type(result)}"
    
        api_call_success, resp_data = result
        # --- 修复结束 ---
    
        if not api_call_success:
            # resp_data 此时是错误信息字符串
            return False, resp_data

        # 现在 resp_data 应该是真正的API响应字典
        if resp_data.get('ret_code') == '000000':
            # 配置成功后发送企业微信群通知
            config_details = f"币对: {sell_cur}->{buy_cur}\n类型: 汇差配置"
            notification_message = f"ℹ️汇率配置更新，请复核ℹ️\n{config_details}"
            send_wechat_work_message(notification_message)
            
            return True, f"✅ 汇差配置成功: {sell_cur}->{buy_cur}"
        else:
            return False, f"❌ 配置失败: {resp_data.get('ret_msg', '未知错误')}"
    
    def configure_forex_pair(self, sell_cur: str, buy_cur: str, 
                            cost_config: Dict, ref_configs: List[Dict]) -> Tuple[bool, str]:
        """配置单个货币对（兼容旧版本，内部使用安全版本）"""
        logger.info("使用增强版安全配置接口")
        return self.safe_configure_forex_pair(sell_cur, buy_cur, cost_config, ref_configs)

# ===================== 路由配置类 =====================
class PaykkaRoutingConfigurator:
    """PAYKKA路由配置器 - 增强版，支持自动重连"""
    
    def __init__(self, token: str):
        self.token = token
        self.base_url = "https://ops-bk.cb.paykka.com"
        self.fx_update_api = "/forex/ops/fx/pair-config/update"
        self.fx_detail_api = "/forex/ops/fx/pair-config/detail"
        self.fx_list_api = "/forex/ops/fx/pair-config/page"
        self.manager = PaykkaSystemManager()  # 新增：引用管理器
    
    def _build_headers(self) -> Dict[str, str]:
        """构建HTTP请求头"""
        return build_auth_headers(self.token)
    
    def _safe_api_request(self, method: str, api_path: str, payload: Dict = None) -> Tuple[bool, Any]:
        """安全的API请求封装"""
        url = f"{self.base_url}{api_path}"
        headers = self._build_headers()
        
        def request_func():
            if method.upper() == "POST":
                response = requests.post(url, headers=headers, json=payload, timeout=30)
            else:
                response = requests.get(url, headers=headers, params=payload, timeout=30)
            
            if response.status_code == 200:
                return response.json()
            else:
                raise Exception(f"HTTP {response.status_code}: {response.text[:100]}")
        
        # 使用管理器的安全API调用
        success, result = self.manager.safe_api_call(
            request_func,
            max_retries=2,
            retry_delay=1
        )
        
        return success, result
    
    def safe_query_fx_pair_config(self, sell_currency: str, buy_currency: str) -> Optional[Dict]:
        """安全的查询单个货币对配置"""
        payload = {"sell_cur": sell_currency.upper(), "buy_cur": buy_currency.upper()}
        
        success, data = self._safe_api_request("POST", self.fx_detail_api, payload)
        
        if success and data.get("ret_code") == "000000":
            current_config = data.get("data", {})
            if current_config:
                return {
                    "fx_strategy_rule": current_config.get("fx_strategy_rule", "未知"),
                    "standalone_fx": current_config.get("standalone_fx", "未知"),
                    "buy_cur": current_config.get("buy_cur", buy_currency),
                    "sell_cur": current_config.get("sell_cur", sell_currency),
                    "status": current_config.get("status", "未知"),
                    "update_time": current_config.get("update_time", "未知")
                }
        
        return None
    
    def safe_update_fx_pair_config(
        self, 
        sell_currency: str, 
        buy_currency: str, 
        strategy_rule: str, 
        standalone_fx_enabled: bool
    ) -> bool:
        """安全的修改货币对配置"""
        if strategy_rule not in FX_STRATEGY_RULES:
            logger.error(f"策略规则 {strategy_rule} 不在支持的列表中")
            return False

        payload = {
            "buy_cur": buy_currency.upper(),
            "sell_cur": sell_currency.upper(),
            "fx_strategy_rule": strategy_rule,
            "standalone_fx": "ENABLED" if standalone_fx_enabled else "DISABLED"
        }
        
        success, data = self._safe_api_request("POST", self.fx_update_api, payload)
        
        if success and data.get("ret_code") == "000000":
            logger.info(f"路由修改成功: {sell_currency}->{buy_currency} 策略:{strategy_rule}")
            return True
        else:
            error_msg = data.get('ret_msg', '未知错误') if success else str(data)
            logger.error(f"路由修改失败: {error_msg}")
            return False
    
    def query_fx_pair_config(self, sell_currency: str, buy_currency: str) -> Optional[Dict]:
        """查询单个货币对配置（兼容旧版本）"""
        return self.safe_query_fx_pair_config(sell_currency, buy_currency)
    
    def update_fx_pair_config(
        self, 
        sell_currency: str, 
        buy_currency: str, 
        strategy_rule: str, 
        standalone_fx_enabled: bool
    ) -> bool:
        """修改货币对配置（兼容旧版本）"""
        return self.safe_update_fx_pair_config(sell_currency, buy_currency, strategy_rule, standalone_fx_enabled)
    
    def safe_query_all_fx_pair_configs(self) -> List[Dict]:
        """安全的分页查询所有货币对配置"""
        all_configs = []
        offset = 0
        limit = 100
        page = 1
        
        while True:
            payload = {"offset": offset, "limit": limit}
            
            success, data = self._safe_api_request("POST", self.fx_list_api, payload)
            
            if not success:
                logger.error(f"第{page}页查询异常: {data}")
                break
            
            if data.get("ret_code") != "000000":
                logger.error(f"第{page}页查询失败: {data.get('ret_msg', '未知错误')}")
                break
            
            page_data = data.get("data", [])
            if isinstance(page_data, dict):
                page_data = page_data.get("list", page_data.get("records", []))
            if not isinstance(page_data, list):
                page_data = []
            
            if not page_data:
                logger.info(f"分页查询完成，共获取 {len(all_configs)} 条配置")
                break
            
            for item in page_data:
                if not isinstance(item, dict):
                    continue
                config = {
                    "fx_strategy_rule": item.get("fx_strategy_rule", "未知"),
                    "standalone_fx": item.get("standalone_fx", "未知"),
                    "buy_cur": item.get("buy_cur", "未知"),
                    "sell_cur": item.get("sell_cur", "未知"),
                    "status": item.get("status", "未知"),
                    "update_time": item.get("update_time", "未知")
                }
                all_configs.append(config)
            
            if len(page_data) < limit:
                break
            
            offset += limit
            page += 1
            time.sleep(0.2)
        
        return all_configs
    
    def query_all_fx_pair_configs(self) -> List[Dict]:
        """分页查询所有货币对配置（兼容旧版本）"""
        return self.safe_query_all_fx_pair_configs()

# ===================== 路由定时切换调度器 =====================
class RoutingScheduler:
    """路由定时切换调度器"""
    
    def __init__(self, token: str):
        self.token = token
        self.routing_configurator = None
        self.is_running = False
        self.task_thread = None
        self.stop_event = threading.Event()
        self.last_switch_time = {}  # 记录上次切换时间
        self.manager = PaykkaSystemManager()
        
        # 路由配置文件的GitHub路径
        self.ROUTING_SCHEDULE_FILE = "routing_schedule.md"
        self.GITHUB_REPO_OWNER = GITHUB_REPO_OWNER
        self.GITHUB_REPO_NAME = "paykka-control"

        # 新增：缓存配置
        self.cached_config = None
        self.last_config_fetch_time = None
        self.next_config_fetch_time = None  # 下次读取配置的时间
        self.config_lock = threading.Lock()
        
    def _get_routing_configurator(self):
        """获取路由配置器实例"""
        if not self.routing_configurator:
            self.routing_configurator = self.manager.get_routing_configurator()
        return self.routing_configurator

    def _calculate_next_switch_time(self, schedule: Dict) -> Optional[datetime]:
        """计算规则的下一次切换时间"""
        try:
            # 获取当前时间
            now = datetime.now()
            
            # 检查规则是否启用
            if not schedule.get("enabled", True):
                return None
            
            # 解析时间
            time_str = schedule.get("time", "")
            if not time_str:
                return None
            
            # 解析小时和分钟
            try:
                hour, minute = map(int, time_str.split(":"))
            except:
                return None
            
            # 解析星期几
            days = schedule.get("days", [])
            if not days:  # 如果没有指定days，表示每天都要检查
                # 构造今天的时间
                target_time = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
                if target_time <= now:  # 如果今天的时间已经过去，就是明天
                    target_time += timedelta(days=1)
                return target_time
            
            # 将星期几字符串映射为数字（0=周一，6=周日）
            day_mapping = {
                "MON": 0, "TUE": 1, "WED": 2, "THU": 3,
                "FRI": 4, "SAT": 5, "SUN": 6,
            }
            
            # 获取今天是星期几（0=周一，6=周日）
            current_weekday = now.weekday()
            
            # 将days转换为数字
            day_numbers = [day_mapping.get(day.upper(), -1) for day in days if day.upper() in day_mapping]
            day_numbers = [d for d in day_numbers if d >= 0]
            
            if not day_numbers:
                return None
            
            # 计算下一个符合条件的时间
            for day_offset in range(8):  # 最多查看8天内（包含今天）
                check_date = now.date() + timedelta(days=day_offset)
                check_weekday = check_date.weekday()
                
                if check_weekday in day_numbers:
                    # 构造这一天的时间
                    target_time = datetime.combine(check_date, dtime(hour, minute, 0))
                    
                    # 如果时间已经过去（对于今天），就跳过
                    if day_offset == 0 and target_time <= now:
                        continue
                    
                    return target_time
            
            return None
            
        except Exception as e:
            logger.error(f"计算下一次切换时间失败: {e}")
            return None

    def _calculate_next_fetch_time(self) -> Optional[datetime]:
        """计算下一次读取配置的时间（基于所有规则的下一次切换时间）"""
        if not self.cached_config or not self.cached_config.get("ENABLED", True):
            # 如果没有配置或功能禁用，默认1小时后重试
            return datetime.now() + timedelta(hours=1)
        
        schedules = self.cached_config.get("SCHEDULES", [])
        if not schedules:
            # 如果没有规则，默认1小时后重试
            return datetime.now() + timedelta(hours=1)
        
        # 找出所有规则的下一次切换时间
        next_times = []
        for schedule in schedules:
            next_time = self._calculate_next_switch_time(schedule)
            if next_time:
                next_times.append(next_time)
        
        if not next_times:
            # 如果没有找到任何有效的切换时间，默认1小时后重试
            return datetime.now() + timedelta(hours=1)
        
        # 找出最近的下一次切换时间
        nearest_time = min(next_times)
        
        # 修复：直接在切换时间点执行检查（不再延后1分钟，避免错过切换窗口）
        fetch_time = nearest_time
        
        # 确保至少是当前时间之后
        now = datetime.now()
        if fetch_time <= now:
            fetch_time = now + timedelta(minutes=5)  # 如果已经过去，5分钟后重试
        
        return fetch_time
    
    def _fetch_routing_schedule(self) -> Dict:
        """从GitHub获取路由切换时间表配置"""
        try:
            logger.info("🔍 开始从GitHub获取路由切换时间表配置...")
            url = f"https://api.github.com/repos/{self.GITHUB_REPO_OWNER}/{self.GITHUB_REPO_NAME}/contents/{self.ROUTING_SCHEDULE_FILE}"
            headers = {
                "Authorization": f"token {GITHUB_TOKEN}",
                "Accept": "application/vnd.github.v3.raw"
            }
            response = requests.get(url, headers=headers, timeout=30)
            
            if response.status_code == 200:
                md_content = response.text
                config = self._parse_routing_schedule_md(md_content)

                # 缓存配置并更新时间（修复：原代码在此处提前return，导致缓存逻辑成为死代码）
                with self.config_lock:
                    self.cached_config = config
                    self.last_config_fetch_time = datetime.now()
                    # 计算下一次读取配置的时间
                    self.next_config_fetch_time = self._calculate_next_fetch_time()
                
                logger.info(f"✅ 路由配置已缓存，共 {len(config.get('SCHEDULES', []))} 条规则")
                if self.next_config_fetch_time:
                    logger.info(f"⏰ 下次读取配置时间: {self.next_config_fetch_time.strftime('%Y-%m-%d %H:%M:%S')}")
                
                return config

            else:
                logger.error(f"❌ 获取路由切换配置失败，状态码: {response.status_code}")
                return self._get_default_schedule()
        except Exception as e:
            logger.error(f"❌ 获取路由切换配置时出错: {e}")
            return self._get_default_schedule()

    def _get_cached_config(self, force_fetch: bool = False) -> Dict:
        """获取缓存的配置，如果需要则从GitHub获取"""
        with self.config_lock:
            # 检查是否需要重新获取配置
            need_fetch = False
            
            if force_fetch:
                need_fetch = True
            elif self.cached_config is None:
                need_fetch = True
            elif self.next_config_fetch_time and datetime.now() >= self.next_config_fetch_time:
                need_fetch = True
                logger.info("⏰ 到达配置读取时间，重新获取配置")
            
            if need_fetch:
                return self._fetch_routing_schedule()
            
            return self.cached_config

    def _should_fetch_config_now(self) -> bool:
        """检查现在是否需要读取配置"""
        with self.config_lock:
            if self.cached_config is None:
                return True
            
            if self.next_config_fetch_time is None:
                return True
            
            if datetime.now() >= self.next_config_fetch_time:
                return True
            
            return False
    
    def _parse_routing_schedule_md(self, md_content: str) -> Dict:
        """解析路由切换时间表配置"""
        config = {
            "ENABLED": True,
            "SCHEDULES": [],
            "NOTIFICATION": True
        }
        
        # 1. 提取开关
        enabled_pattern = r'ENABLED\s*=\s*(True|False)'
        enabled_match = re.search(enabled_pattern, md_content)
        if enabled_match:
            config["ENABLED"] = enabled_match.group(1) == "True"
        
        # 2. 提取通知开关
        notification_pattern = r'NOTIFICATION\s*=\s*(True|False)'
        notification_match = re.search(notification_pattern, md_content)
        if notification_match:
            config["NOTIFICATION"] = notification_match.group(1) == "True"
        
        # 3. 提取时间表配置
        schedules_pattern = r'SCHEDULES\s*=\s*(\[[\s\S]*?\])(?=\s*\n\S|\s*\Z)'
        schedules_match = re.search(schedules_pattern, md_content, re.DOTALL)
        if schedules_match:
            schedules_str = schedules_match.group(1)
            try:
                config["SCHEDULES"] = ast.literal_eval(schedules_str)
            except Exception as e:
                logger.error(f"解析SCHEDULES失败: {e}")
                config["SCHEDULES"] = []
        
        logger.info(f"✅ 成功解析路由切换配置: {len(config['SCHEDULES'])} 条时间规则")
        #logger.info(f"✅ 路由切换配置详情: {config['SCHEDULES']} ")
        return config
    
    def _get_default_schedule(self) -> Dict:
        """获取默认时间表（示例）"""
        return {
            "ENABLED": True,
            "NOTIFICATION": True,
            "SCHEDULES": [
                {
                    "id": "morning_switch",
                    "description": "工作日早上切换到OCBC",
                    "currency_pair": {"sell": "USD", "buy": "CNH"},
                    "target_rule": "RULE_OCBC",
                    "time": "08:05",
                    "days": ["MON", "TUE", "WED", "THU", "FRI"],  # 工作日
                    "enabled": True
                },
                {
                    "id": "afternoon_switch",
                    "description": "工作日下午切换到HCE_TOM",
                    "currency_pair": {"sell": "USD", "buy": "CNH"},
                    "target_rule": "RULE_HCE_TOM",
                    "time": "14:50",
                    "days": ["MON", "TUE", "WED", "THU", "FRI"],  # 工作日
                    "enabled": True
                },
                {
                    "id": "saturday_switch",
                    "description": "周六早上切换到YB",
                    "currency_pair": {"sell": "USD", "buy": "CNH"},
                    "target_rule": "RULE_YB",
                    "time": "04:55",
                    "days": ["SAT"],  # 周六
                    "enabled": True
                }
            ]
        }
    
    def _check_schedule_match(self, schedule: Dict) -> bool:
        """检查当前时间是否匹配时间表（含 ±2 分钟容错窗口）"""
        now = datetime.now()
        current_time = now.strftime("%H:%M")
        current_day = now.strftime("%a").upper()  # 3个字母的星期几，如MON, TUE
        
        # 检查是否启用
        if not schedule.get("enabled", True):
            return False
        
        # 检查时间（修复：增加 ±2 分钟容错窗口，避免网络延迟/处理耗时导致错过切换）
        schedule_time_str = schedule.get("time", "")
        if not schedule_time_str:
            return False
        
        try:
            sh, sm = map(int, schedule_time_str.split(":"))
            ch, cm = map(int, current_time.split(":"))
        except (ValueError, TypeError):
            return False
        
        schedule_minutes = sh * 60 + sm
        current_minutes = ch * 60 + cm
        time_diff = abs(current_minutes - schedule_minutes)
        
        if time_diff > 2:  # 允许 ±2 分钟的误差
            return False
        
        # 检查星期几
        allowed_days = schedule.get("days", [])
        if allowed_days and current_day not in allowed_days:
            return False
        
        return True
    
    def _switch_currency_pair_route(self, schedule: Dict) -> bool:
        """执行货币对路由切换"""
        try:
            currency_pair = schedule.get("currency_pair", {})
            sell_currency = currency_pair.get("sell", "")
            buy_currency = currency_pair.get("buy", "")
            target_rule = schedule.get("target_rule", "")
            schedule_id = schedule.get("id", "")
            description = schedule.get("description", "")
            
            if not sell_currency or not buy_currency or not target_rule:
                logger.error(f"❌ 路由切换配置无效: {schedule}")
                return False
            
            # 检查目标规则是否有效
            if target_rule not in FX_STRATEGY_RULES:
                logger.error(f"❌ 无效的路由规则: {target_rule}")
                return False
            
            # 获取路由配置器
            configurator = self._get_routing_configurator()
            
            # 查询当前配置
            current_config = configurator.safe_query_fx_pair_config(sell_currency, buy_currency)
            
            if current_config:
                current_rule = current_config.get("fx_strategy_rule", "未知")
                if current_rule == target_rule:
                    logger.info(f"ℹ️ 路由无需切换: {sell_currency}->{buy_currency} 已经是 {target_rule}")
                    return True
            
            # 执行路由切换
            logger.info(f"🔄 正在切换路由: {sell_currency}->{buy_currency} 到 {target_rule}")
            success = configurator.safe_update_fx_pair_config(
                sell_currency=sell_currency,
                buy_currency=buy_currency,
                strategy_rule=target_rule,
                standalone_fx_enabled=True
            )
            
            if success:
                logger.info(f"✅ 路由切换成功: {sell_currency}->{buy_currency} 到 {target_rule}")
                
                # 记录切换时间
                self.last_switch_time[schedule_id] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                
                # 发送通知
                if schedule.get("send_notification", True):
                    self._send_switch_notification(schedule, current_config, target_rule)
                
                return True
            else:
                logger.error(f"❌ 路由切换失败: {sell_currency}->{buy_currency} 到 {target_rule}")
                return False
                
        except Exception as e:
            logger.error(f"❌ 路由切换异常: {e}")
            return False
    
    def _send_switch_notification(self, schedule: Dict, old_config: Optional[Dict], new_rule: str):
        """发送路由切换通知"""
        try:
            currency_pair = schedule.get("currency_pair", {})
            sell_currency = currency_pair.get("sell", "")
            buy_currency = currency_pair.get("buy", "")
            description = schedule.get("description", "")
            schedule_id = schedule.get("id", "")
            
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            pair_str = f"{sell_currency}->{buy_currency}"
            
            # 构建消息
            message = f"🔄 路由定时切换完成\n"
            message += f"⏰ 切换时间: {current_time}\n"
            message += f"📅 计划ID: {schedule_id}\n"
            message += f"📋 描述: {description}\n"
            message += f"💰 货币对: {pair_str}\n"
            
            if old_config:
                old_rule = old_config.get("fx_strategy_rule", "未知")
                message += f"📈 原路由: {old_rule}\n"
            
            message += f"🎯 新路由: {new_rule}\n"
            message += f"✅ 状态: 切换成功"
            
            # 发送到企业微信
            send_wechat_work_message(message)
            logger.info(f"✅ 路由切换通知已发送: {pair_str} -> {new_rule}")
            
        except Exception as e:
            logger.error(f"❌ 发送路由切换通知失败: {e}")
    
    def _execute_scheduled_checks(self):
        """执行定时检查（动态读取配置版）"""
        try:
            # 检查是否需要读取配置
            if self._should_fetch_config_now():
                config = self._fetch_routing_schedule()
            else:
                config = self.cached_config
            
            if not config or not config.get("ENABLED", True):
                logger.debug("路由定时切换功能已禁用")
                # 如果功能禁用，1小时后重试读取配置
                self.next_config_fetch_time = datetime.now() + timedelta(hours=1)
                return
            
            schedules = config.get("SCHEDULES", [])
            if not schedules:
                logger.debug("没有配置路由切换时间表")
                # 如果没有规则，1小时后重试读取配置
                self.next_config_fetch_time = datetime.now() + timedelta(hours=1)
                return
            
            # 执行规则检查
            executed_switch = False
            for schedule in schedules:
                if self._check_schedule_match(schedule):
                    schedule_id = schedule.get("id", "")
                    description = schedule.get("description", "")
                    
                    # 检查上次切换时间，避免重复切换
                    last_switch = self.last_switch_time.get(schedule_id)
                    if last_switch:
                        last_time = datetime.strptime(last_switch, "%Y-%m-%d %H:%M:%S")
                        time_diff = (datetime.now() - last_time).total_seconds() / 60
                        
                        # 如果5分钟内已经切换过，跳过
                        if time_diff < 5:
                            logger.debug(f"跳过最近切换的计划: {schedule_id}")
                            continue
                    
                    logger.info(f"⏰ 执行路由切换计划: {description}")
                    success = self._switch_currency_pair_route(schedule)
                    
                    if success:
                        executed_switch = True
                        # 记录切换时间
                        self.last_switch_time[schedule_id] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # 修复：无论是否执行了切换，都重新计算下一次配置读取时间
            # （避免未匹配到任何计划时 next_config_fetch_time 不更新导致循环异常）
            with self.config_lock:
                self.next_config_fetch_time = self._calculate_next_fetch_time()
                if self.next_config_fetch_time:
                    logger.info(f"⏰ 下次读取配置时间更新为: {self.next_config_fetch_time.strftime('%Y-%m-%d %H:%M:%S')}")
        
        except Exception as e:
            logger.error(f"❌ 执行路由定时检查异常: {e}")
            # 发生异常时，1小时后重试
            self.next_config_fetch_time = datetime.now() + timedelta(hours=1)
    
    def _task_loop(self):
        """任务循环主体 - 动态间隔版"""
        logger.info("✅ 路由定时切换任务已启动（动态读取配置模式）")
        
        # 首次读取配置
        config = self._fetch_routing_schedule()
        
        while not self.stop_event.is_set():
            try:
                # 计算下一次检查的时间（基于下次配置读取时间）
                now = datetime.now()
                next_check_time = self.next_config_fetch_time
                
                if next_check_time:
                    # 计算需要等待的秒数
                    wait_seconds = (next_check_time - now).total_seconds()
                    
                    if wait_seconds > 0:
                        # 记录日志
                        logger.info(f"⏰ 下次检查时间: {next_check_time.strftime('%Y-%m-%d %H:%M:%S')} (还有{wait_seconds/60:.1f}分钟)")
                        
                        # 等待到下一次检查时间
                        self.stop_event.wait(timeout=min(wait_seconds, 3600))  # 最多等待1小时
                    else:
                        # 已经到了检查时间，立即执行
                        self._execute_scheduled_checks()
                        # 执行后短暂休眠，避免CPU占用过高
                        self.stop_event.wait(timeout=60)  # 等待1分钟
                else:
                    # 没有下一次检查时间，默认等待5分钟
                    logger.debug("未计算到下次检查时间，等待5分钟")
                    self.stop_event.wait(timeout=300)
                    
            except Exception as e:
                logger.error(f"路由定时任务循环内发生异常: {e}")
                # 发生异常时，等待5分钟后重试
                self.stop_event.wait(timeout=300)

    def get_status_detail(self) -> str:
        """获取详细状态信息"""
        with self.config_lock:
            status = []
            status.append(f"🔄 任务状态: {'运行中' if self.is_running else '已停止'}")
            
            if self.last_config_fetch_time:
                status.append(f"📅 最后读取配置: {self.last_config_fetch_time.strftime('%Y-%m-%d %H:%M:%S')}")
            
            if self.next_config_fetch_time:
                now = datetime.now()
                if self.next_config_fetch_time > now:
                    minutes_left = (self.next_config_fetch_time - now).total_seconds() / 60
                    status.append(f"⏰ 下次读取配置: {self.next_config_fetch_time.strftime('%Y-%m-%d %H:%M:%S')} (还有{minutes_left:.1f}分钟)")
                else:
                    status.append(f"⏰ 下次读取配置: 即将执行")
            
            if self.cached_config:
                schedules = self.cached_config.get("SCHEDULES", [])
                enabled_schedules = [s for s in schedules if s.get("enabled", True)]
                status.append(f"📋 配置规则: {len(enabled_schedules)}/{len(schedules)} 条启用")
                
                # 显示最近的下一次切换时间
                next_times = []
                for schedule in enabled_schedules:
                    next_time = self._calculate_next_switch_time(schedule)
                    if next_time:
                        next_times.append((schedule.get("id"), next_time))
                
                if next_times:
                    next_times.sort(key=lambda x: x[1])
                    next_id, next_time = next_times[0]
                    minutes_left = (next_time - datetime.now()).total_seconds() / 60
                    status.append(f"⏳ 下一次切换: {next_id} 于 {next_time.strftime('%Y-%m-%d %H:%M')} (还有{minutes_left:.1f}分钟)")
            
            return "\n".join(status)
    
    def start(self):
        """启动定时任务（在后台线程中）"""
        if self.is_running:
            return "⚠️ 路由定时切换任务已在运行中"
        
        self.is_running = True
        self.stop_event.clear()
        
        self.task_thread = threading.Thread(
            target=self._task_loop,
            name="RoutingScheduler",
            daemon=True
        )
        self.task_thread.start()
        
        return "✅ 已启动路由定时切换任务\n⏰ 检查间隔: 每30分钟检查一次"
    
    def stop(self):
        """停止定时任务"""
        if not self.is_running:
            return "ℹ️ 路由定时切换任务未在运行"
        
        self.is_running = False
        self.stop_event.set()
        
        if self.task_thread and self.task_thread.is_alive():
            self.task_thread.join(timeout=5.0)
        
        return "🛑 路由定时切换任务已停止"
    
    def status(self):
        """获取任务状态"""
        if self.is_running and self.task_thread and self.task_thread.is_alive():
            return self.get_status_detail()
        else:
            return "🔴 任务状态: 已停止"

    def force_reload_config(self):
        """强制重新加载配置"""
        logger.info("🔄 强制重新加载路由配置...")
        config = self._fetch_routing_schedule()
        return f"✅ 配置已强制重载，共 {len(config.get('SCHEDULES', []))} 条规则"

# ===================== 余额查询配置类 =====================
class PaykkaBalanceQuery:
    """PAYKKA渠道余额查询与预警模块 - 增强版"""
    
    def __init__(self, token: str):
        self.token = token
        self.base_url = BALANCE_BASE_URL
        self.api_endpoint = BALANCE_API_ENDPOINT
        self.full_api_url = f"{self.base_url}{self.api_endpoint}"
        self.institution_map = INSTITUTION_MAP
        self.institution_currencies = INSTITUTION_CURRENCIES
        self.excel_filename = EXCEL_FILENAME
        self.manager = PaykkaSystemManager()  # 新增
    
    def _safe_balance_query(self, payload: Dict) -> Tuple[bool, Any]:
        """安全的余额查询请求"""
        def query_func():
            headers = self._build_headers()
            response = requests.post(
                self.full_api_url, 
                headers=headers, 
                json=payload, 
                timeout=30
            )
            if response.status_code == 200:
                return response.json()
            else:
                raise Exception(f"HTTP {response.status_code}")
        
        # 使用管理器的安全API调用
        return self.manager.safe_api_call(
            query_func,
            max_retries=2,
            retry_delay=1
        )
    
    def _build_headers(self) -> Dict[str, str]:
        """构建HTTP请求头"""
        return build_auth_headers(self.token)
    
    def _format_balance(self, balance, currency):
        """格式化余额"""
        try:
            balance_float = float(balance)
            # 修复：使用全局常量 NO_DIVIDE_CURRENCIES 列表，而非仅硬编码 "JPY"
            if currency not in NO_DIVIDE_CURRENCIES:
                balance_float = balance_float / 100.0
            return "{:,.2f}".format(balance_float)
        except (ValueError, TypeError):
            return "0.00"
    
    def _backup_hce_query(self, headers, org_code, org_name, query_time):
        """备用方式查询海云汇币种"""
        currencies = self.institution_currencies.get(org_code, [])
        all_results = []
        for currency in currencies:
            try:
                payload = {
                    "offset": 0,
                    "limit": 100,
                    "account_type": "FUND_ACCOUNT",
                    "currency": currency,
                    "org_code": org_code
                }
                response = requests.post(self.full_api_url, headers=headers, json=payload, timeout=30)
                data = response.json()
                if data.get("ret_code") == "000000":
                    items = data.get("data", [])
                    for item in items:
                        if isinstance(item, dict):
                            balance_raw = item.get("balance") or item.get("currentBalance") or item.get("amount") or 0
                            if balance_raw and balance_raw != 0 and balance_raw != "0":
                                balance_formatted = self._format_balance(balance_raw, currency)
                                record = {
                                    "查询时间": query_time,
                                    "渠道名": org_name,
                                    "币种": currency,
                                    "余额": balance_formatted,
                                }
                                all_results.append(record)
                time.sleep(0.1)
            except Exception as e:
                logger.error(f"  {currency}备用查询出错: {str(e)}")
        return all_results
    
    def _query_institution_balance(self, org_code: str, org_name: str) -> List[Dict]:
        """查询单个机构余额"""
        logger.info(f"查询机构: {org_name}")
        headers = self._build_headers()
        currencies = self.institution_currencies.get(org_code, ["USD", "CNY", "HKD", "EUR", "GBP", "JPY", "AUD", "CAD", "SGD"])
        all_results = []
        query_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        found_currencies = []
        
        if org_code == "HCE":
            logger.info("  海云汇机构使用特殊查询模式（无account_type参数）...")
            try:
                payload = {
                    "offset": 0,
                    "limit": 100,
                    "org_code": org_code
                }
                response = requests.post(self.full_api_url, headers=headers, json=payload, timeout=30)
                data = response.json()
                if data.get("ret_code") == "000000":
                    items = data.get("data", [])
                    logger.info(f"  返回数据条目数: {len(items)}")
                    for item in items:
                        if isinstance(item, dict):
                            currency = item.get("currency")
                            balance_raw = item.get("balance") or item.get("currentBalance") or item.get("amount") or 0
                            if currency in currencies:
                                if balance_raw and balance_raw != 0 and balance_raw != "0":
                                    balance_formatted = self._format_balance(balance_raw, currency)
                                    record = {
                                        "查询时间": query_time,
                                        "渠道名": org_name,
                                        "币种": currency,
                                        "余额": balance_formatted,
                                    }
                                    all_results.append(record)
                                    found_currencies.append(f"{currency}: {balance_formatted}")
                else:
                    error_msg = data.get("ret_msg", "未知错误")
                    logger.error(f"  海云汇查询失败: {error_msg}")
                    logger.info("  尝试备用查询方式...")
                    all_results = self._backup_hce_query(headers, org_code, org_name, query_time)
            except Exception as e:
                logger.error(f"  海云汇查询出错: {str(e)}")
                logger.info("  尝试备用查询方式...")
                all_results = self._backup_hce_query(headers, org_code, org_name, query_time)
        else:
            for currency in currencies:
                payload = {
                    "offset": 0,
                    "limit": 100,
                    "account_type": "FUND_ACCOUNT",
                    "currency": currency,
                    "org_code": org_code
                }
                try:
                    response = requests.post(self.full_api_url, headers=headers, json=payload, timeout=30)
                    data = response.json()
                    if data.get("ret_code") == "000000":
                        items = data.get("data", [])
                        for item in items:
                            if isinstance(item, dict):
                                balance_raw = item.get("balance") or item.get("currentBalance") or item.get("amount") or 0
                                if balance_raw and balance_raw != 0 and balance_raw != "0":
                                    balance_formatted = self._format_balance(balance_raw, currency)
                                    record = {
                                        "查询时间": query_time,
                                        "渠道名": org_name,
                                        "币种": currency,
                                        "余额": balance_formatted,
                                    }
                                    all_results.append(record)
                                    found_currencies.append(f"{currency}: {balance_formatted}")
                    time.sleep(0.1)
                except Exception as e:
                    logger.error(f"  {currency}查询出错: {str(e)}")
        
        if found_currencies:
            display_count = min(5, len(found_currencies))
            display_text = ", ".join(found_currencies[:display_count])
            if len(found_currencies) > display_count:
                display_text += f" ...等共 {len(found_currencies)} 个币种"
            logger.info(f"  {org_name}余额: {display_text}")
        else:
            logger.info("  无余额数据")
            
        return all_results
    
    def _save_to_excel(self, all_results: List[Dict]) -> bool:
        """保存查询结果到Excel"""
        try:
            df = pd.DataFrame(all_results)
            if os.path.exists(self.excel_filename):
                try:
                    # 修复：显式指定 engine='openpyxl'，兼容 pandas 3.0+
                    existing_df = pd.read_excel(self.excel_filename, engine='openpyxl')
                    combined_df = pd.concat([existing_df, df], ignore_index=True)
                except Exception as read_err:
                    # 容错：如果已有文件损坏或格式不兼容，仅使用新数据覆盖
                    logger.warning(f"⚠️ 读取已有Excel文件失败({read_err})，将覆盖写入新数据")
                    combined_df = df
            else:
                combined_df = df
            with pd.ExcelWriter(self.excel_filename, engine='openpyxl', mode='w') as writer:
                combined_df.to_excel(writer, sheet_name='余额查询记录', index=False)
            logger.info(f"数据已保存到: {self.excel_filename}")
            return True
        except Exception as e:
            logger.error(f"保存Excel文件时出错: {e}")
            return False
    
    def _generate_html_report(self, results: List[Dict]) -> str:
        """生成HTML报告"""
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # 按机构组织数据
        org_balances = {}
        for record in results:
            org_name = record["渠道名"]
            currency = record["币种"]
            balance = record["余额"]
            if org_name not in org_balances:
                org_balances[org_name] = []
            org_balances[org_name].append((currency, balance))
        
        # 构建HTML
        html_content = f'''
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>PayKKa 机构余额看板</title>
        <style>
            body {{ font-family: 'Segoe UI', Arial, sans-serif; margin: 40px; background-color: #f5f5f5; color: #333; }}
            .container {{ max-width: 1200px; margin: auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }}
            h1 {{ color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 15px; }}
            .update-time {{ color: #7f8c8d; font-size: 0.95em; margin-bottom: 30px; }}
            .institution {{ margin-bottom: 35px; }}
            .institution h2 {{ color: #16a085; background-color: #ecf0f1; padding: 12px 20px; border-radius: 8px; }}
            table {{ width: 100%; border-collapse: collapse; margin-top: 15px; }}
            th, td {{ padding: 15px 20px; text-align: left; border-bottom: 1px solid #ddd; }}
            th {{ background-color: #3498db; color: white; font-weight: 600; }}
            tr:hover {{ background-color: #f9f9f9; }}
            .balance {{ font-family: 'Courier New', monospace; font-weight: bold; color: #27ae60; }}
            .footer {{ margin-top: 40px; text-align: center; font-size: 0.9em; color: #95a5a6; }}
            .alert {{ background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 8px; margin-top: 20px; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🏦 PayKKa 渠道机构资金余额看板</h1>
            <div class="update-time">最后更新时间: <strong>{current_time}</strong> (北京时间)</div>
            <div class="alert">
                说明：本页面数据通过自动化脚本定时更新，展示各机构资金账户的实时余额。
            </div>
    '''
        
        # 为每个机构添加表格
        for org_name, currencies in org_balances.items():
            html_content += f'''
            <div class="institution">
                <h2>📊 {org_name}</h2>
                <table>
                    <thead>
                        <tr>
                            <th>币种</th>
                            <th>余额</th>
                        </tr>
                    </thead>
                    <tbody>
            '''
            for currency, balance in currencies:
                html_content += f'''
                        <tr>
                            <td><strong>{currency}</strong></td>
                            <td class="balance">{balance}</td>
                        </tr>
                '''
            html_content += '''
                    </tbody>
                </table>
            </div>
        '''
        
        # 页脚
        html_content += f'''
            <div class="footer">
                <p>数据来源: PayKKa 运营平台 | 本页面由自动化工具生成，更新间隔可配置</p>
                <p>仓库: {GITHUB_REPO_OWNER}/{GITHUB_BALANCE_REPO_NAME} | 如有疑问，请联系相关运维人员。</p>
            </div>
        </div>
    </body>
    </html>
    '''
        return html_content
    
    def _upload_to_github(self, html_content: str, commit_message: str = "Auto update balance report") -> bool:
        """上传HTML报告到GitHub"""
        url = f"https://api.github.com/repos/{GITHUB_REPO_OWNER}/{GITHUB_BALANCE_REPO_NAME}/contents/{GITHUB_BALANCE_FILE_PATH}"
        headers = {
            "Authorization": f"token {GITHUB_TOKEN}",
            "Accept": "application/vnd.github.v3+json"
        }
        content_encoded = base64.b64encode(html_content.encode("utf-8")).decode("utf-8")
        sha = None
        try:
            response = requests.get(url, headers=headers)
            if response.status_code == 200:
                sha = response.json().get("sha")
        except:
            pass
        data = {
            "message": commit_message,
            "content": content_encoded,
            "branch": GITHUB_BRANCH
        }
        if sha:
            data["sha"] = sha
        try:
            response = requests.put(url, headers=headers, json=data, timeout=30)
            if response.status_code in [200, 201]:
                logger.info(f"✅ 余额报告已成功上传至 GitHub 仓库。")
                pages_url = f"https://{GITHUB_REPO_OWNER}.github.io/{GITHUB_BALANCE_REPO_NAME}/"
                logger.info(f"🌐 网页访问地址（需配置Pages后生效）: {pages_url}")
                return True
            else:
                logger.error(f"❌ GitHub 上传失败，状态码: {response.status_code}")
                logger.error(f"错误信息: {response.text[:200]}")
                return False
        except Exception as e:
            logger.error(f"❌ 连接GitHub API时出错: {str(e)}")
            return False
    
    def _fetch_thresholds_from_github(self) -> Dict:
        """从GitHub读取阈值配置"""
        thresholds = {}
        try:
            logger.info(f"🔍 开始从GitHub获取阈值配置...")
            url = f"https://api.github.com/repos/{GITHUB_REPO_OWNER}/{GITHUB_BALANCE_REPO_NAME}/contents/balance_threshold.md"
            headers = {
                "Authorization": f"token {GITHUB_TOKEN}",
                "Accept": "application/vnd.github.v3.raw"
            }
            response = requests.get(url, headers=headers, timeout=30)
            if response.status_code == 200:
                md_content = response.text
                # 方法1：尝试解析Python字典格式
                try:
                    import re
                    pattern = r'BALANCE_THRESHOLDS\s*=\s*({[\s\S]*?})'
                    match = re.search(pattern, md_content)
        
                    if match:
                        dict_str = match.group(1)
                        import ast
                        thresholds = ast.literal_eval(dict_str)
                        print(f"✅ 成功解析BALANCE_THRESHOLDS字典，共 {len(thresholds)} 条规则")
                        return thresholds
                except Exception as e:
                    print(f"⚠️ 解析字典格式失败: {e}")

                # 方法2：尝试解析CSV格式
                try:
                    lines = md_content.strip().split('\n')
                    for line_num, line in enumerate(lines, 1):
                        line = line.strip()
                        if not line or line.startswith('#'):
                            continue
                        parts = [p.strip() for p in line.split(',')]
                        if len(parts) >= 3:
                            try:
                                org_name = parts[0]
                                currency = parts[1]
                                threshold_value = float(parts[2])
                                thresholds[(org_name, currency)] = threshold_value
                                print(f"  第{line_num}行: {org_name}, {currency}, {threshold_value}")
                            except ValueError as e:
                                print(f"  ⚠️ 第{line_num}行解析失败: {e}")
        
                    if thresholds:
                        print(f"✅ 成功解析CSV格式，共 {len(thresholds)} 条规则")
                        return thresholds
                except Exception as e:
                    print(f"⚠️ 解析CSV格式失败: {e}")
    
                return thresholds
            else:
                logger.error(f"❌ 获取阈值配置失败，HTTP状态码: {response.status_code}")
                return thresholds
        except Exception as e:
            logger.error(f"❌ 获取预警阈值配置时出错: {e}")
            return thresholds
    
    def _send_balance_alert(self, alert_messages: List[Dict]) -> bool:
        """发送余额预警消息"""
        if not alert_messages:
            return False
        
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        markdown_content = f"## ⚠️  PayKKa渠道余额预警\n**触发时间：** {current_time}\n\n"
        markdown_content += "以下渠道币种余额已低于预设阈值，请及时关注：\n\n"
        
        for alert in alert_messages:
            markdown_content += f"**{alert['机构名']} ({alert['币种']})**\n"
            markdown_content += f"> 当前余额：`{alert['当前余额']:.2f}`\n"
            markdown_content += f"> 预警阈值：`{alert['预警阈值']:.2f}`\n\n"
        
        markdown_content += "---\n*本消息由余额监控系统自动发送*"
        
        payload = {
            "msgtype": "markdown",
            "markdown": {
                "content": markdown_content
            }
        }
        
        try:
            response = requests.post(WECHAT_WEBHOOK_URL, json=payload, timeout=10)
            if response.status_code == 200:
                logger.info(f"✅ 余额预警消息已发送至企业微信。触发警报数: {len(alert_messages)}")
                return True
            else:
                logger.error(f"❌ 发送企业微信预警失败: {response.text}")
                return False
        except Exception as e:
            logger.error(f"❌ 连接企业微信Webhook时出错: {e}")
            return False
    
    def query_all_balances(self) -> Tuple[bool, str, List[Dict]]:
        """查询所有渠道余额"""
        logger.info("开始查询所有机构余额...")
        all_results = []
        
        for org_code, org_name in self.institution_map.items():
            try:
                results = self._query_institution_balance(org_code, org_name)
                all_results.extend(results)
            except Exception as e:
                logger.error(f"查询机构 {org_name} 时出错: {e}")
        
        if not all_results:
            return False, "❌ 没有查询到任何余额数据", []
        
        # 保存到Excel
        save_success = self._save_to_excel(all_results)
        if not save_success:
            return False, "❌ 保存查询结果到Excel失败", all_results
        
        return True, "✅ 余额查询成功", all_results
    
    def check_balance_alert(self, query_results: List[Dict]) -> Tuple[bool, str]:
        """检查余额预警"""
        logger.info("开始余额阈值检查...")
        thresholds = self._fetch_thresholds_from_github()
        
        if not thresholds:
            return False, "ℹ️ 未配置任何预警阈值，跳过余额检查。"
        
        alerts = []
        for record in query_results:
            org_name = record["渠道名"]
            currency = record["币种"]
            balance_str_clean = record["余额"].replace(',', '')
            try:
                current_balance = float(balance_str_clean)
            except ValueError:
                logger.warning(f"⚠️ 无法解析余额数值: {org_name} {currency} -> {record['余额']}")
                continue
            
            threshold_key = (org_name, currency)
            if threshold_key in thresholds:
                threshold = thresholds[threshold_key]
                if current_balance < threshold:
                    alert_info = {
                        '机构名': org_name,
                        '币种': currency,
                        '当前余额': current_balance,
                        '预警阈值': threshold
                    }
                    alerts.append(alert_info)
                    logger.warning(f"⚠️ 预警: {org_name} {currency} 余额 {current_balance:.2f} < 阈值 {threshold:.2f}")
        
        if alerts:
            alert_sent = self._send_balance_alert(alerts)
            if alert_sent:
                return True, f"✅ 发现 {len(alerts)} 个预警，已成功发送到企业微信。"
            else:
                return False, f"⚠️ 发现 {len(alerts)} 个预警，但发送到企业微信失败。"
        else:
            return True, "✅ 所有渠道币种余额均正常，未触发预警。"
    
    def generate_balance_report(self, query_results: List[Dict]) -> Tuple[bool, str]:
        """生成并上传余额报告"""
        logger.info("正在生成网页报告并上传至 GitHub...")
        html_report = self._generate_html_report(query_results)
        upload_success = self._upload_to_github(html_report, f"Auto update: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        
        if upload_success:
            return True, f"✅ 余额报告生成并上传成功！\n🌐 网页访问地址: https://{GITHUB_REPO_OWNER}.github.io/{GITHUB_BALANCE_REPO_NAME}/"
        else:
            return False, "❌ 余额报告上传失败。"

# ===================== 余额预警定时任务类 =====================
class BalanceMonitoringScheduledTask:
    """余额查询与预警定时任务执行器"""
    
    def __init__(self, manager: PaykkaSystemManager, interval_minutes: int = 60):
        """
        初始化定时任务
        :param manager: 全局系统管理器
        :param interval_minutes: 监控间隔（分钟），默认60分钟
        """
        self.manager = manager
        self.interval_minutes = interval_minutes
        self.is_running = False
        self.balance_query = None
        self.task_thread = None
        self.stop_event = threading.Event()
    
    def _get_balance_query(self) -> PaykkaBalanceQuery:
        """获取或创建余额查询器实例"""
        if not self.balance_query:
            self.balance_query = self.manager.get_balance_query()
        return self.balance_query
    
    def _execute_monitoring_task(self):
        """执行一次余额监控任务的核心逻辑"""
        try:
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            logger.info(f"🔄 余额定时任务执行中 ({current_time})")
            
            # 1. 获取余额查询器
            balance_query = self._get_balance_query()
            if not balance_query:
                logger.error("❌ 无法获取余额查询器实例")
                return
            
            # 2. 执行余额查询
            success, message, query_results = balance_query.query_all_balances()
            if not success:
                logger.error(f"❌ 余额查询失败: {message}")
                return
            
            logger.info(f"✅ 余额查询成功，共获取 {len(query_results)} 条记录")
            
            # 3. 检查并发送余额预警
            alert_success, alert_message = balance_query.check_balance_alert(query_results)
            logger.info(f"⚠️ 余额预警检查: {alert_message}")
            
            # 4. 生成并上传余额报告
            report_success, report_message = balance_query.generate_balance_report(query_results)
            logger.info(f"📄 余额报告: {report_message}")
  
        except Exception as e:
            logger.error(f"❌ 余额定时任务执行异常: {e}")
            import traceback
            logger.error(f"详细错误信息: {traceback.format_exc()}")
    
    def _task_loop(self):
        """任务循环主体"""
        logger.info(f"✅ 余额监控定时任务已启动")
        logger.info(f"   执行间隔: 每 {self.interval_minutes} 分钟")
        
        while not self.stop_event.is_set():
            try:
                # 执行一次监控
                self._execute_monitoring_task()
            except Exception as e:
                logger.error(f"余额监控定时任务循环内发生异常: {e}")
            
            # 等待指定的间隔时间
            self.stop_event.wait(timeout=self.interval_minutes * 60)
    
    def start(self):
        """启动定时任务（在后台线程中）"""
        if self.is_running:
            return f"⚠️ 余额监控定时任务已在运行中。当前执行间隔: {self.interval_minutes}分钟"
        
        self.is_running = True
        self.stop_event.clear()
        
        self.task_thread = threading.Thread(
            target=self._task_loop,
            name=f"BalanceMonitoringTask_{self.interval_minutes}min",
            daemon=True
        )
        self.task_thread.start()
        
        return (f"✅ 已启动余额监控定时任务\n"
                f"⏰ 执行间隔: 每 {self.interval_minutes} 分钟\n"
                f"📊 监控内容: 机构余额查询 + 阈值预警 + 报告生成")
    
    def stop(self):
        """停止定时任务"""
        if not self.is_running:
            return f"ℹ️ 余额监控定时任务未在运行。"
        
        self.is_running = False
        self.stop_event.set()
        
        if self.task_thread and self.task_thread.is_alive():
            self.task_thread.join(timeout=5.0)
        
        return f"🛑 余额监控定时任务已停止。"
    
    def status(self):
        """获取任务状态"""
        if self.is_running and self.task_thread and self.task_thread.is_alive():
            return (f"🟢 任务状态: 运行中\n"
                    f"⏰ 执行间隔: {self.interval_minutes} 分钟")
        else:
            return f"🔴 任务状态: 已停止"

# ===================== 换汇交易监控类 =====================
class PaykkaFxTransactionMonitor:
    """PAYKKA换汇交易量统计与监控模块"""
    
    def __init__(self, token: str):
        self.token = token
        self.base_url = "https://ops-bk.cb.paykka.com"
        self.fx_api_endpoint = FX_TRANSACTION_API
        self.full_api_url = FX_FULL_TRANSACTION_URL
        self.org_list = ORG_LIST
        self.no_divide_currencies = NO_DIVIDE_CURRENCIES
        self.manager = PaykkaSystemManager()
    
    def _build_headers(self) -> Dict[str, str]:
        """构建HTTP请求头"""
        return build_auth_headers(self.token)
    
    def _convert_amount(self, raw_amt: any, currency: str) -> float:
        """转换金额"""
        try:
            amt = float(raw_amt)
            if currency not in self.no_divide_currencies:
                amt = amt / 100
            return amt
        except (ValueError, TypeError):
            return 0.0
    
    def _format_number(self, num: float) -> str:
        """格式化数字"""
        return f"{num:,.2f}"
    
    def _convert_org_settlement_time(self, iso_time_str: str) -> Optional[datetime]:
        """转换交割时间为北京时间"""
        if not iso_time_str:
            return None
        try:
            utc_time = datetime.strptime(iso_time_str, "%Y-%m-%dT%H:%M:%SZ")
            return utc_time + timedelta(hours=8)
        except (ValueError, TypeError):
            return None
    
    def fetch_fx_threshold_config(self) -> Dict:
        """从GitHub拉取并解析最新的fx_threshold.md（公有方法）"""
        try:
            #logger.info(f"🔍 开始从GitHub获取换汇阈值配置...")
            url = f"https://api.github.com/repos/{GITHUB_REPO_OWNER}/paykka-control/contents/{GITHUB_THRESHOLD_FILE_PATH_MD}"
            headers = {
                "Authorization": f"token {GITHUB_TOKEN}",
                "Accept": "application/vnd.github.v3.raw"
            }
            response = requests.get(url, headers=headers, timeout=30)
            
            if response.status_code == 200:
                md_content = response.text
                return self._parse_fx_threshold_md(md_content)
            else:
                logger.error(f"❌ 获取阈值配置失败，状态码: {response.status_code}")
                return self._get_default_config()
        except Exception as e:
            logger.error(f"❌ 获取预警阈值配置时出错: {e}")
            return self._get_default_config()
    
    def _parse_fx_threshold_md(self, md_content: str) -> Dict:
        """解析fx_threshold.md内容"""
        config = {
            "WECHAT_WEBHOOK_URL": "",
            "ALERT_THRESHOLDS": {},
            "PROCESSING_ALERT_THRESHOLDS": {},  # 新增：处理中交易阈值
            "ENABLE_WECHAT_ALERT": True,
            "TRADING_HOURS": {}
        }

        # 1. 提取 Webhook URL
        webhook_pattern = r'WECHAT_WEBHOOK_URL\s*=\s*"([^"]+)"'
        webhook_match = re.search(webhook_pattern, md_content)
        if webhook_match:
            config["WECHAT_WEBHOOK_URL"] = webhook_match.group(1)

        # 2. 提取 ALERT_THRESHOLDS 字典
        threshold_pattern = r'ALERT_THRESHOLDS\s*=\s*({[^}]+})'
        threshold_match = re.search(threshold_pattern, md_content, re.DOTALL)
        if threshold_match:
            threshold_dict_str = threshold_match.group(1)
            try:
                config["ALERT_THRESHOLDS"] = ast.literal_eval(threshold_dict_str)
            except:
                logger.warning("⚠️ 解析ALERT_THRESHOLDS失败，使用默认阈值")

        # 3. 新增：提取 PROCESSING_ALERT_THRESHOLDS 字典
        processing_threshold_pattern = r'PROCESSING_ALERT_THRESHOLDS\s*=\s*({[^}]+})'
        processing_threshold_match = re.search(processing_threshold_pattern, md_content, re.DOTALL)
        if processing_threshold_match:
            processing_threshold_dict_str = processing_threshold_match.group(1)
            try:
                config["PROCESSING_ALERT_THRESHOLDS"] = ast.literal_eval(processing_threshold_dict_str)
            except:
                logger.warning("⚠️ 解析PROCESSING_ALERT_THRESHOLDS失败，使用ALERT_THRESHOLDS作为默认")
                config["PROCESSING_ALERT_THRESHOLDS"] = config.get("ALERT_THRESHOLDS", {})
        else:
            # 如果没有配置，默认使用ALERT_THRESHOLDS
            config["PROCESSING_ALERT_THRESHOLDS"] = config.get("ALERT_THRESHOLDS", {})
            logger.warning("⚠️ 未配置PROCESSING_ALERT_THRESHOLDS，使用ALERT_THRESHOLDS")


        # 4. 提取提醒开关
        alert_switch_pattern = r'ENABLE_WECHAT_ALERT\s*=\s*(True|False)'
        alert_switch_match = re.search(alert_switch_pattern, md_content)
        if alert_switch_match:
            config["ENABLE_WECHAT_ALERT"] = alert_switch_match.group(1) == "True"

        # 5. 提取 TRADING_HOURS 字典
        trading_hours_pattern = r'TRADING_HOURS\s*=\s*(\{(?:[^{}]|\{[^{}]*\})*\})'
        trading_hours_match = re.search(trading_hours_pattern, md_content, re.DOTALL)
        if trading_hours_match:
            trading_hours_str = trading_hours_match.group(1)
            try:
                config["TRADING_HOURS"] = ast.literal_eval(trading_hours_str)
            except:
                logger.warning("⚠️ 解析TRADING_HOURS失败，使用默认配置")
        
        #logger.info(f"✅ 成功解析换汇阈值配置: {len(config['ALERT_THRESHOLDS'])} 个阈值规则")
        logger.info(f"   已完成交易阈值: {len(config['ALERT_THRESHOLDS'])} 个货币对")
        logger.info(f"   处理中交易阈值: {len(config['PROCESSING_ALERT_THRESHOLDS'])} 个货币对")

        return config
    
    def _get_default_config(self) -> Dict:
        """获取默认配置"""
        return {
            "WECHAT_WEBHOOK_URL": WECHAT_WEBHOOK_URL,
            "ALERT_THRESHOLDS": {"USD/CNH": 100000.0, "EUR/CNH": 50000.0, "GBP/CNH": 30000.0},
            "ENABLE_WECHAT_ALERT": True,
            "TRADING_HOURS": {}
        }
    
    def query_fx_transactions(
        self, 
        org_code: Optional[str] = None,
        merchant_status: str = DEFAULT_MERCHANT_STATUS,
        org_status: str = DEFAULT_ORG_STATUS,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None
    ) -> Dict:
        """
        查询换汇交易并统计敞口
        返回包含统计结果的字典
        """
        # 拉取GitHub最新配置
        config = self.fetch_fx_threshold_config()

        ALERT_THRESHOLDS = config["ALERT_THRESHOLDS"]  # 已完成交易阈值
        PROCESSING_THRESHOLDS = config["PROCESSING_ALERT_THRESHOLDS"]  # 处理中交易阈值
        
        # 默认查询当日+上一个工作日
        today = date.today()
        if not start_date:
            # 上一个工作日
            prev = today
            while True:
                prev = prev - timedelta(days=1)
                if prev.weekday() < 5:
                    break
            start_date = prev.strftime("%Y-%m-%d")
        if not end_date:
            end_date = today.strftime("%Y-%m-%d")
        
        all_transactions = []
        page_num = 1
        page_size = 100
        
        #logger.info(f"📡 正在查询 {start_date} 至 {end_date} 期间所有货币对的交割敞口...")
        #logger.info(f"   机构: {org_code or '全部'} | 状态: 企业为成功/机构为成功/处理中")
        
        # 查询所有货币对数据
        while True:
            payload = {
                "offset": (page_num - 1) * page_size,
                "limit": page_size,
                "sell_currency": "",
                "buy_currency": "",
                "org_code": org_code,
                "status": merchant_status,
                "org_fx_order_status": org_status,
                #"start_time": start_date,
                #"end_time": end_date
            }
            
            try:
                response = requests.post(
                    self.full_api_url,
                    headers=self._build_headers(),
                    json=payload,
                    timeout=30
                )
                data = response.json()
                
                if data.get("ret_code") == "000000":
                    response_data = data.get("data", {})
                    
                    if isinstance(response_data, dict):
                        transactions = response_data.get("list", [])
                        total = response_data.get("total", 0)
                    elif isinstance(response_data, list):
                        transactions = response_data
                        total = len(response_data)
                    else:
                        transactions = []
                        total = 0
                    
                    if not transactions:
                        break
                    
                    all_transactions.extend(transactions)
                    
                    logger.info(f"   已获取_所有明细，累计 {len(all_transactions)}/{total} 条")
                    
                    if len(all_transactions) >= total or total == 0:
                        break
                    
                    page_num += 1
                    time.sleep(0.5)
                else:
                    logger.error(f"❌ 查询失败: {data.get('ret_msg', '未知错误')}")
                    break
            except Exception as e:
                logger.error(f"❌ 查询异常: {str(e)}")
                break
        
        # 按交割日期+货币对统计
        settlement_stats: Dict[str, Dict[str, Dict[str, float]]] = {}
        processing_stats: Dict[str, Dict[str, float]] = {}  # 新增：用于PROCESSING状态，按货币对统计
        filtered_transactions = []

        for tx in all_transactions:
            # 获取交易状态（假设状态字段为 org_fx_order_status）
            tx_status = tx.get("org_fx_order_status", "").upper()
    
            # 转换金额
            sell_currency = tx.get("sell_currency", "")
            buy_currency = tx.get("buy_currency", "")
            sell_amt = self._convert_amount(tx.get("sell_amt", 0), sell_currency)
            buy_amt = self._convert_amount(tx.get("buy_amt", 0), buy_currency)
    
            currency_pair = f"{sell_currency}/{buy_currency}"
    
            if tx_status == "PROCESSING":
                # 对于PROCESSING状态，只按货币对统计，不分日期
                if currency_pair not in processing_stats:
                    processing_stats[currency_pair] = {
                        "total_sell": 0.0,
                        "total_buy": 0.0,
                        "count": 0
                    }
                processing_stats[currency_pair]["total_sell"] += sell_amt
                processing_stats[currency_pair]["total_buy"] += buy_amt
                processing_stats[currency_pair]["count"] += 1
                filtered_transactions.append(tx)  # 可选：保留交易记录
            else:
                # 对于SUCCEEDED状态，按交割日期统计
                settlement_date_str = tx.get("settlement_date", "")
                if not settlement_date_str:
                    # 回退：尝试从 org_settlement_date 解析
                    org_settlement_time = self._convert_org_settlement_time(tx.get("org_settlement_date", ""))
                    if not org_settlement_time:
                        continue
                    settlement_date_str = org_settlement_time.strftime("%Y-%m-%d")
        
                # 按日期范围过滤（start_date ~ end_date）
                if start_date and settlement_date_str < start_date:
                    continue
                if end_date and settlement_date_str > end_date:
                    continue
        
                if settlement_date_str not in settlement_stats:
                    settlement_stats[settlement_date_str] = {}
                if currency_pair not in settlement_stats[settlement_date_str]:
                    settlement_stats[settlement_date_str][currency_pair] = {
                        "total_sell": 0.0,
                        "total_buy": 0.0,
                        "count": 0
                    }
        
                settlement_stats[settlement_date_str][currency_pair]["total_sell"] += sell_amt
                settlement_stats[settlement_date_str][currency_pair]["total_buy"] += buy_amt
                settlement_stats[settlement_date_str][currency_pair]["count"] += 1
                filtered_transactions.append(tx)
        
        # 超限判断+发送提醒
        query_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        alerts_sent = []

        # 1. 检查SUCCEEDED状态的交易（使用ALERT_THRESHOLDS）        
        for settle_date, currency_pairs in settlement_stats.items():
            for currency_pair, stats in currency_pairs.items():
                if currency_pair in ALERT_THRESHOLDS:
                    threshold = ALERT_THRESHOLDS[currency_pair]
                    actual_sell = stats["total_sell"]
                    
                    if actual_sell > threshold:
                        alert_data = {
                            "query_time": query_time,
                            "org_code": org_code,
                            "settle_date": settle_date,
                            "currency_pair": currency_pair,
                            "threshold": self._format_number(threshold),
                            "actual_sell": self._format_number(actual_sell),
                            "excess_amount": self._format_number(actual_sell - threshold),
                            "count": stats["count"],
                            "status": "SUCCEEDED",  # 状态标识
                            "threshold_type": "ALERT_THRESHOLDS"  # 阈值类型
                        }
                        # 简化处理，这里不发送实际告警
                        alerts_sent.append(alert_data)

        # 2. 检查PROCESSING状态的交易（使用PROCESSING_THRESHOLDS）
        for currency_pair, stats in processing_stats.items():
            if currency_pair in PROCESSING_THRESHOLDS:
                threshold = PROCESSING_THRESHOLDS[currency_pair]
                actual_sell = stats["total_sell"]
        
                if actual_sell > threshold:
                    alert_data = {
                        "query_time": query_time,
                        "org_code": org_code,
                        "settle_date": "PROCESSING",  # 没有交割日期
                        "currency_pair": currency_pair,
                        "threshold": self._format_number(threshold),
                        "actual_sell": self._format_number(actual_sell),
                        "excess_amount": self._format_number(actual_sell - threshold),
                        "count": stats["count"],
                        "status": "PROCESSING",  # 状态标识
                        "threshold_type": "PROCESSING_THRESHOLDS"  # 阈值类型
                    }
                    alerts_sent.append(alert_data)
        
        # 整理结果
        result = {
            "settlement_stats": settlement_stats,
            "processing_stats": processing_stats,  # 新增：PROCESSING状态统计结果
            "transactions": filtered_transactions,
            "total_count": len(filtered_transactions),
            "start_date": start_date,
            "end_date": end_date,
            "query_time": query_time,
            "alerts_sent": alerts_sent,
            "used_config": {
                "ALERT_THRESHOLDS": ALERT_THRESHOLDS,
                "PROCESSING_ALERT_THRESHOLDS": PROCESSING_THRESHOLDS,  # 新增
                "TRADING_HOURS": config.get("TRADING_HOURS", {}),
                "ENABLE_WECHAT_ALERT": config["ENABLE_WECHAT_ALERT"]
            }
        }
        
        return result

# ===================== 交易监控定时任务类 =====================
class FxMonitoringScheduledTask:
    """换汇交易监控定时任务执行器 - 针对'交易监控'指令"""
    
    def __init__(self, manager: PaykkaSystemManager, interval_minutes: int = 5):
        """
        初始化定时任务
        :param manager: 全局系统管理器
        :param interval_minutes: 监控间隔（分钟），默认5分钟
        """
        self.manager = manager
        self.interval_minutes = interval_minutes
        self.is_running = False
        self.monitor = None
        self.org_code = None
        self.task_thread = None
        self.stop_event = threading.Event()
    
    def set_org_code(self, org_code: Optional[str]):
        """设置要监控的机构代码"""
        self.org_code = org_code
    
    def _get_monitor(self) -> PaykkaFxTransactionMonitor:
        """获取或创建监控器实例"""
        if not self.monitor:
            self.monitor = self.manager.get_fx_transaction_monitor()
        return self.monitor
    
    def _execute_monitoring_task(self):
        """执行一次交易监控任务的核心逻辑"""
        try:
            org_display = self.org_code or "全部"
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            logger.info("=" * 60)            
            logger.info(f"🚀 定期任务执行中 ({current_time})")
            logger.info("=" * 60)
            
            # 获取监控器
            monitor = self._get_monitor()
            if not monitor:
                logger.error("❌ 无法获取交易监控器实例")
                return
            
            # 从监控器中获取配置
            try:
                config = monitor.fetch_fx_threshold_config()
                logger.info(f"✅ GitHub连接成功，已绑定paykka-control仓库")
                logger.info(f"✅ 从fx_threshold.md解析到配置：{len(config['ALERT_THRESHOLDS'])} 个阈值规则")
            except AttributeError as e:
                logger.error(f"❌ 获取GitHub配置失败: {e}")
                # 使用默认配置
                config = {
                    "WECHAT_WEBHOOK_URL": None,
                    "ALERT_THRESHOLDS": {},
                    "ENABLE_WECHAT_ALERT": True,
                    "TRADING_HOURS": {}
                }
                logger.info(f"ℹ️ 使用默认配置")
            
            # 显示Webhook信息
            webhook_url = config.get("WECHAT_WEBHOOK_URL", "使用全局默认")
            if webhook_url and len(webhook_url) > 20:
                webhook_display = webhook_url[:20] + "..."
            else:
                webhook_display = webhook_url
            
            #logger.info(f"  - Webhook: {webhook_display}")
            #logger.info(f"  - 阈值: {config.get('ALERT_THRESHOLDS', {})}")
            #logger.info(f"  - 提醒开关: {'开启' if config.get('ENABLE_WECHAT_ALERT', True) else '关闭'}")
            
            trading_hours = config.get("TRADING_HOURS", {})
            #if trading_hours:
                #logger.info(f"  - 交易时段: {trading_hours}")
            
            # 检查交易时段
            if org_display != "全部" and trading_hours and org_display in trading_hours:
                time_range = trading_hours[org_display]
                start_time = time_range.get('start', '00:00')
                end_time = time_range.get('end', '23:59')
                current_hour_min = datetime.now().strftime("%H:%M")
                
                # 简单检查是否在交易时段内
                if start_time <= current_hour_min <= end_time:
                    logger.info(f"✅ 当前时间 {current_hour_min} 在 {org_display} 的交易时段内 ({start_time}-{end_time})")
                else:
                    logger.info(f"⚠️ 当前时间 {current_hour_min} 不在 {org_display} 的交易时段内 ({start_time}-{end_time})")
            
            # 计算查询时间范围
            today = date.today()
            start_date = today.strftime("%Y-%m-%d")
            end_date = (today + timedelta(days=10)).strftime("%Y-%m-%d")
            
            #logger.info(f"📡 正在查询 {start_date} 至 {end_date} 期间所有货币对的交割敞口...")
            #logger.info(f"   机构: {org_display} | 状态: 企业为成功/机构为成功/处理中")
            
            #logger.info(f"   本次使用配置（来自GitHub fx_threshold.md）:")
            #logger.info(f"    - 阈值: {config.get('ALERT_THRESHOLDS', {})}")
            #logger.info(f"    - 交易时段: {config.get('TRADING_HOURS', {})}")
            #logger.info(f"    - 提醒开关: {'开启' if config.get('ENABLE_WECHAT_ALERT', True) else '关闭'}")
            #logger.info(f"    - Webhook: {webhook_display}")
            
            # 执行查询
            result = monitor.query_fx_transactions(
                org_code=self.org_code,
                merchant_status=DEFAULT_MERCHANT_STATUS,
                org_status=DEFAULT_ORG_STATUS
            )
            
            # 如果有分页信息，记录分页进度
            if 'total_count' in result:
                logger.info(f"   已获取_符合条件明细，累计 {result.get('total_count', 0)}/{result.get('total_count', 0)} 条")
            
            # 生成详细统计报告
            self._generate_detailed_report(result, config, org_display, start_date, end_date)
            
            # 记录结果摘要
            settlement_stats = result.get('settlement_stats', {})
            processing_stats = result.get('processing_stats', {})

            if settlement_stats or processing_stats:
                # SUCCEEDED状态统计
                if settlement_stats:
                    date_count = len(settlement_stats)
                    total_sell_succeeded = 0.0
                    for date_stats in settlement_stats.values():
                        for pair_stats in date_stats.values():
                            total_sell_succeeded += pair_stats.get('total_sell', 0.0)
    
                # PROCESSING状态统计
                if processing_stats:
                    pair_count_processing = len(processing_stats)
                    total_sell_processing = 0.0
                    for pair_stats in processing_stats.values():
                        total_sell_processing += pair_stats.get('total_sell', 0.0)
    
                logger.info(f"✅ 交易监控完成。")
                logger.info(f"   监控机构: {org_display}")
    
                if settlement_stats:
                    logger.info(f"   ✅ 已完成交易: {date_count}个交割日，总卖出: {total_sell_succeeded:,.2f}")
                if processing_stats:
                    logger.info(f"   ⏳ 处理中交易: {pair_count_processing}个货币对，总卖出: {total_sell_processing:,.2f}")
    
                # 如果有告警发送，在日志中体现
                if result.get('alerts_sent'):
                    alert_count = len(result['alerts_sent'])
                    logger.warning(f"🚨 触发 {alert_count} 条敞口超限告警")
        
                    # 统计两种状态的告警数量
                    succeeded_alerts = len([a for a in result['alerts_sent'] if a.get('status') == 'SUCCEEDED'])
                    processing_alerts = len([a for a in result['alerts_sent'] if a.get('status') == 'PROCESSING'])
        
                    if succeeded_alerts > 0:
                        logger.warning(f"   ✅ 已完成交易告警: {succeeded_alerts} 条")
                    if processing_alerts > 0:
                        logger.warning(f"   ⏳ 处理中交易告警: {processing_alerts} 条")
        
                    # 发送汇总告警到企业微信
                    if alert_count > 0:
                        self._send_monitoring_summary_alert(result, config, org_display, start_date, end_date)
            else:
                logger.info(f"ℹ️ 交易监控完成，{org_display}机构未发现未来交割或处理中交易。")
        
        except Exception as e:
            logger.error(f"❌ 交易监控定时任务执行异常: {e}")
            import traceback
            logger.error(f"详细错误信息: {traceback.format_exc()}")
    
    def _generate_detailed_report(self, result: Dict, config: Dict, org_display: str, start_date: str, end_date: str):
        """生成详细的统计报告"""

        settlement_stats = result.get('settlement_stats', {})
        processing_stats = result.get('processing_stats', {})
    
        if not settlement_stats and not processing_stats:
            return
        
        total_transactions = result.get('total_count', {})
        alert_thresholds = config.get('ALERT_THRESHOLDS', {})
        processing_thresholds = config.get('PROCESSING_ALERT_THRESHOLDS', {})
        trading_hours = config.get('TRADING_HOURS', {})
        enable_alert = config.get('ENABLE_WECHAT_ALERT', True)
        
        # 生成详细报告
        report_lines = []
        report_lines.append("=" * 80)
        report_lines.append("📊 换汇交易敞口统计结果（按交割日期）")
        report_lines.append("=" * 80)
        report_lines.append(f"统计范围: {start_date} 至 {end_date} 期间的未来交割敞口（含当日）")
        report_lines.append(f"机构: {org_display}")
        report_lines.append(f"状态: 企业-{DEFAULT_MERCHANT_STATUS} | 机构-{DEFAULT_ORG_STATUS}")
        report_lines.append(f"本次使用配置（GitHub fx_threshold.md）:")
        report_lines.append(f"  - 阈值: {alert_thresholds}")
        report_lines.append(f"  - 处理中交易阈值: {processing_thresholds}")
        report_lines.append(f"  - 交易时段: {trading_hours}")
        report_lines.append(f"  - 提醒开关: {'开启' if enable_alert else '关闭'}")
        report_lines.append(f"总交易笔数: {total_transactions} 笔")
        report_lines.append("=" * 80)
        
        # 1. 显示SUCCEEDED状态统计
        if settlement_stats:
           report_lines.append("📅 已完成交易统计 (按交割日期):")
           report_lines.append("=" * 60)
        
           # 按交割日期排序
           sorted_dates = sorted(settlement_stats.keys())
        
           for settle_date in sorted_dates[:5]:  # 只显示前5个交割日
               currency_pairs = settlement_stats[settle_date]
               report_lines.append(f"交割日期: {settle_date}")
               report_lines.append("-" * 40)
            
               sorted_pairs = sorted(currency_pairs.keys())[:3]  # 只显示前3个货币对
               for currency_pair in sorted_pairs:
                   stats = currency_pairs[currency_pair]
                   total_sell = stats.get('total_sell', 0)
                   total_buy = stats.get('total_buy', 0)
                   count = stats.get('count', 0)
                
                   if '/' in currency_pair:
                       sell_cur, buy_cur = currency_pair.split('/')
                   else:
                       sell_cur, buy_cur = currency_pair[:3], currency_pair[3:]
                
                   report_lines.append(f"货币对 {currency_pair}:")
                   report_lines.append(f"  交易笔数: {count} 笔")
                   report_lines.append(f"  总卖出金额: {total_sell:,.2f} {sell_cur}")
                   report_lines.append(f"  总买入金额: {total_buy:,.2f} {buy_cur}")
                
                   # 检查是否超过阈值
                   if currency_pair in config.get('ALERT_THRESHOLDS', {}):
                       threshold = config['ALERT_THRESHOLDS'][currency_pair]
                       if total_sell > threshold:
                           excess = total_sell - threshold
                           report_lines.append(f"  ⚠️ 超限告警: 卖出 {total_sell:,.2f} > 阈值 {threshold:,.2f} (超出 {excess:,.2f})")
                
                   report_lines.append("")
    
        # 2. 显示PROCESSING状态统计
        if processing_stats:
            report_lines.append("⏳ 处理中交易统计 (按货币对):")
            report_lines.append("=" * 60)
        
            sorted_pairs = sorted(processing_stats.keys())[:3]  # 只显示前3个货币对
            for currency_pair in sorted_pairs:
                stats = processing_stats[currency_pair]
                total_sell = stats.get('total_sell', 0)
                total_buy = stats.get('total_buy', 0)
                count = stats.get('count', 0)
            
                if '/' in currency_pair:
                    sell_cur, buy_cur = currency_pair.split('/')
                else:
                    sell_cur, buy_cur = currency_pair[:3], currency_pair[3:]
            
                report_lines.append(f"货币对 {currency_pair}:")
                report_lines.append(f"  交易笔数: {count} 笔")
                report_lines.append(f"  总卖出金额: {total_sell:,.2f} {sell_cur}")
                report_lines.append(f"  总买入金额: {total_buy:,.2f} {buy_cur}")
            
                # 检查是否超过阈值
                if currency_pair in config.get('ALERT_THRESHOLDS', {}):
                    threshold = config['ALERT_THRESHOLDS'][currency_pair]
                    if total_sell > threshold:
                        excess = total_sell - threshold
                        report_lines.append(f"  ⚠️ 超限告警: 卖出 {total_sell:,.2f} > 阈值 {threshold:,.2f} (超出 {excess:,.2f})")
            
                report_lines.append("")
    
        # 将报告写入日志
        for line in report_lines:
            logger.info(line)
    
    def _send_monitoring_summary_alert(self, result: Dict, config: Dict, org_display: str, start_date: str, end_date: str):
        """发送交易监控汇总告警"""
        try:
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            alerts_sent = result.get('alerts_sent', [])
            alert_count = len(alerts_sent)
        
            if alert_count == 0:
                return  # 没有告警，不发送消息
        
            # 初始化告警消息
            alert_msg = ""
        
            # 按状态分组告警
            succeeded_alerts = [a for a in alerts_sent if a.get('status') == 'SUCCEEDED']
            processing_alerts = [a for a in alerts_sent if a.get('status') == 'PROCESSING']
        
            # 构建告警标题
            alert_msg += f"🚨 换汇交易量监控告警\n"
            alert_msg += f"⏰ 触发时间: {current_time}\n"
            alert_msg += f"🏦 监控机构: {org_display}\n"
            alert_msg += f"📅 查询范围: {start_date} 至 {end_date}\n"
            alert_msg += f"📊 告警总数: {alert_count} 条\n\n"
        
            # 如果有SUCCEEDED状态的告警
            if succeeded_alerts:
                alert_msg += f"✅ 已完成交易告警 ({len(succeeded_alerts)}条):\n"
                alert_msg += "-" * 40 + "\n"
            
                for i, alert in enumerate(succeeded_alerts[:5], 1):  # 最多显示3条
                    currency_pair = alert.get('currency_pair', 'N/A')
                    settle_date = alert.get('settle_date', 'N/A')
                    threshold = alert.get('threshold', 'N/A')
                    actual_sell = alert.get('actual_sell', 'N/A')
                    excess_amount = alert.get('excess_amount', 'N/A')
                    threshold_type = alert.get('threshold_type', '已完成交易阈值')
                
                    alert_msg += f"{i}. {currency_pair} (交割日: {settle_date})\n"
                    alert_msg += f"   阈值类型: {threshold_type}\n"
                    alert_msg += f"   阈值: {threshold} | 实际: {actual_sell} | 超出: {excess_amount}\n"
            
                if len(succeeded_alerts) > 5:
                    alert_msg += f"   还有 {len(succeeded_alerts) - 5} 条已折叠...\n"
                alert_msg += "\n"
        
            # 如果有PROCESSING状态的告警
            if processing_alerts:
                alert_msg += f"⏳ 处理中交易告警 ({len(processing_alerts)}条):\n"
                alert_msg += "-" * 40 + "\n"
            
                for i, alert in enumerate(processing_alerts[:5], 1):  # 最多显示3条
                    currency_pair = alert.get('currency_pair', 'N/A')
                    threshold = alert.get('threshold', 'N/A')
                    actual_sell = alert.get('actual_sell', 'N/A')
                    excess_amount = alert.get('excess_amount', 'N/A')
                    threshold_type = alert.get('threshold_type', '处理中交易阈值')
                    count = alert.get('count', 0)
                
                    alert_msg += f"{i}. {currency_pair} (处理中)\n"
                    alert_msg += f"   阈值类型: {threshold_type}\n"
                    alert_msg += f"   阈值: {threshold} | 实际: {actual_sell} | 超出: {excess_amount}\n"
                    alert_msg += f"   交易笔数: {count} 笔\n"
            
                if len(processing_alerts) > 5:
                    alert_msg += f"   还有 {len(processing_alerts) - 5} 条已折叠...\n"
                alert_msg += "\n"
        
            # 添加统计摘要
            settlement_stats = result.get('settlement_stats', {})
            processing_stats = result.get('processing_stats', {})
        
            if settlement_stats or processing_stats:
                alert_msg += f"📈 统计摘要:\n"
                alert_msg += "-" * 40 + "\n"
            
                # SUCCEEDED状态统计
                if settlement_stats:
                    total_sell_succeeded = 0.0
                    for date_stats in settlement_stats.values():
                        for pair_stats in date_stats.values():
                            total_sell_succeeded += pair_stats.get('total_sell', 0.0)
                    alert_msg += f"✅ 已完成交易: {len(settlement_stats)}个交割日\n"
                    alert_msg += f"   总卖出金额: {total_sell_succeeded:,.2f}\n"
            
                # PROCESSING状态统计
                if processing_stats:
                    total_sell_processing = 0.0
                    for pair_stats in processing_stats.values():
                        total_sell_processing += pair_stats.get('total_sell', 0.0)
                    alert_msg += f"⏳ 处理中交易: {len(processing_stats)}个货币对\n"
                    alert_msg += f"   总卖出金额: {total_sell_processing:,.2f}\n"
            
                alert_msg += "\n"

            alert_msg += f"⚠️ 提醒: 两种状态使用不同的阈值配置\n"        
            alert_msg += f"⚠️ 提醒: 当某货币对的总卖出金额超过阈值时触发告警\n"
            alert_msg += f"📅 下次监控: {self.interval_minutes}分钟后"
        
            # 发送到企业微信
            send_wechat_work_message(alert_msg)
        
        except Exception as e:
            logger.error(f"发送交易监控汇总告警失败: {e}")
    
    def _task_loop(self):
        """任务循环主体"""
        org_display = self.org_code or "全部"
        logger.info(f"✅ 交易监控定时任务已启动")
        logger.info(f"   监控机构: {org_display}")
        logger.info(f"   执行间隔: {self.interval_minutes} 分钟")
        
        while not self.stop_event.is_set():
            try:
                # 执行一次监控
                self._execute_monitoring_task()
            except Exception as e:
                logger.error(f"交易监控定时任务循环内发生异常: {e}")
            
            # 等待指定的间隔时间
            self.stop_event.wait(timeout=self.interval_minutes * 60)
    
    def start(self):
        """启动定时任务（在后台线程中）"""
        if self.is_running:
            org_display = self.org_code or "全部"
            return f"⚠️ 交易监控定时任务已在运行中。当前监控机构: {org_display}"
        
        self.is_running = True
        self.stop_event.clear()
        
        self.task_thread = threading.Thread(
            target=self._task_loop,
            name=f"FxMonitoringTask_{self.org_code or 'ALL'}",
            daemon=True
        )
        self.task_thread.start()
        
        org_display = self.org_code or "全部"
        return (f"✅ 已启动交易监控定时任务\n"
                f"🏦 监控机构: {org_display}\n"
                f"⏰ 执行间隔: 每 {self.interval_minutes} 分钟\n"
                f"📊 监控内容: 未来交割交易敞口与阈值告警")
    
    def stop(self):
        """停止定时任务"""
        if not self.is_running:
            org_display = self.org_code or "全部"
            return f"ℹ️ 交易监控定时任务未在运行。"
        
        self.is_running = False
        self.stop_event.set()
        
        if self.task_thread and self.task_thread.is_alive():
            self.task_thread.join(timeout=5.0)
        
        org_display = self.org_code or "全部"
        return f"🛑 交易监控定时任务已停止。原监控机构: {org_display}"
    
    def status(self):
        """获取任务状态"""
        if self.is_running and self.task_thread and self.task_thread.is_alive():
            org_display = self.org_code or "全部"
            return (f"🟢 任务状态: 运行中\n"
                    f"🏦 监控机构: {org_display}\n"
                    f"⏰ 执行间隔: {self.interval_minutes} 分钟")
        else:
            return f"🔴 任务状态: 已停止"

# ===================== 汇率监控类 =====================
class PaykkaRateMonitor:
    """PAYKKA-XT汇率价差监控模块 - 增强版"""
    
    def __init__(self, token: str, alert_threshold: float = RATE_ALERT_THRESHOLD):
        self.token = token
        self.alert_threshold = alert_threshold
        self.last_check_time = None
        self.rate_history = []
        self.alert_history = {}
        self.alert_count = {}
        self.manager = PaykkaSystemManager()  # 新增
        
        # 确保XT结果目录存在
        os.makedirs(XT_RESULTS_DIR, exist_ok=True)
    
    def _safe_paykka_rate_query(self, from_currency: str, to_currency: str) -> Optional[float]:
        """安全的PAYKKA汇率查询"""
        def query_func():
            payload = {
                "pair_list": [{
                    "sell_currency": from_currency,
                    "buy_currency": to_currency
                }]
            }
            
            response = requests.post(
                url=PAYKKA_RATE_URL,
                headers=self._build_headers(),
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                if result.get("ret_code") == "000000":
                    quota_list = result.get("data", {}).get("quota_list", [])
                    if quota_list and len(quota_list) > 0:
                        rate = quota_list[0].get("exchange_rate")
                        if rate:
                            return float(rate)
            
            raise Exception(f"汇率查询失败: {response.status_code}")
        
        success, result = self.manager.safe_api_call(
            query_func,
            max_retries=1,  # 汇率查询快速失败，不重试太多次
            retry_delay=0.5
        )
        
        return result if success else None
    
    def _build_headers(self) -> Dict[str, str]:
        """构建HTTP请求头（用于PAYKKA汇率查询）"""
        headers = build_auth_headers(self.token)
        return headers
    
    def query_paykka_rate(self, from_currency: str, to_currency: str) -> Optional[float]:
        """查询PAYKKA单一货币对汇率"""
        try:
            payload = {
                "pair_list": [{
                    "sell_currency": from_currency,
                    "buy_currency": to_currency
                }]
            }
            
            response = requests.post(
                url=PAYKKA_RATE_URL,
                headers=self._build_headers(),
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                if result.get("ret_code") == "000000":
                    quota_list = result.get("data", {}).get("quota_list", [])
                    if quota_list and len(quota_list) > 0:
                        rate = quota_list[0].get("exchange_rate")
                        if rate:
                            return float(rate)
            else:
                logger.error(f"PAYKKA汇率查询失败 {from_currency}→{to_currency}: HTTP {response.status_code}")
            
            return None
                
        except Exception as e:
            logger.error(f"PAYKKA汇率查询异常 {from_currency}→{to_currency}: {e}")
            return None
    
    def query_all_paykka_rates(self) -> Dict[str, float]:
        """查询所有PAYKKA汇率"""
        rates = {}
        
        for from_curr, to_curr, description in CURRENCY_PAIRS:
            rate = self.query_paykka_rate(from_curr, to_curr)
            if rate is not None:
                pair_key = f"{from_curr}→{to_curr}"
                rates[pair_key] = rate
                logger.info(f"PAYKKA汇率 {pair_key}: {rate}")
            else:
                logger.warning(f"PAYKKA汇率 {from_curr}→{to_curr}: 查询失败")
            
            time.sleep(0.2)  # 避免请求过快
        
        return rates
    
    def query_xt_rates(self) -> Dict[str, float]:
        """查询XT汇率（使用集成模块，支持缓存复用）"""
        rates = {}
        
        logger.info("查询 XT 汇率（集成模块）...")
        
        try:
            xt = XTRateQueryManager()
            
            # 检查/执行登录
            loop = asyncio.new_event_loop()
            try:
                login_ok = loop.run_until_complete(xt.login())
            finally:
                loop.close()
            
            if not login_ok:
                logger.error("XT 登录失败，无法查询汇率")
                return rates
            
            # 批量查询
            results = xt.query_all_rates(xt.get_currency_pairs())
            
            # 转换为旧格式: {"USD→CNH": rate, ...}
            for r in results:
                if r.get('rate') is not None and r.get('status') == '成功':
                    pair_key = f"{r['from_ccy']}→{r['to_ccy']}"
                    # CNY → CNH 统一
                    pair_key = pair_key.replace("CNY", "CNH")
                    rates[pair_key] = r['rate']
                    logger.info(f"XT {pair_key}: {r['rate']}")
            
            logger.info(f"✅ XT 汇率查询完成: {len(rates)} 个货币对")
            
        except Exception as e:
            logger.error(f"XT 汇率查询异常: {e}")
        
        return rates
    
    def _parse_xt_results(self) -> Dict[str, float]:
        """解析XT查询结果"""
        rates = {}
        
        # 修复：提前定义 desktop_path，避免在 lambda 中引用未定义变量
        desktop_path = os.path.join(os.path.expanduser("~"), "Desktop", "query_py", "xt_query")
        
        try:
            # 查找最新的XT结果Excel文件
            xt_files = [f for f in os.listdir(XT_RESULTS_DIR) 
                       if f.startswith("XTransfer_汇率查询_") and f.endswith(".xlsx")]
            
            if not xt_files:
                # 尝试在桌面目录查找
                if os.path.exists(desktop_path):
                    xt_files = [f for f in os.listdir(desktop_path) 
                               if f.startswith("XTransfer_汇率查询") and f.endswith(".xlsx")]
            
            if xt_files:
                # 按修改时间排序，获取最新的文件
                xt_files.sort(key=lambda x: os.path.getmtime(
                    os.path.join(XT_RESULTS_DIR, x) if os.path.exists(os.path.join(XT_RESULTS_DIR, x)) 
                    else os.path.join(desktop_path, x)
                ), reverse=True)
                
                latest_file = xt_files[0]
                file_path = os.path.join(XT_RESULTS_DIR, latest_file) if os.path.exists(os.path.join(XT_RESULTS_DIR, latest_file)) else os.path.join(desktop_path, latest_file)
                
                logger.info(f"解析XT结果文件: {file_path}")
                
                # 读取Excel文件（修复：显式指定 engine='openpyxl'，兼容 pandas 3.0+）
                df = pd.read_excel(file_path, engine='openpyxl')
                
                # 解析数据
                for _, row in df.iterrows():
                    pair = row.get("货币对", "")
                    rate = row.get("汇率", "")
                    status = row.get("状态", "")
                    
                    if pair and rate and status == "成功":
                        try:
                            # 统一货币对格式：将CNY转换为CNH
                            pair = pair.replace("CNY", "CNH")
                            rates[pair] = float(rate)
                            logger.info(f"XT {pair}: {rate}")
                        except (ValueError, TypeError):
                            logger.warning(f"跳过无效的汇率数据: {pair}={rate}")
            
        except Exception as e:
            logger.error(f"解析XT结果文件失败: {e}")
        
        return rates
    
    def can_send_alert(self, pair_key: str) -> bool:
        """检查是否可以发送报警"""
        now = datetime.now()
        hour_key = now.strftime("%Y%m%d%H")  # 按小时统计
        
        # 检查每小时报警次数限制
        if hour_key not in self.alert_count:
            self.alert_count[hour_key] = 0
        
        if self.alert_count[hour_key] >= RATE_MAX_ALERTS_PER_HOUR:
            logger.warning(f"已达到每小时报警上限({RATE_MAX_ALERTS_PER_HOUR}次)")
            return False
        
        # 检查同一货币对报警间隔（10分钟内不重复报警）
        if pair_key in self.alert_history:
            last_alert_time = self.alert_history[pair_key]
            time_diff = (now - last_alert_time).total_seconds() / 60  # 分钟
            
            if time_diff < 10:  # 10分钟内不重复报警
                logger.info(f"{pair_key} 在{time_diff:.1f}分钟前已报警，跳过")
                return False
        
        # 更新记录
        self.alert_history[pair_key] = now
        self.alert_count[hour_key] += 1
        
        # 清理过期记录
        self._cleanup_old_records()
        
        return True
    
    def _cleanup_old_records(self):
        """清理过期记录"""
        now = datetime.now()
        cutoff_time = now - timedelta(hours=1)
        
        # 清理报警历史（保留1小时）
        keys_to_delete = []
        for pair_key, alert_time in self.alert_history.items():
            if alert_time < cutoff_time:
                keys_to_delete.append(pair_key)
        
        for key in keys_to_delete:
            del self.alert_history[key]
        
        # 清理报警计数（保留当天）
        hour_keys_to_delete = []
        for hour_key in self.alert_count.keys():
            hour_time = datetime.strptime(hour_key, "%Y%m%d%H")
            if hour_time < cutoff_time:
                hour_keys_to_delete.append(hour_key)
        
        for key in hour_keys_to_delete:
            del self.alert_count[key]
    
    def compare_rates(self, paykka_rates: Dict[str, float], xt_rates: Dict[str, float]) -> List[Dict]:
        """比较两个平台的汇率"""
        discrepancies = []
        
        for pair_key in paykka_rates.keys():
            if pair_key in xt_rates:
                paykka_rate = paykka_rates[pair_key]
                xt_rate = xt_rates[pair_key]
                
                # 计算差距百分比（统一使用平均值为分母，与 generate_report 保持一致）
                if paykka_rate > 0 and xt_rate > 0:
                    diff = abs(paykka_rate - xt_rate)
                    avg_rate = (paykka_rate + xt_rate) / 2
                    diff_percent = (diff / avg_rate) * 100
                    
                    # 记录到历史
                    self.rate_history.append({
                        "timestamp": datetime.now(),
                        "pair": pair_key,
                        "paykka_rate": paykka_rate,
                        "xt_rate": xt_rate,
                        "diff_percent": diff_percent
                    })
                    
                    # 只保留最近100条记录
                    if len(self.rate_history) > 100:
                        self.rate_history = self.rate_history[-100:]
                    
                    # 检查是否超过阈值
                    if diff_percent > self.alert_threshold:
                        discrepancies.append({
                            "pair": pair_key,
                            "paykka_rate": paykka_rate,
                            "xt_rate": xt_rate,
                            "diff": diff,
                            "diff_percent": diff_percent,
                            "direction": "PAYKKA更高" if paykka_rate > xt_rate else "XT更高"
                        })
        
        return discrepancies
    
    def generate_report(self, paykka_rates: Dict, xt_rates: Dict, discrepancies: List[Dict]) -> str:
        """生成对比报告"""
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        report = f"# PAYKKA vs XT 汇率对比报告\n"
        report += f"**时间**: {now}\n"
        report += f"**平台**: PAYKKA vs XT\n"
        report += f"**货币对数量**: {len(CURRENCY_PAIRS)}\n"
        report += f"**报警阈值**: {self.alert_threshold}%\n\n"
        
        # 成功查询的货币对
        common_pairs = set(paykka_rates.keys()) & set(xt_rates.keys())
        report += f"**成功查询**: {len(common_pairs)}个\n"
        report += f"**PAYKKA成功**: {len(paykka_rates)}个\n"
        report += f"**XT成功**: {len(xt_rates)}个\n\n"
        
        # 汇率对比表格
        if common_pairs:
            report += "## 汇率对比\n"
            report += "| 货币对 | PAYKKA | XT | 差价 | 差距% | 状态 |\n"
            report += "|--------|--------|----|------|-------|------|\n"
            
            for pair_key in sorted(common_pairs):
                paykka_rate = paykka_rates[pair_key]
                xt_rate = xt_rates[pair_key]
                diff = abs(paykka_rate - xt_rate)
                diff_percent = (diff / ((paykka_rate + xt_rate) / 2)) * 100
                
                status = "正常"
                if diff_percent > self.alert_threshold:
                    status = "⚠️ 异常"
                
                report += f"| {pair_key} | {paykka_rate:.6f} | {xt_rate:.6f} | {diff:.6f} | {diff_percent:.4f}% | {status} |\n"
        
        # 异常货币对
        if discrepancies:
            report += "\n## 🚨 异常汇率\n"
            for disc in discrepancies:
                report += f"- **{disc['pair']}**: PAYKKA={disc['paykka_rate']:.6f}, XT={disc['xt_rate']:.6f}, 差距={disc['diff_percent']:.4f}% ({disc['direction']})\n"
        
        # 仅一个平台有数据的货币对
        paykka_only = set(paykka_rates.keys()) - set(xt_rates.keys())
        xt_only = set(xt_rates.keys()) - set(paykka_rates.keys())
        
        if paykka_only:
            report += "\n## ⚠️ 仅PAYKKA有数据\n"
            for pair in sorted(paykka_only):
                report += f"- {pair}: {paykka_rates[pair]:.6f}\n"
        
        if xt_only:
            report += "\n## ⚠️ 仅XT有数据\n"
            for pair in sorted(xt_only):
                report += f"- {pair}: {xt_rates[pair]:.6f}\n"
        
        return report
    
    def _send_rate_alert(self, alert_data: dict) -> bool:
        """发送汇率异常报警"""
        alert_msg = f"🚨 汇率异常报警\n"
        alert_msg += f"货币对: {alert_data['pair']}\n"
        alert_msg += f"PAYKKA: {alert_data['paykka_rate']:.6f}\n"
        alert_msg += f"XT: {alert_data['xt_rate']:.6f}\n"
        alert_msg += f"差距: {alert_data['diff_percent']:.4f}%\n"
        alert_msg += f"方向: {alert_data['direction']}\n"
        alert_msg += f"时间: {datetime.now().strftime('%H:%M:%S')}\n"
        alert_msg += f"阈值: {self.alert_threshold}%"
        
        return send_wechat_work_message(alert_msg)
    
    def _upload_report_to_github(self, report: str) -> bool:
        """上传汇率报告到GitHub"""
        try:
            commit_message = f"汇率监控自动更新: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
            return upload_to_github_md(report, GITHUB_RATE_FILE_PATH, commit_message)
        except Exception as e:
            logger.error(f"上传汇率报告到GitHub失败: {e}")
            return False
    
    def check_rates(self) -> Dict:
        """执行汇率检查，返回结果字典"""
        logger.info("=" * 60)
        logger.info(f"开始汇率检查: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("=" * 60)
        
        # 查询PAYKKA汇率
        logger.info("1. 查询PAYKKA汇率...")
        paykka_rates = self.query_all_paykka_rates()
        
        # 查询XT汇率
        logger.info("2. 查询XT汇率（通过运行xt_rateV3.py）...")
        xt_rates = self.query_xt_rates()
        
        # 比较汇率
        discrepancies = self.compare_rates(paykka_rates, xt_rates)
        
        # 生成报告
        report = self.generate_report(paykka_rates, xt_rates, discrepancies)
        
        # 记录日志
        logger.info(f"PAYKKA查询成功: {len(paykka_rates)}个")
        logger.info(f"XT查询成功: {len(xt_rates)}个")
        logger.info(f"发现异常: {len(discrepancies)}个")
        
        # 上传报告到GitHub
        upload_success = self._upload_report_to_github(report)
        if upload_success:
            logger.info("✅ 汇率报告已上传到GitHub")
        else:
            logger.error("❌ 汇率报告上传到GitHub失败")
        
        # 发送报警
        alerts_sent = []
        if discrepancies:
            for disc in discrepancies:
                pair_key = disc['pair']
                
                # 检查是否可以发送报警
                if self.can_send_alert(pair_key):
                    if self._send_rate_alert(disc):
                        alerts_sent.append(pair_key)
                        logger.info(f"已发送报警: {pair_key}")
                    else:
                        logger.error(f"报警发送失败: {pair_key}")
        
        # 整理结果
        result = {
            "paykka_rates": paykka_rates,
            "xt_rates": xt_rates,
            "discrepancies": discrepancies,
            "total_count": len(paykka_rates) + len(xt_rates),
            "discrepancy_count": len(discrepancies),
            "alerts_sent": alerts_sent,
            "check_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "report": report,
            "uploaded_to_github": upload_success
        }
        
        self.last_check_time = datetime.now()
        logger.info(f"汇率检查完成: {datetime.now().strftime('%H:%M:%S')}")
        
        return result

# ===================== 路由价格监控类 =====================
class PaykkaExchangeRateMonitor:
    """PAYKKA路由价格监控模块 - 集成到全局框架"""
    
    def __init__(self, token: str):
        self.token = token
        self.api_url = EXCHANGE_RATE_API_URL
        self.webhook_url = EXCHANGE_RATE_WEBHOOK_URL
        self.target_sources = TARGET_RATE_SOURCES
        self.manager = PaykkaSystemManager()  # 集成到全局管理器
        
        # 时区设置
        self.beijing_tz = pytz.timezone('Asia/Shanghai')
        
        # 配置监控日志
        self.logger = logging.getLogger('ExchangeRateMonitor')
        self._setup_logging()
    
    def _build_headers(self) -> Dict[str, str]:
        """构建HTTP请求头（每次动态获取最新Token）"""
        current_token = self.token or self.manager._token
        if current_token:
            self.token = current_token  # 同步更新本地token
        return build_auth_headers(current_token)
    
    def _setup_logging(self):
        """配置监控专用日志"""
        if not self.logger.handlers:
            handler = logging.FileHandler(EXCHANGE_RATE_MONITOR_LOG)
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)
    
    def _safe_exchange_rate_query(self, payload: Dict) -> Tuple[bool, Any]:
        """安全的汇率查询请求"""

        def query_func():
            response = requests.post(
                self.api_url,
                headers=self._build_headers(),  # 修复：每次请求动态获取最新headers
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                raise Exception(f"HTTP {response.status_code}")
        
        # 使用管理器的安全API调用
        return self.manager.safe_api_call(
            query_func,
            max_retries=2,
            retry_delay=1
        )
    
    def get_current_time_range(self) -> Dict[str, str]:
        """
        获取当前查询的时间范围（最近10分钟）
        """
        now_utc = datetime.now(timezone.utc)
        start_time = now_utc - timedelta(minutes=10)
        
        return {
            "start_time": start_time.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "end_time": now_utc.strftime("%Y-%m-%dT%H:%M:%SZ")
        }
    
    def build_payload(self, start_time: str, end_time: str, limit: int = 50) -> Dict:
        """
        构建请求Payload
        """
        return {
            "offset": 0,
            "limit": limit,
            "start_time": start_time,
            "end_time": end_time,
            "base_currency": "USD",
            "quote_currency": "CNH"
        }
    
    def query_exchange_rates(self) -> Optional[List[Dict]]:
        """
        查询汇率数据
        返回: 汇率数据列表或None
        """
        try:

            # 获取时间范围
            time_range = self.get_current_time_range()
            
            # 构建请求数据
            payload = self.build_payload(
                start_time=time_range["start_time"],
                end_time=time_range["end_time"]
            )
            
            self.logger.info(f"查询时间范围: {time_range['start_time']} 到 {time_range['end_time']}")
            
            # 使用安全的API调用
            success, data = self._safe_exchange_rate_query(payload)
            
            if not success:
                self.logger.error(f"汇率查询失败: {data}")
                return None

            # 确保 data 是字典类型
            if not isinstance(data, dict):
                self.logger.error(f"API返回了非字典类型的响应: {type(data)} - {data}")
                return None
            
            if "data" in data:
                self.logger.info(f"成功获取 {len(data['data'])} 条汇率数据")
                return data["data"]
            else:
                self.logger.error("响应数据格式错误，缺少'data'字段")
                return None
                
        except Exception as e:
            self.logger.error(f"查询汇率数据异常: {e}")
            return None
    
    def filter_latest_rates_by_source(self, rates: List[Dict]) -> Dict[str, Dict]:
        """
        按来源过滤最新汇率数据
        """
        filtered_rates = {}
        
        for source in self.target_sources:
            # 过滤指定来源的数据
            source_rates = [rate for rate in rates if rate.get("source") == source]
            
            if source_rates:
                # 按发布时间排序，取最新的
                try:
                    latest_rate = max(
                        source_rates,
                        key=lambda x: datetime.fromisoformat(x["release_time"].replace('Z', '+00:00'))
                    )
                    filtered_rates[source] = latest_rate
                    self.logger.info(f"找到{source}最新报价: {latest_rate.get('bid_rate', 'N/A')} (发布时间: {latest_rate.get('release_time', 'N/A')})")
                except (KeyError, ValueError) as e:
                    self.logger.error(f"处理{source}数据时出错: {e}")
                    filtered_rates[source] = None
            else:
                self.logger.warning(f"未找到{source}的汇率数据")
                filtered_rates[source] = None
        
        return filtered_rates
    
    def check_rate_alert(self, rates: Dict[str, Dict]) -> Optional[Dict]:
        """
        检查是否需要发送告警
        """
        # 检查OCBC数据是否存在
        ocbc_rate = rates.get("OCBC")
        yb_rate = rates.get("YB")
        mdaq_rate = rates.get("MDAQ_FX_TOM")
        
        if not ocbc_rate:
            self.logger.error("OCBC汇率数据缺失，无法进行比较")
            return None
        
        alert_info = {
            "ocbc_rate": ocbc_rate.get("bid_rate", 0),
            "comparisons": [],
            "triggered": False
        }
        
        # 比较YB
        if yb_rate and yb_rate.get("bid_rate") is not None:
            try:
                ocbc_bid = float(ocbc_rate["bid_rate"])
                yb_bid = float(yb_rate["bid_rate"])
                
                if ocbc_bid < yb_bid:
                    alert_info["comparisons"].append({
                        "source": "YB",
                        "rate": yb_bid,
                        "difference": yb_bid - ocbc_bid
                    })
                    alert_info["triggered"] = True
            except (ValueError, TypeError) as e:
                self.logger.error(f"解析YB汇率时出错: {e}")
        
        # 比较MDAQ_FX_TOM
        if mdaq_rate and mdaq_rate.get("bid_rate") is not None:
            try:
                ocbc_bid = float(ocbc_rate["bid_rate"])
                mdaq_bid = float(mdaq_rate["bid_rate"])
                
                if ocbc_bid < mdaq_bid:
                    alert_info["comparisons"].append({
                        "source": "MDAQ_FX_TOM",
                        "rate": mdaq_bid,
                        "difference": mdaq_bid - ocbc_bid
                    })
                    alert_info["triggered"] = True
            except (ValueError, TypeError) as e:
                self.logger.error(f"解析MDAQ_FX_TOM汇率时出错: {e}")
        
        return alert_info if alert_info["triggered"] else None
    
    def send_wechat_alert(self, alert_info: Dict, rates: Dict[str, Dict]) -> bool:
        """
        发送企业微信告警
        返回: 是否发送成功
        """
        try:
            # 获取当前时间
            current_time = datetime.now(self.beijing_tz).strftime('%Y-%m-%d %H:%M:%S')
            
            # 构建消息
            message = {
                "msgtype": "markdown",
                "markdown": {
                    "content": f"""**汇率监控告警**\n
**告警时间**: {current_time}\n
**OCBC买入价异常低于其他来源**\n
---
**汇率详情**:\n
- **OCBC**: {rates['OCBC'].get('bid_rate', 'N/A')} (发布时间: {rates['OCBC'].get('release_time', 'N/A')})\n
"""
                }
            }
            
            # 添加比较信息
            for comparison in alert_info["comparisons"]:
                message["markdown"]["content"] += f"- **{comparison['source']}**: {comparison['rate']:.4f} (高出: {comparison['difference']:.6f})\n"
            
            message["markdown"]["content"] += f"""
**告警条件**: OCBC买入价 < 其他来源买入价
**监控货币对**: USD/CNH
**监控来源**: OCBC, YB, MDAQ_FX_TOM
"""
            
            self.logger.info(f"发送企微告警: {message['markdown']['content'][:200]}...")
            
            # 发送请求
            response = requests.post(
                self.webhook_url,
                json=message,
                timeout=5
            )
            
            if response.status_code == 200:
                self.logger.info("企业微信告警发送成功")
                return True
            else:
                self.logger.error(f"企业微信告警发送失败: {response.status_code}")
                return False
                
        except Exception as e:
            self.logger.error(f"发送企业微信告警失败: {e}")
            return False
    
    def is_trading_hours(self) -> bool:
        """
        检查当前是否在交易时段内
        返回: True如果在交易时段内 (08:00-15:30 UTC+8，含08:00整点)
        """
        # 获取当前北京时间
        now_beijing = datetime.now(self.beijing_tz)
        current_hour = now_beijing.hour
        current_minute = now_beijing.minute
        
        if current_hour < TRADING_START_HOUR:
            self.logger.debug(f"当前时间{current_hour:02d}:{current_minute:02d}早于08:00")
            return False
        elif current_hour > TRADING_END_HOUR:
            self.logger.debug(f"当前时间{current_hour:02d}:{current_minute:02d}晚于18:00")
            return False
        elif current_hour == TRADING_END_HOUR and current_minute > TRADING_END_MINUTE:
            self.logger.debug(f"当前时间{current_hour:02d}:{current_minute:02d}晚于{TRADING_END_HOUR}:{TRADING_END_MINUTE:02d}")
            return False
        
        self.logger.debug(f"当前时间{current_hour:02d}:{current_minute:02d}在交易时段内")
        return True
    
    def run_monitoring(self) -> Dict:
        """
        执行一次监控任务
        返回: 监控结果字典
        """
        result = {
            "success": False,
            "message": "",
            "alert_sent": False,
            "rates": {},
            "check_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

        self.logger.info("开始执行汇率监控任务")

        # 检查是否在交易时段内
        if not self.is_trading_hours():
            msg = "当前不在交易时段内 (08:00-15:30 UTC+8)，跳过监控"
            result["message"] = msg
            self.logger.info(msg)
            return result
        
        # 查询汇率数据
        rates = self.query_exchange_rates()
        if not rates:
            msg = "未获取到汇率数据，跳过本次监控"
            result["message"] = msg
            self.logger.warning(msg)
            return result
        
        # 过滤最新数据
        filtered_rates = self.filter_latest_rates_by_source(rates)
        result["rates"] = filtered_rates
        
        # 检查所有目标来源是否都有数据
        missing_sources = [source for source, data in filtered_rates.items() if data is None]
        if missing_sources:
            self.logger.warning(f"以下来源数据缺失: {missing_sources}")
        
        # 检查是否需要告警
        alert_info = self.check_rate_alert(filtered_rates)
        
        if alert_info:
            alert_msg = f"检测到汇率异常: OCBC买入价({alert_info['ocbc_rate']})低于其他来源"
            result["message"] = alert_msg
            self.logger.warning(alert_msg)
            
            # 发送告警
            alert_sent = self.send_wechat_alert(alert_info, filtered_rates)
            result["alert_sent"] = alert_sent
            result["alert_info"] = alert_info
        else:
            normal_msg = "汇率正常，无需告警"
            result["message"] = normal_msg
            self.logger.info(normal_msg)
        
        result["success"] = True
        return result
    
    def print_current_rates(self, rates: Dict[str, Dict]) -> str:
        """
        打印当前汇率信息
        返回: 格式化后的汇率信息字符串
        """
        output = "\n" + "="*50 + "\n"
        output += "当前汇率监控结果:\n"
        output += "="*50 + "\n"
        
        for source, data in rates.items():
            if data:
                output += f"{source}: {data.get('bid_rate', 'N/A')} (发布时间: {data.get('release_time', 'N/A')})\n"
            else:
                output += f"{source}: 无数据\n"
        output += "="*50 + "\n"
        
        return output
    
    def start_scheduled_monitoring(self, interval_minutes: int = EXCHANGE_RATE_MONITOR_INTERVAL):
        """
        启动定时监控
        注意: 由于全局框架已有调度机制，这里提供独立启动方法
        """
        self.logger.info(f"启动汇率监控，每{interval_minutes}分钟执行一次")
        self.logger.info(f"交易时段: 08:00-15:30 (UTC+8)")
        self.logger.info(f"监控来源: {', '.join(self.target_sources)}")
        
        # 立即执行一次
        result = self.run_monitoring()
        print(self.print_current_rates(result.get("rates", {})))
        
        # 设置定时任务
        schedule.every(interval_minutes).minutes.do(self.run_monitoring)
        
        try:
            while True:
                schedule.run_pending()
                time.sleep(1)
        except KeyboardInterrupt:
            self.logger.info("汇率监控程序已停止")
        except Exception as e:
            self.logger.error(f"汇率监控程序异常终止: {e}")

# ===================== XT 汇率查询模块 =====================
class XTRateQueryManager:
    """XT 汇率查询模块 - 支持登录态持久化和批量/按需查询"""
    
    def __init__(self):
        self.cookie_str = ""
        self.xsrf_token = ""
        self.jwt_token = ""
        self.server_grant_id = ""  # XT API 必需 header
        self.auth_time = None
        self.session = None
        self._load_auth_cache()
    
    # ===================== 认证缓存 =====================
    def _load_auth_cache(self):
        """从缓存文件加载 XT 认证信息"""
        try:
            if os.path.exists(XT_AUTH_CACHE_FILE):
                with open(XT_AUTH_CACHE_FILE, 'r', encoding='utf-8') as f:
                    cache = json.load(f)
                self.cookie_str = cache.get("cookie_str", "")
                self.xsrf_token = cache.get("xsrf_token", "")
                self.jwt_token = cache.get("jwt_token", "")
                self.server_grant_id = cache.get("server_grant_id", "")
                auth_time_str = cache.get("auth_time", "")
                if auth_time_str:
                    self.auth_time = datetime.fromisoformat(auth_time_str)
                logger.info(f"📦 已加载 XT 认证缓存 (时间: {auth_time_str})")
        except Exception as e:
            logger.warning(f"加载 XT 认证缓存失败: {e}")
    
    def _save_auth_cache(self):
        """保存 XT 认证信息到缓存文件"""
        try:
            cache = {
                "cookie_str": self.cookie_str,
                "xsrf_token": self.xsrf_token,
                "jwt_token": self.jwt_token,
                "server_grant_id": self.server_grant_id,
                "auth_time": datetime.now().isoformat(),
            }
            with open(XT_AUTH_CACHE_FILE, 'w', encoding='utf-8') as f:
                json.dump(cache, f, ensure_ascii=False, indent=2)
            self.auth_time = datetime.now()
            logger.info(f"💾 XT 认证缓存已保存")
        except Exception as e:
            logger.error(f"保存 XT 认证缓存失败: {e}")
    
    def _is_auth_valid(self) -> bool:
        """检查认证是否在有效期内"""
        if not self.cookie_str or not self.xsrf_token:
            return False
        if not self.auth_time:
            return False
        elapsed = (datetime.now() - self.auth_time).total_seconds()
        return elapsed < XT_AUTH_CACHE_DURATION
    
    # ===================== Cookie 解析 =====================
    def _parse_cookie_str(self, cookie_str: str) -> Dict[str, str]:
        """解析 cookie 字符串为字典"""
        cookies = {}
        for item in cookie_str.split(';'):
            item = item.strip()
            if '=' in item:
                parts = item.split('=', 1)
                if len(parts) == 2:
                    name, value = parts
                    cookies[name.strip()] = value.strip()
        return cookies
    
    def _setup_session(self):
        """设置 requests 会话的 Cookie"""
        if not self.session:
            self.session = requests.Session()
        cookie_dict = self._parse_cookie_str(self.cookie_str)
        for name, value in cookie_dict.items():
            self.session.cookies.set(name, value)
    
    # ===================== 构建请求头 =====================
    def _build_headers(self) -> Dict[str, str]:
        """构建 XT API 请求头"""
        headers = {
            'accept': 'application/json',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'zh-CN,zh;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
            'origin': 'https://www.xtransfer.cn',
            'referer': 'https://www.xtransfer.cn/',
            'sec-ch-ua': '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36',
            'x-language': 'CN',
        }
        if self.xsrf_token:
            headers['x-xsrf-token'] = self.xsrf_token
        if self.jwt_token:
            headers['Authorization'] = f'Bearer {self.jwt_token}'
        if self.server_grant_id:
            headers['x-server-grant-id'] = self.server_grant_id
            headers['x-user-agent-context'] = f'PC_Browser;serverGrantId:{self.server_grant_id};'
        return headers
    
    # ===================== 登录 =====================
    async def login(self) -> bool:
        """Playwright 自动登录 XT 平台，提取 Cookie 和 Token"""
        if self._is_auth_valid():
            logger.info("✅ XT 认证缓存有效，跳过登录")
            self._setup_session()
            return True
        
        logger.info("🔐 开始 XT 平台自动登录...")
        
        try:
            from playwright.async_api import async_playwright
            
            playwright = await async_playwright().start()
            browser = await playwright.chromium.launch(
                headless=True,
                slow_mo=100,
                args=[
                    "--disable-blink-features=AutomationControlled",
                    "--no-sandbox",
                    "--disable-dev-shm-usage",
                ]
            )
            context = await browser.new_context(
                viewport={"width": 1920, "height": 1080},
            )
            page = await context.new_page()
            
            # 访问登录页
            logger.info(f"访问 XT 登录页: {XT_LOGIN_URL}")
            await page.goto(XT_LOGIN_URL, timeout=30000)
            await asyncio.sleep(3)
            
            # 切换到 Password Login 标签（如果当前不是）
            try:
                password_tab = await page.wait_for_selector(
                    "text=Password Login", timeout=5000
                )
                if password_tab:
                    await password_tab.click()
                    logger.info("已切换到 Password Login 标签")
                    await asyncio.sleep(1)
            except:
                pass  # 可能已经在 Password Login 标签
            
            # 输入手机号（使用正确的 ID）
            phone_input = await page.wait_for_selector(
                "#accountLoginMobileInput",
                timeout=10000
            )
            await phone_input.click()
            await asyncio.sleep(0.3)
            await phone_input.fill("")
            await asyncio.sleep(0.3)
            await phone_input.type(XT_LOGIN_PHONE, delay=80)
            await asyncio.sleep(0.5)
            
            # 输入密码（使用正确的 ID）
            password_input = await page.wait_for_selector(
                "#accountLoginPasswordInput",
                timeout=10000
            )
            await password_input.click()
            await asyncio.sleep(0.3)
            await password_input.fill("")
            await asyncio.sleep(0.3)
            await password_input.type(XT_LOGIN_PASSWORD, delay=80)
            await asyncio.sleep(0.5)
            
            # 点击登录按钮
            login_button = await page.wait_for_selector(
                "button:has-text('Login')",
                timeout=10000
            )
            await login_button.click()
            logger.info("✅ 已点击 XT 登录按钮")
            await asyncio.sleep(3)
            
            # 检查是否出现 CAPTCHA 验证
            try:
                captcha = await page.wait_for_selector(
                    ".captcha-modal, .geetest_holder, [class*='captcha'], [class*='geetest']",
                    timeout=5000
                )
                if captcha:
                    logger.warning("⚠️ XT 登录触发 CAPTCHA 验证，自动化登录无法继续")
                    logger.warning("   请使用以下方式获取 Cookie：")
                    logger.warning("   1. 在本地浏览器手动登录 https://www.xtransfer.cn/login")
                    logger.warning("   2. 打开开发者工具 → Application → Cookies")
                    logger.warning("   3. 复制所有 Cookie 并保存到 xt_auth_cache.json")
                    await browser.close()
                    return False
            except:
                pass  # 没有 CAPTCHA，继续
            
            # 等待页面跳转（最多 10 秒）
            for _ in range(10):
                await asyncio.sleep(1)
                current_url = page.url
                if "login" not in current_url.lower():
                    logger.info(f"✅ XT 登录成功，已跳转到: {current_url}")
                    break
            else:
                logger.warning(f"⚠️ XT 登录后 URL 未变化: {current_url}")
            
            # 提取 Cookies
            cookies = await context.cookies()
            logger.info(f"✅ 提取到 {len(cookies)} 个 XT Cookie")
            
            cookie_parts = []
            for cookie in cookies:
                name = cookie.get('name', '')
                value = cookie.get('value', '')
                if name and value and value != 'null':
                    cookie_parts.append(f"{name}={value}")
                    if 'XSRF-TOKEN' in name.upper():
                        self.xsrf_token = value
                        logger.info(f"  XSRF-TOKEN: {value[:30]}...")
                    elif name.lower() == 'token' and len(value) > 30:
                        self.jwt_token = value
                        logger.info(f"  JWT Token: {value[:30]}...")
            
            self.cookie_str = "; ".join(cookie_parts)
            
            # 从 localStorage 提取 server_grant_id（API 必需 header）
            try:
                grant_id = await page.evaluate("() => localStorage.getItem('xt_new_server_grant_id')")
                if grant_id:
                    self.server_grant_id = grant_id
                    logger.info(f"  server_grant_id: {grant_id[:30]}...")
            except Exception as e:
                logger.warning(f"  无法提取 server_grant_id: {e}")
            
            # 保存缓存
            self._save_auth_cache()
            self._setup_session()
            
            await browser.close()
            
            # 验证 Cookie 是否包含关键认证信息
            has_auth = '_dx_FMrPY6' in self.cookie_str or 'token' in self.cookie_str.lower()
            if has_auth:
                logger.info(f"✅ XT 登录完成，Cookie 长度: {len(self.cookie_str)}")
                return True
            else:
                logger.warning("⚠️ XT Cookie 中未检测到有效认证信息，可能需要手动导入")
                return False
            
        except Exception as e:
            logger.error(f"❌ XT 登录失败: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return False
    
    # ===================== 汇率查询 =====================
    def query_single_rate(self, from_ccy: str, to_ccy: str) -> Optional[Dict]:
        """查询单一货币对的 XT 汇率"""
        if not self.session:
            self._setup_session()
        
        params = {
            'fromCcy': from_ccy.upper(),
            'toCcy': to_ccy.upper(),
            'requestFrom': 'PC'
        }
        
        try:
            response = self.session.get(
                XT_RATE_API_URL,
                headers=self._build_headers(),
                params=params,
                timeout=15,
            )
            
            if response.status_code == 200:
                data = response.json()
                # 解析汇率数据
                rate_value = None
                if 'rate' in data:
                    rate_value = data.get('rate')
                elif 'code' in data and data.get('code') == 0 and 'data' in data:
                    data_field = data['data']
                    if isinstance(data_field, dict) and 'rate' in data_field:
                        rate_value = data_field.get('rate')
                    elif isinstance(data_field, (int, float)):
                        rate_value = data_field
                
                if rate_value is not None:
                    return {
                        "from_ccy": from_ccy.upper(),
                        "to_ccy": to_ccy.upper(),
                        "rate": float(rate_value),
                        "status": "成功",
                    }
                else:
                    return {
                        "from_ccy": from_ccy.upper(),
                        "to_ccy": to_ccy.upper(),
                        "rate": None,
                        "status": "未找到汇率",
                    }
            elif response.status_code == 401:
                logger.error(f"XT 认证失败 (401)，Cookie 已过期或无效")
                # 清除缓存，下次会尝试重新登录
                self.cookie_str = ""
                self.xsrf_token = ""
                self.jwt_token = ""
                self.auth_time = None
                try:
                    if os.path.exists(XT_AUTH_CACHE_FILE):
                        os.remove(XT_AUTH_CACHE_FILE)
                except:
                    pass
                return None
            else:
                logger.error(f"XT 查询 {from_ccy}/{to_ccy} 失败: HTTP {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"XT 查询 {from_ccy}/{to_ccy} 异常: {e}")
            return None
    
    def query_all_rates(self, pairs: List[Tuple[str, str, str]] = None) -> List[Dict]:
        """批量查询 XT 汇率
        
        Args:
            pairs: 货币对列表，格式 [(from_ccy, to_ccy, description), ...]
                   如果为 None，默认查询全部 XT_CURRENCY_PAIRS
        """
        if pairs is None:
            pairs = XT_CURRENCY_PAIRS
        
        results = []
        total = len(pairs)
        
        for i, (from_ccy, to_ccy, description) in enumerate(pairs, 1):
            logger.info(f"[{i}/{total}] XT 查询 {from_ccy}/{to_ccy} ({description})...")
            
            rate_data = self.query_single_rate(from_ccy, to_ccy)
            
            # 展示时 CNY → CNH
            display_from = from_ccy
            display_to = to_ccy if to_ccy != "CNY" else "CNH"
            display_pair = f"{display_from}/{display_to}"
            
            if rate_data:
                result = {
                    'pair': display_pair,
                    'from_ccy': from_ccy,
                    'to_ccy': to_ccy,
                    'rate': rate_data.get('rate'),
                    'status': rate_data.get('status', '未知'),
                    'description': description,
                }
                if rate_data.get('rate'):
                    logger.info(f"   ✅ {display_pair}: {rate_data['rate']}")
                else:
                    logger.info(f"   ⚠️ {display_pair}: 未获取到汇率")
            else:
                result = {
                    'pair': display_pair,
                    'from_ccy': from_ccy,
                    'to_ccy': to_ccy,
                    'rate': None,
                    'status': '查询失败',
                    'description': description,
                }
            
            results.append(result)
            
            # 请求间隔
            if i < total:
                time.sleep(0.5)
        
        return results
    
    def get_currency_pairs(self) -> List[Tuple[str, str, str]]:
        """返回 XT 货币对列表"""
        return list(XT_CURRENCY_PAIRS)
    
    # ===================== 结果格式化 =====================
    def format_results(self, results: List[Dict]) -> str:
        """格式化 XT 汇率查询结果为可读文本"""
        if not results:
            return "❌ XT 汇率查询无结果"
        
        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        success_count = len([r for r in results if r.get('status') == '成功'])
        fail_count = len(results) - success_count
        
        response = f"📊 XT 汇率查询结果\n"
        response += f"⏰ 查询时间: {now_str}\n"
        response += f"📈 成功: {success_count} 个 | 失败: {fail_count} 个\n"
        
        if fail_count > 0 and success_count == 0:
            response += f"⚠️ 所有查询均失败，可能原因：\n"
            response += f"   1. XT Cookie 已过期，需要重新登录\n"
            response += f"   2. XT 平台触发 CAPTCHA，无法自动登录\n"
            response += f"   💡 建议：在本地浏览器登录 XT 后导出 Cookie 到 {XT_AUTH_CACHE_FILE}\n"
        
        response += f"{'─' * 40}\n"
        
        # 按货币对分组展示
        for r in results:
            pair = r['pair']
            rate = r['rate']
            status = r['status']
            desc = r.get('description', '')
            
            if rate is not None:
                # 根据货币对类型决定小数位数
                if 'IDR' in pair or 'VND' in pair:
                    rate_str = f"{rate:.2f}"
                elif 'NGN' in pair:
                    rate_str = f"{rate:.6f}"
                elif 'RON' in pair or 'PLN' in pair or 'HUF' in pair:
                    rate_str = f"{rate:.6f}"
                else:
                    rate_str = f"{rate:.6f}"
                response += f"  {pair:<12} {rate_str:<16} [{status}] {desc}\n"
            else:
                response += f"  {pair:<12} {'N/A':<16} [{status}] {desc}\n"
        
        response += f"{'─' * 40}\n"
        
        # 汇总
        if success_count > 0:
            # 列出主要货币对汇率便于快速查看
            major_pairs = ['USD/CNH', 'EUR/CNH', 'GBP/CNH', 'HKD/CNH']
            quick_view = []
            for r in results:
                if r['pair'] in major_pairs and r['rate'] is not None:
                    quick_view.append(f"{r['pair']}={r['rate']:.6f}")
            if quick_view:
                response += f"📌 主要货币: {', '.join(quick_view)}\n"
        
        return response

# ===================== 友商汇率查询模块 =====================
class CompetitorRateQuery:
    """友商汇率查询类 - 集成 XT、WF、LL、AW、KS、SK 六个友商"""
    
    def __init__(self):
        self.xt = None  # 延迟初始化，避免事件循环问题
        
    def _get_xt(self):
        if self.xt is None:
            self.xt = XTRateQueryManager()
        return self.xt
    
    # ===================== WF (WorldFirst) =====================
    def _query_wf(self, pairs: List[Tuple]) -> List[Dict]:
        """查询 WorldFirst 汇率（通过 API，需先登录获取 Token/Cookie）"""
        results = []
        try:
            # 尝试加载缓存
            cache = {}
            if os.path.exists(WF_AUTH_CACHE_FILE):
                with open(WF_AUTH_CACHE_FILE, 'r') as f:
                    cache = json.load(f)
            
            token = cache.get("token", "")
            cookies = cache.get("cookies", {})
            device_id = cache.get("device_id", "")
            
            if not token and not cookies.get("ALIPAYWFSESSIONID"):
                logger.warning("WF 未登录，尝试自动登录...")
                login_ok = self._wf_login()
                if not login_ok:
                    return [{"pair": f"{f}/{t}", "rate": None, "status": "登录失败", "source": "WF"} for f, t, _ in pairs]
                # 重新加载
                if os.path.exists(WF_AUTH_CACHE_FILE):
                    with open(WF_AUTH_CACHE_FILE, 'r') as f:
                        cache = json.load(f)
                    token = cache.get("token", "")
                    cookies = cache.get("cookies", {})
                    device_id = cache.get("device_id", "")
            
            if not device_id:
                import hashlib, random, string
                chars = string.ascii_letters + string.digits + "_-="
                random_str = ''.join(random.choices(chars, k=50))
                device_id = f"T2gA{random_str}"
            
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Origin": WF_PORTAL_URL,
                "Referer": f"{WF_PORTAL_URL}/",
                "Appid": "WORLDFIRST_WEB",
                "Operation-Type": "com.worldfirst.portal.pc.dashboard.fxinfo",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Workspaceid": "default",
                "X-Cors-Worldfirst_web-Default": "1",
            }
            if token:
                headers["Token"] = token
            if cookies:
                headers["Cookie"] = "; ".join([f"{k}={v}" for k, v in cookies.items()])
            
            payload = [{
                "envInfo": {
                    "terminalType": "PC", "serviceLocation": "sea",
                    "authCode": "authCode", "deviceId": device_id,
                    "lang": "zh_CN", "operateEntrance": "portal",
                    "sourceSite": "WEB", "timeZone": "Asia/Shanghai"
                },
                "extParams": {}
            }]
            
            resp = requests.post(WF_API_URL, json=payload, headers=headers, timeout=30)
            if resp.status_code == 200:
                data = resp.json()
                if isinstance(data, list) and data:
                    data = data[0]
                if data.get("success"):
                    rates = data.get("data", {}).get("rates", [])
                    for f, t, desc in pairs:
                        pair_str = f"{f}/{t}"
                        match = [r for r in rates if r.get("currencyPair") == pair_str]
                        if match:
                            wr = match[0].get("withdrawalRate", {})
                            rate_val = wr.get("rateValue") or wr.get("accuratePrice")
                            results.append({"pair": pair_str, "rate": float(rate_val) if rate_val else None, "status": "成功", "source": "WF"})
                        else:
                            results.append({"pair": pair_str, "rate": None, "status": "未找到", "source": "WF"})
                else:
                    for f, t, desc in pairs:
                        results.append({"pair": f"{f}/{t}", "rate": None, "status": "API失败", "source": "WF"})
            else:
                for f, t, desc in pairs:
                    results.append({"pair": f"{f}/{t}", "rate": None, "status": f"HTTP {resp.status_code}", "source": "WF"})
        except Exception as e:
            logger.error(f"WF 查询异常: {e}")
            for f, t, desc in pairs:
                results.append({"pair": f"{f}/{t}", "rate": None, "status": str(e)[:30], "source": "WF"})
        return results
    
    def _wf_login(self) -> bool:
        """Playwright 自动登录 WorldFirst"""
        try:
            from playwright.sync_api import sync_playwright
            logger.info("🔐 WF 自动登录中...")
            
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True, args=["--no-sandbox", "--disable-blink-features=AutomationControlled"])
                context = browser.new_context(viewport={"width": 1920, "height": 1080})
                page = context.new_page()
                
                page.goto(WF_LOGIN_URL, timeout=30000)
                page.wait_for_selector('input[placeholder*="手机号"]', timeout=15000)
                
                phone_input = page.locator('input[placeholder*="手机号"], input[placeholder*="邮箱"]').first
                phone_input.fill(WF_USERNAME)
                
                password_input = page.locator('input[type="password"]').first
                password_input.fill(WF_PASSWORD)
                
                login_btn = page.locator('button:has-text("立即登录"), button:has-text("登录"), button[type="submit"]').first
                login_btn.click()
                
                try:
                    page.wait_for_url("**/portal/**", timeout=15000)
                except:
                    pass
                
                import time as _time
                _time.sleep(3)
                
                cookies_list = context.cookies()
                cookies = {c['name']: c['value'] for c in cookies_list}
                
                token = page.evaluate("""() => {
                    const keys = ['token', 'Token', 'access_token', 'accessToken'];
                    for (const k of keys) {
                        const v = localStorage.getItem(k) || sessionStorage.getItem(k);
                        if (v) return v;
                    }
                    return null;
                }""")
                
                device_id = page.evaluate("""() => {
                    const keys = ['deviceId', 'device_id', 'deviceTokenId'];
                    for (const k of keys) {
                        const v = localStorage.getItem(k);
                        if (v) return v;
                    }
                    return null;
                }""")
                
                browser.close()
                
                cache = {
                    "token": token or "",
                    "cookies": cookies,
                    "device_id": device_id or "",
                    "auth_time": datetime.now().isoformat(),
                }
                with open(WF_AUTH_CACHE_FILE, 'w') as f:
                    json.dump(cache, f, ensure_ascii=False, indent=2)
                
                logger.info(f"✅ WF 登录成功 (Cookie: {len(cookies)} 个)")
                return bool(cookies.get("ALIPAYWFSESSIONID") or token)
        except Exception as e:
            logger.error(f"WF 登录失败: {e}")
            return False
    
    # ===================== LL (LianLian) =====================
    def _query_ll(self, pairs: List[Tuple]) -> List[Dict]:
        """查询 LianLian 汇率"""
        results = []
        if not LL_LOGIN_TOKEN:
            for f, t, desc in pairs:
                results.append({"pair": f"{f}/{t}", "rate": None, "status": "未配置TOKEN", "source": "LL"})
            return results
        
        headers = {
            "Content-Type": "application/json",
            "Cookie": f"LOGIN_TOKEN={LL_LOGIN_TOKEN}",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        
        for f, t, desc in pairs:
            try:
                ll_from = f
                ll_to = "CNY" if t == "CNH" else t
                resp = requests.post(LL_API_URL, json={"sourceCurrency": ll_from, "targetCurrency": ll_to}, headers=headers, timeout=15)
                if resp.status_code == 200:
                    data = resp.json()
                    if data.get("code") == "000000" and "data" in data:
                        rate = float(data["data"]["rebateRate"])
                        results.append({"pair": f"{f}/{t}", "rate": rate, "status": "成功", "source": "LL"})
                    else:
                        results.append({"pair": f"{f}/{t}", "rate": None, "status": data.get("message", "失败")[:20], "source": "LL"})
                else:
                    results.append({"pair": f"{f}/{t}", "rate": None, "status": f"HTTP {resp.status_code}", "source": "LL"})
            except Exception as e:
                results.append({"pair": f"{f}/{t}", "rate": None, "status": str(e)[:30], "source": "LL"})
            time.sleep(0.3)
        return results
    
    # ===================== AW (Airwallex) =====================
    def _query_aw(self, pairs: List[Tuple]) -> List[Dict]:
        """查询 Airwallex 汇率"""
        results = []
        headers = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
            'Cookie': AW_COOKIE,
            'Referer': 'https://www.airwallex.com/',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        }
        
        for f, t, desc in pairs:
            try:
                params = {'sellAmount': '1', 'sellCcy': f, 'buyCcy': t, 'feePercent': '0'}
                resp = requests.get(AW_API_URL, params=params, headers=headers, timeout=15)
                if resp.status_code == 200:
                    data = resp.json()
                    client_rate = data.get('clientRate', 0)
                    if client_rate and float(client_rate) > 0:
                        rate = 1.0 / float(client_rate)
                        results.append({"pair": f"{f}/{t}", "rate": rate, "status": "成功", "source": "AW"})
                    else:
                        results.append({"pair": f"{f}/{t}", "rate": None, "status": "无效汇率", "source": "AW"})
                else:
                    results.append({"pair": f"{f}/{t}", "rate": None, "status": f"HTTP {resp.status_code}", "source": "AW"})
            except Exception as e:
                results.append({"pair": f"{f}/{t}", "rate": None, "status": str(e)[:30], "source": "AW"})
            time.sleep(0.2)
        return results
    
    # ===================== KS (Ksher) =====================
    def _query_ks(self, pairs: List[Tuple]) -> List[Dict]:
        """查询 Ksher 汇率"""
        results = []
        headers = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Authorization': 'true',
            'Content-Type': 'application/json',
            'Cookie': KS_COOKIE,
            'Host': 'www.ksher.cn',
            'M_id': KS_M_ID,
            'Merchantid': KS_MERCHANT_ID,
            'Origin': 'https://www.ksher.cn',
            'Referer': 'https://www.ksher.cn/b2c/dashboard',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        }
        
        try:
            resp = requests.post(KS_API_URL, headers=headers, json={"business_scope": "B2C"}, timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("code") == 0 and "data" in data:
                    all_rates = data["data"].get("ccy_pairs", [])
                    rate_map = {}
                    for r in all_rates:
                        key = f"{r['source_currency']}/{r['target_currency']}"
                        rate_map[key] = float(r['exchange_rate'])
                    
                    for f, t, desc in pairs:
                        key = f"{f}/{t}"
                        if key in rate_map:
                            results.append({"pair": key, "rate": rate_map[key], "status": "成功", "source": "KS"})
                        else:
                            results.append({"pair": key, "rate": None, "status": "未找到", "source": "KS"})
                else:
                    for f, t, desc in pairs:
                        results.append({"pair": f"{f}/{t}", "rate": None, "status": "API失败", "source": "KS"})
            else:
                for f, t, desc in pairs:
                    results.append({"pair": f"{f}/{t}", "rate": None, "status": f"HTTP {resp.status_code}", "source": "KS"})
        except Exception as e:
            logger.error(f"KS 查询异常: {e}")
            for f, t, desc in pairs:
                results.append({"pair": f"{f}/{t}", "rate": None, "status": str(e)[:30], "source": "KS"})
        return results
    
    # ===================== SK (Skyee) =====================
    def _query_sk(self, pairs: List[Tuple]) -> List[Dict]:
        """查询 Skyee 汇率"""
        results = []
        headers = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Authorization': SK_AUTH_TOKEN,
            'X-Language': 'zh',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        }
        
        try:
            resp = requests.get(SK_API_URL, headers=headers, timeout=15)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("meta", {}).get("ack") == "true":
                    all_rates = data.get("body", {}).get("content", [])
                    rate_map = {}
                    for r in all_rates:
                        pair = r.get("currencyPair", "")
                        selling = r.get("sellingRate")
                        if pair and selling:
                            rate_map[pair] = float(selling)
                    
                    for f, t, desc in pairs:
                        key = f"{f}/{t}"
                        if key in rate_map:
                            results.append({"pair": key, "rate": rate_map[key], "status": "成功", "source": "SK"})
                        else:
                            results.append({"pair": key, "rate": None, "status": "未找到", "source": "SK"})
                else:
                    for f, t, desc in pairs:
                        results.append({"pair": f"{f}/{t}", "rate": None, "status": "API失败", "source": "SK"})
            else:
                for f, t, desc in pairs:
                    results.append({"pair": f"{f}/{t}", "rate": None, "status": f"HTTP {resp.status_code}", "source": "SK"})
        except Exception as e:
            logger.error(f"SK 查询异常: {e}")
            for f, t, desc in pairs:
                results.append({"pair": f"{f}/{t}", "rate": None, "status": str(e)[:30], "source": "SK"})
        return results
    
    # ===================== 统一查询接口 =====================
    def query_all_competitors(self, pairs: List[Tuple] = None, sources: List[str] = None) -> Dict[str, List[Dict]]:
        """查询所有友商汇率
        
        Args:
            pairs: 货币对列表，默认 COMPETITOR_CURRENCY_PAIRS
            sources: 友商列表，如 ["XT", "WF", "LL", "AW", "KS", "SK"]，默认全部
        
        Returns:
            {"XT": [...], "WF": [...], ...}
        """
        if pairs is None:
            pairs = COMPETITOR_CURRENCY_PAIRS
        
        if sources is None:
            sources = ["XT", "WF", "LL", "AW", "KS", "SK"]
        
        all_results = {}
        
        for src in sources:
            logger.info(f"查询 {COMPETITOR_CODES.get(src, src)} 汇率...")
            if src == "XT":
                # XT 需要登录检查（线程隔离）
                import threading
                xt_result = {"ok": False}
                def _xt_login():
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        xt = self._get_xt()
                        xt_result["ok"] = loop.run_until_complete(xt.login())
                    except:
                        pass
                    finally:
                        loop.close()
                
                t = threading.Thread(target=_xt_login)
                t.start()
                t.join(timeout=30)
                
                if xt_result["ok"]:
                    # XT 使用 CNY，需要转换
                    xt_pairs = [(f, "CNY" if t == "CNH" else t, d) for f, t, d in pairs]
                    xt = self._get_xt()
                    xt_raw = xt.query_all_rates(xt_pairs)
                    # 转换结果格式
                    xt_formatted = []
                    for r in xt_raw:
                        xt_formatted.append({
                            "pair": r['pair'],
                            "rate": r['rate'],
                            "status": r['status'],
                            "source": "XT"
                        })
                    all_results["XT"] = xt_formatted
                else:
                    all_results["XT"] = [{"pair": f"{f}/{t}", "rate": None, "status": "登录失败", "source": "XT"} for f, t, _ in pairs]
            
            elif src == "WF":
                all_results["WF"] = self._query_wf(pairs)
            elif src == "LL":
                all_results["LL"] = self._query_ll(pairs)
            elif src == "AW":
                all_results["AW"] = self._query_aw(pairs)
            elif src == "KS":
                all_results["KS"] = self._query_ks(pairs)
            elif src == "SK":
                all_results["SK"] = self._query_sk(pairs)
        
        return all_results
    
    def format_competitor_results(self, all_results: Dict[str, List[Dict]]) -> str:
        """格式化友商汇率查询结果为对比表格"""
        now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        response = f"📊 友商汇率查询结果\n"
        response += f"⏰ 查询时间: {now_str}\n"
        response += f"{'─' * 70}\n"
        
        if not all_results:
            return response + "❌ 无查询结果\n"
        
        # 收集所有货币对
        all_pairs = []
        for src, results in all_results.items():
            for r in results:
                if r['pair'] not in all_pairs:
                    all_pairs.append(r['pair'])
        
        # 表头
        header = f"{'货币对':<12}"
        for src in ["XT", "WF", "LL", "AW", "KS", "SK"]:
            if src in all_results:
                header += f" {src:<14}"
        response += header + "\n"
        response += "─" * 70 + "\n"
        
        # 每行
        for pair in all_pairs:
            row = f"{pair:<12}"
            for src in ["XT", "WF", "LL", "AW", "KS", "SK"]:
                if src in all_results:
                    match = [r for r in all_results[src] if r['pair'] == pair]
                    if match and match[0]['rate'] is not None:
                        rate = match[0]['rate']
                        if rate < 0.01:
                            row += f" {rate:<14.8f}"
                        elif rate < 1:
                            row += f" {rate:<14.6f}"
                        else:
                            row += f" {rate:<14.6f}"
                    else:
                        row += f" {'--':<14}"
            response += row + "\n"
        
        response += "─" * 70 + "\n"
        
        # 统计
        total_ok = 0
        total_fail = 0
        for src, results in all_results.items():
            ok = len([r for r in results if r['rate'] is not None])
            fail = len(results) - ok
            total_ok += ok
            total_fail += fail
            name = COMPETITOR_CODES.get(src, src)
            response += f"  {src} ({name}): ✅{ok} ❌{fail}\n"
        
        response += f"  合计: ✅{total_ok} ❌{total_fail}\n"
        return response

# ===================== 友商历史汇率数据查询类 =====================
class CompetitorHistoryQuery:
    """友商历史汇率数据查询 - 支持 XT、WF、LL 的历史汇率查询和图表生成"""
    
    # 时间范围解析映射
    TIME_RANGE_MAP = {
        "7D": 7, "7d": 7,
        "14D": 14, "14d": 14,
        "30D": 30, "30d": 30,
        "1M": 30, "1m": 30,
        "3M": 90, "3m": 90,
        "6M": 180, "6m": 180,
        "1Y": 365, "1y": 365,
    }
    
    # 图表输出目录
    CHART_DIR = "/workspace/logs/charts"
    
    def __init__(self):
        self.xt = None
        self.wf = None
        os.makedirs(self.CHART_DIR, exist_ok=True)
    
    def _get_xt(self):
        if self.xt is None:
            self.xt = XTRateQueryManager()
        return self.xt
    
    def _get_wf_auth(self) -> Dict:
        """获取 WF 认证信息"""
        cache = {}
        if os.path.exists(WF_AUTH_CACHE_FILE):
            try:
                with open(WF_AUTH_CACHE_FILE, 'r') as f:
                    cache = json.load(f)
            except:
                pass
        return cache
    
    def _parse_time_range(self, range_str: str) -> int:
        """解析时间范围字符串为天数，如 7D→7, 30D→30"""
        if range_str in self.TIME_RANGE_MAP:
            return self.TIME_RANGE_MAP[range_str]
        # 尝试直接解析数字
        try:
            num = int(re.sub(r'[^0-9]', '', range_str))
            if num > 0:
                return num
        except:
            pass
        return 7  # 默认 7 天
    
    def _parse_currency_pair(self, pair_str: str) -> Tuple[str, str]:
        """解析货币对字符串，如 NGNUSD → (NGN, USD)，支持 6 位或通过分隔符"""
        pair_str = pair_str.upper().strip()
        if len(pair_str) == 6:
            return pair_str[:3], pair_str[3:]
        # 尝试通过 / 或空格分隔
        for sep in ['/', '-', ' ']:
            if sep in pair_str:
                parts = pair_str.split(sep)
                if len(parts) == 2 and len(parts[0]) == 3 and len(parts[1]) == 3:
                    return parts[0].strip(), parts[1].strip()
        return None, None
    
    # ===================== XT 历史汇率查询 =====================
    def query_xt_history(self, from_ccy: str, to_ccy: str, days: int = 7) -> Dict:
        """查询 XT 历史汇率数据
        
        XT API: spotfx/graph/present-rate/v2/getWithSource
        参数: fromCcy, toCcy, type=WEEK/MONTH, siteCode=CN
        响应: sourceRatePointList.SPOT[{rateTime, rate, taxRate, fromCcy, toCcy, source}]
        """
        result = {"source": "XT", "pair": f"{from_ccy}/{to_ccy}", "data": [], "success": False, "error": ""}
        
        try:
            xt = self._get_xt()
            if not xt._is_auth_valid():
                # 线程隔离登录
                login_ok = {"ok": False}
                def _login():
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        login_ok["ok"] = loop.run_until_complete(xt.login())
                    except:
                        pass
                    finally:
                        loop.close()
                t = threading.Thread(target=_login)
                t.start()
                t.join(timeout=30)
                if not login_ok["ok"]:
                    result["error"] = "XT 登录失败"
                    return result
            
            xt._setup_session()
            headers = xt._build_headers()
            
            # 根据天数选择 type 参数
            rate_type = "WEEK" if days <= 7 else "MONTH"
            
            params = {
                "fromCcy": from_ccy.upper(),
                "toCcy": to_ccy.upper(),
                "type": rate_type,
                "siteCode": "CN"
            }
            
            # XT 历史数据 API
            xt_history_url = "https://api.xtransfer.cn/api/v1/spotfx/graph/present-rate/v2/getWithSource"
            
            resp = xt.session.get(xt_history_url, headers=headers, params=params, timeout=30)
            if resp.status_code != 200:
                result["error"] = f"XT API HTTP {resp.status_code}"
                return result
            
            data = resp.json()
            
            # 解析 sourceRatePointList.SPOT
            spot_list = data.get("sourceRatePointList", {}).get("SPOT", [])
            if not spot_list:
                result["error"] = "XT 无历史数据 (SPOT 为空)"
                return result
            
            # 根据 days 过滤数据
            cutoff_ms = int((datetime.now() - timedelta(days=days)).timestamp() * 1000)
            
            for item in spot_list:
                rate_time_ms = item.get("rateTime")
                if rate_time_ms and rate_time_ms >= cutoff_ms:
                    result["data"].append({
                        "time": datetime.fromtimestamp(rate_time_ms / 1000).strftime("%Y-%m-%d %H:%M"),
                        "timestamp_ms": rate_time_ms,
                        "rate": float(item.get("rate", 0)),
                        "source_name": item.get("source", "XT"),
                    })
            
            if result["data"]:
                result["success"] = True
                result["data"].sort(key=lambda x: x["timestamp_ms"])
            else:
                result["error"] = f"XT {days}天内无数据"
            
        except Exception as e:
            logger.error(f"XT 历史查询异常: {e}")
            result["error"] = str(e)[:80]
        
        return result
    
    # ===================== WF 历史汇率查询 =====================
    def query_wf_history(self, from_ccy: str, to_ccy: str, days: int = 7) -> Dict:
        """查询 WorldFirst 历史汇率数据
        
        WF API: imgs.worldfirst.com/mgw.htm
        Operation-Type: com.worldfirst.portal.pc.dashboard.historicalRates
        参数: extParams.ccyPair, startTime(ms), endTime(ms), frequency, channelList=["WF"]
        响应: data.chart.timeline[{time.dateString, WF.price, WF.reversePrice}]
        """
        result = {"source": "WF", "pair": f"{from_ccy}/{to_ccy}", "data": [], "success": False, "error": ""}
        
        try:
            cache = self._get_wf_auth()
            token = cache.get("token", "")
            cookies = cache.get("cookies", {})
            device_id = cache.get("device_id", "")
            
            if not device_id:
                import random as _rnd
                import string as _str
                chars = _str.ascii_letters + _str.digits + "_-="
                device_id = f"T2gA{''.join(_rnd.choices(chars, k=50))}"
            
            headers = {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Origin": WF_PORTAL_URL,
                "Referer": f"{WF_PORTAL_URL}/",
                "Appid": "WORLDFIRST_WEB",
                "Operation-Type": "com.worldfirst.portal.pc.dashboard.historicalRates",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Workspaceid": "default",
                "X-Cors-Worldfirst_web-Default": "1",
            }
            if token:
                headers["Token"] = token
            if cookies:
                headers["Cookie"] = "; ".join([f"{k}={v}" for k, v in cookies.items()])
            
            end_ms = int(time.time() * 1000)
            start_ms = end_ms - days * 24 * 60 * 60 * 1000
            
            # WF 的 currency_pair 格式：USD（表示 USD/NGN 方向取决于 reverse_price）
            # 直接用第一个货币作为 ccyPair
            wf_pair = from_ccy.upper()
            frequency = "DAY" if days > 7 else "HOUR"
            
            payload = [{
                "envInfo": {
                    "terminalType": "PC", "serviceLocation": "sea",
                    "authCode": "authCode", "deviceId": device_id,
                    "lang": "zh_CN", "operateEntrance": "portal",
                    "sourceSite": "WEB", "timeZone": "Asia/Shanghai"
                },
                "extParams": {
                    "ccyPair": wf_pair,
                    "startTime": start_ms,
                    "endTime": end_ms,
                    "frequency": frequency,
                    "channelList": ["WF"]
                }
            }]
            
            resp = requests.post(WF_API_URL, json=payload, headers=headers, timeout=30)
            if resp.status_code != 200:
                result["error"] = f"WF API HTTP {resp.status_code}"
                return result
            
            data = resp.json()
            if isinstance(data, list) and data:
                data = data[0]
            
            if not data.get("success"):
                result["error"] = f"WF API 失败: {str(data)[:100]}"
                return result
            
            chart = data.get("data", {}).get("chart", {})
            timeline = chart.get("timeline", [])
            
            for item in timeline:
                time_info = item.get("time", {})
                wf_data = item.get("WF", {})
                
                date_str = time_info.get("dateString", "")
                price = wf_data.get("price", "")
                reverse_price = wf_data.get("reversePrice", "")
                
                if price:
                    try:
                        rate_val = float(price)
                    except:
                        rate_val = None
                elif reverse_price:
                    try:
                        rate_val = 1.0 / float(reverse_price) if float(reverse_price) != 0 else None
                    except:
                        rate_val = None
                else:
                    continue
                
                if rate_val is not None:
                    result["data"].append({
                        "time": date_str,
                        "rate": rate_val,
                        "source_name": "WF",
                    })
            
            if result["data"]:
                result["success"] = True
            else:
                result["error"] = "WF 无历史数据"
            
        except Exception as e:
            logger.error(f"WF 历史查询异常: {e}")
            result["error"] = str(e)[:80]
        
        return result
    
    # ===================== LL 历史汇率查询 =====================
    def query_ll_history(self, from_ccy: str, to_ccy: str, days: int = 7) -> Dict:
        """查询 LianLian 历史汇率数据
        
        LL API: lianlianglobal.cn/b2b/rate/payout/queryHistorySingleCurrency
        参数: currencyPair(如NGNUSD), rateType(THREEHOUR), processTimeStartTime, processTimeEndTime
        响应: data[{processTime, currencyPair, quoteRate, coreRate}]
        """
        result = {"source": "LL", "pair": f"{from_ccy}/{to_ccy}", "data": [], "success": False, "error": ""}
        
        if not LL_LOGIN_TOKEN:
            result["error"] = "LL 未配置 LOGIN_TOKEN"
            return result
        
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)
            
            headers = {
                "Content-Type": "application/json",
                "Cookie": f"LOGIN_TOKEN={LL_LOGIN_TOKEN}",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Origin": "https://www.lianlianglobal.cn",
                "Referer": "https://www.lianlianglobal.cn/dashboard/home",
                "App-Name": "lli-b2b-user-web-v3",
                "Bizsource": "cn_b2b",
                "Biz-Lang": "zh-CN",
            }
            
            payload = {
                "currencyPair": f"{from_ccy.upper()}{to_ccy.upper()}",
                "rateType": "THREEHOUR",
                "processTimeStartTime": start_date.strftime("%Y-%m-%d 00:00:00"),
                "processTimeEndTime": end_date.strftime("%Y-%m-%d 23:59:59"),
            }
            
            ll_history_url = "https://www.lianlianglobal.cn/b2b/rate/payout/queryHistorySingleCurrency"
            
            resp = requests.post(ll_history_url, json=payload, headers=headers, timeout=30)
            if resp.status_code != 200:
                result["error"] = f"LL API HTTP {resp.status_code}"
                return result
            
            data = resp.json()
            if data.get("code") != "000000":
                result["error"] = f"LL API: {data.get('message', '失败')}"
                return result
            
            rate_list = data.get("data", [])
            for item in rate_list:
                quote_rate = item.get("quoteRate", "")
                process_time = item.get("processTime", "")
                if quote_rate:
                    try:
                        rate_val = float(quote_rate)
                    except:
                        continue
                    result["data"].append({
                        "time": process_time,
                        "rate": rate_val,
                        "source_name": "LL",
                    })
            
            if result["data"]:
                result["success"] = True
            else:
                result["error"] = "LL 无历史数据"
            
        except Exception as e:
            logger.error(f"LL 历史查询异常: {e}")
            result["error"] = str(e)[:80]
        
        return result
    
    # ===================== 统一查询接口 =====================
    def query_history(self, source: str, from_ccy: str, to_ccy: str, days: int = 7) -> Dict:
        """统一历史数据查询入口
        
        Args:
            source: 友商标识 (XT/WF/LL)
            from_ccy: 源货币
            to_ccy: 目标货币
            days: 查询天数
        
        Returns:
            {"source": "XT", "pair": "NGN/USD", "data": [...], "success": bool, "error": ""}
        """
        source = source.upper()
        if source == "XT":
            return self.query_xt_history(from_ccy, to_ccy, days)
        elif source == "WF":
            return self.query_wf_history(from_ccy, to_ccy, days)
        elif source == "LL":
            return self.query_ll_history(from_ccy, to_ccy, days)
        else:
            return {"source": source, "pair": f"{from_ccy}/{to_ccy}", "data": [], "success": False, "error": f"不支持的友商: {source}"}
    
    # ===================== 图表生成 =====================
    def generate_chart(self, result: Dict, save_path: str = None) -> str:
        """生成汇率走势图
        
        Args:
            result: query_history 返回的结果字典
            save_path: 保存路径，默认自动生成
        
        Returns:
            图表文件路径，失败返回空字符串
        """
        if not result.get("success") or not result.get("data"):
            logger.warning(f"无数据可生成图表: {result.get('error', '')}")
            return ""
        
        try:
            import matplotlib
            matplotlib.use('Agg')
            import matplotlib.pyplot as plt
            import matplotlib.dates as mdates
            from matplotlib.ticker import ScalarFormatter
            
            # 设置中文字体 - 使用 Noto Sans CJK JP (覆盖中日韩)
            import matplotlib.font_manager as fm
            cjk_font_path = '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
            if os.path.exists(cjk_font_path):
                cjk_prop = fm.FontProperties(fname=cjk_font_path)
                plt.rcParams['font.family'] = cjk_prop.get_name()
            else:
                plt.rcParams['font.sans-serif'] = ['Noto Sans CJK JP', 'Noto Sans CJK SC', 'SimHei', 'DejaVu Sans']
            plt.rcParams['axes.unicode_minus'] = False
            
            data = result["data"]
            source_name = result.get("source", "Unknown")
            pair = result.get("pair", "Unknown")
            
            # 解析时间和汇率
            times = []
            rates = []
            for d in data:
                try:
                    t = datetime.strptime(d["time"], "%Y-%m-%d %H:%M")
                except:
                    try:
                        t = datetime.strptime(d["time"], "%Y-%m-%d %H:%M:%S")
                    except:
                        continue
                times.append(t)
                rates.append(d["rate"])
            
            if not times:
                return ""
            
            # 创建图表
            fig, ax = plt.subplots(figsize=(12, 6))
            
            # 绘制折线图
            ax.plot(times, rates, color='#2196F3', linewidth=1.5, marker='o', markersize=3, label=f'{source_name} {pair}')
            
            # 添加趋势线（简单移动平均）
            if len(rates) >= 5:
                window = max(3, len(rates) // 10)
                trend = pd.Series(rates).rolling(window=window, center=True).mean()
                ax.plot(times, trend, color='#FF5722', linewidth=2, linestyle='--', alpha=0.7, label=f'{window}点移动平均')
            
            # 标注最高/最低点
            max_idx = rates.index(max(rates))
            min_idx = rates.index(min(rates))
            ax.annotate(f'最高: {rates[max_idx]:.4f}', xy=(times[max_idx], rates[max_idx]),
                       xytext=(10, 10), textcoords='offset points', fontsize=8,
                       arrowprops=dict(arrowstyle='->', color='red'), color='red')
            ax.annotate(f'最低: {rates[min_idx]:.4f}', xy=(times[min_idx], rates[min_idx]),
                       xytext=(10, -15), textcoords='offset points', fontsize=8,
                       arrowprops=dict(arrowstyle='->', color='green'), color='green')
            
            # 格式化
            ax.set_title(f'{source_name} 历史汇率走势 - {pair}', fontsize=14, fontweight='bold')
            ax.set_xlabel('时间', fontsize=11)
            ax.set_ylabel('汇率', fontsize=11)
            ax.legend(loc='best', fontsize=9)
            ax.grid(True, alpha=0.3)
            
            # X 轴时间格式
            if len(times) > 10:
                ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
                ax.xaxis.set_major_locator(mdates.AutoDateLocator())
            else:
                ax.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d %H:%M'))
            plt.xticks(rotation=45, ha='right')
            
            # Y 轴格式
            avg_rate = sum(rates) / len(rates)
            if avg_rate < 0.01:
                ax.yaxis.set_major_formatter(ScalarFormatter())
                ax.ticklabel_format(axis='y', style='plain', useOffset=False)
            
            plt.tight_layout()
            
            # 保存
            if not save_path:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                safe_pair = pair.replace("/", "_")
                save_path = os.path.join(self.CHART_DIR, f"{source_name}_{safe_pair}_{timestamp}.png")
            
            plt.savefig(save_path, dpi=150, bbox_inches='tight')
            plt.close(fig)
            
            logger.info(f"📊 图表已保存: {save_path}")
            return save_path
            
        except Exception as e:
            logger.error(f"生成图表失败: {e}")
            import traceback
            logger.error(traceback.format_exc())
            return ""
    
    def format_history_result(self, result: Dict, chart_path: str = None) -> str:
        """格式化历史查询结果为文本消息
        
        Args:
            result: query_history 返回的结果
            chart_path: 图表文件路径（可选）
        
        Returns:
            格式化的文本消息
        """
        if not result.get("success"):
            return f"❌ {result.get('source', '')} 历史汇率查询失败: {result.get('error', '未知错误')}"
        
        data = result["data"]
        source_name = result.get("source", "")
        pair = result.get("pair", "")
        
        if not data:
            return f"⚠️ {source_name} {pair} 无历史数据"
        
        rates = [d["rate"] for d in data]
        times = [d["time"] for d in data]
        
        response = f"📊 {source_name} 历史汇率查询 - {pair}\n"
        response += f"{'─' * 50}\n"
        response += f"⏰ 数据范围: {times[0]} ~ {times[-1]}\n"
        response += f"📈 数据点数: {len(data)}\n"
        response += f"📊 最高: {max(rates):.6f}  最低: {min(rates):.6f}\n"
        response += f"📉 平均: {sum(rates)/len(rates):.6f}\n"
        response += f"📐 波动率: {(max(rates)-min(rates))/min(rates)*100:.4f}%\n"
        
        # 最近 5 条
        response += f"\n📋 最近数据:\n"
        for d in data[-5:]:
            response += f"  {d['time']}  |  {d['rate']:.6f}\n"
        
        if chart_path:
            response += f"\n📊 走势图已生成"
        
        return response

# ===================== 指令处理器 =====================
class IntegratedCommandProcessor:
    """集成指令处理器 - 增强版，支持自动重连"""
    
    def __init__(self, manager: PaykkaSystemManager):
        self.manager = manager
        self.forex_config = None
        self.routing_config = None
        self.balance_query = None
        self.fx_monitor = None
        self.rate_monitor = None
        self.exchange_rate_monitor = None  # 新增
        self.fx_monitoring_task = None  # 新增：交易监控定时任务实例
        self.balance_monitoring_task = None

        self.commands = {
            "帮助": self.handle_help,
            "help": self.handle_help,
            "状态": self.handle_status,
            "测试": self.handle_test,
            "Token刷新状态": self.handle_token_refresh_status,
            "手动刷新Token": self.handle_manual_token_refresh,
            "配置": self.handle_configure_forex,
            "修改路由": self.handle_update_routing,
            "查询路由": self.handle_query_routing,
            "所有路由": self.handle_query_all_routing,
            "同步路由": self.handle_sync_to_github,
            "启动路由调度": self.handle_start_routing_scheduler,
            "停止路由调度": self.handle_stop_routing_scheduler,
            "路由调度状态": self.handle_routing_scheduler_status,
            "更新路由调度配置": self.handle_force_reload_routing_config,
            "余额查询": self.handle_query_balance,
            "余额预警": self.handle_check_balance_alert,
            "生成余额报告": self.handle_generate_balance_report,
            "敞口统计": self.handle_fx_statistics,
            "交易监控": self.handle_fx_monitoring,
            "机构列表": self.handle_org_list,
            "汇率监控": self.handle_rate_monitoring,
            "汇率检查": self.handle_rate_check,
            "汇率报告": self.handle_rate_report,
            "货币对列表": self.handle_currency_pairs,
            "路由价格监控": self.handle_exchange_rate_monitor,
            "定时路由价格监控": self.handle_start_exchange_rate_monitor,
            "路由汇率告警": self.handle_exchange_rate_alert,
            "路由汇率查询": self.handle_exchange_rate_status,
            "定时余额监控": self.handle_balance_monitoring,
            "余额监控状态": self.handle_balance_monitoring_status,
            "停止余额监控": self.handle_stop_balance_monitoring,
            "XT汇率查询": self.handle_xt_rate_query,
            "友商汇率查询": self.handle_competitor_rate_query,
            "友商查询": self.handle_competitor_rate_query,
            "历史报价": self.handle_history_rate_query,
            "XT报价": self.handle_history_rate_query,
            "WF报价": self.handle_history_rate_query,
            "LL报价": self.handle_history_rate_query,
            "报价对比": self.handle_rate_comparison,
        }
        
        # ===================== 智能指令别名表 =====================
        # 格式: (别名列表, 参数提取函数, 说明)
        self.command_aliases = [
            # --- 查询类 ---
            (["查询路由", "路由查询", "查看路由", "路由"], 
             lambda t: self._extract_pair_args(t), "查询某货币对路由"),
            (["所有路由", "全部路由", "路由列表", "路由配置"], 
             lambda t: ([], None), "查看所有路由配置"),
            (["余额查询", "查询余额", "余额", "查余额"], 
             lambda t: ([], None), "查询所有机构余额"),
            (["路由汇率查询", "路由汇率", "路由价格查询", "路由价格", "汇率查询"], 
             lambda t: ([], None), "查询路由实时汇率"),
            (["XT汇率查询", "XT查询", "查询XT汇率", "xt汇率", "XT价格", "XT报价"], 
             lambda t: self._extract_xt_pair_args(t), "查询XT平台汇率报价"),
            (["友商汇率查询", "友商查询", "友商汇率", "查询友商", "友商报价", "同行汇率"], 
             lambda t: self._extract_competitor_args(t), "查询所有友商汇率报价"),
            (["历史报价", "XT报价", "WF报价", "LL报价", "XT历史", "WF历史", "LL历史", "汇率走势", "汇率历史"], 
             lambda t: self._extract_history_args(t), "查询友商历史汇率数据并生成走势图"),
            (["汇率检查", "检查汇率", "汇率对比"], 
             lambda t: ([], None), "检查汇率差异"),
            (["报价对比", "汇率对比", "多方对比", "渠道对比", "渠道友商对比", "友商渠道对比"], 
             lambda t: self._extract_comparison_args(t), "对比渠道与友商历史汇率报价（支持自定义货币对/天数/渠道/友商）"),
            (["汇率监控", "汇率监控查询"], 
             lambda t: ([t] if len(t.split()) > 1 else []), "执行汇率监控"),
            (["路由价格监控", "路由汇率监控"], 
             lambda t: ([], None), "执行一次路由价格监控"),
            (["路由调度状态", "调度状态", "调度器状态"], 
             lambda t: ([], None), "查看路由调度器状态"),
            (["余额监控状态", "余额监控"], 
             lambda t: ([], None), "查看余额监控状态"),
            (["机构列表", "机构", "渠道列表"], 
             lambda t: ([], None), "查看机构列表"),
            (["货币对列表", "货币对", "币种列表"], 
             lambda t: ([], None), "查看货币对列表"),
            (["Token刷新状态", "token状态", "令牌状态"], 
             lambda t: ([], None), "查看Token状态"),
            (["汇率报告", "汇率报告查询"], 
             lambda t: ([], None), "查看汇率报告"),
            # --- 操作类 ---
            (["敞口统计", "统计敞口", "敞口查询", "敞口"], 
             lambda t: self._extract_org_and_date_args(t), "换汇敞口统计"),
            (["生成余额报告", "余额报告", "生成报告"], 
             lambda t: ([], None), "生成并上传余额报告"),
            (["余额预警", "预警检查"], 
             lambda t: ([], None), "检查余额预警"),
            (["交易监控", "换汇监控", "交易统计"], 
             lambda t: self._extract_org_args(t), "换汇交易监控"),
            (["修改路由", "更新路由", "设置路由", "切换路由"], 
             lambda t: self._extract_route_update_args(t), "修改货币对路由"),
            (["同步路由", "同步配置", "同步到github"], 
             lambda t: ([], None), "同步路由配置到GitHub"),
            (["配置", "汇差配置", "设置汇差"], 
             lambda t: self._extract_pair_args(t), "配置汇差"),
            (["路由汇率告警", "汇率告警", "路由告警"], 
             lambda t: ([], None), "检查路由汇率告警"),
            # --- 定时任务类 ---
            (["启动路由调度", "开启路由调度", "路由调度启动"], 
             lambda t: ([], None), "启动路由定时切换"),
            (["停止路由调度", "关闭路由调度", "路由调度停止"], 
             lambda t: ([], None), "停止路由定时切换"),
            (["定时余额监控", "启动余额监控", "开启余额监控"], 
             lambda t: self._extract_number_arg(t, 60), "启动余额定时监控"),
            (["停止余额监控", "关闭余额监控"], 
             lambda t: ([], None), "停止余额定时监控"),
            (["定时路由价格监控", "启动路由价格监控", "开启路由价格监控"], 
             lambda t: self._extract_number_arg(t, 5), "启动路由价格定时监控"),
            (["更新路由调度配置", "重载路由配置", "刷新路由配置"], 
             lambda t: ([], None), "重新加载路由调度配置"),
            # --- 系统类 ---
            (["手动刷新Token", "刷新token", "刷新令牌"], 
             lambda t: ([], None), "手动刷新Token"),
            (["状态", "系统状态", "status"], 
             lambda t: ([], None), "查看系统状态"),
            (["帮助", "help", "命令", "?", "？"], 
             lambda t: ([], None), "查看帮助"),
            (["测试", "test", "测试连接"], 
             lambda t: ([], None), "测试系统连接"),
        ]

    # 添加处理方法：
    def handle_token_refresh_status(self, args: List[str]) -> str:
        """查看Token自动刷新状态"""
        try:
            manager = self.manager
            response = "🔐 Token自动刷新状态\n"
            response += "=" * 40 + "\n"
        
            if manager._token_refresh_thread and manager._token_refresh_thread.is_alive():
                response += "🟢 状态: 运行中\n"
            else:
                response += "🔴 状态: 已停止\n"
        
            response += f"⏰ 刷新时间点: {', '.join(manager._token_refresh_times)}\n"
        
            if manager._last_login_time:
                last_time = datetime.fromtimestamp(manager._last_login_time)
                age_hours = (datetime.now() - last_time).total_seconds() / 3600
                response += f"📅 上次刷新: {last_time.strftime('%Y-%m-%d %H:%M:%S')} ({age_hours:.1f}小时前)\n"
        
            # 计算下次刷新时间
            try:
                next_refresh_time = manager._calculate_next_refresh_time()
                hours_left = (next_refresh_time - datetime.now()).total_seconds() / 3600
                response += f"⏳ 下次刷新: {next_refresh_time.strftime('%Y-%m-%d %H:%M:%S')} ({hours_left:.1f}小时后)\n"
            except:
                response += f"⏳ 下次刷新: 计算中...\n"
        
            response += f"🔑 Token状态: {'有效' if manager._token else '无效'}\n"
            if manager._token:
                response += f"   长度: {len(manager._token)} 字符\n"
        
            response += "\n💡 提示: Token有效期为24小时，自动刷新确保不过期"
            return response
        
        except Exception as e:
            return f"❌ 获取Token刷新状态失败: {e}"

    def handle_manual_token_refresh(self, args: List[str]) -> str:
        """手动刷新Token"""
        try:
            manager = self.manager
            logger.info("🔄 手动触发Token刷新...")
        
            success = manager._refresh_token_with_retry()
        
            if success:
                return "✅ Token手动刷新成功"
            else:
                return "❌ Token手动刷新失败，请检查日志"
        
        except Exception as e:
            return f"❌ 手动刷新Token失败: {e}"
    
    # ===================== 智能指令别名系统 =====================
    # 初始化在 __init__ 末尾完成
    
    def _extract_pair_args(self, text: str) -> tuple:
        """从文本中提取货币对参数 (如 'USD CNH' 或 'USDCNH')"""
        import re
        # 去掉指令关键词，提取剩余部分
        # 尝试匹配 3字母+空格+3字母 或 6字母连写
        m = re.search(r'([A-Za-z]{3})\s*([A-Za-z]{3})', text)
        if m:
            return ([m.group(1).upper(), m.group(2).upper()], None)
        return ([], None)
    
    def _extract_org_args(self, text: str) -> tuple:
        """从文本中提取机构代码"""
        import re
        m = re.search(r'\b(YB|CC|OCBC|HCE|MDAQ)\b', text, re.IGNORECASE)
        if m:
            return ([m.group(1).upper()], None)
        # 也检查中文
        if '易宝' in text or 'yb' in text.lower():
            return (['YB'], None)
        if 'cc' in text.lower():
            return (['CC'], None)
        return ([], None)
    
    def _extract_org_and_date_args(self, text: str) -> tuple:
        """从文本中提取机构代码和日期参数"""
        args = []
        import re
        m = re.search(r'\b(YB|CC|OCBC|HCE|MDAQ)\b', text, re.IGNORECASE)
        if m:
            args.append(m.group(1).upper())
        return (args, None)
    
    def _extract_route_update_args(self, text: str) -> tuple:
        """从文本中提取修改路由的参数: 货币对 + 规则"""
        import re
        args = []
        m = re.search(r'([A-Za-z]{3})\s*([A-Za-z]{3})', text)
        if m:
            args.extend([m.group(1).upper(), m.group(2).upper()])
        # 提取规则
        m2 = re.search(r'(RULE_\w+)', text, re.IGNORECASE)
        if m2:
            args.append(m2.group(1).upper())
        return (args, None)
    
    def _extract_number_arg(self, text: str, default: int) -> tuple:
        """从文本中提取数字参数（如间隔分钟数）"""
        import re
        m = re.search(r'\b(\d+)\b', text)
        if m:
            return ([m.group(1)], None)
        return ([], None)
    
    def _extract_xt_pair_args(self, text: str) -> tuple:
        """从文本中提取 XT 货币对参数（支持单对和多对查询）
        示例: 'XT查询 USD CNY' → ['USD', 'CNY']
              'XT查询 USD CNY, EUR CNY' → ['USD', 'CNY', 'EUR', 'CNY']
        """
        import re
        args = []
        # 去掉指令关键词部分，只保留参数
        # 匹配格式: 3字母+空格+3字母（可能逗号分隔多组）
        pairs = re.findall(r'([A-Za-z]{3})\s+([A-Za-z]{3})', text)
        for m in pairs:
            args.extend([m[0].upper(), m[1].upper()])
        return (args, None)

    def _extract_competitor_args(self, text: str) -> tuple:
        """从文本中提取友商代码和货币对参数
        示例: '友商查询 XT WF' → ['XT', 'WF']
              '友商查询 USD CNY' → ['USD', 'CNY']
        """
        import re
        args = []
        # 先检查是否有友商代码
        codes_found = re.findall(r'\b(XT|WF|LL|AW|KS|SK)\b', text, re.IGNORECASE)
        for c in codes_found:
            args.append(c.upper())
        
        # 如果没有友商代码，检查是否有货币对
        if not args:
            m = re.search(r'([A-Za-z]{3})\s+([A-Za-z]{3})', text)
            if m:
                args.extend([m.group(1).upper(), m.group(2).upper()])
        
        return (args, None)

    def _extract_comparison_args(self, text: str) -> tuple:
        """从文本中提取报价对比参数: (pair_str, days, channels, competitors)
        
        支持格式:
        - "报价对比"                              → 默认 USDCNH, 3天, 全部渠道 + XT
        - "报价对比 USDCNH 7D"                    → USDCNH, 7天, 全部渠道 + XT
        - "报价对比 USD CNY 1D"                   → USDCNY, 1天
        - "报价对比 NGNUSD 3D YB MDAQ"            → NGNUSD, 3天, YB + MDAQ_FX_TOM
        - "报价对比 USDCNH 7D XT WF"              → USDCNH, 7天, 全部渠道 + XT + WF
        - "报价对比 EURCNH BOC YB XT"             → EURCNH, 3天(默认), BOC + YB + XT
        
        返回: (args_list, None)，args_list 格式为 [pair_str, days, channel1, channel2, ..., competitor1, ...]
        """
        import re
        text = text.strip()
        args = text.split()
        
        pair_str = None
        days = 3  # 默认3天
        channels = []
        competitors = []
        
        # 已知渠道代码映射（支持缩写）
        channel_aliases = {
            "YB": "YB", "易宝": "YB",
            "BOC": "BOC", "中国银行": "BOC",
            "MDAQ": "MDAQ_FX_TOM", "MDAQ_FX_TOM": "MDAQ_FX_TOM",
            "HCE": "HCE_FX_TOM", "HCE_FX_TOM": "HCE_FX_TOM",
            "PP": "PP", "OCBC": "OCBC", "CC": "CC",
        }
        
        # 已知友商代码
        competitor_codes = {"XT", "WF", "LL"}
        
        for arg in args:
            upper = arg.upper()
            
            # 识别天数（1D, 3D, 7D）
            day_match = re.match(r'^(\d+)[Dd]$', arg)
            if day_match:
                days = int(day_match.group(1))
                if days > 30:
                    days = 30  # 上限30天
                continue
            
            # 识别6字母货币对
            if re.match(r'^[A-Za-z]{6}$', arg):
                pair_str = arg.upper()
                continue
            
            # 识别友商
            if upper in competitor_codes:
                competitors.append(upper)
                continue
            
            # 识别渠道
            if upper in channel_aliases:
                resolved = channel_aliases[upper]
                if resolved not in channels:
                    channels.append(resolved)
                continue
        
        # 尝试从相邻两个3字母参数中提取货币对
        if not pair_str:
            for i, arg in enumerate(args):
                if len(arg) == 3 and arg.isalpha() and i + 1 < len(args):
                    next_arg = args[i + 1]
                    if len(next_arg) == 3 and next_arg.isalpha():
                        # 确认这两个都不是渠道或友商代码
                        if arg.upper() not in channel_aliases and arg.upper() not in competitor_codes:
                            if next_arg.upper() not in channel_aliases and next_arg.upper() not in competitor_codes:
                                pair_str = arg.upper() + next_arg.upper()
                                break
        
        # 默认值
        if not pair_str:
            pair_str = "USDCNH"
        if not channels:
            channels = DEFAULT_CHANNEL_SOURCES.copy()
        if not competitors:
            competitors = DEFAULT_COMPETITOR_SOURCES.copy()
        
        # 返回扁平化的 args 列表
        result_args = [pair_str, str(days)] + channels + competitors
        return (result_args, None)

    def _fuzzy_match_command(self, text: str) -> tuple:
        """
        智能匹配指令。
        返回 (规范指令名, 参数列表, 匹配得分)
        得分: 100=精确匹配, 80+=高置信别名, 60+=模糊匹配, 0=不匹配
        """
        text_stripped = text.strip()
        if not text_stripped:
            return (None, [], 0)
        
        best_score = 0
        best_cmd = None
        best_args = []
        
        for aliases, arg_extractor, _desc in self.command_aliases:
            for alias in aliases:
                alias_lower = alias.lower()
                text_lower = text_stripped.lower()
                
                # 1. 精确前缀匹配 (100分)
                if text_lower == alias_lower:
                    args, _ = arg_extractor(text_stripped)
                    return (aliases[0], args, 100)
                
                # 2. 以别名开头 (95分) - 如 "查询路由 USD CNH"
                if text_lower.startswith(alias_lower + ' ') or text_lower.startswith(alias_lower):
                    args, _ = arg_extractor(text_stripped)
                    score = 95
                    if score > best_score:
                        best_score = score
                        best_cmd = aliases[0]
                        best_args = args
                
                # 3. 别名包含在文本中 (80分) - 如 "帮我查询路由"
                if alias_lower in text_lower and len(alias_lower) >= 2:
                    score = 80
                    if score > best_score:
                        best_score = score
                        best_cmd = aliases[0]
                        # 从完整文本中提取参数（而不只是截取别名后的部分）
                        best_args, _ = arg_extractor(text_stripped)
                
                # 4. 关键词匹配 (60分) - 别名的主要字符必须在文本中出现
                # 要求至少2/3的字符匹配，避免"乱七八糟"匹配到"帮助"
                if len(alias) >= 3:
                    chars = set(alias_lower.replace(' ', ''))
                    text_chars = set(text_lower.replace(' ', ''))
                    overlap = len(chars & text_chars)
                    required = max(len(chars) - 1, int(len(chars) * 0.6))
                    if overlap >= required and overlap >= 2:
                        score = 60 + overlap
                        if score > best_score:
                            best_score = score
                            best_cmd = aliases[0]
                            best_args, _ = arg_extractor(text_stripped)
        
        return (best_cmd, best_args, best_score)
    
    def parse_command(self, text: str) -> Dict:
        """智能解析指令文本（支持别名、模糊匹配）"""
        parts = text.strip().split()
        if not parts:
            return {"command": "", "args": []}
        
        # 先尝试精确匹配原有 commands 字典（兼容性）
        for cmd_key in self.commands:
            if text.startswith(cmd_key):
                args = text[len(cmd_key):].strip().split()
                # 对于历史报价指令，将友商代码前置到 args 中，便于 handler 识别
                if cmd_key in ["XT报价", "WF报价", "LL报价", "历史报价"]:
                    if cmd_key == "XT报价":
                        args = ["XT"] + args
                    elif cmd_key == "WF报价":
                        args = ["WF"] + args
                    elif cmd_key == "LL报价":
                        args = ["LL"] + args
                    else:
                        # 历史报价 - 尝试从 args 中识别友商，如果没有则默认 XT
                        has_source = any(a.upper() in ["XT", "WF", "LL"] for a in args)
                        if not has_source:
                            args = ["XT"] + args
                return {"command": cmd_key, "args": args}
        
        # 智能模糊匹配
        cmd, args, score = self._fuzzy_match_command(text)
        
        if cmd and score >= 60:
            return {"command": cmd, "args": args}
        
        # 完全无法匹配
        return {"command": text.split()[0], "args": text.split()[1:] if len(text.split()) > 1 else []}
    
    def safe_execute(self, func, *args, **kwargs):
        """
        安全的指令执行封装
        自动处理Token过期和网络异常，最多重试2次
        所有异常都会被捕获并返回友好的错误信息，不会导致进程崩溃
        """
        max_retries = kwargs.pop('max_retries', 2)
        last_error = None
        
        for attempt in range(max_retries + 1):
            try:
                result = func(*args, **kwargs)
                return result
                
            except Exception as e:
                last_error = e
                error_msg = str(e)
                logger.error(f"指令执行异常（第{attempt+1}次）: {error_msg}")
                
                # 检查是否是认证相关错误
                is_auth_error = any(keyword in error_msg.lower() for keyword in 
                                  ['token', 'auth', 'unauthorized', 'forbidden', '010112', '401', '403'])
                
                if is_auth_error and attempt < max_retries:
                    logger.warning("🔐 检测到认证错误，尝试刷新Token并重试...")
                    try:
                        self.manager._refresh_token_with_retry(max_retries=1, retry_delay=10)
                    except Exception as refresh_err:
                        logger.error(f"Token刷新也失败: {refresh_err}")
                    time.sleep(1)
                    continue
                elif attempt < max_retries:
                    logger.warning(f"🔁 指令执行失败，第{attempt+1}次重试...")
                    time.sleep(1)
                    continue
        
        # 所有重试都失败，返回友好错误信息而非抛出异常
        return f"❌ 指令执行失败（已重试{max_retries}次）: {str(last_error)[:200]}"
    
    def handle_configure_forex(self, args: List[str]) -> str:
        """处理汇差配置指令（增强版，支持自动重连）"""
        if len(args) < 5:
            return "❌ 参数不足，格式: 配置 [卖出币种]->[买入币种] [成本/参考] [数据源] [类型] [值]"
        
        try:
            # 使用安全执行
            return self.safe_execute(self._configure_forex_impl, args)
        except Exception as e:
            return f"❌ 汇差配置失败（自动重连后仍失败）: {str(e)}"
    
    def _configure_forex_impl(self, args: List[str]) -> str:
        """汇差配置实现（被safe_execute包装）"""
        # 解析货币对
        pair_match = re.match(r'([A-Z]{3})->([A-Z]{3})', args[0])
        if not pair_match:
            return "❌ 货币对格式错误，应为: NGN->USD"
        
        sell_cur, buy_cur = pair_match.groups()
        
        # 配置类型
        config_type = args[1]
        if config_type not in ["成本底价", "参考基准"]:
            return "❌ 配置类型错误，应为: 成本底价 或 参考基准"
        
        # 数据源
        provider = args[2].upper()
        if provider not in ["FW", "WISE", "PROC", "YB"]:
            return "❌ 数据源错误，不在渠道列表中"
        
        # 配置方式
        type_value = args[3]
        if type_value not in ["BY_RATIO", "BY_DIFF"]:
            return "❌ 配置方式错误，应为: BY_RATIO 或 BY_DIFF"
        
        # 汇差值
        value = args[4]
        
        # 获取汇差配置器
        if not self.forex_config:
            self.forex_config = self.manager.get_forex_configurator()
        
        # 构建配置
        config = {
            "provider": provider,
            "type": type_value,
            "value": value
        }
        
        # 这里简化处理
        if config_type == "成本底价":
            cost_config = config
            ref_configs = [{"provider": "BOC", "type": "BY_DIFF", "value": "0.0"}]
        else:
            # 对于参考基准，假设成本为默认值
            cost_config = {"provider": "WISE", "type": "BY_RATIO", "value": "-0.01"}
            ref_configs = [config]
        
        # 调用增强的PAYKKA配置接口（内部已包含重试）
        success, message = self.forex_config.configure_forex_pair(
            sell_cur, buy_cur, cost_config, ref_configs
        )
        
        if success:
            return f"✅ 汇差配置成功！\n币对: {sell_cur}->{buy_cur}\n类型: {config_type}\n数据源: {provider}\n方式: {type_value}\n值: {value}\n📢 已发送企业微信群通知"
        else:
            return f"❌ 汇差配置失败: {message}"
    
    def handle_update_routing(self, args: List[str]) -> str:
        """处理路由修改指令（增强版，支持自动重连）"""
        if len(args) < 4:
            return "❌ 参数不足，格式: 修改路由 [卖出币种] [买入币种] [策略规则] [启用/禁用]"
        
        try:
            # 使用安全执行
            return self.safe_execute(self._update_routing_impl, args)
        except Exception as e:
            return f"❌ 路由修改失败（自动重连后仍失败）: {str(e)}"
    
    def _update_routing_impl(self, args: List[str]) -> str:
        """路由修改实现（被safe_execute包装）"""
        sell_cur = args[0].upper()
        buy_cur = args[1].upper()
        strategy = args[2].upper()
        standalone = args[3] in ["启用", "enable", "enabled", "1", "true", "是", "yes"]
        
        # 获取路由配置器
        if not self.routing_config:
            self.routing_config = self.manager.get_routing_configurator()
        
        # 检查策略是否有效
        if strategy not in FX_STRATEGY_RULES:
            return f"❌ 策略规则 {strategy} 无效\n支持的规则: {', '.join(FX_STRATEGY_RULES)}"
        
        # 执行修改（使用增强版方法）
        success = self.routing_config.update_fx_pair_config(
            sell_cur, buy_cur, strategy, standalone
        )
        
        if success:
            # 发送企业微信群通知
            notification_message = f"✅路由配置更新✅\n币对: {sell_cur}->{buy_cur}\n策略: {strategy}\n独立换汇: {'启用' if standalone else '禁用'}"
            send_wechat_work_message(notification_message)
            
            return f"✅ 路由修改成功\n卖出: {sell_cur} -> 买入: {buy_cur}\n策略: {strategy}\n独立换汇: {'启用' if standalone else '禁用'}\n📢 已发送企业微信群通知"
        else:
            return f"❌ 路由修改失败"

    def _check_routing_scheduler_process(self) -> Optional[int]:
        """检查独立的路由调度进程是否在运行"""
        import subprocess
        try:
            result = subprocess.run(
                ["pgrep", "-f", "python3.*routing_scheduler_daemon\\.py"],
                capture_output=True, text=True, timeout=5
            )
            pids = [p for p in result.stdout.strip().split('\n') if p]
            return int(pids[0]) if pids else None
        except:
            return None

    def handle_start_routing_scheduler(self, args: List[str]) -> str:
        """启动路由调度器（独立守护进程）"""
        import subprocess
        existing = self._check_routing_scheduler_process()
        if existing:
            return f"⚠️ 路由调度器已在运行 (PID: {existing})"
        try:
            subprocess.Popen(
                ["python3", "/workspace/routing_scheduler_daemon.py"],
                stdout=open("/workspace/routing_scheduler_output.log", "a"),
                stderr=subprocess.STDOUT,
                cwd="/workspace",
                start_new_session=True
            )
            return "✅ 已启动路由调度器\n⏰ 将从 GitHub 读取 routing_schedule.md 配置自动执行"
        except Exception as e:
            return f"❌ 启动失败: {e}"

    def handle_stop_routing_scheduler(self, args: List[str]) -> str:
        """停止路由调度器"""
        import subprocess
        pid = self._check_routing_scheduler_process()
        if not pid:
            return "ℹ️ 路由调度器未在运行"
        try:
            subprocess.run(["kill", str(pid)], timeout=5)
            import time
            time.sleep(1)
            if not self._check_routing_scheduler_process():
                return f"🛑 路由调度器已停止 (PID: {pid})"
            else:
                subprocess.run(["kill", "-9", str(pid)], timeout=5)
                return f"🛑 路由调度器已强制停止 (PID: {pid})"
        except Exception as e:
            return f"❌ 停止失败: {e}"

    def handle_routing_scheduler_status(self, args: List[str]) -> str:
        """获取路由调度器状态（详细信息版）"""
        import subprocess, re
        from datetime import datetime

        pid = self._check_routing_scheduler_process()
        if not pid:
            return "🔴 路由调度器: 未启动\n💡 使用「启动路由调度」启动"

        # 尝试从日志中提取关键信息
        next_check = "未知"
        next_config_fetch = "未知"
        rule_count = "未知"
        enabled_count = "未知"
        token_refresh = "未知"

        try:
            with open("/workspace/logs/routing_scheduler.log", "r", encoding="utf-8") as f:
                lines = f.readlines()
            for line in reversed(lines):
                if "下次检查时间:" in line and next_check == "未知":
                    m = re.search(r"下次检查时间:\s*([\d\-]+\s+[\d:]+)", line)
                    if m:
                        next_check = m.group(1)
                if "下次读取配置时间:" in line and next_config_fetch == "未知":
                    m = re.search(r"下次读取配置时间:\s*([\d\-]+\s+[\d:]+)", line)
                    if m:
                        next_config_fetch = m.group(1)
                if "成功解析路由切换配置:" in line and rule_count == "未知":
                    m = re.search(r"成功解析路由切换配置:\s*(\d+)\s*条", line)
                    if m:
                        rule_count = m.group(1)
                if "下次Token刷新时间:" in line and token_refresh == "未知":
                    m = re.search(r"下次Token刷新时间:\s*([\d\-]+\s+[\d:]+)", line)
                    if m:
                        token_refresh = m.group(1)
        except Exception:
            pass

        # 从日志提取规则详情（避免触发登录导致崩溃）
        schedule_rules = []
        try:
            with open("/workspace/logs/routing_scheduler.log", "r", encoding="utf-8") as f:
                log_content = f.read()
            # 从日志中的调度器状态区域提取规则信息
            # 回退方案：直接从GitHub获取配置文件
            import requests
            url = "https://api.github.com/repos/13058199807zk-oss/paykka-control/contents/routing_schedule.md"
            headers = {"Authorization": "token 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", "Accept": "application/vnd.github.v3.raw"}
            resp = requests.get(url, headers=headers, timeout=10)
            if resp.status_code == 200:
                import json as _json
                md = resp.text
                # 解析 SCHEDULES JSON
                m = re.search(r'SCHEDULES\s*=\s*(\[[\s\S]*?\n\])', md)
                if m:
                    try:
                        schedules = _json.loads(m.group(1))
                        enabled_rules = [s for s in schedules if s.get("enabled", True)]
                        enabled_count = str(len(enabled_rules))
                        if rule_count == "未知":
                            rule_count = str(len(schedules))
                        for s in schedules:
                            status_icon = "🟢" if s.get("enabled", True) else "⚪"
                            days = ",".join(s.get("days", []))
                            pair = s.get("currency_pair", {})
                            pair_str = f"{pair.get('sell','')}/{pair.get('buy','')}"
                            target = s.get("target_rule", "")
                            time_str = s.get("time", "")
                            desc = s.get("description", "")
                            schedule_rules.append(f"{status_icon} {desc}\n   ⏰ {time_str} [{days}] | {pair_str} → {target}")
                    except _json.JSONDecodeError:
                        pass
        except Exception:
            pass

        result = f"""🟢 路由调度器: 运行中
🔢 进程 PID: {pid}
📋 规则总数: {rule_count} | 启用: {enabled_count}
⏰ 下次检查: {next_check}
📅 下次读取配置: {next_config_fetch}
🔐 下次Token刷新: {token_refresh}
📝 日志: /workspace/logs/routing_scheduler.log
───────────────────────"""
        if schedule_rules:
            result += "\n📊 路由规则:\n" + "\n".join(schedule_rules)
        return result

    def handle_force_reload_routing_config(self, args: List[str]) -> str:
        """重新加载路由调度配置"""
        try:
            scheduler = self.manager.get_routing_scheduler()
            result = scheduler.force_reload_config()
            return result
        except Exception as e:
            return f"❌ 强制重载路由配置失败: {e}"
    
    def handle_query_balance(self, args: List[str]) -> str:
        """处理余额查询指令（增强版）"""
        try:
            return self.safe_execute(self._query_balance_impl, args)
        except Exception as e:
            return f"❌ 余额查询失败（自动重连后仍失败）: {str(e)}"
    
    def _query_balance_impl(self, args: List[str]) -> str:
        """余额查询实现（支持指定渠道/币种）"""
        if not self.balance_query:
            self.balance_query = self.manager.get_balance_query()
        
        # 解析参数：余额查询 [渠道] [币种]
        # 渠道: YB/易宝, CC/Currencycloud, HCE/海云汇, 全部/ALL
        # 币种: USD, CNH, EUR 等（三字母）
        target_org = None  # None = 全部
        target_ccy = None  # None = 全部
        
        org_map = {"YB": "YB", "易宝": "YB", "CC": "CC", "CURRENCYCLOUD": "CC", 
                    "HCE": "HCE", "海云汇": "HCE", "全部": None, "ALL": None}
        
        for arg in args:
            upper = arg.upper().strip()
            # 检查是否是机构
            if upper in org_map:
                target_org = org_map[upper]
            elif upper in ["YB", "CC", "HCE"]:
                target_org = upper
            # 检查是否是币种（三字母）
            elif re.match(r'^[A-Z]{3}$', upper):
                target_ccy = upper
        
        if target_org:
            # 指定渠道查询
            org_name = {"YB": "易宝", "CC": "Currencycloud", "HCE": "海云汇"}.get(target_org, target_org)
            try:
                results = self.balance_query._query_institution_balance(target_org, org_name)
                if target_ccy:
                    results = [r for r in results if r["币种"].upper() == target_ccy]
                    if not results:
                        return f"ℹ️ {org_name} 未找到币种 {target_ccy} 的余额数据"
                
                if not results:
                    return f"ℹ️ {org_name} 未查询到余额数据"
                
                summary = self._format_balance_summary(results)
                return f"✅ {org_name} 余额查询成功！\n\n📊 查询结果:\n{summary}"
            except Exception as e:
                return f"❌ {org_name} 余额查询失败: {e}"
        else:
            # 全渠道查询
            success, message, results = self.balance_query.query_all_balances()
            
            if success:
                if target_ccy:
                    results = [r for r in results if r["币种"].upper() == target_ccy]
                
                summary = self._format_balance_summary(results)
                
                response = f"✅ 余额查询成功！\n\n"
                response += f"📊 查询结果汇总:\n{summary}\n"
                response += f"💾 数据已保存到: {EXCEL_FILENAME}"
                
                return response
            else:
                return f"❌ 余额查询失败: {message}"
    
    def handle_fx_statistics(self, args: List[str]) -> str:
        """处理'敞口统计'指令（增强版）"""
        try:
            return self.safe_execute(self._fx_statistics_impl, args)
        except Exception as e:
            return f"❌ 敞口统计失败（自动重连后仍失败）: {str(e)}"
    
    def _fx_statistics_impl(self, args: List[str]) -> str:
        """敞口统计实现
        默认统计范围：当日 + 上一个工作日（已交割交易）
        """
        if not self.fx_monitor:
            self.fx_monitor = self.manager.get_fx_transaction_monitor()
        
        # 解析参数
        org_code = None
        start_date = None
        end_date = None
        
        i = 0
        while i < len(args):
            if args[i] == "--org" and i + 1 < len(args):
                org_code = args[i + 1]
                i += 2
            elif args[i] == "--start" and i + 1 < len(args):
                start_date = args[i + 1]
                i += 2
            elif args[i] == "--end" and i + 1 < len(args):
                end_date = args[i + 1]
                i += 2
            else:
                # 位置参数：机构代码（如 YB, CC）
                if org_code is None and not args[i].startswith('--'):
                    org_code = args[i]
                i += 1
        
        # 如果未指定日期范围，默认：当日 + 上一个工作日
        if not start_date and not end_date:
            today = date.today()
            # 计算上一个工作日（跳过周末）
            prev_business_day = today
            while True:
                prev_business_day = prev_business_day - timedelta(days=1)
                if prev_business_day.weekday() < 5:  # 周一到周五
                    break
            start_date = prev_business_day.strftime("%Y-%m-%d")
            end_date = today.strftime("%Y-%m-%d")
        
        result = self.fx_monitor.query_fx_transactions(
            org_code=org_code,
            start_date=start_date,
            end_date=end_date
        )
        
        # 格式化返回结果
        response = self._format_fx_statistics_result(result)
        return response
    
    def handle_rate_monitoring(self, args: List[str]) -> str:
        """处理'汇率监控'指令（增强版）"""
        try:
            return self.safe_execute(self._rate_monitoring_impl, args)
        except Exception as e:
            return f"❌ 汇率监控失败（自动重连后仍失败）: {str(e)}"
    
    def _rate_monitoring_impl(self, args: List[str]) -> str:
        """汇率监控实现"""
        if not self.rate_monitor:
            self.rate_monitor = self.manager.get_rate_monitor()
        
        # 解析参数
        threshold = RATE_ALERT_THRESHOLD
        if args and len(args) > 0:
            try:
                threshold = float(args[0])
            except ValueError:
                pass
        
        # 更新阈值
        self.rate_monitor.alert_threshold = threshold
        
        result = self.rate_monitor.check_rates()
        
        response = f"🔍 汇率监控完成\n"
        response += f"📅 检查时间: {result['check_time']}\n"
        response += f"📊 监控结果:\n"
        response += f"  - PAYKKA汇率: {len(result['paykka_rates'])} 个\n"
        response += f"  - XT汇率: {len(result['xt_rates'])} 个\n"
        response += f"  - 异常货币对: {result['discrepancy_count']} 个\n"
        response += f"  - 发送报警: {len(result['alerts_sent'])} 个\n"
        response += f"⚙️ 使用阈值: {threshold}%\n"
        
        if result['discrepancies']:
            response += f"\n🚨 异常货币对详情:\n"
            for disc in result['discrepancies'][:5]:  # 只显示前5个
                response += f"  - {disc['pair']}: {disc['diff_percent']:.4f}% ({disc['direction']})\n"
            if len(result['discrepancies']) > 5:
                response += f"  ... 还有 {len(result['discrepancies']) - 5} 个异常\n"
        
        if result['uploaded_to_github']:
            response += f"\n💾 汇率报告已上传到GitHub: {GITHUB_RATE_FILE_PATH}\n"
        else:
            response += f"\n❌ 汇率报告上传到GitHub失败\n"
        
        return response

    def handle_exchange_rate_monitor(self, args: List[str]) -> str:
        """处理'路由价格监控'指令（执行一次监控）"""
        try:
            return self.safe_execute(self._exchange_rate_monitor_impl, args)
        except Exception as e:
            return f"❌ 路由价格监控失败（自动重连后仍失败）: {str(e)}"
    
    def _exchange_rate_monitor_impl(self, args: List[str]) -> str:
        """路由价格监控实现"""
        if not self.exchange_rate_monitor:
            self.exchange_rate_monitor = self.manager.get_exchange_rate_monitor()
        
        # 执行监控
        result = self.exchange_rate_monitor.run_monitoring()
        
        # 构建响应
        response = f"🔍 路由价格监控结果\n"
        response += f"📅 检查时间: {result['check_time']}\n"
        response += f"✅ 执行状态: {'成功' if result['success'] else '失败'}\n"
        response += f"📊 监控结果: {result['message']}\n"
        
        if result['rates']:
            response += self.exchange_rate_monitor.print_current_rates(result['rates'])
        
        if result.get('alert_sent', False):
            response += f"🚨 已发送企业微信告警\n"
        
        return response
    
    def handle_start_exchange_rate_monitor(self, args: List[str]) -> str:
        """处理'启动路由价格监控'指令（启动定时监控）"""
        try:
            return self.safe_execute(self._start_exchange_rate_monitor_impl, args)
        except Exception as e:
            return f"❌ 启动路由价格监控失败: {str(e)}"
    
    def _start_exchange_rate_monitor_impl(self, args: List[str]) -> str:
        """启动路由价格定时监控实现"""
        if not self.exchange_rate_monitor:
            self.exchange_rate_monitor = self.manager.get_exchange_rate_monitor()
        
        # 解析间隔参数
        interval_minutes = EXCHANGE_RATE_MONITOR_INTERVAL
        if args and len(args) > 0:
            try:
                interval_minutes = int(args[0])
                if interval_minutes < 1 or interval_minutes > 60:
                    return f"❌ 监控间隔必须在1-60分钟之间"
            except ValueError:
                return f"❌ 无效的监控间隔: {args[0]}"
        
        # 启动后台线程执行定时监控
        def monitor_thread():
            self.exchange_rate_monitor.start_scheduled_monitoring(interval_minutes)
        
        thread = threading.Thread(
            target=monitor_thread,
            daemon=True,
            name="ExchangeRateMonitor"
        )
        thread.start()
        
        return f"✅ 已启动路由价格定时监控\n" \
               f"⏰ 监控间隔: 每{interval_minutes}分钟一次\n" \
               f"🏦 监控来源: {', '.join(self.exchange_rate_monitor.target_sources)}\n" \
               f"⏳ 交易时段: 08:00-15:30 (UTC+8)\n" \
               f"📊 日志文件: {EXCHANGE_RATE_MONITOR_LOG}"
    
    def handle_exchange_rate_alert(self, args: List[str]) -> str:
        """处理'汇率告警'指令（手动检查并发送告警）"""
        try:
            return self.safe_execute(self._exchange_rate_alert_impl, args)
        except Exception as e:
            return f"❌ 汇率告警检查失败: {str(e)}"
    
    def _exchange_rate_alert_impl(self, args: List[str]) -> str:
        """汇率告警检查实现"""
        if not self.exchange_rate_monitor:
            self.exchange_rate_monitor = self.manager.get_exchange_rate_monitor()
        
        # 检查是否在交易时段内
        if not self.exchange_rate_monitor.is_trading_hours():
            return f"ℹ️ 当前不在交易时段内 (08:00-15:30 UTC+8)\n" \
                   f"汇率告警监控仅在交易时段内执行"
        
        # 查询汇率数据
        rates = self.exchange_rate_monitor.query_exchange_rates()
        if not rates:
            return f"❌ 未获取到汇率数据，无法进行告警检查"
        
        # 过滤最新数据
        filtered_rates = self.exchange_rate_monitor.filter_latest_rates_by_source(rates)
        
        # 检查是否需要告警
        alert_info = self.exchange_rate_monitor.check_rate_alert(filtered_rates)
        
        if alert_info:
            # 发送告警
            alert_sent = self.exchange_rate_monitor.send_wechat_alert(alert_info, filtered_rates)
            
            response = f"🚨 检测到汇率异常，已发送告警\n"
            response += f"📅 检查时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            response += f"📈 OCBC买入价: {alert_info['ocbc_rate']}\n"
            response += f"🔔 告警发送: {'成功' if alert_sent else '失败'}\n\n"
            
            response += "📊 异常来源详情:\n"
            for comparison in alert_info["comparisons"]:
                response += f"  - {comparison['source']}: {comparison['rate']:.4f} (高出: {comparison['difference']:.6f})\n"
            
            response += self.exchange_rate_monitor.print_current_rates(filtered_rates)
        else:
            response = f"✅ 汇率检查正常，无需发送告警\n"
            response += f"📅 检查时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            response += self.exchange_rate_monitor.print_current_rates(filtered_rates)
        
        return response
    
    def handle_exchange_rate_status(self, args: List[str]) -> str:
        """处理'路由汇率查询'指令（查看当前路由汇率）"""
        try:
            return self.safe_execute(self._exchange_rate_status_impl, args)
        except Exception as e:
            return f"❌ 路由汇率查询失败: {str(e)}"
    
    def _exchange_rate_status_impl(self, args: List[str]) -> str:
        """路由汇率查询实现"""
        if not self.exchange_rate_monitor:
            self.exchange_rate_monitor = self.manager.get_exchange_rate_monitor()
        
        # 查询汇率数据
        rates = self.exchange_rate_monitor.query_exchange_rates()
        if not rates:
            return f"❌ 未获取到汇率数据"
        
        # 过滤最新数据
        filtered_rates = self.exchange_rate_monitor.filter_latest_rates_by_source(rates)
        
        response = f"📊 最新路由汇率\n"
        response += f"📅 查询时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        response += f"💱 监控货币对: USD/CNH\n"
        response += f"🏦 监控来源: {', '.join(self.exchange_rate_monitor.target_sources)}\n"
        response += f"⏳ 交易时段状态: {'✅ 在交易时段内' if self.exchange_rate_monitor.is_trading_hours() else '❌ 不在交易时段内'}\n\n"
        
        response += "📈 实时汇率详情:\n"
        for source, data in filtered_rates.items():
            if data:
                release_time = data.get('release_time', 'N/A')
                # 格式化时间
                if release_time != 'N/A':
                    try:
                        dt = datetime.fromisoformat(release_time.replace('Z', '+00:00'))
                        release_time = dt.astimezone(self.exchange_rate_monitor.beijing_tz).strftime('%Y-%m-%d %H:%M:%S')
                    except:
                        pass
                
                response += f"  - {source}: {data.get('bid_rate', 'N/A')} (发布时间: {release_time})\n"
            else:
                response += f"  - {source}: 无数据\n"
        
        # 检查是否需要告警
        alert_info = self.exchange_rate_monitor.check_rate_alert(filtered_rates)
        if alert_info:
            response += f"\n🚨 告警状态: 检测到汇率异常\n"
            response += f"   OCBC买入价低于其他来源，建议发送告警\n"
        else:
            response += f"\n✅ 告警状态: 汇率正常\n"
        
        return response
    
    # ===================== XT 汇率查询指令 =====================
    def handle_xt_rate_query(self, args: List[str]) -> str:
        """处理'XT汇率查询'指令"""
        try:
            return self.safe_execute(self._xt_rate_query_impl, args)
        except Exception as e:
            return f"❌ XT 汇率查询失败: {str(e)}"
    
    def _xt_rate_query_impl(self, args: List[str]) -> str:
        """XT 汇率查询实现 - 支持全部查询和指定货币对查询"""
        xt = self.manager.get_xt_rate_query()
        
        # 检查/执行登录（在独立线程+独立事件循环中，避免与主事件循环冲突）
        import threading
        login_result = {"ok": False, "error": None}
        
        def _do_login():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                login_result["ok"] = loop.run_until_complete(xt.login())
            except Exception as e:
                login_result["error"] = str(e)
            finally:
                loop.close()
        
        login_thread = threading.Thread(target=_do_login, name="XTLogin")
        login_thread.start()
        login_thread.join(timeout=60)
        
        if login_thread.is_alive():
            return "❌ XT 登录超时，请稍后重试"
        
        if not login_result["ok"]:
            err_msg = login_result.get("error", "")
            if "CAPTCHA" in err_msg or "captcha" in err_msg:
                return "❌ XT 登录触发验证码验证，无法自动完成\n💡 请手动登录 XT 后导出 Cookie 到 xt_auth_cache.json"
            return f"❌ XT 平台登录失败: {err_msg or '请检查账号或手动导入 Cookie'}"
        
        # 解析参数，决定查询范围
        target_pairs = None
        
        if args and len(args) >= 2:
            # 指定货币对查询：args 格式 ['USD', 'CNY'] 或 ['USD', 'CNY', 'EUR', 'CNY']
            target_pairs = []
            i = 0
            while i + 1 < len(args):
                from_ccy = args[i].upper()
                to_ccy = args[i + 1].upper()
                target_pairs.append((from_ccy, to_ccy, f"{from_ccy}→{to_ccy}"))
                i += 2
            
            if not target_pairs:
                target_pairs = None  # 参数不足，退回全部查询
        
        if target_pairs is None:
            pairs = xt.get_currency_pairs()
        else:
            pairs = target_pairs
        
        results = xt.query_all_rates(pairs)
        return xt.format_results(results)
    
    # ===================== 友商汇率查询指令 =====================
    def handle_competitor_rate_query(self, args: List[str]) -> str:
        """处理'友商汇率查询'指令"""
        try:
            return self.safe_execute(self._competitor_rate_query_impl, args)
        except Exception as e:
            return f"❌ 友商汇率查询失败: {str(e)}"
    
    def _competitor_rate_query_impl(self, args: List[str]) -> str:
        """友商汇率查询实现 - 支持全部友商和指定友商/货币对"""
        comp = CompetitorRateQuery()
        
        # 解析参数
        target_sources = None  # None = 全部友商
        target_pairs = None    # None = 全部货币对
        
        if args:
            # 检查是否指定了友商代码
            source_codes = [a for a in args if a.upper() in COMPETITOR_CODES]
            if source_codes:
                target_sources = [s.upper() for s in source_codes]
            
            # 检查是否有货币对参数（不在友商代码中的）
            non_source = [a for a in args if a.upper() not in COMPETITOR_CODES]
            if len(non_source) >= 2:
                target_pairs = []
                i = 0
                while i + 1 < len(non_source):
                    f = non_source[i].upper()
                    t = non_source[i + 1].upper()
                    target_pairs.append((f, t, f"{f}→{t}"))
                    i += 2
        
        if target_pairs is None:
            target_pairs = COMPETITOR_CURRENCY_PAIRS
        
        all_results = comp.query_all_competitors(pairs=target_pairs, sources=target_sources)
        return comp.format_competitor_results(all_results)
    
    # ===================== 友商历史报价查询 =====================
    def _extract_history_args(self, text: str):
        """从文本中提取历史报价参数: (source, pair, days)
        
        支持格式:
        - "XT报价 NGNUSD 7D"
        - "WF报价 USDCNH 30D"  
        - "LL报价 EURCNH 14D"
        - "XT历史 USD CNY 7D"
        - "汇率走势 WF USDCNH"
        """
        text = text.strip()
        args = text.split()
        
        source = None
        pair_str = None
        days = 7  # 默认 7 天
        
        # 尝试从指令首词中识别友商
        first_word = args[0].upper() if args else ""
        for code in ["XT", "WF", "LL"]:
            if code in first_word:
                source = code
                break
        
        # 从参数中识别
        for arg in args:
            upper = arg.upper()
            if upper in ["XT", "WF", "LL"]:
                source = upper
            elif re.match(r'^[A-Za-z]{6}$', arg):
                pair_str = arg.upper()
            elif re.match(r'^\d+[DdMmYy]$', arg) or arg.upper() in CompetitorHistoryQuery.TIME_RANGE_MAP:
                days_str = arg
                hq = CompetitorHistoryQuery()
                days = hq._parse_time_range(days_str)
        
        # 如果 pair_str 还没找到，尝试相邻的两个 3 字母
        if not pair_str:
            for i, arg in enumerate(args):
                if len(arg) == 3 and arg.isalpha() and i + 1 < len(args) and len(args[i + 1]) == 3 and args[i + 1].isalpha():
                    pair_str = arg.upper() + args[i + 1].upper()
                    break
        
        # 默认值
        if not pair_str:
            pair_str = "NGNUSD"
        
        return (source, pair_str, days)
    
    def handle_history_rate_query(self, args: List[str]) -> str:
        """处理历史报价指令"""
        try:
            return self.safe_execute(self._history_rate_query_impl, args)
        except Exception as e:
            return f"❌ 历史报价查询失败: {str(e)}"
    
    def _history_rate_query_impl(self, args: List[str]) -> str:
        """历史报价查询实现"""
        hq = CompetitorHistoryQuery()
        
        # 解析参数
        source = None
        pair_str = "NGNUSD"
        days = 7
        
        # 从原始消息文本中识别友商（args 中可能不包含指令关键字）
        text = " ".join(args) if args else ""
        full_text = text  # 保留原始文本用于友商识别
        
        # 从完整文本中识别友商（支持 "XT报价"、"XT历史" 等格式）
        for code in ["XT", "WF", "LL"]:
            if code in full_text.upper():
                source = code
                break
        
        # 从 args 中再次确认友商
        if not source:
            for arg in args:
                upper = arg.upper()
                if upper in ["XT", "WF", "LL"]:
                    source = upper
                    break
        
        if not source:
            return "❌ 请指定友商 (XT/WF/LL)，格式: XT报价 NGNUSD 7D"
        
        # 解析货币对
        for arg in args:
            arg_upper = arg.upper()
            if re.match(r'^[A-Z]{6}$', arg_upper):
                pair_str = arg_upper
                break
            elif re.match(r'^[A-Z]{3}[/\- ][A-Z]{3}$', arg_upper):
                parts = re.split(r'[/\- ]', arg_upper)
                pair_str = parts[0] + parts[1]
                break
        
        # 尝试相邻的两个 3 字母参数
        if pair_str == "NGNUSD" and len(args) >= 3:
            for i, arg in enumerate(args):
                if len(arg) == 3 and arg.isalpha() and i + 1 < len(args) and len(args[i + 1]) == 3 and args[i + 1].isalpha():
                    pair_str = arg.upper() + args[i + 1].upper()
                    break
        
        # 解析时间范围
        for arg in args:
            if re.match(r'^\d+[DdMmYy]$', arg):
                days = hq._parse_time_range(arg)
                break
            elif arg.upper() in CompetitorHistoryQuery.TIME_RANGE_MAP:
                days = hq._parse_time_range(arg.upper())
                break
        
        # 解析货币对方向
        from_ccy, to_ccy = hq._parse_currency_pair(pair_str)
        if not from_ccy or not to_ccy:
            return f"❌ 无法解析货币对: {pair_str}，请使用如 NGNUSD 格式"
        
        source_name = COMPETITOR_CODES.get(source, source)
        logger.info(f"📊 查询 {source_name} 历史汇率: {from_ccy}/{to_ccy} (最近 {days} 天)")
        
        # 执行查询
        result = hq.query_history(source, from_ccy, to_ccy, days)
        
        if not result.get("success"):
            return f"❌ {source_name} {from_ccy}/{to_ccy} 历史查询失败: {result.get('error', '未知错误')}"
        
        # 生成图表
        chart_path = hq.generate_chart(result)
        
        # 格式化文本结果
        text_result = hq.format_history_result(result, chart_path)
        
        # 如果有图表，嵌入图表路径标记，由 handle_message 检测并发送
        if chart_path and os.path.exists(chart_path):
            text_result += f"\n[CHART:{chart_path}]"
        
        return text_result

    # ===================== 报价对比指令 =====================
    def handle_rate_comparison(self, args: List[str]) -> str:
        """处理'报价对比'指令 - 渠道与友商历史汇率对比"""
        try:
            return self.safe_execute(self._rate_comparison_impl, args)
        except Exception as e:
            return f"❌ 报价对比查询失败: {str(e)}"
    
    def _rate_comparison_impl(self, args: List[str]) -> str:
        """报价对比实现 - 查询渠道与友商历史汇率并生成对比图表
        
        args 格式: [pair_str, days_str, channel1, channel2, ..., competitor1, ...]
        由 _extract_comparison_args 解析生成
        """
        # 解析参数
        pair_str = "USDCNH"
        days = 3
        channels = DEFAULT_CHANNEL_SOURCES.copy()
        competitors = DEFAULT_COMPETITOR_SOURCES.copy()
        
        known_channels = {"YB", "MDAQ_FX_TOM", "BOC", "HCE_FX_TOM", "MDAQ", "PP", "OCBC", "CC"}
        known_competitors = {"XT", "WF", "LL"}
        
        parsed_channels = []
        parsed_competitors = []
        
        for i, arg in enumerate(args):
            upper = arg.upper()
            if i == 0 and len(upper) == 6 and upper.isalpha():
                pair_str = upper
            elif i == 1 and arg.isdigit():
                days = int(arg)
                if days > 30:
                    days = 30
            elif upper in known_competitors:
                if upper not in parsed_competitors:
                    parsed_competitors.append(upper)
            elif upper in known_channels:
                if upper not in parsed_channels:
                    parsed_channels.append(upper)
        
        if parsed_channels:
            channels = parsed_channels
        if parsed_competitors:
            competitors = parsed_competitors
        
        # 解析货币对
        if len(pair_str) >= 6:
            base_ccy = pair_str[:3]
            quote_ccy = pair_str[3:6]
        else:
            base_ccy, quote_ccy = "USD", "CNH"
        
        # 获取 Token
        token = self.manager._token
        if not token:
            # 尝试刷新
            self.manager._refresh_token_with_retry(max_retries=1, retry_delay=5)
            token = self.manager._token
        if not token:
            return "❌ OPS Token 未就绪，无法查询渠道数据。请稍后重试或输入'手动刷新Token'"
        
        logger.info(
            f"📊 报价对比: {base_ccy}/{quote_ccy}, {days}天, "
            f"渠道={channels}, 友商={competitors}"
        )
        
        # 执行对比
        engine = QuoteComparisonEngine(token)
        result = engine.run_comparison(
            base_currency=base_ccy,
            quote_currency=quote_ccy,
            days=days,
            channel_sources=channels,
            competitor_sources=competitors,
        )
        
        if not result.get("success"):
            return f"❌ 报价对比失败: {result.get('error', '所有来源查询失败')}\n\n{result.get('summary', '')}"
        
        # 返回文本汇总（包含 [CHART:path] 标记，由 handle_message 自动发送图片）
        return result.get("summary", "报价对比完成，但无法生成汇总")


    
    # 原有方法保持不变，为保持完整性，这里列出方法签名
    def handle_help(self, args: List[str]) -> str:
        """处理帮助指令"""
        help_text = """🤖 PAYKKA集成控制系统 - 使用说明

📋 可用指令：

🔄 汇差配置功能：
1. 配置 [卖出币种]->[买入币种] [成本/参考] [数据源] [类型] [值]
   示例: 配置 NGN->USD 成本底价 FW BY_RATIO -0.0005
   示例: 配置 NGN->USD 参考基准 FW BY_RATIO -0.005

🛣️ 路由配置功能：
1. 修改路由 [卖出币种] [买入币种] [策略规则] [启用/禁用]
   示例: 修改路由 USD CNH RULE_CC 启用
2. 查询路由 [卖出币种] [买入币种]
   示例: 查询路由 USD CNH
3. 所有路由 - 查询所有路由配置
4. 同步路由 - 同步路由配置到GitHub
5. 启动路由调度 - 启动路由定时切换任务
6. 停止路由调度 - 停止路由定时切换任务
7. 路由调度状态 - 查看路由调度器状态
8. 更新路由调度配置 - 重新加载路由调度器配置

💰 余额查询功能：
1. 余额查询 [渠道] [币种] - 查询余额（支持指定渠道/币种）
   示例: 余额查询           → 查询全部渠道
   示例: 余额查询 YB        → 查询易宝全部币种
   示例: 余额查询 CC USD    → 查询Currencycloud的USD余额
   示例: 余额查询 易宝 CNH  → 查询易宝的CNH余额
2. 余额预警 - 检查余额是否低于阈值并发送预警
3. 生成余额报告 - 生成HTML报告并发布到GitHub Pages
4. 定时余额监控 [间隔分钟数]: 启动定时余额监控任务（默认60分钟）  
5. 余额监控状态: 查看定时余额监控任务运行状态               
6. 停止余额监控: 停止正在运行的定时余额监控任务              

📊 换汇交易监控功能：
1. 敞口统计 [参数] - 查询换汇交易敞口统计
   参数: --org [机构代码] --start [开始日期] --end [结束日期]
   示例: 敞口统计 --org YB --start 2024-01-01 --end 2024-01-31
2. 交易监控 [机构] [--interval 分钟] [--stop] [--status] - 监控指定机构的换汇交易
   单次执行: 交易监控 YB
   单次执行: 交易监控 全部
   定期执行: 交易监控 YB --interval 10
   定期执行: 交易监控 全部 --interval 30
   停止任务: 交易监控 --stop
   查看状态: 交易监控 --status
3. 机构列表 - 显示支持的机构列表

💱 汇率监控功能：
1. 汇率监控 [阈值] - 检查PAYKKA与XT汇率差异
   示例: 汇率监控 0.5
2. 汇率检查 - 快速汇率检查
3. 汇率报告 - 查看最新汇率对比报告
4. 货币对列表 - 显示支持的货币对

🏦 XT汇率查询功能（新增）：
1. XT汇率查询 - 查询XT平台全部16个货币对报价
   示例: XT汇率查询
2. XT汇率查询 [货币对] - 查询指定货币对XT报价
   示例: XT汇率查询 USD CNY
   示例: XT查询 EUR CNY, GBP CNY

🌐 友商汇率查询功能（新增）：
1. 友商汇率查询 - 查询全部友商(XT/WF/LL/AW/KS/SK)全部货币对报价
   示例: 友商汇率查询
2. 友商查询 [友商代码] - 查询指定友商报价
   示例: 友商查询 XT WF
3. 友商查询 [货币对] - 查询指定货币对在所有友商的报价
   示例: 友商查询 USD CNH

📈 友商历史报价功能（新增）：
1. 历史报价 [友商] [货币对] [时间范围] - 查询友商历史汇率并生成走势图
   示例: XT报价 NGNUSD 7D
   示例: WF报价 USDCNH 30D
   示例: LL报价 EURCNH 14D
   示例: XT历史 USD CNY 7D
2. 支持友商: XT (XTransfer)、WF (WorldFirst)、LL (LianLian)
3. 时间范围: 7D(7天)、14D(14天)、30D/1M(30天)、3M(90天)、6M(180天)、1Y(365天)

📊 报价对比功能（V17 新增 - 渠道与友商历史汇率对比）：
1. 报价对比 - 默认 USD/CNH 3天，对比全部渠道(YB/MDAQ/BOC/HCE) + XT
   示例: 报价对比
2. 报价对比 [货币对] [天数] - 指定货币对和时间范围
   示例: 报价对比 USDCNH 7D
   示例: 报价对比 NGNUSD 3D
   示例: 报价对比 USD CNY 1D
3. 报价对比 [货币对] [天数] [渠道...] [友商...] - 自定义渠道和友商范围
   示例: 报价对比 USDCNH 7D YB BOC           → 仅 YB + BOC
   示例: 报价对比 EURCNH 3D XT               → 全部渠道 + 仅 XT
   示例: 报价对比 USDCNH 7D YB MDAQ XT WF    → YB + MDAQ + XT + WF
   💡 支持渠道: YB, BOC, MDAQ(MDAQ_FX_TOM), HCE(HCE_FX_TOM)
   💡 支持友商: XT, WF, LL
   💡 时间范围: 1D(1天), 3D(3天), 7D(7天)
   ⚠️ XT 仅支持 USD/CNY（在岸），与渠道 USD/CNH（离岸）存在基差

🚨 路由价格监控功能（新增）：
1. 路由价格监控 - 执行一次路由价格监控
2. 定时路由价格监控 [间隔分钟] - 启动定时监控（默认10分钟）
   示例: 启动路由价格监控 5
3. 路由汇率告警 - 手动检查并发送汇率告警
4. 路由汇率查询 - 查看当前路由汇率

⚙️ 系统功能：
1. 状态 - 查看系统状态
2. 测试 - 测试连接
3. 帮助 - 显示此帮助信息
4. Token刷新状态
5. 手动刷新Token
6. 退出

🔄 自动重连功能：
- 检测到登录超时自动刷新Token
- 网络异常自动重试（最多2次）
- Token过期自动重新登录
- 指令执行失败自动恢复
"""
        return help_text
    
    def handle_query_routing(self, args: List[str]) -> str:
        """处理路由查询指令"""
        if len(args) < 2:
            return "❌ 参数不足，格式: 查询路由 [卖出币种] [买入币种]"
        
        sell_cur = args[0].upper()
        buy_cur = args[1].upper()
        
        # 获取路由配置器
        if not self.routing_config:
            self.routing_config = self.manager.get_routing_configurator()
        
        config = self.routing_config.query_fx_pair_config(sell_cur, buy_cur)
        
        if config:
            return f"""🔍 路由配置详情
卖出币种: {config['sell_cur']}
买入币种: {config['buy_cur']}
策略规则: {config['fx_strategy_rule']}
独立换汇: {config['standalone_fx']}
状态: {config['status']}
最后修改: {config['update_time']}"""
        else:
            return f"ℹ️ 未找到 {sell_cur}->{buy_cur} 的路由配置"
    
    def handle_query_all_routing(self, args: List[str]) -> str:
        """查询所有路由"""
        # 获取路由配置器
        if not self.routing_config:
            self.routing_config = self.manager.get_routing_configurator()
        
        all_configs = self.routing_config.query_all_fx_pair_configs()
        
        if not all_configs:
            return "ℹ️ 未找到任何路由配置"
        
        # 按币种分组统计
        currency_stats = {}
        for config in all_configs:
            pair = f"{config['sell_cur']}->{config['buy_cur']}"
            if pair not in currency_stats:
                currency_stats[pair] = 0
            currency_stats[pair] += 1
        
        stats_text = "📊 路由配置统计\n"
        stats_text += f"总配置数: {len(all_configs)}\n"
        stats_text += f"货币对数: {len(currency_stats)}\n\n"
        
        # 显示前10个配置
        stats_text += "最近配置示例:\n"
        for i, config in enumerate(all_configs[:10], 1):
            stats_text += f"{i}. {config['sell_cur']}->{config['buy_cur']}: {config['fx_strategy_rule']} ({config['status']})\n"
        
        if len(all_configs) > 10:
            stats_text += f"\n... 还有 {len(all_configs) - 10} 个配置未显示"
        
        return stats_text
    
    def handle_sync_to_github(self, args: List[str]) -> str:
        """同步配置到GitHub"""
        try:
            # 获取路由配置器
            if not self.routing_config:
                self.routing_config = self.manager.get_routing_configurator()
            
            all_configs = self.routing_config.query_all_fx_pair_configs()
            
            if not all_configs:
                return "ℹ️ 未找到任何路由配置，跳过同步"
            
            # 生成Markdown内容
            update_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            md_content = f"""# 换汇路由配置表
> 最后更新时间：{update_time}
> 总配置数：{len(all_configs)}

| 卖出币种 | 买入币种 | 换汇策略规则 | 独立换汇状态 | 配置状态 | 最后修改时间 |
|----------|----------|--------------|--------------|----------|--------------|
"""
            for config in all_configs:
                md_content += (
                    f"| {config['sell_cur']} | {config['buy_cur']} | {config['fx_strategy_rule']} | "
                    f"{config['standalone_fx']} | {config['status']} | {config['update_time']} |\n"
                )
            md_content += f"\n> 配置规则说明：{', '.join(FX_STRATEGY_RULES)}"
            
            # 更新到GitHub
            g = Github(GITHUB_TOKEN)
            repo = g.get_repo(GITHUB_REPO_NAME)
            author = InputGitAuthor(GITHUB_USERNAME, GITHUB_EMAIL)
            
            try:
                contents = repo.get_contents(GITHUB_FILE_PATH)
                repo.update_file(
                    path=GITHUB_FILE_PATH,
                    message=f"飞书机器人自动同步 {update_time}",
                    content=md_content,
                    sha=contents.sha,
                    author=author
                )
            except GithubException as e:
                if e.status == 404:
                    # 文件不存在，创建新文件
                    repo.create_file(
                        path=GITHUB_FILE_PATH,
                        message=f"飞书机器人初始化同步 {update_time}",
                        content=md_content,
                        author=author
                    )
                else:
                    raise
            
            return f"✅ 路由配置已同步到GitHub\n文件: {GITHUB_FILE_PATH}\n记录数: {len(all_configs)}\n时间: {update_time}"
            
        except Exception as e:
            return f"❌ 同步到GitHub时出错: {str(e)}"
    
    def handle_check_balance_alert(self, args: List[str]) -> str:
        """处理余额预警指令"""
        if not self.balance_query:
            self.balance_query = self.manager.get_balance_query()
        
        # 先查询余额
        success, query_msg, results = self.balance_query.query_all_balances()
        if not success:
            return f"❌ 无法执行预警检查，因为查询失败: {query_msg}"
        
        # 检查预警
        alert_success, alert_msg = self.balance_query.check_balance_alert(results)
        
        response = f"✅ 余额查询完成\n"
        response += f"📊 查询到 {len(results)} 条记录\n"
        response += f"🔔 预警检查结果: {alert_msg}"
        
        return response
    
    def handle_generate_balance_report(self, args: List[str]) -> str:
        """处理生成余额报告指令"""
        if not self.balance_query:
            self.balance_query = self.manager.get_balance_query()
        
        # 先查询余额
        success, query_msg, results = self.balance_query.query_all_balances()
        if not success:
            return f"❌ 无法生成报告，因为查询失败: {query_msg}"
        
        # 生成并上传报告
        report_success, report_msg = self.balance_query.generate_balance_report(results)
        
        if report_success:
            return f"✅ 余额报告生成成功！\n{report_msg}"
        else:
            return f"❌ 余额报告生成失败: {report_msg}"
    
    def _format_balance_summary(self, results: List[Dict]) -> str:
        """格式化余额查询结果为字符串"""
        if not results:
            return "无余额数据"
        
        summary = {}
        for record in results:
            channel = record["渠道名"]
            currency = record["币种"]
            balance = record["余额"]
            if channel not in summary:
                summary[channel] = {}
            summary[channel][currency] = balance
        
        formatted = ""
        for channel, currencies in summary.items():
            formatted += f"【{channel}】\n"
            for currency, balance in currencies.items():
                formatted += f"  {currency}: {balance}\n"
        
        return formatted

    def _check_balance_monitor_process(self) -> Optional[int]:
        """检查独立的余额监控进程是否在运行，返回 PID 或 None"""
        import subprocess
        try:
            result = subprocess.run(
                ["pgrep", "-f", "python3.*balance_monitor\\.py"],
                capture_output=True, text=True, timeout=5
            )
            pids = [p for p in result.stdout.strip().split('\n') if p]
            return int(pids[0]) if pids else None
        except:
            return None
    
    def handle_balance_monitoring(self, args: list) -> str:
        """
        处理"定时余额监控"指令（管理独立守护进程）。
        格式: 定时余额监控 [间隔分钟数]
        """
        import subprocess, os
        
        interval_minutes = 60
        if args:
            try:
                interval_minutes = int(args[0])
                if interval_minutes <= 0:
                    return "❌ 间隔分钟数必须为正整数。"
            except ValueError:
                return f"❌ 无法解析间隔参数: '{args[0]}'"
        
        # 检查是否已有进程在运行
        existing_pid = self._check_balance_monitor_process()
        if existing_pid:
            return f"⚠️ 余额监控已在运行 (PID: {existing_pid})。请先执行「停止余额监控」"
        
        # 启动独立进程
        try:
            subprocess.Popen(
                ["python3", "/workspace/balance_monitor.py", str(interval_minutes)],
                stdout=open("/workspace/balance_monitor_output.log", "a"),
                stderr=subprocess.STDOUT,
                cwd="/workspace",
                start_new_session=True
            )
            return f"✅ 已启动余额监控定时任务\n⏰ 执行间隔: 每 {interval_minutes} 分钟\n📊 监控内容: 机构余额查询 + 阈值预警 + 报告生成"
        except Exception as e:
            return f"❌ 启动失败: {e}"

    def handle_balance_monitoring_status(self, args: list) -> str:
        """
        处理"余额监控状态"指令（详细信息版）。
        """
        import subprocess, re
        from datetime import datetime, timedelta

        pid = self._check_balance_monitor_process()
        if not pid:
            return "🔴 余额监控定时任务: 未启动\n💡 使用「定时余额监控 60」启动"

        # 尝试从日志和进程参数中提取信息
        interval = "60"
        last_query = "未知"
        record_count = "未知"
        next_query = "未知"
        github_updated = "未知"

        # 从进程命令行获取间隔参数
        try:
            result = subprocess.run(
                ["ps", "-p", str(pid), "-o", "args="],
                capture_output=True, text=True, timeout=5
            )
            cmd = result.stdout.strip()
            parts = cmd.split()
            if len(parts) >= 2:
                interval = parts[-1] if parts[-1].isdigit() else "60"
        except Exception:
            pass

        # 从日志提取信息
        try:
            with open("/workspace/logs/balance_monitor.log", "r", encoding="utf-8") as f:
                lines = f.readlines()
            for line in reversed(lines):
                if "✅" in line and "条记录" in line and record_count == "未知":
                    m = re.search(r"✅\s*(\d+)\s*条记录", line)
                    if m:
                        record_count = m.group(1)
                        # 记录时间从日志前缀提取
                        m2 = re.match(r"(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})", line)
                        if m2:
                            last_query = m2.group(1)
                if "📤 GitHub Pages 已更新" in line and github_updated == "未知":
                    m = re.match(r"(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})", line)
                    if m:
                        github_updated = m.group(1)
                if "🟢 余额监控启动，间隔:" in line:
                    m = re.search(r"间隔:\s*(\d+)", line)
                    if m:
                        interval = m.group(1)
        except Exception:
            pass

        # 计算下次查询时间
        if last_query != "未知":
            try:
                last_dt = datetime.strptime(last_query, "%Y-%m-%d %H:%M:%S")
                next_dt = last_dt + timedelta(minutes=int(interval))
                next_query = next_dt.strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                pass

        # 获取阈值配置（从GitHub读取，避免import balance_monitor触发登录）
        threshold_info = ""
        try:
            import requests as _req
            url = "https://api.github.com/repos/13058199807zk-oss/Paykka-K/contents/balance_threshold.md"
            headers = {"Authorization": "token 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", "Accept": "application/vnd.github.v3.raw"}
            resp = _req.get(url, headers=headers, timeout=10)
            if resp.status_code == 200:
                md = resp.text
                threshold_lines = []
                for m in re.finditer(r'\(["\'](.+?)["\'],\s*["\'](.+?)["\']\)\s*:\s*([\d.]+)', md):
                    org = m.group(1)
                    ccy = m.group(2)
                    val = float(m.group(3))
                    threshold_lines.append(f"   • {org} {ccy}: {val:,.2f}")
                if threshold_lines:
                    threshold_info = "\n🚨 预警阈值:\n" + "\n".join(threshold_lines)
        except Exception:
            pass

        return f"""🟢 余额监控定时任务: 运行中
🔢 进程 PID: {pid}
⏰ 执行间隔: 每 {interval} 分钟
📅 上次查询: {last_query}
📊 记录数: {record_count}
📤 GitHub更新: {github_updated}
⏳ 下次查询: {next_query}
📝 日志: /workspace/logs/balance_monitor.log{threshold_info}"""

    def handle_stop_balance_monitoring(self, args: list) -> str:
        """
        处理"停止余额监控"指令。
        """
        import subprocess
        pid = self._check_balance_monitor_process()
        if not pid:
            return "ℹ️ 余额监控定时任务未在运行。"
        
        try:
            subprocess.run(["kill", str(pid)], timeout=5)
            import time
            time.sleep(1)
            if not self._check_balance_monitor_process():
                return f"🛑 余额监控已停止 (PID: {pid})"
            else:
                subprocess.run(["kill", "-9", str(pid)], timeout=5)
                return f"🛑 余额监控已强制停止 (PID: {pid})"
        except Exception as e:
            return f"❌ 停止失败: {e}"
    
    def handle_fx_monitoring(self, args: List[str]) -> str:
        """处理'交易监控'指令 - 同时支持单次执行和定期执行模式"""
        try:
            return self.safe_execute(self._fx_monitoring_impl, args)
        except Exception as e:
            return f"❌ 交易监控失败: {str(e)}"
    
    def _fx_monitoring_impl(self, args: List[str]) -> str:
        """交易监控指令实现 - 支持多种执行模式"""
        # 解析参数
        org_code = None
        interval = None
        stop_task = False
        show_status = False
        
        i = 0
        while i < len(args):
            if args[i] == "--interval" and i + 1 < len(args):
                try:
                    interval = int(args[i + 1])
                    if interval < 1 or interval > 1440:
                        return "❌ 执行间隔需在 1 到 1440 分钟之间。"
                    i += 2
                except ValueError:
                    return f"❌ 无效的时间间隔参数: {args[i+1]}"
            elif args[i] == "--stop":
                stop_task = True
                i += 1
            elif args[i] == "--status":
                show_status = True
                i += 1
            else:
                # 机构参数
                if org_code is None and not stop_task and not show_status:
                    org_param = args[i].upper()
                    if org_param == "全部":
                        org_code = None
                    elif org_param in ORG_LIST:
                        org_code = org_param
                    else:
                        return f"❌ 不支持的机构代码: {org_param}\n支持的机构: {', '.join(ORG_LIST)}"
                i += 1
        
        # 处理不同的执行模式
        if stop_task:
            return self._stop_fx_monitoring_task()
        elif show_status:
            return self._get_fx_monitoring_task_status()
        elif interval is not None:
            return self._start_fx_monitoring_task(org_code, interval)
        else:
            return self._execute_single_fx_monitoring(org_code)
    
    def _execute_single_fx_monitoring(self, org_code: Optional[str]) -> str:
        """执行单次交易监控"""
        if not self.fx_monitor:
            self.fx_monitor = self.manager.get_fx_transaction_monitor()
        
        result = self.fx_monitor.query_fx_transactions(
            org_code=org_code,
            merchant_status=DEFAULT_MERCHANT_STATUS,
            org_status=DEFAULT_ORG_STATUS
        )
        
        return self._format_fx_monitoring_result(result, org_code)
    
    def _start_fx_monitoring_task(self, org_code: Optional[str], interval: int) -> str:
        """启动定期交易监控任务 - 使用全局实例"""

        # 从管理器获取全局任务实例
        fx_monitoring_task = self.manager.get_fx_monitoring_task()
        
        if not fx_monitoring_task:
            # 创建新任务
            fx_monitoring_task = FxMonitoringScheduledTask(self.manager, interval)

            self.manager.set_fx_monitoring_task(fx_monitoring_task)

        elif fx_monitoring_task.is_running:
            org_display = fx_monitoring_task.org_code or "全部"
            return f"⚠️ 交易监控定时任务已在运行中，当前监控机构: {org_display}"
        else:
            # 如果任务存在但已停止，更新配置
            fx_monitoring_task.interval_minutes = interval
        
        # 设置机构代码
        fx_monitoring_task.set_org_code(org_code)
        
        # 启动任务
        return fx_monitoring_task.start()
    
    def _stop_fx_monitoring_task(self) -> str:
        """停止定期交易监控任务 - 使用全局实例"""
        fx_monitoring_task = self.manager.get_fx_monitoring_task()
        if not fx_monitoring_task:
            return "ℹ️ 交易监控定时任务未初始化。"
        return fx_monitoring_task.stop()
    
    def _get_fx_monitoring_task_status(self) -> str:
        """获取定期交易监控任务状态 - 使用全局实例"""
        fx_monitoring_task = self.manager.get_fx_monitoring_task()
        if not fx_monitoring_task:
            return "ℹ️ 交易监控定时任务未初始化。"
        return fx_monitoring_task.status()
    
    def _format_fx_monitoring_result(self, result: Dict, org_code: Optional[str]) -> str:
        """格式化交易监控结果 - 参照敞口统计的详细格式"""
        org_display = org_code or "全部机构"
        
        # 构建详细的返回信息
        response = "🔍 交易监控结果详情\n"
        response += "=" * 50 + "\n"
        
        # 1. 基本信息
        response += f"📅 查询时间: {result.get('query_time', '未知')}\n"
        response += f"🏦 监控机构: {org_display}\n"
        response += f"📅 时间范围: {result.get('start_date', '未知')} 至 {result.get('end_date', '未知')}\n"
        response += f"📊 总交易笔数: {result.get('total_count', 0)}\n"
        response += "-" * 50 + "\n\n"
        
        settlement_stats = result.get('settlement_stats', {})
        
        if not settlement_stats:
            response += "ℹ️ 未发现未来交割的换汇交易\n"
            return response
        
        # 2. 详细统计表格
        response += "📈 详细交割敞口统计:\n\n"
        
        # 先按交割日期排序
        sorted_dates = sorted(settlement_stats.keys())
        
        for settle_date in sorted_dates:
            currency_pairs = settlement_stats[settle_date]
            
            response += f"📅 交割日: {settle_date}\n"
            response += "-" * 40 + "\n"
            
            # 表头
            response += f"{'货币对':<12} {'卖出金额':<15} {'买入金额':<15} {'交易笔数':<10}\n"
            response += f"{'-'*12:<12} {'-'*15:<15} {'-'*15:<15} {'-'*10:<10}\n"
            
            # 按货币对排序
            sorted_pairs = sorted(currency_pairs.keys())
            
            for currency_pair in sorted_pairs:
                stats = currency_pairs[currency_pair]
                total_sell = stats.get('total_sell', 0)
                total_buy = stats.get('total_buy', 0)
                count = stats.get('count', 0)
                
                response += f"{currency_pair:<12} {total_sell:>15,.2f} {total_buy:>15,.2f} {count:>10}\n"
            
            # 当日合计
            date_total_sell = sum(pair_stats.get('total_sell', 0) for pair_stats in currency_pairs.values())
            date_total_buy = sum(pair_stats.get('total_buy', 0) for pair_stats in currency_pairs.values())
            date_total_count = sum(pair_stats.get('count', 0) for pair_stats in currency_pairs.values())
            
            response += f"{'-'*12:<12} {'-'*15:<15} {'-'*15:<15} {'-'*10:<10}\n"
            response += f"{'小计':<12} {date_total_sell:>15,.2f} {date_total_buy:>15,.2f} {date_total_count:>10}\n\n"
        
        # 3. 汇总统计
        response += "📊 总体统计摘要:\n"
        response += "-" * 40 + "\n"
        
        # 计算总体统计
        all_pairs = []
        for date_pairs in settlement_stats.values():
            all_pairs.extend(date_pairs.keys())
        
        unique_currency_pairs = set(all_pairs)
        total_transactions = result.get('total_count', 0)
        date_count = len(settlement_stats)
        
        # 计算总卖出/买入金额
        total_sell_amount = 0.0
        total_buy_amount = 0.0
        for date_stats in settlement_stats.values():
            for pair_stats in date_stats.values():
                total_sell_amount += pair_stats.get('total_sell', 0)
                total_buy_amount += pair_stats.get('total_buy', 0)
        
        response += f"🔢 交割日数量: {date_count}\n"
        response += f"💱 货币对数量: {len(unique_currency_pairs)}\n"
        response += f"📄 总交易笔数: {total_transactions}\n"
        response += f"💰 总卖出金额: {total_sell_amount:,.2f}\n"
        response += f"💰 总买入金额: {total_buy_amount:,.2f}\n\n"
        
        # 4. 告警信息
        alerts_sent = result.get('alerts_sent', [])
        if alerts_sent:
            response += "🚨 告警详情:\n"
            response += "-" * 40 + "\n"
            
            for i, alert in enumerate(alerts_sent, 1):
                currency_pair = alert.get('currency_pair', 'N/A')
                settle_date = alert.get('settle_date', 'N/A')
                threshold = alert.get('threshold', 'N/A')
                actual_sell = alert.get('actual_sell', 'N/A')
                excess_amount = alert.get('excess_amount', 'N/A')
                count = alert.get('count', 0)
                
                response += f"告警 #{i}:\n"
                response += f"  • 货币对: {currency_pair}\n"
                response += f"  • 交割日: {settle_date}\n"
                response += f"  • 阈值: {threshold}\n"
                response += f"  • 实际卖出: {actual_sell}\n"
                response += f"  • 超限额: {excess_amount}\n"
                response += f"  • 交易笔数: {count}\n"
                
                if i < len(alerts_sent):
                    response += "  " + "-" * 30 + "\n"
            
            response += f"\n📢 共触发 {len(alerts_sent)} 条告警\n\n"
        
        # 5. 配置信息
        used_config = result.get('used_config', {})
        if used_config:
            response += "⚙️ 监控配置信息:\n"
            response += "-" * 40 + "\n"
            
            alert_thresholds = used_config.get('ALERT_THRESHOLDS', {})
            if alert_thresholds:
                response += "告警阈值配置:\n"
                for pair, threshold in alert_thresholds.items():
                    response += f"  • {pair}: {threshold:,.2f}\n"
                response += "\n"

            # 新增：显示处理中交易阈值
            processing_thresholds = used_config.get('PROCESSING_ALERT_THRESHOLDS', {})
            if processing_thresholds:
                response += "⏳ 处理中交易告警阈值:\n"
                for pair, threshold in processing_thresholds.items():
                    response += f"  • {pair}: {threshold:,.2f}\n"
                response += "\n"
            
            enable_alert = used_config.get('ENABLE_WECHAT_ALERT', True)
            response += f"微信告警开关: {'开启' if enable_alert else '关闭'}\n"
        
        response += "=" * 50 + "\n"
        response += "✅ 交易监控完成"
        
        return response
    
    def handle_org_list(self, args: List[str]) -> str:
        """处理'机构列表'指令"""
        if not self.fx_monitor:
            self.fx_monitor = self.manager.get_fx_transaction_monitor()
        
        response = "🏦 支持的机构列表:\n"
        for i, org in enumerate(self.fx_monitor.org_list, 1):
            response += f"{i}. {org}\n"
        response += "\n📌 使用示例:"
        response += "\n  敞口统计 --org YB --start 2024-01-01 --end 2024-01-31"
        response += "\n  交易监控 YB  (监控易宝机构的交易)"
        response += "\n  交易监控 全部  (监控所有机构)"
        
        return response
    
    def _format_fx_statistics_result(self, result: Dict) -> str:
        """格式化换汇统计结果为字符串（完整版：已交割敞口 + 处理中交易 + 配置信息）"""
        response = f"📊 换汇交易敞口统计结果\n"
        response += f"📅 统计范围: {result['start_date']} 至 {result['end_date']}\n"
        response += f"⏰ 查询时间: {result['query_time']}\n"
        response += f"📈 总交易笔数: {result['total_count']} 笔\n"

        used_config = result.get('used_config', {})
        alert_thresholds = used_config.get('ALERT_THRESHOLDS', {})
        processing_thresholds = used_config.get('PROCESSING_ALERT_THRESHOLDS', {})
        
        # 超限告警汇总（包含已交割和处理中的告警）
        alerts_sent = result.get('alerts_sent', [])
        if alerts_sent:
            response += f"\n🚨 超限告警 ({len(alerts_sent)} 条):\n"
            for alert in alerts_sent:
                settle_label = alert['settle_date'] if alert['settle_date'] != 'PROCESSING' else 'PROCESSING'
                response += f"  • {settle_label} {alert['currency_pair']}: "
                response += f"{alert['actual_sell']} > 阈值 {alert['threshold']} (超限 {alert['excess_amount']})\n"
        
        # 已交割交易统计（按交割日期）
        settlement_stats = result.get('settlement_stats', {})
        processing_stats = result.get('processing_stats', {})
        
        if settlement_stats or processing_stats:
            response += f"\n📋 交易统计 (按交割日期):\n"
        
        if settlement_stats:
            for settle_date in sorted(result['settlement_stats'].keys()):
                currency_pairs = result['settlement_stats'][settle_date]
                response += f"\n📅 交割日期: {settle_date}\n"
                
                for pair in sorted(currency_pairs.keys()):
                    stats = currency_pairs[pair]
                    sell_curr, buy_curr = pair.split('/')
                    
                    threshold = alert_thresholds.get(pair, 0)
                    alert_mark = " 🚨" if stats['total_sell'] > threshold else ""
                    
                    response += f"  {pair}{alert_mark}:\n"
                    response += f"    交易笔数: {stats['count']} 笔\n"
                    response += f"    总卖出金额: {self.fx_monitor._format_number(stats['total_sell'])} {sell_curr}\n"
                    response += f"    总买入金额: {self.fx_monitor._format_number(stats['total_buy'])} {buy_curr}\n"
                    if pair in alert_thresholds:
                        response += f"    预警阈值: {self.fx_monitor._format_number(threshold)} {sell_curr}\n"
        
        # 处理中交易统计（按货币对）
        if processing_stats:
            response += f"\n⏳ 处理中交易统计 (按货币对):\n"
            for pair in sorted(processing_stats.keys()):
                stats = processing_stats[pair]
                sell_curr, buy_curr = pair.split('/')
                
                threshold = processing_thresholds.get(pair, 0)
                alert_mark = " 🚨" if stats['total_sell'] > threshold else ""
                
                response += f"  {pair}{alert_mark}:\n"
                response += f"    交易笔数: {stats['count']} 笔\n"
                response += f"    总卖出金额: {self.fx_monitor._format_number(stats['total_sell'])} {sell_curr}\n"
                response += f"    总买入金额: {self.fx_monitor._format_number(stats['total_buy'])} {buy_curr}\n"
                if pair in processing_thresholds:
                    response += f"    预警阈值: {self.fx_monitor._format_number(threshold)} {sell_curr}\n"
        
        # 配置信息
        trading_hours = used_config.get('TRADING_HOURS', {})
        wechat_enabled = used_config.get('ENABLE_WECHAT_ALERT', False)
        response += f"\n⚙️ 使用配置:\n"
        response += f"  预警阈值: {len(alert_thresholds)} 个货币对\n"
        response += f"  处理中交易阈值: {len(processing_thresholds)} 个货币对\n"
        response += f"  交易时段配置: {len(trading_hours)} 个机构\n"
        response += f"  企业微信告警: {'开启' if wechat_enabled else '关闭'}\n"
        
        return response
    
    def handle_rate_check(self, args: List[str]) -> str:
        """处理'汇率检查'指令（简化版）"""
        if not self.rate_monitor:
            self.rate_monitor = self.manager.get_rate_monitor()
        
        result = self.rate_monitor.check_rates()
        
        # 生成简洁报告
        if result['discrepancies']:
            response = f"⚠️ 汇率检查发现 {len(result['discrepancies'])} 个异常:\n"
            for disc in result['discrepancies']:
                response += f"  {disc['pair']}: PAYKKA={disc['paykka_rate']:.6f}, XT={disc['xt_rate']:.6f}, 差{disc['diff_percent']:.4f}% ({disc['direction']})\n"
        else:
            response = f"✅ 汇率检查正常，未发现异常\n"
        
        response += f"📅 检查时间: {result['check_time']}\n"
        response += f"📊 共查询: {len(result['paykka_rates'])} 个PAYKKA汇率, {len(result['xt_rates'])} 个XT汇率"
        
        return response
    
    def handle_rate_report(self, args: List[str]) -> str:
        """处理'汇率报告'指令（支持 --force 强制重新检查）"""
        if not self.rate_monitor:
            self.rate_monitor = self.manager.get_rate_monitor()
        
        # 检查是否有 --force 参数
        force_check = "--force" in args or "-f" in args
        
        # 如果没有最近检查，或者强制重新检查，则执行一次检查
        if not self.rate_monitor.last_check_time or force_check:
            result = self.rate_monitor.check_rates()
        else:
            # 返回最近一次检查的结果摘要
            return f"ℹ️ 最近一次汇率检查: {self.rate_monitor.last_check_time.strftime('%Y-%m-%d %H:%M:%S')}\n查看完整报告: https://github.com/{GITHUB_REPO_NAME}/blob/main/{GITHUB_RATE_FILE_PATH}\n💡 使用 '汇率报告 --force' 可强制重新检查"
        
        # 返回报告摘要
        if result['uploaded_to_github']:
            return f"✅ 汇率报告已生成并上传到GitHub\n📅 检查时间: {result['check_time']}\n📊 发现异常: {result['discrepancy_count']} 个\n🌐 完整报告: https://github.com/{GITHUB_REPO_NAME}/blob/main/{GITHUB_RATE_FILE_PATH}"
        else:
            return f"❌ 汇率报告生成失败，请检查网络连接和GitHub权限"
    
    def handle_currency_pairs(self, args: List[str]) -> str:
        """处理'货币对列表'指令"""
        response = "💱 支持的货币对列表:\n"
        for i, (from_curr, to_curr, description) in enumerate(CURRENCY_PAIRS, 1):
            response += f"{i}. {from_curr}→{to_curr} ({description})\n"
        response += "\n📌 使用示例:"
        response += "\n  汇率监控 0.5  (使用0.5%的阈值检查)"
        response += "\n  汇率检查  (快速检查汇率差异)"
        
        return response
    
    def handle_status(self, args: List[str]) -> str:
        """处理状态指令"""
        manager = self.manager
        
        status = f"""
🤖 集成控制系统状态：
- 全局登录状态: {'✅ 已登录' if manager._token else '❌ 未登录'}
- Token状态: {len(manager._token) if manager._token else 0} 字符
- 最后登录时间: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(manager._last_login_time)) if manager._last_login_time else '从未登录'}
- 汇差配置器: {'✅ 已初始化' if self.forex_config else '❌ 未初始化'}
- 路由配置器: {'✅ 已初始化' if self.routing_config else '❌ 未初始化'}
- 余额查询器: {'✅ 已初始化' if self.balance_query else '❌ 未初始化'}
- 交易监控器: {'✅ 已初始化' if self.fx_monitor else '❌ 未初始化'}
- 汇率监控器: {'✅ 已初始化' if self.rate_monitor else '❌ 未初始化'}
- XT汇率查询: {'✅ 已认证' if manager.get_xt_rate_query()._is_auth_valid() else '❌ 未认证'}
- 已处理消息: {len(manager.get_deduplicator().processed_messages)} 个
- 运行模式: 自动登录+混合模式
- 支持机构: {len(ORG_LIST)} 个
- 监控货币对: {len(CURRENCY_PAIRS)} 个
- 自动重连: ✅ 已启用
"""
        return status
    
    def handle_test(self, args: List[str]) -> str:
        """处理测试指令"""
        return "✅ 集成控制系统运行正常！"
    
    def process(self, text: str) -> str:
        """处理用户输入（智能匹配版，带异常保护）"""
        try:
            parsed = self.parse_command(text)
            command = parsed["command"]
            args = parsed["args"]
            
            if not command:
                return "❓ 未能识别指令，输入'帮助'查看可用指令"
            
            # 先在原有精确字典中查找
            for cmd_key, handler in self.commands.items():
                if cmd_key.lower() == command.lower():
                    try:
                        return handler(args)
                    except Exception as e:
                        logger.error(f"❌ 指令 [{command}] 执行异常: {e}", exc_info=True)
                        return f"❌ 指令执行失败: {str(e)[:200]}\n💡 系统已自动恢复，可重试或输入'帮助'查看"
            
            # 如果精确匹配失败，重新做一次模糊匹配获取得分
            _, _, score = self._fuzzy_match_command(text)
            
            if score >= 80:
                return f"⚠️ 识别到指令意图但执行失败，请用更明确的指令重试\n💡 输入'帮助'查看可用指令"
            
            return f"❌ 未识别指令: \"{text}\"\n💡 输入'帮助'查看可用指令列表"
        except Exception as e:
            logger.error(f"❌ process() 顶层异常: {e}", exc_info=True)
            return f"❌ 系统处理异常，已自动恢复: {str(e)[:200]}"

# ===================== 飞书机器人处理器 =====================
class LarkBotHandler:
    """飞书机器人消息处理器"""
    
    def __init__(self, command_processor: IntegratedCommandProcessor):
        self.processor = command_processor
    
    def handle_message(self, data: lark.im.v1.P2ImMessageReceiveV1) -> None:
        """处理飞书消息事件（带去重检查 + 异常保护）"""
        message_id = "unknown"
        chat_id = "unknown"
        
        try:
            message = data.event.message
            message_id = message.message_id
            chat_id = message.chat_id
            
            # 检查消息是否已经处理过（防止重复执行）
            try:
                dedup = self.processor.manager.get_deduplicator()
                if dedup.is_processed(message_id):
                    logger.info(f"⏭️  消息 {message_id} 已处理过，跳过")
                    return
            except Exception as dedup_err:
                logger.warning(f"去重检查异常（继续处理）: {dedup_err}")
            
            content = json.loads(message.content)
            text = content.get("text", "").strip()
            
            logger.info(f"📩 收到飞书消息: {text}")
            
            # 处理指令（process 内部已有异常保护）
            reply_text = self.processor.process(text)
            
            # 检查是否包含图表路径标记（格式: [CHART:path]）
            chart_path = None
            chart_marker = "[CHART:"
            if chart_marker in reply_text:
                idx = reply_text.index(chart_marker)
                end_idx = reply_text.index("]", idx)
                chart_path = reply_text[idx + len(chart_marker):end_idx]
                reply_text = reply_text[:idx] + reply_text[end_idx + 1:]
                reply_text = reply_text.strip()
            
            # 回复消息
            try:
                self.reply_message(chat_id, message_id, reply_text)
            except Exception as reply_err:
                logger.error(f"❌ 回复消息失败: {reply_err}")
            
            # 如果有图表，发送图片
            if chart_path and os.path.exists(chart_path):
                try:
                    self.reply_image(chat_id, message_id, chart_path)
                except Exception as img_err:
                    logger.error(f"❌ 发送图片失败: {img_err}")
            
            # 标记消息为已处理
            try:
                dedup.mark_as_processed(message_id)
            except Exception as mark_err:
                logger.warning(f"标记已处理异常: {mark_err}")
            
        except Exception as e:
            logger.error(f"❌ 处理飞书消息失败: {e}")
            try:
                self.reply_message(chat_id, message_id, f"❌ 处理消息时发生错误: {str(e)}")
            except:
                pass
    
    def reply_message(self, chat_id: str, message_id: str, text: str) -> None:
        """回复飞书消息"""
        try:
            # 创建客户端
            client = lark.Client.builder() \
                .app_id(LARK_APP_ID) \
                .app_secret(LARK_APP_SECRET) \
                .log_level(lark.LogLevel.INFO) \
                .build()
            
            # 创建回复内容
            content = json.dumps({"text": text}, ensure_ascii=False)
            
            # 发送回复
            request = CreateMessageRequest.builder() \
                .receive_id_type("chat_id") \
                .request_body(CreateMessageRequestBody.builder()
                    .receive_id(chat_id)
                    .msg_type("text")
                    .content(content)
                    .uuid(message_id)
                    .build()) \
                .build()
            
            response = client.im.v1.message.create(request)
            
            if response.code == 0:
                logger.info(f"✅ 已回复飞书消息: {text[:50]}...")
            else:
                logger.error(f"❌ 回复飞书消息失败: {response.msg}")
                
        except Exception as e:
            logger.error(f"❌ 回复飞书消息异常: {e}")
    
    def reply_image(self, chat_id: str, message_id: str, image_path: str) -> None:
        """发送图片到飞书（先上传再发送）"""
        try:
            client = lark.Client.builder() \
                .app_id(LARK_APP_ID) \
                .app_secret(LARK_APP_SECRET) \
                .log_level(lark.LogLevel.INFO) \
                .build()
            
            # 上传图片获取 image_key - image 字段需要是文件句柄 (io.IOBase)
            import lark_oapi.api.im.v1 as im_v1
            
            with open(image_path, 'rb') as f:
                upload_request = im_v1.CreateImageRequest.builder() \
                    .request_body(im_v1.CreateImageRequestBody.builder()
                        .image_type("message")
                        .image(f)
                        .build()) \
                    .build()
                
                upload_response = client.im.v1.image.create(upload_request)
            
            if upload_response.code != 0:
                logger.error(f"❌ 上传图片失败: {upload_response.msg}")
                return
            
            image_key = upload_response.data.image_key
            logger.info(f"✅ 图片上传成功, image_key: {image_key}")
            
            # 发送图片消息 - 使用不同的 uuid 避免和文本消息冲突
            content = json.dumps({"image_key": image_key}, ensure_ascii=False)
            img_uuid = f"{message_id}_img"
            
            send_request = CreateMessageRequest.builder() \
                .receive_id_type("chat_id") \
                .request_body(CreateMessageRequestBody.builder()
                    .receive_id(chat_id)
                    .msg_type("image")
                    .content(content)
                    .uuid(img_uuid)
                    .build()) \
                .build()
            
            response = client.im.v1.message.create(send_request)
            
            if response.code == 0:
                logger.info(f"✅ 图片已发送到飞书")
            else:
                logger.error(f"❌ 发送图片失败: {response.msg}")
                
        except Exception as e:
            logger.error(f"❌ 发送图片异常: {e}")

# ===================== 飞书事件处理器 =====================
# 全局缓存 IntegratedCommandProcessor 实例，避免每次消息都重新创建
_global_command_processor = None
_global_command_processor_lock = threading.Lock()

def _get_command_processor(manager):
    """获取或创建全局 IntegratedCommandProcessor 实例（线程安全）"""
    global _global_command_processor
    with _global_command_processor_lock:
        if _global_command_processor is None:
            _global_command_processor = IntegratedCommandProcessor(manager)
        return _global_command_processor

def do_p2_im_message_receive_v1(data: lark.im.v1.P2ImMessageReceiveV1) -> None:
    """飞书消息接收事件处理"""
    logger.info(f'[消息接收] 事件ID: {data.header.event_id}')
    logger.info(f'[消息接收] 时间戳: {data.header.create_time}')
    
    try:
        # 使用单例管理器获取处理器
        manager = PaykkaSystemManager()
        # 修复：复用全局 IntegratedCommandProcessor 实例，避免每次消息都重新创建
        command_processor = _get_command_processor(manager)
        
        bot_handler = LarkBotHandler(command_processor)
        bot_handler.handle_message(data)
    except Exception as e:
        logger.error(f"❌ 处理飞书消息时出错: {e}")

def do_customized_event(data: lark.CustomizedEvent) -> None:
    """自定义事件处理"""
    logger.info(f'[自定义事件] 事件类型: {data.event.type}')
    logger.info(f'[自定义事件] 请求ID: {data.header.request_id}')

# ===================== 主程序入口 =====================
def start_lark_bot():
    """启动飞书机器人"""
    try:
        logger.info("🤖 启动飞书机器人...")
        
        # 创建事件处理器
        event_handler = lark.EventDispatcherHandler.builder(
            LARK_ENCRYPT_KEY,
            LARK_VERIFICATION_TOKEN
        ) \
        .register_p2_im_message_receive_v1(do_p2_im_message_receive_v1) \
        .register_p1_customized_event("message", do_customized_event) \
        .build()
        
        # 创建WebSocket客户端
        client = lark.ws.Client(
            LARK_APP_ID,
            LARK_APP_SECRET,
            event_handler=event_handler,
            log_level=lark.LogLevel.INFO
        )
        
        # 启动客户端
        client.start()
        
    except Exception as e:
        logger.error(f"❌ 飞书机器人启动失败: {e}")

def start_lark_bot_in_background():
    """在后台启动飞书机器人"""
    def run_bot():
        start_lark_bot()
    
    # 在新线程中启动机器人
    bot_thread = threading.Thread(target=run_bot, daemon=True, name="LarkBotThread")
    bot_thread.start()
    return bot_thread

# ===================== 交互式命令行 =====================
def interactive_command_line():
    """交互式命令行界面（用于测试）- 使用单例，避免重复登录"""
    print("\n" + "="*60)
    print("PAYKKA集成控制系统 - 命令行模式")
    print("="*60)
    print("注意：使用已登录的全局配置器，不会重复登录")
    print("输入'退出'或'exit'结束程序")
    print("输入'帮助'查看可用指令")
    print("="*60)
    
    try:
        # 使用单例管理器获取处理器
        manager = PaykkaSystemManager()
        command_processor = IntegratedCommandProcessor(manager)
        
        while True:
            try:
                user_input = input("\n请输入指令: ").strip()
                
                if user_input.lower() in ["退出", "exit", "quit"]:
                    print("👋 再见！")
                    break
                
                if not user_input:
                    continue
                
                # 处理指令
                response = command_processor.process(user_input)
                print(f"\n🤖 系统回复:\n{response}")
                
            except KeyboardInterrupt:
                print("\n👋 程序被用户中断")
                break
            except Exception as e:
                print(f"❌ 错误: {e}")
    except Exception as e:
        print(f"❌ 初始化失败: {e}")

# ===================== 主程序 =====================
async def main():
    """主函数 - 直接启动混合模式（增强版，无健康监控）"""
    print("="*70)
    print("🚀 PAYKKA集成控制系统 - 混合模式（增强版）")
    print("="*70)
    print("🔐 功能: 汇差配置 + 路由配置 + 余额查询 + 换汇交易监控 + PAYKKA-XT汇率监控")
    print("🔄 增强: 全局自动重连 + Token自动刷新")
    print("📱 接口: 飞书机器人 + 命令行交互")
    print("🔧 特性: 消息去重 + 企业微信群通知 + GitHub同步")
    print("="*70)
    
    try:
        # 初始化单例管理器（全局自动登录一次）
        manager = PaykkaSystemManager()
        
        # 全局登录
        print("🔐 全局自动登录中...")
        token = await manager.login()
        if not token:
            print("❌ 全局登录失败，请检查凭据")
            return
        
        print(f"✅ 全局登录成功，Token长度: {len(token)}")

        if manager._token_refresh_thread and manager._token_refresh_thread.is_alive():
            print("✅ Token自动刷新任务已成功启动")
            print(f"下次刷新时间: 13:00 和 01:00")
        else:
            print("❌ Token自动刷新任务启动失败")
            print("尝试手动启动自动刷新任务...")
            manager._start_token_auto_refresh()

        # 计算并显示下次刷新时间
        try:
            next_refresh_time = manager._calculate_next_refresh_time()
            hours_left = (next_refresh_time - datetime.now()).total_seconds() / 3600
            print(f"⏳ 下次自动刷新: {next_refresh_time.strftime('%Y-%m-%d %H:%M:%S')} ({hours_left:.1f}小时后)")
        except:
            pass
        
        # 预加载配置器
        print("🔧 初始化配置器...")
        forex_config = manager.get_forex_configurator()
        routing_config = manager.get_routing_configurator()
        balance_query = manager.get_balance_query()
        fx_monitor = manager.get_fx_transaction_monitor()
        rate_monitor = manager.get_rate_monitor()
        exchange_rate_monitor = manager.get_exchange_rate_monitor()  # 新增
        routing_scheduler = manager.get_routing_scheduler()

        print(f"✅ 汇差配置器初始化: {'成功' if forex_config else '失败'}")
        print(f"✅ 路由配置器初始化: {'成功' if routing_config else '失败'}")
        print(f"✅ 余额查询器初始化: {'成功' if balance_query else '失败'}")
        print(f"✅ 换汇监控器初始化: {'成功' if fx_monitor else '失败'}")
        print(f"✅ 汇率监控器初始化: {'成功' if rate_monitor else '失败'}")
        print(f"✅ 路由价格监控器初始化: {'成功' if exchange_rate_monitor else '失败'}")  # 新增
        print(f"✅ 路由调度器初始化: {'成功' if routing_scheduler else '失败'}")
        
        # 检查XT脚本
        if os.path.exists(XT_SCRIPT):
            print(f"✅ XT查询脚本存在: {XT_SCRIPT}")
        else:
            print(f"⚠️  XT查询脚本不存在: {XT_SCRIPT}")
            print(f"   汇率监控功能需要 {XT_SCRIPT} 文件")
        
        # 启动飞书机器人
        print("\n🤖 启动飞书机器人...")
        bot_thread = start_lark_bot_in_background()
        print("✅ 飞书机器人已启动，等待消息...")
        print("💻 命令行交互模式已就绪")
        
        print("\n" + "="*70)
        print("🔄 新增自动重连功能:")
        print("  - Token过期自动刷新（检测错误码010112/401/403）")
        print("  - 网络异常自动重试（最多2次）")
        print("  - Token过期自动重新登录")
        print("  - 指令执行失败自动恢复")
        print("="*70)
        
        # 启动命令行交互
        interactive_command_line()
        
    except Exception as e:
        print(f"❌ 系统启动失败: {e}")
        import traceback
        traceback.print_exc()

if __name__ == '__main__':
    # 检查依赖
    try:
        import lark_oapi
        import playwright
        import pyotp
        from github import Github
        import pandas as pd
        import asyncio
    except ImportError as e:
        print(f"❌ 缺少依赖: {str(e)}")
        print("请安装以下依赖:")
        print("pip install lark-oapi playwright pyotp PyGithub pandas")
        print("安装后运行: playwright install chromium")
        exit(1)
    
    # 检查XT脚本
    if not os.path.exists(XT_SCRIPT):
        print(f"⚠️  警告: XT查询脚本 {XT_SCRIPT} 不存在")
        print("汇率监控功能需要此脚本，请确保 xt_rateV3.py 文件在当前目录")
        print("您仍然可以使用其他功能")
    
    asyncio.run(main())  # 使用asyncio.run运行异步main函数