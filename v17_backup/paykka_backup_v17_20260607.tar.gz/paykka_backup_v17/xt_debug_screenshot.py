import asyncio, os
from playwright.async_api import async_playwright

async def main():
    os.environ['DISPLAY'] = ':99'
    playwright = await async_playwright().start()
    browser = await playwright.chromium.launch(
        headless=False,
        args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-blink-features=AutomationControlled"],
    )
    context = await browser.new_context(
        viewport={"width": 1280, "height": 720},
        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
        locale="zh-CN",
    )
    page = await context.new_page()
    
    await page.goto("https://www.xtransfer.cn/login", timeout=30000, wait_until="networkidle")
    await asyncio.sleep(3)
    
    # 截图
    await page.screenshot(path="/workspace/xt_login_page.png", full_page=True)
    print(f"截图已保存")
    print(f"URL: {page.url}")
    print(f"Title: {await page.title()}")
    
    # 列出所有可见按钮
    buttons = await page.query_selector_all("button")
    print(f"找到 {len(buttons)} 个 button 元素:")
    for i, btn in enumerate(buttons):
        try:
            text = await btn.inner_text()
            visible = await btn.is_visible()
            print(f"  [{i}] visible={visible} text='{text}'")
        except:
            pass
    
    # 列出所有 input 元素
    inputs = await page.query_selector_all("input")
    print(f"找到 {len(inputs)} 个 input 元素:")
    for i, inp in enumerate(inputs):
        try:
            pid = await inp.get_attribute("id")
            ptype = await inp.get_attribute("type")
            placeholder = await inp.get_attribute("placeholder")
            visible = await inp.is_visible()
            print(f"  [{i}] visible={visible} id='{pid}' type='{ptype}' placeholder='{placeholder}'")
        except:
            pass
    
    # 页面 HTML 结构
    html = await page.content()
    # 搜索关键元素
    for keyword in ['Password', 'Login', 'login', 'button', 'submit', '手机', '密码']:
        count = html.count(keyword)
        if count > 0:
            print(f"HTML 含 '{keyword}': {count} 处")
    
    await browser.close()

asyncio.run(main())
