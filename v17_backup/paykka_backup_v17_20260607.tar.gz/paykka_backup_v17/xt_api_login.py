#!/usr/bin/env python3
"""XT API 直接登录尝试 - 分析登录 API 调用链"""
import requests, json, os, re, time

def load_env():
    env_path = "/workspace/.env"
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, _, val = line.partition('=')
                    os.environ[key.strip()] = val.strip()

load_env()

phone = os.getenv("XT_LOGIN_PHONE", "")
password = os.getenv("XT_LOGIN_PASSWORD", "")

if not phone or not password:
    print("❌ 未配置 XT 凭据")
    exit(1)

session = requests.Session()

# 先获取 XSRF token 和 server_grant_id
print("Step 1: 获取 XSRF token...")
resp = session.get("https://www.xtransfer.cn/login", headers={
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
})
xsrf = ""
for c in session.cookies:
    if 'XSRF' in c.name.upper():
        xsrf = c.value
        print(f"  XSRF Token: {xsrf}")

base_headers = {
    "accept": "application/json",
    "x-xsrf-token": xsrf,
    "x-language": "CN",
    "origin": "https://www.xtransfer.cn",
    "referer": "https://www.xtransfer.cn/login",
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
}

# Step 2: 获取 public key (用于密码加密)
print("\nStep 2: 获取公钥...")
resp = session.get(
    "https://api.xtransfer.cn/api/v1/user-front/publickey",
    headers=base_headers
)
print(f"  HTTP {resp.status_code}: {resp.text[:200]}")

# Step 3: 获取 flow-id
print("\nStep 3: 获取登录 flow-id...")
resp = session.get(
    "https://api.xtransfer.cn/api/v1/user-login-front/flow-id/cross-site-sign-in-v2",
    headers=base_headers
)
print(f"  HTTP {resp.status_code}: {resp.text[:200]}")

# Step 4: 检查登录信息
print("\nStep 4: 获取登录信息...")
resp = session.get(
    "https://api.xtransfer.cn/api/v1/user-login-front/login-info",
    headers=base_headers
)
print(f"  HTTP {resp.status_code}: {resp.text[:300]}")

# Step 5: 尝试密码登录（可能需要 CAPTCHA）
print("\nStep 5: 尝试密码登录...")
# XT 使用 RSA 加密密码，需要公钥
# 先看看 login-info 中有没有公钥信息
login_info = resp.json() if resp.status_code == 200 else {}

# 获取 area code
print("\nStep 5a: 获取 area code...")
resp = session.get(
    "https://api.xtransfer.cn/api/v1/user-front/area-code/last-sign-in-area-code",
    headers=base_headers
)
print(f"  HTTP {resp.status_code}: {resp.text[:200]}")

area_code_data = resp.json() if resp.status_code == 200 else {}
area_code = area_code_data.get("data", {}).get("areaCode", "86") if area_code_data.get("code") == 0 else "86"
print(f"  Area code: {area_code}")

# 尝试 sign-in
print("\nStep 5b: 发送登录请求...")
# XT 可能使用 RSA 加密，先获取 publicKey
pubkey_resp = session.get(
    "https://api.xtransfer.cn/api/v1/user-front/publickey",
    headers=base_headers
)
pubkey_data = pubkey_resp.json() if pubkey_resp.status_code == 200 else {}
public_key = pubkey_data.get("data", {}).get("publicKey", "")
print(f"  Public key (first 80): {public_key[:80]}...")

# 用公钥加密密码
import base64
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding

try:
    # 加载公钥
    from cryptography.hazmat.primitives.serialization import load_der_public_key
    key_bytes = base64.b64decode(public_key)
    pub_key = load_der_public_key(key_bytes)
    
    encrypted = pub_key.encrypt(
        password.encode('utf-8'),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    encrypted_pwd = base64.b64encode(encrypted).decode()
    print(f"  加密后密码: {encrypted_pwd[:50]}...")
except Exception as e:
    print(f"  密码加密失败: {e}")
    encrypted_pwd = password

# 登录请求
login_payload = {
    "areaCode": area_code,
    "mobile": phone,
    "password": encrypted_pwd,
    "targetSite": "FUND",
    "needCrossSite": True,
}

resp = session.post(
    "https://api.xtransfer.cn/api/v1/user-login-front/cross-site-sign-in-v2",
    json=login_payload,
    headers=base_headers
)
print(f"  HTTP {resp.status_code}")
print(f"  Response: {resp.text[:500]}")

# 检查 cookies
print("\nStep 6: 检查返回的 cookies...")
for c in session.cookies:
    if any(kw in c.name.lower() for kw in ['token', 'jwt', 'auth', 'dx', 'server']):
        print(f"  {c.name}: {c.value[:60]}...")

print("\n全部 cookies:")
for c in session.cookies:
    print(f"  {c.name}: {c.value[:40]}...")
