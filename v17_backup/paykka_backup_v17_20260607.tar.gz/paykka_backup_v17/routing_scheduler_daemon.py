#!/usr/bin/env python3
# ===================== 路由调度器独立启动脚本 =====================
# 基于 V17 模块化版本
# 功能：从GitHub读取routing_schedule.md配置，按定时规则自动切换货币对路由

import sys
import os
import time
import logging
from logging.handlers import RotatingFileHandler

# 确保可以导入 paykka 模块
sys.path.insert(0, '/workspace')

# 配置日志
LOG_DIR = '/workspace/logs'
os.makedirs(LOG_DIR, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[
        RotatingFileHandler(
            os.path.join(LOG_DIR, 'routing_scheduler.log'),
            maxBytes=5*1024*1024,
            backupCount=5,
            encoding='utf-8'
        ),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('RoutingSchedulerDaemon')

from paykka_core import PaykkaSystemManager
from paykka_routing_sched import RoutingScheduler

def main():
    logger.info("=" * 60)
    logger.info("🚀 启动路由调度器...")
    logger.info("=" * 60)
    
    # 1. 初始化系统管理器并登录
    manager = PaykkaSystemManager()
    token = manager.get_token()
    
    if not token:
        logger.error("❌ 无法获取Token，登录失败，退出")
        sys.exit(1)
    
    logger.info(f"✅ Token获取成功 (前8位: {token[:8]}...)")
    
    # 2. 初始化路由调度器
    scheduler = RoutingScheduler(token)
    logger.info("✅ 路由调度器初始化完成")
    
    # 3. 启动
    result = scheduler.start()
    logger.info(result)
    
    if not scheduler.is_running:
        logger.error("❌ 路由调度器启动失败")
        sys.exit(1)
    
    # 4. 打印初始状态
    status = scheduler.get_status_detail()
    logger.info(f"📊 调度器状态:\n{status}")
    
    logger.info("✅ 路由调度器已成功启动，后台运行中...")
    logger.info("📝 日志文件: /workspace/logs/routing_scheduler.log")
    
    # 保持进程运行
    try:
        while scheduler.is_running:
            time.sleep(60)
    except KeyboardInterrupt:
        logger.info("🛑 收到中断信号，停止路由调度器...")
        scheduler.stop()
        logger.info("✅ 路由调度器已停止")

if __name__ == '__main__':
    main()
